# infra/simulation/swi_simulator.py
import json
import time
import random
import hashlib

class SWISimulator:
    """
    Minimal Working Prototype for SWI Distributed Governance.
    Simulates a client node watching for reality drift.
    """
    def __init__(self, node_id):
        self.node_id = node_id
        self.local_tick = 0
        self.state_hash = "GENESIS"

    def calculate_drift(self):
        # Simulate environmental noise
        return random.random() * 0.15

    def generate_proof(self, data):
        self.local_tick += 1
        payload = {
            "node_id": self.node_id,
            "logicalTick": self.local_tick,
            "data": data,
            "driftScore": self.calculate_drift()
        }
        
        # Cryptographic link
        serialized = json.dumps(payload, sort_keys=True)
        new_hash = hashlib.sha256((self.state_hash + serialized).encode()).hexdigest()
        self.state_hash = new_hash
        
        return payload, new_hash

    def run(self, cycles=10):
        print(f"🚀 [SWI SIM] Starting Node: {self.node_id}")
        for i in range(cycles):
            proof, state = self.generate_proof({"action": "HEARTBEAT", "val": random.randint(0, 100)})
            print(f"Tick {proof['logicalTick']} | Drift: {proof['driftScore']:.4f} | State: {state[:12]}...")
            time.sleep(1)

if __name__ == "__main__":
    sim = SWISimulator("SIM_NODE_01")
    sim.run()
