#!/bin/bash
echo "====================================================="
echo "  Structured Workflow Intelligence (SWI) V1.01"
echo "  Research Prototype Launcher"
echo "====================================================="
echo ""

echo "[1] Checking Node.js..."
if ! command -v node &> /dev/null
then
    echo "ERROR: Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org"
    exit 1
else
    echo "✓ Node.js detected"
fi

echo ""
echo "[2] Installing dependencies (first time only)..."
npm install

echo ""
echo "[3] Starting SWI V1.01..."
echo ""
echo "The dashboard should open automatically in your browser."
echo "If it doesn't, open http://localhost:3000 manually."
echo ""

npm run dev
