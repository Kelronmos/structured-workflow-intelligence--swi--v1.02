import fs from 'fs';
import path from 'path';

const files = {
  'swi-rust-monorepo/docker-compose.yml': `version: '3.9'

services:

  kernel:
    build: ./apps/kernel
    ports:
      - "7000:7000"
    depends_on:
      - consensus
      - audit

  consensus:
    build: ./services/consensus
    ports:
      - "7100:7100"

  audit:
    build: ./services/audit
    ports:
      - "7200:7200"

  verifier:
    build: ./apps/verifier
    ports:
      - "7300:7300"

  simulator:
    build: ./apps/simulator
    ports:
      - "7400:7400"

  dashboard:
    build: ./dashboard
    ports:
      - "3000:3000"

  opa:
    image: openpolicyagent/opa
    command:
      - "run"
      - "--server"
      - "/policy/policy.rego"
    volumes:
      - ./services/policy:/policy
    ports:
      - "8181:8181"`,
  'swi-rust-monorepo/Makefile': `build:
\tdocker compose build

up:
\tdocker compose up

down:
\tdocker compose down

logs:
\tdocker compose logs -f`,
  'swi-rust-monorepo/README.md': `# SWI FULL GITHUB MONOREPO

This is a real production-oriented scaffold for a local runnable SWI stack with:
* Rust services
* Docker Compose cluster
* OPA + SPIFFE placeholders
* HotStuff service skeleton
* Merkle audit runtime
* Chaos simulator
* Attack dashboard UI
* zk verifier service wiring`,
  'swi-rust-monorepo/apps/kernel/src/main.rs': `use axum::{routing::get, Router};

async fn health() -> &'static str {
    "SWI Kernel Online"
}

#[tokio::main]
async fn main() {
    println!("[SWI] Kernel boot");

    let app = Router::new()
        .route("/health", get(health));

    let listener =
        tokio::net::TcpListener::bind("0.0.0.0:7000")
            .await
            .unwrap();

    axum::serve(listener, app)
        .await
        .unwrap();
}`,
  'swi-rust-monorepo/apps/kernel/Cargo.toml': `[package]
name = "kernel"
version = "0.1.0"
edition = "2021"

[dependencies]
tokio = { version = "1", features = ["full"] }
axum = "0.7"`,
  'swi-rust-monorepo/services/consensus/src/main.rs': `#[derive(Clone)]
struct Block {
    height: u64,
    hash: String,
}

fn validate_quorum(votes: usize, f: usize) -> bool {
    votes >= (2 * f + 1)
}

fn main() {
    println!("[CONSENSUS] HotStuff service started");
    let valid = validate_quorum(3, 1);
    println!("Quorum valid: {}", valid);
}`,
  'swi-rust-monorepo/services/consensus/Cargo.toml': `[package]
name = "consensus"
version = "0.1.0"
edition = "2021"

[dependencies]`,
  'swi-rust-monorepo/services/audit/src/main.rs': `use sha2::{Digest, Sha256};

fn hash_event(event: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(event);
    format!("{:x}", hasher.finalize())
}

fn main() {
    let event = "kernel_boot";
    let hash = hash_event(event);

    println!("[AUDIT]");
    println!("EVENT={}", event);
    println!("HASH={}", hash);
}`,
  'swi-rust-monorepo/services/audit/Cargo.toml': `[package]
name = "audit"
version = "0.1.0"
edition = "2021"

[dependencies]
sha2 = "0.10"`,
  'swi-rust-monorepo/apps/simulator/src/main.rs': `fn main() {
    println!("[CHAOS]");
    println!("Injecting partition fault");

    println!("[ATTACK]");
    println!("Spoofed identity detected");

    println!("[RECOVERY]");
    println!("Leader re-election triggered");
}`,
  'swi-rust-monorepo/apps/simulator/Cargo.toml': `[package]
name = "simulator"
version = "0.1.0"
edition = "2021"

[dependencies]`,
  'swi-rust-monorepo/apps/verifier/src/main.rs': `fn main() {
    println!("[VERIFIER] zk-SNARK verifier ready");
}`,
  'swi-rust-monorepo/apps/verifier/Cargo.toml': `[package]
name = "verifier"
version = "0.1.0"
edition = "2021"

[dependencies]`,
  'swi-rust-monorepo/zk/circuits/swi_transition.circom': `pragma circom 2.0.0;

template SWITransition() {
    signal input identity_valid;
    signal input policy_pass;
    signal input risk;

    signal output valid;

    valid <== identity_valid * policy_pass;
}

component main = SWITransition();`,
  'swi-rust-monorepo/services/policy/policy.rego': `package swi.authz

default allow = false

allow {
  input.identity == "trusted"
  input.risk <= 10
}`,
  'swi-rust-monorepo/dashboard/src/App.tsx': `export default function App() {
  const events = [
    "Kernel boot",
    "Consensus established",
    "Partition detected",
    "Recovery triggered"
  ];

  return (
    <div style={{ padding: 20 }}>
      <h1>SWI Control Dashboard</h1>
      {events.map((e, i) => (
        <div key={i}>
          • {e}
        </div>
      ))}
    </div>
  );
}`,
  'swi-rust-monorepo/dashboard/package.json': `{
  "name": "swi-dashboard",
  "private": true,
  "scripts": {
    "dev": "vite",
    "build": "vite build"
  },
  "dependencies": {
    "react": "^18.3.0",
    "react-dom": "^18.3.0"
  },
  "devDependencies": {
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.0.0"
  }
}`
};

for (const [filepath, content] of Object.entries(files)) {
  const absolutePath = path.resolve(process.cwd(), filepath);
  fs.mkdirSync(path.dirname(absolutePath), { recursive: true });
  fs.writeFileSync(absolutePath, content, 'utf8');
}
console.log('Successfully created scaffold in swi-rust-monorepo/');
