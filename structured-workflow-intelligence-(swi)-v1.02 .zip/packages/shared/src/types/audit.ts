export type AuditEventType =
  | "DECISION_EVALUATED"
  | "POLICY_APPLIED"
  | "DRIFT_DETECTED"
  | "BOOT_VERIFIED"
  | "SIGNATURE_CHECK";

export interface AuditEvent {
  id: string;
  type: AuditEventType;
  timestamp: number;
  actor: "SYSTEM" | "HUMAN";
  refId: string;
  payload: Record<string, any>;
  prevHash: string;
  hash: string;
}

export interface AuditBlock {
  index: number;
  timestamp: number;
  eventId: string;
  eventType: string;
  sourceNode: string;
  payloadHash: string;
  previousHash: string;
  stateRoot: string;
  blsSignature: string;
  consensus: {
    approved: number;
    rejected: number;
    quorum: number;
    result: "APPROVED" | "REJECTED" | "PENDING";
    strength?: "STRONG" | "WEAK" | "DISPUTED";
  };
  causalPath?: string[];
  nonce: number;
  hash: string;
}
