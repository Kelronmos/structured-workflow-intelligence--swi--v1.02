export interface GovernanceEvidence {
  evidenceId: string;
  source: string;
  timestamp: number;
  confidence: number;
  integrityHash: string;
}

export interface TraceEvidence {
  hash: string;
  signature: string;
  signer: string;
  timestamp: number;
}
