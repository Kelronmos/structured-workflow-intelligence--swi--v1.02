export type PolicyEffect = "ALLOW" | "DENY" | "REQUIRE_HUMAN" | "REVIEW";

export interface PolicyRule {
  id: string;
  priority: number; // higher wins
  effect: PolicyEffect;
  conditions: {
    riskScore?: { gte?: number; lte?: number };
    confidence?: { gte?: number; lte?: number };
    stateMatch?: string[];
    metricsMatch?: string[];
  };
  source: "SYSTEM" | "HUMAN" | "AUDIT";
}
