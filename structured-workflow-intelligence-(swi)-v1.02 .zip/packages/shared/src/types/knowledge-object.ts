export type RustState = 
  | 'Active'
  | 'Stable'
  | 'Dormant'
  | 'Rusting'
  | 'Rust'
  | 'Archived'
  | 'Reactivated';

export interface GovernanceHistoryEntry {
  timestamp: Date;
  previousState: RustState;
  newState: RustState;
  reason: string;
}

export interface KnowledgeObject {
  id: string;
  content: string;
  last_validated: Date;
  last_used: Date;
  confidence: number;
  evidence_score: number;
  governance_score: number;
  importance_score: number;
  usage_frequency: number;
  rust_factor: number;
  patina_factor: number;
  state: RustState;
  history: GovernanceHistoryEntry[];
}
