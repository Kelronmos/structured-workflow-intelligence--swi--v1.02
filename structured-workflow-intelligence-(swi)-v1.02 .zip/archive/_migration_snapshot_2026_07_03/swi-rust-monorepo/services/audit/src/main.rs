use sha2::{Digest, Sha256};

fn hash_event(event: &str) -> String {
    let mut hasher = Sha256::new();
    hasher.update(event);
    format!("{:x}", hasher.finalize())
}

fn main() {
    let event = "kernel_boot";
    let hash = hash_event(event);

    println!("[AUDIT]");
    println!("EVENT={}", event);
    println!("HASH={}", hash);
}