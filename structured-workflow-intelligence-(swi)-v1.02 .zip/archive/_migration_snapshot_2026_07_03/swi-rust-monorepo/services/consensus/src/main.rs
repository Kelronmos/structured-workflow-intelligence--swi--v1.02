#[derive(Clone)]
struct Block {
    height: u64,
    hash: String,
}

fn validate_quorum(votes: usize, f: usize) -> bool {
    votes >= (2 * f + 1)
}

fn main() {
    println!("[CONSENSUS] HotStuff service started");
    let valid = validate_quorum(3, 1);
    println!("Quorum valid: {}", valid);
}