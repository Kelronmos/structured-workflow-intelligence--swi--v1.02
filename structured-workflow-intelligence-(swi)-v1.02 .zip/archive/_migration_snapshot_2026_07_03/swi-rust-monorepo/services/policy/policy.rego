package swi.authz

default allow = false

allow {
  input.identity == "trusted"
  input.risk <= 10
}