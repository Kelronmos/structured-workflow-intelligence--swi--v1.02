fn main() {
    println!("[CHAOS]");
    println!("Injecting partition fault");

    println!("[ATTACK]");
    println!("Spoofed identity detected");

    println!("[RECOVERY]");
    println!("Leader re-election triggered");
}