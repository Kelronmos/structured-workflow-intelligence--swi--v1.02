use axum::{routing::get, Router};

async fn health() -> &'static str {
    "SWI Kernel Online"
}

#[tokio::main]
async fn main() {
    println!("[SWI] Kernel boot");

    let app = Router::new()
        .route("/health", get(health));

    let listener =
        tokio::net::TcpListener::bind("0.0.0.0:7000")
            .await
            .unwrap();

    axum::serve(listener, app)
        .await
        .unwrap();
}