pragma circom 2.0.0;

template SWITransition() {
    signal input identity_valid;
    signal input policy_pass;
    signal input risk;

    signal output valid;

    valid <== identity_valid * policy_pass;
}

component main = SWITransition();