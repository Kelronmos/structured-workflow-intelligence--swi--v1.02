# SWI FULL GITHUB MONOREPO

This is a real production-oriented scaffold for a local runnable SWI stack with:
* Rust services
* Docker Compose cluster
* OPA + SPIFFE placeholders
* HotStuff service skeleton
* Merkle audit runtime
* Chaos simulator
* Attack dashboard UI
* zk verifier service wiring