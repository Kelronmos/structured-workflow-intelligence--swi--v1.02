use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub enum TraceEventType {
    ZkProofGenerated,
    ZkProofVerified,
    SignatureVerified,
    MerkleProofVerified,
    PbftVoteCast,
    PbftCommit,
    StateTransition,
    VerificationFailed,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct TraceEvent {
    pub event_type: TraceEventType,
    pub timestamp: u64,
    pub module: String,
    pub tx_id: Option<String>,
    pub result: bool,
    pub proof_hash: Option<String>,
    pub public_inputs_hash: Option<String>,
    pub trace_id: String,
    pub parent_trace: String,
}

pub struct TracerState {
    pub last_hash: String,
    pub log: Vec<TraceEvent>,
}

impl TracerState {
    pub fn new() -> Self {
        Self {
            last_hash: vec![0u8; 32].iter().map(|b| format!("{:02x}", b)).collect::<String>(),
            log: Vec::new(),
        }
    }
}

lazy_static::lazy_static! {
    static ref TRACER_STATE: Mutex<TracerState> = Mutex::new(TracerState::new());
}

pub struct CryptoTracer;

impl CryptoTracer {
    pub fn log(
        event_type: TraceEventType,
        module: &str,
        tx_id: Option<&str>,
        result: bool,
        proof_hash: Option<&str>,
        public_inputs_hash: Option<&str>,
    ) -> TraceEvent {
        let mut state = TRACER_STATE.lock().unwrap();
        
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis() as u64;
            
        let trace_id = format!("trace-{}", timestamp);
        
        let event = TraceEvent {
            event_type,
            timestamp,
            module: module.to_string(),
            tx_id: tx_id.map(|s| s.to_string()),
            result,
            proof_hash: proof_hash.map(|s| s.to_string()),
            public_inputs_hash: public_inputs_hash.map(|s| s.to_string()),
            trace_id,
            parent_trace: state.last_hash.clone(),
        };

        // Hash chain logic
        let event_json = serde_json::to_string(&event).unwrap();
        let mut hasher = Sha256::new();
        hasher.update(event_json.as_bytes());
        hasher.update(state.last_hash.as_bytes());
        state.last_hash = hex::encode(hasher.finalize());
        
        state.log.push(event.clone());
        
        event
    }
}
