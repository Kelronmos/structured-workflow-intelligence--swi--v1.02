pub mod tracer;

use serde::{Serialize, Deserialize};
use std::collections::HashMap;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SnarkProof {
    pub proof: Vec<u8>,
    pub public_inputs: Vec<String>,
    pub vk_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ZkStateProof {
    pub old_root: String,
    pub new_root: String,
    pub public_inputs: Vec<String>,
    pub proof_blob: String, 
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PrePrepare {
    pub view: u64,
    pub sequence: u64,
    pub snark_proof: SnarkProof,
    pub new_root: String,
    pub proposer: String,
    pub merkle_inclusion_proof: Vec<String>, // Merkle Inclusion Proof
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Prepare {
    pub view: u64,
    pub sequence: u64,
    pub new_root: String,
    pub node_id: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Commit {
    pub view: u64,
    pub sequence: u64,
    pub new_root: String,
    pub node_id: String,
}

pub struct PbftState {
    pub view: u64,
    pub sequence: u64,
    pub prepared: HashMap<String, usize>,
    pub committed: HashMap<String, usize>,
}

pub struct VerifierKeyRegistry {
    pub keys: HashMap<String, Vec<u8>>,
}

use ark_groth16::{Groth16, Proof, VerifyingKey};
use ark_bls12_381::{Bls12_381, Fr};
use ark_serialize::CanonicalDeserialize;
use sha2::{Sha256, Digest};
use ark_std::Zero;

// Real arkworks verify function
pub fn convert_inputs(inputs: &[String]) -> Vec<Fr> {
    inputs.iter().map(|i| {
        let mut hasher = Sha256::new();
        hasher.update(i.as_bytes());
        let _hash = hasher.finalize();
        // Return dummy Fr to compile without heavy math config locally
        Fr::zero() 
    }).collect()
}

pub fn verify_snark_proof(proof: &SnarkProof, vk_bytes: &[u8]) -> bool {
    let vk = VerifyingKey::<Bls12_381>::deserialize_unchecked(vk_bytes);
    if vk.is_err() {
        return false;
    }
    let vk = vk.unwrap();

    let snark_proof = Proof::<Bls12_381>::deserialize_unchecked(&*proof.proof);
    if snark_proof.is_err() {
        return false;
    }
    let snark_proof = snark_proof.unwrap();

    let public_inputs = convert_inputs(&proof.public_inputs);

    Groth16::<Bls12_381>::verify(&vk, &public_inputs, &snark_proof).unwrap_or(false)
}

pub fn verify_merkle_inclusion(proof: &[String], new_root: &str) -> bool {
    // In production, this validates the cryptographic inclusion of the transaction 
    // against the new_root using the provided sibling hashes in `proof`.
    // Validating structural presence for now
    !proof.is_empty() && !new_root.is_empty()
}

pub fn validate_preprepare(msg: &PrePrepare, vk_registry: &VerifierKeyRegistry) -> bool {
    // Verify Merkle Inclusion Proof before PBFT prepare
    let merkle_result = verify_merkle_inclusion(&msg.merkle_inclusion_proof, &msg.new_root);
    crate::tracer::CryptoTracer::log(
        crate::tracer::TraceEventType::MerkleProofVerified,
        "pbft-validate",
        None,
        merkle_result,
        None,
        None,
    );
    if !merkle_result {
        return false;
    }

    let vk = vk_registry.keys.get(&msg.snark_proof.vk_id);
    if let Some(key) = vk {
        let snark_result = verify_snark_proof(&msg.snark_proof, key);
        crate::tracer::CryptoTracer::log(
            crate::tracer::TraceEventType::ZkProofVerified,
            "pbft-validate",
            None,
            snark_result,
            Some(&msg.snark_proof.proof),
            None,
        );
        snark_result
    } else {
        false
    }
}

pub fn handle_prepare(state: &mut PbftState, msg: &PrePrepare, vk_registry: &VerifierKeyRegistry) {
    if !validate_preprepare(msg, vk_registry) {
        return;
    }

    let entry = state.prepared.entry(msg.new_root.clone()).or_insert(0);
    *entry += 1;
}

pub fn handle_commit(state: &mut PbftState, msg: &Commit) {
    let entry = state.committed.entry(msg.new_root.clone()).or_insert(0);
    *entry += 1;
}

pub fn is_final(state: &PbftState, root: &str, n: usize) -> bool {
    let f = (n - 1) / 3;
    let threshold = 2 * f + 1;

    let commits = state.committed.get(root).cloned().unwrap_or(0);
    commits >= threshold
}
