export default function App() {
  const events = [
    "Kernel boot",
    "Consensus established",
    "Partition detected",
    "Recovery triggered"
  ];

  return (
    <div style={{ padding: 20 }}>
      <h1>SWI Control Dashboard</h1>
      {events.map((e, i) => (
        <div key={i}>
          • {e}
        </div>
      ))}
    </div>
  );
}