export default function MerkleViewer({ root }: { root: string }) {
  return (
    <div>
      <h2>Merkle Root</h2>
      <p>{root}</p>
    </div>
  );
}
