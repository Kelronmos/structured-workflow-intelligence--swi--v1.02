import { sign } from "../crypto/signer";

export default function SigningPanel() {
  function handleSign() {
    try {
      const signature = sign("test-data");
      alert(signature);
    } catch (e: unknown) {
      const message = e instanceof Error ? e.message : String(e);
      alert("Error signing: " + message);
    }
  }

  return (
    <div>
      <button onClick={handleSign}>Sign Data</button>
    </div>
  );
}
