// swi-core/EventLedger.ts
import { EventStreamEngine } from "./kernel/EventStreamEngine";
import { MerkleLedger } from "./infrastructure/MerkleLedger";
import { UniverseEvent } from "./kernel/UniverseTypes";
import { EventEmitter } from "events";
import { SimulatedKafka } from "./infrastructure/Queue";

import { DriftScorer } from "./kernel/DriftScorer";
import { SWIContext } from "./kernel/engines/types";
import { LogicalClock } from "./kernel/LogicalClock";

import { EXECUTION_AUTHORITY_TOKEN } from "./trust/CryptoVerifyGate";

/**
 * 📜 SWI Event Ledger
 */
export class EventLedger {
  private static instance: EventLedger;
  private ledger: MerkleLedger;
  private kafka: SimulatedKafka;
  public events: EventEmitter = new EventEmitter();

  private constructor() {
    this.ledger = new MerkleLedger();
    this.kafka = SimulatedKafka.getInstance();
  }

  public static getInstance(): EventLedger {
    if (!EventLedger.instance) {
      EventLedger.instance = new EventLedger();
    }
    return EventLedger.instance;
  }

  public async ingest(
    type: string,
    payload: Record<string, unknown>,
    metadata: Record<string, unknown> = {},
    auth: symbol,
  ): Promise<UniverseEvent> {
    if (auth !== EXECUTION_AUTHORITY_TOKEN) {
      throw new Error(
        "UNAUTHORIZED_EXECUTION: CryptoVerifyGate token missing! Ingestion halted.",
      );
    }
    const event = await EventStreamEngine.ingest(type, payload, metadata);

    // Commit to Merkle Ledger
    this.ledger.append({ event }, event.hash || "SWI-CONT-v3.5");

    // Emit for downstream systems (UI, Indexers)
    this.events.emit("committed", event);

    return event;
  }

  public getChain() {
    return this.ledger.getChain();
  }

  public append(data: unknown, proof: string, auth: symbol) {
    if (auth !== EXECUTION_AUTHORITY_TOKEN) {
      throw new Error(
        "UNAUTHORIZED_EXECUTION: CryptoVerifyGate token missing! Append halted.",
      );
    }
    return this.ledger.append(data, proof);
  }

  public getInternalLedger(): MerkleLedger {
    return this.ledger;
  }

  public getRoot(): string {
    return this.ledger.getRoot();
  }

  public getLatestEvents(count: number = 50): UniverseEvent[] {
    return EventStreamEngine.getLatestEvents(count);
  }

  public calculateDrift(ctx: SWIContext) {
    return DriftScorer.calculate(ctx);
  }

  public nextTick(): number {
    return LogicalClock.nextTick();
  }

  public produce(topic: string, message: unknown) {
    return this.kafka.produce(topic, message);
  }

  public getDLQ() {
    return EventStreamEngine.getDLQ();
  }
}

// Trace.log
