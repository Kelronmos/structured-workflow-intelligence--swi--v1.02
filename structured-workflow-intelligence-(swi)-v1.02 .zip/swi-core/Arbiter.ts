// swi-core/Arbiter.ts
import { EngineDecision, Decision, ExecutionBoundaryState, SWIContext } from "./kernel/engines/types";
import { HSMSimulator } from "./infrastructure/HSM";
import { DriftScorer } from "./kernel/DriftScorer";
import { DriftReport } from "./kernel/DriftTypes";
import crypto from "crypto";

export interface GlobalConsensus {
  stabilityScore: number;
  finalDecision: Decision;
  engineReports: EngineDecision[];
  consensusReached: boolean;
  verificationState?: string;
  boundaryProof?: string;
  standing?: ExecutionBoundaryState;
  boundaryState?: string;
   driftReport?: DriftReport;
    receipt?: unknown;
   safetyReport?: Record<string, unknown>;
 }

/**
 * SWI Arbiter: Formalizing Governed Execution at the Boundary
 */
export class SWIArbiter {
  public arbitrate(decisions: EngineDecision[], ctx?: SWIContext): GlobalConsensus {
    const totalWeight = decisions.reduce((acc, d) => acc + d.resolutionWeight, 0);
    const avgWeight = totalWeight / decisions.length;
    
    // Dimensional Sync: Calculate standing geometry and check for divergence
    const { standing, divergence } = this.calculateStandingConsensus(decisions);
    
    // Detailed Drift Scoring
    let driftReport: DriftReport | undefined;
    if (ctx) {
      driftReport = DriftScorer.calculate(ctx, standing);
    }

    const allAgreed = decisions.every(d => d.admissible === decisions[0].admissible);
    const hasCriticalFault = decisions.some(d => d.reason.includes("FAULT") || d.reason.includes("COMPROMISED"));
    
    const driftValue = driftReport ? driftReport.overallScore : standing.drift;
    const hasDrift = decisions.some(d => d.reason.includes("DRIFT")) || driftValue > 0.4;
    
    // Stability Score calculation with divergence penalty
    let stabilityScore = avgWeight * 100;
    if (!allAgreed) stabilityScore -= 30;
    if (divergence > 0.2) stabilityScore -= (divergence * 40); 
    if (hasCriticalFault) stabilityScore -= 60;
    if (standing.viability < 0.5) stabilityScore -= 20;
    
    // Apply drift penalty from the Scorer
    if (driftReport) {
      stabilityScore -= (driftReport.overallScore * 50);
    } else {
      if (hasDrift) stabilityScore -= 20;
    }
    
    stabilityScore = Math.max(0, Math.min(100, stabilityScore));

    let finalDecision: Decision;
    
    if (hasCriticalFault || stabilityScore < 30) {
      finalDecision = Decision.HALT;
    } else if (stabilityScore < 50) {
      finalDecision = Decision.ESCALATE;
    } else if (!allAgreed && avgWeight > 0.7) {
      finalDecision = Decision.REDIRECT;
    } else if (hasDrift || driftValue > 0.7 || standing.burden > 0.95) {
      finalDecision = Decision.REFUSE;
    } else if (allAgreed && decisions[0].admissible && stabilityScore > 85) {
      finalDecision = Decision.EXECUTE;
    } else {
      finalDecision = Decision.REFUSE;
    }

    return {
      stabilityScore,
      finalDecision,
      engineReports: decisions,
      consensusReached: allAgreed && stabilityScore > 75,
      boundaryProof: `lawful_boundary_${crypto.createHash('sha256').update(JSON.stringify(standing)).digest('hex').substring(0, 12)}`,
      standing,
      driftReport
    };
  }

  private calculateStandingConsensus(decisions: EngineDecision[]): { standing: ExecutionBoundaryState, divergence: number } {
    const standings = decisions.map(d => d.metadata.boundary).filter(Boolean) as ExecutionBoundaryState[];
    
    if (standings.length === 0) {
      throw new Error("CRITICAL_FAILURE: Execution boundary metadata missing");
    }

    // High-Dimensional Synthesis
    const averaged: ExecutionBoundaryState = {
      authority: this.avg(standings.map(s => s.authority)),
      capacity: this.avg(standings.map(s => s.capacity)),
      burden: this.avg(standings.map(s => s.burden)),
      drift: this.avg(standings.map(s => s.drift || 0)),
      viability: this.avg(standings.map(s => s.viability)),
      evidence: standings[0].evidence,
      custody: standings[0].custody,
      continuity: Math.max(...standings.map(s => s.continuity)),
      policy: standings[0].policy,
      corridor: standings[0].corridor,
      regime: standings[0].regime
    };

    // Diversity Check: Ensure engines aren't seeing wildly different manifolds
    const divergence = this.calculateVariance(standings.map(s => s.authority)) +
                       this.calculateVariance(standings.map(s => s.viability)) +
                       this.calculateVariance(standings.map(s => s.capacity));

    return { standing: averaged, divergence };
  }

  private avg(arr: number[]): number {
    return arr.length === 0 ? 0 : arr.reduce((a, b) => a + b, 0) / arr.length;
  }

  private calculateVariance(arr: number[]): number {
    if (arr.length <= 1) return 0;
    const mean = this.avg(arr);
    return this.avg(arr.map(x => Math.pow(x - mean, 2)));
  }

  public replay(receipt: { 
    verificationState: string; 
    consensus: GlobalConsensus; 
    standing?: ExecutionBoundaryState;
    attestation?: { signature: string; attestation: string }
  }): boolean {
    console.log("REPLAY_ENGINE: Re-verifying manifold integrity...");
    
    if (receipt.verificationState === "UNVERIFIED" || !receipt.standing) return false;

    // 1. HSM Attestation Verification
    if (receipt.attestation) {
      const isValidSig = HSMSimulator.verify(receipt.attestation.signature, {
        decision: receipt.consensus.finalDecision,
        standing: receipt.standing,
        root: receipt.consensus.boundaryProof?.startsWith('chain_') ? 'prev' : 'root' // Simplified for simulation
      });
      if (!isValidSig) {
        console.error("REPLAY_FAILURE: HSM Attestation Signature mismatch");
        return false;
      }
    }

    // 2. Dimensional Constraint: EXECUTE requires high authority and low drift
    const { finalDecision, stabilityScore } = receipt.consensus;
    
    /**
     * Formal Drift Scoring Algorithm:
     * Accuracy(S) = (1 - Drift) * Viability * sqrt(Authority)
     * Rejection required if Accuracy < 0.75
     */
    if (finalDecision === Decision.EXECUTE) {
      const accuracy = (1 - receipt.standing.drift) * receipt.standing.viability * Math.sqrt(receipt.standing.authority);
      if (accuracy < 0.7) {
        console.warn(`REPLAY_FAILURE: EXECUTE path inconsistent with formal Accuracy score: ${accuracy.toFixed(4)}`);
        return false;
      }
    }

    return stabilityScore > 75;
  }
}

// Trace.log
