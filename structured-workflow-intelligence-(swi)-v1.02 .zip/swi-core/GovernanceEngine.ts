// swi-core/GovernanceEngine.ts
import { IntelligenceEngine } from './governance/IntelligenceEngine';
import { PolicyCompiler as PCC } from './ethics/PolicyCompiler';
import { PolicyCompiler as VMPolicyCompiler, SWIPolicyDefinition } from './vm/PolicyCompiler';
import { EthicalReflexController } from './ethics/EthicalReflexController';
import { EthicalDriftIndex } from './ethics/EthicalDriftIndex';
import { VectorEthicalMemory } from './ethics/VectorEthicalMemory';
import { AnticipatoryEthicsForecaster } from './ethics/AnticipatoryEthicsForecaster';
import { JoeKernel } from '../src/swi/joe';
import { DriftScorer } from './kernel/DriftScorer';
import { UniverseState, ModuleStatus } from './kernel/UniverseTypes';
import { DiagnosticEngine } from './kernel/DiagnosticEngine';
import { DriftReport } from './kernel/DriftTypes';

/**
 * ⚖️ SWI Governance Engine
 * Oversight, ethics, and policy enforcement layer.
 */
export class GovernanceEngine {
  private static instance: GovernanceEngine;

  public static getInstance(): GovernanceEngine {
    if (!GovernanceEngine.instance) {
      GovernanceEngine.instance = new GovernanceEngine();
    }
    return GovernanceEngine.instance;
  }

  public async compileEPG(rawPolicy: string) {
    return await PCC.compile(rawPolicy);
  }

  public compileVM(config: SWIPolicyDefinition) {
    return VMPolicyCompiler.compile(config);
  }

  public async processEthicalReflex(type: string, payload: { drift?: number; forceCommit?: boolean; [key: string]: unknown }) {
    const decision = await EthicalReflexController.processReflex(type, payload);
    EthicalDriftIndex.update(decision.decision !== 'BLOCK', payload.drift || 0.01);
    
    if (decision.decision !== 'BLOCK' || payload.forceCommit) {
      await VectorEthicalMemory.commit(type, decision.decision, decision.confidence);
    }

    // Auto-escalation if drift is massive
    if ((payload.drift as number || 0) > 0.5) {
        this.escalateToSupervisor("EXTREME_ETHICAL_DRIFT", payload);
    }

    return decision;
  }

  public escalateToSupervisor(reason: string, context: unknown) {
    console.error(`🚨 [GOVERNANCE] ESCALATION_TO_SUPERVISOR: ${reason}`);
    console.log(`📂 [CONTEXT]`, context);
  }

  public getMaintenanceGuide(universe: UniverseState) {
    return DiagnosticEngine.getDiagnosisReport(universe);
  }

  public getTruthMatrix(universe: UniverseState) {
    const modules = universe.modules;
    return Object.keys(modules).map(id => ({
        module: id,
        status: modules[id].status,
        confidence: modules[id].confidence,
        health: (modules[id].confidence * 100).toFixed(1) + "%",
        isOperational: modules[id].status === ModuleStatus.ACTIVE && modules[id].confidence > 0.8
    }));
  }

  public getEthicalStability() {
    return {
      score: EthicalDriftIndex.calculateStabilityScore(),
      trends: EthicalDriftIndex.getTrends(),
      memoryCount: VectorEthicalMemory.getMemoryFieldCount()
    };
  }

  public async forecastEthics(action: string, payload: Record<string, unknown>) {
    return await AnticipatoryEthicsForecaster.forecast(action, payload);
  }

  public reviewContractChange(oldSchema: string, newSchema: string) {
    return IntelligenceEngine.reviewContractChange(oldSchema, newSchema);
  }

  public evaluateJoeState(input: { envStability: number; executionStanding: number; contextualDrift: number; timestamp: number }) {
    return JoeKernel.evaluateState(input);
  }

  public calculateDrift(ethicalWeight: number, riskBand: number) {
    return DriftScorer.calculateDrift(ethicalWeight, riskBand);
  }

  public evolve(universe: UniverseState, driftReport: DriftReport) {
    return IntelligenceEngine.evolve(universe, driftReport);
  }
}
