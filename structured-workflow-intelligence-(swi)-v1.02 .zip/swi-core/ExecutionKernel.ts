// swi-core/ExecutionKernel.ts
import { SafetyInterlockEngine } from "./kernel/SafetyInterlockEngine";
import { StateGraphEngine } from "./kernel/StateGraphEngine";
import { UniverseKernel } from "./kernel/UniverseKernel";
import { ConfigEngine } from "./kernel/ConfigEngine";
import { AttestationEngine } from "./kernel/AttestationEngine";
import { PolicyCompiler as PCC } from "./ethics/PolicyCompiler";
import {
  UniverseState,
  PhysicsConstants,
  UserPersona,
} from "./kernel/UniverseTypes";

import { EventStreamEngine } from "./kernel/EventStreamEngine";
import { SandboxManager } from "./kernel/SandboxManager";
import { EventNormalizer } from "./kernel/EventNormalizer";
import { TopologyEngine } from "./kernel/TopologyEngine";
import {
  CryptoVerifyGate,
  CryptoRequestIR,
  CryptoVerifyGate as GateClass,
  EXECUTION_AUTHORITY_TOKEN,
} from "./trust/CryptoVerifyGate";
import { EventLedger } from "./EventLedger";

/**
 * 🛡️ Secured SWI Execution Kernel (Unified Verification Gate)
 * Enforces the Execution Closure Model: No execution transition can occur without strict cryptographic authorization.
 */
export class ExecutionKernel {
  private static instance: ExecutionKernel;
  private cryptoGate = new CryptoVerifyGate();

  private constructor() {
    TopologyEngine.initialize();
  }
  public static getInstance(): ExecutionKernel {
    if (!ExecutionKernel.instance) {
      ExecutionKernel.instance = new ExecutionKernel();
    }
    return ExecutionKernel.instance;
  }

  /**
   * Universal Execution Gateway
   * ALL execution requests must pass through this funnel. No bypass loops exist.
   */
  public async swiExecute(request: CryptoRequestIR) {
    console.log(
      `⚡ [KERNEL] Processing High-Integrity execution Request ID: ${request.id}`,
    );

    // --- 1. ATOMIC CRYPTOGRAPHIC VERIFICATION GATE ---
    // Physical isolation: execution cannot start unless gate produces the exact authority token
    const gateResult = await this.cryptoGate.verify(request);

    if (
      gateResult.decision !== "ALLOW" ||
      !GateClass.isAuthorized(gateResult.executionToken)
    ) {
      console.error(
        `❌ [KERNEL] GATING FAILURE: Execution Blocked. Reason: ${gateResult.reason}`,
      );
      return {
        status: "BLOCKED",
        reason: gateResult.reason,
        decision: "REJECT",
      };
    }

    // --- 2. ISOLATED EXECUTION DOMAIN ---
    // Execution Layer loses authority. It only operates because the token is explicitly verified.

    // P7: Event Normalization (Canonical Hashing & Trace Correlation)
    const normalized = EventNormalizer.normalize(
      request.command.action,
      (request.command.args as Record<string, unknown>) || {},
      (request.metadata as Record<string, unknown>) || {},
    );

    // SWI V1.01: Staged Sandbox Triage (Security Maze)
    const triage = await SandboxManager.runTriage(
      normalized.type!,
      normalized.payload!,
      request.metadata?.persona as UserPersona | undefined,
    );

    if (!triage.success) {
      console.error(
        `❌ [KERNEL] Execution Halted at stage: ${triage.stageReached} | Reason: ${triage.reason}`,
      );
      return {
        status: "BLOCKED",
        stage: triage.stageReached,
        reason: triage.reason,
        safetyReport: triage.safetyReport,
        timestamp: Date.now(),
        decision: "ALLOW_BUT_HALTED",
      };
    }

    console.log(
      `✅ [KERNEL] Triage Passed. Production Execution Attested & Root Verified.`,
    );

    // Execute physically gated by EXECUTION_AUTHORITY_TOKEN
    const ledger = EventLedger.getInstance();
    const result = await ledger.ingest(
      normalized.type!,
      normalized.payload!,
      {
        ...normalized.meta,
        attestation: triage.attestation,
        cryptographicProof: "SECURE_TOKEN_ATTACHED",
      },
      EXECUTION_AUTHORITY_TOKEN,
    );

    return {
      status: "COMMITTED",
      result,
      attestation: triage.attestation,
      timestamp: Date.now(),
      decision: "EXECUTE",
    };
  }

  public async bootstrap(
    seedLaws?: Partial<PhysicsConstants>,
  ): Promise<UniverseState> {
    console.log(
      "🌌 [BOOT] Initializing SWI Universe Kernel v3.5 (Crypto Gated)...",
    );
    const universe = UniverseKernel.bootstrap(seedLaws);

    // Audit Readiness
    const configReport = await ConfigEngine.auditReadiness();
    console.log(
      `🛠️ [P2_CONFIG] Audit Complete. Readiness Score: ${configReport.score.toFixed(2)}`,
    );
    if (!configReport.isReady) {
      console.warn(
        "⚠️ [SYSTEM] CONFIGURATION DEGRADED: Missing secrets or unbound modules detected.",
      );
    }

    // Verify Integrity
    const attestReport =
      await AttestationEngine.verifyRuntimeIntegrity("KERNEL");
    console.log(
      `🔒 [S5_ATTEST] Kernel Attestation Complete. Hash: ${attestReport.binaryHash.slice(0, 16)}... | Score: ${attestReport.trustScore.toFixed(3)}`,
    );
    if (
      attestReport.teeStatus === "COMPROMISED" ||
      !attestReport.manifestVerified
    ) {
      console.error(
        "❌ [SECURITY] KERNEL ATTESTATION FAILURE: Integrity compromised.",
      );
    }

    // Default Policy Ingestion
    await this.loadPolicies(`
      [POLICY_ID: EDUC_RIGHT_01]
      [LAW: UN_CRC_ART_28]
      - Every child MUST have the right to primary education.
      - SWI FORBIDDEN from providing dangerous information to children.
      - Access limits MUST adjust based on [AGE, REGION, JURISDICTION].
      - Formal evidence proof REQUIRED for sensitive content delivery.
      - System FORBIDDEN from actions that restrict educational access.
      - AUTOMATIC_CORRECT enabled for resource allocation.
    `);

    return universe;
  }

  public async loadPolicies(policyText: string): Promise<void> {
    console.log("⚙️ [KERNEL] Ingesting Governance Policies...");
    await PCC.compile(policyText);
  }

  public fork(
    parentId: string,
    mutations?: Partial<PhysicsConstants>,
  ): UniverseState {
    return UniverseKernel.fork(parentId, mutations);
  }

  public verifyReality(universeId: string): boolean {
    return UniverseKernel.verifyReality(universeId);
  }

  public getActiveUniverse(): UniverseState | null {
    return UniverseKernel.getActiveUniverse();
  }

  public getEBL() {
    return UniverseKernel.getEBL();
  }

  public haltExecution(reason: string): void {
    const universe = UniverseKernel.getActiveUniverse();
    if (universe) {
      universe.isHalted = true;
      console.error(`🛑 [KERNEL] SYSTEM_HALTED: ${reason}`);
    }
  }

  public resumeExecution(): void {
    const universe = UniverseKernel.getActiveUniverse();
    if (universe) {
      universe.isHalted = false;
      console.log(`🟢 [KERNEL] SYSTEM_RESUMED`);
    }
  }

  public processSafetyApproval(partyId: string, signature: string): boolean {
    const universe = UniverseKernel.getActiveUniverse();
    if (!universe) return false;
    return SafetyInterlockEngine.processApproval(universe, partyId, signature);
  }

  public answerSafetyChallenge(answer: string): {
    success: boolean;
    error?: string;
    [key: string]: unknown;
  } {
    const universe = UniverseKernel.getActiveUniverse();
    if (!universe) return { success: false, error: "No active universe" };
    return SafetyInterlockEngine.answerChallenge(universe, answer);
  }

  public async verifyDependencies() {
    return TopologyEngine.verifyIntegrity();
  }

  public async auditConfig() {
    return await ConfigEngine.auditReadiness();
  }

  public getGraphStats() {
    return StateGraphEngine.getStats();
  }
}

// Trace.log
