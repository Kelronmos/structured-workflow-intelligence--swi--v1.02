// swi-core/ProofEngine.ts
import { FormalVerificationEngine } from './kernel/FormalVerificationEngine';
import { ZKProverS9 } from './crypto/ZKProverS9';
import { AttestationEngine } from './kernel/AttestationEngine';
import { UniverseEvent, UniverseState } from './kernel/UniverseTypes';
import { RedTeamEngine } from './kernel/RedTeamEngine';
import { LegalEvidenceExporter } from './kernel/LegalEvidenceExporter';
import { DeterministicReplayRunner } from './kernel/DeterministicReplayRunner';
import { MerkleLedger } from './infrastructure/MerkleLedger';
import { ProofOfReplayEngine } from './kernel/ProofOfReplayEngine';
import { ExecutionKernel } from './ExecutionKernel';

/**
 * 🔒 SWI Proof Engine
 * Handles formal verification, ZK-proof generation, and hardware attestation.
 */
export class ProofEngine {
  private static instance: ProofEngine;

  public static getInstance(): ProofEngine {
    if (!ProofEngine.instance) {
      ProofEngine.instance = new ProofEngine();
    }
    return ProofEngine.instance;
  }

  public async verifyStateTransition(events: UniverseEvent[]): Promise<boolean> {
    return await FormalVerificationEngine.auditTransition(events);
  }

  public async generateZKProof(payload: unknown) {
    return await ZKProverS9.generateBoundaryProof("FABRIC", String(payload), 0.05);
  }

  public async runZKProof(payload: unknown) {
    return await this.generateZKProof(payload);
  }

  public async verifyBinaryIntegrity(moduleName: string) {
    return await AttestationEngine.verifyRuntimeIntegrity(moduleName);
  }

  public getFormalVerificationReport() {
    return FormalVerificationEngine.getReport();
  }

  public async runProofOfReplay() {
    const universe = ExecutionKernel.getInstance().getActiveUniverse();
    if (!universe) throw new Error("No active universe");
    return await ProofOfReplayEngine.generateProof(universe);
  }

  public async runRedTeamStressTest() {
    return await RedTeamEngine.runStressTest();
  }

  public async generateLegalEvidence(universe: UniverseState, event: UniverseEvent) {
    return await LegalEvidenceExporter.generateCourtEvidence(universe, event);
  }

  public verifyChain(merkleLedger: MerkleLedger) {
    return DeterministicReplayRunner.verifyChain(merkleLedger);
  }
}

// Trace.log
