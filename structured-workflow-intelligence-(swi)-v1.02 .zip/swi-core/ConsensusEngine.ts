// swi-core/ConsensusEngine.ts
import { ApprovalCoordinator } from './kernel/ApprovalCoordinator';
import { ConsensusEngine as LegacyConsensus } from './kernel/consensus';
import { MetricsCollector } from './kernel/MetricsCollector';

import { RustCEKCore, Context as RustContext } from '../src/swi/RustEngineBridge';
import { SWIArbiter, GlobalConsensus } from './Arbiter';
import { EnvironmentEngine } from './kernel/engines/EnvironmentEngine';
import { LegalEngine } from './kernel/engines/LegalEngine';
import { InfrastructureEngine } from './kernel/engines/InfrastructureEngine';
import { SWIContext, EngineDecision, ExecutionBoundaryState } from './kernel/engines/types';

/**
 * 🤝 SWI Consensus Engine
 */
export class ConsensusEngine {
  private static instance: ConsensusEngine;
  private cekCore: RustCEKCore;
  private arbiter: SWIArbiter;
  private envEngine: EnvironmentEngine;
  private legalEngine: LegalEngine;

  private constructor() {
    this.cekCore = new RustCEKCore();
    this.arbiter = new SWIArbiter();
    this.envEngine = new EnvironmentEngine();
    this.legalEngine = new LegalEngine();
  }

  public static getInstance(): ConsensusEngine {
    if (!ConsensusEngine.instance) {
      ConsensusEngine.instance = new ConsensusEngine();
    }
    return ConsensusEngine.instance;
  }

  public async requestApproval(action: string, context: Record<string, unknown>) {
    return await ApprovalCoordinator.requestApproval(action, context);
  }

  public recordByzantineFault(nodeName: string) {
    LegacyConsensus.quarantineNode(nodeName);
  }

  public getQuorumHealth(): number {
    const metrics = MetricsCollector.getSnapshot();
    return metrics.quorumHealth;
  }

  public getValidatorStatus() {
    return {
      reputations: LegacyConsensus.getReputations(),
      quarantine: LegacyConsensus.getQuarantine(),
      faults: LegacyConsensus.getByzantineReports()
    };
  }

  public arbitrate(engineDecisions: EngineDecision[], swiCtx: SWIContext) {
    return this.arbiter.arbitrate(engineDecisions, swiCtx);
  }

  public replay(data: { 
    verificationState: string; 
    consensus: GlobalConsensus; 
    standing?: ExecutionBoundaryState;
    attestation?: { signature: string; attestation: string }
  }) {
    return this.arbiter.replay(data);
  }

  public evaluateCEK(data: RustContext) {
    return this.cekCore.evaluate(data);
  }

  public evaluateEnvironment(swiCtx: SWIContext) {
    return this.envEngine.evaluate(swiCtx);
  }

  public evaluateLegal(swiCtx: SWIContext) {
    return this.legalEngine.evaluate(swiCtx);
  }

  public evaluateInfrastructure(swiCtx: SWIContext) {
    return InfrastructureEngine.evaluate(swiCtx);
  }

  public pulse(nodeId: string) {
    ApprovalCoordinator.pulse(nodeId);
  }

  public getMetricsHistory() {
    return MetricsCollector.getHistory(20);
  }
}
