// coordinator/node_router.ts
import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { v4 as uuidv4 } from 'uuid';
import { SWIRollupKernel } from '../swi-core/rollup/state';
import { ZKProver } from '../src/lib/zk_proof';
import { AttackVector, RedTeamSimulator } from '../swi-core/kernel/red_team';

const app = express.Router();
const kernel = new SWIRollupKernel();

app.use(express.json());

// --- Identity & Registry State ---
const identityRegistry = new Map<string, {
    publicKey: string;
    revoked: boolean;
    standing: number;
    joinedAt: number;
}>();

let currentNodeKey = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
});

// Seed an initial trusted node
identityRegistry.set("NODE_GENESIS", {
    publicKey: currentNodeKey.publicKey,
    revoked: false,
    standing: 1.0,
    joinedAt: Date.now()
});

// ----------------------------------------------------
// 🔗 VRIT SIGNING MIDDLEWARE (Verifiable Runtime Integrity Token)
// ----------------------------------------------------
const vritSigningMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const signature = req.headers['x-vrit-signature'] as string;
    const nodeId = req.headers['x-swi-node-id'] as string;

    if (!signature || !nodeId) {
        return res.status(401).json({ error: "MISSING_VRIT_HEADERS", reason: "Zero-trust policy requires VRIT signature and Node ID." });
    }

    const identity = identityRegistry.get(nodeId);
    if (!identity) {
        return res.status(403).json({ error: "UNKNOWN_NODE", reason: "Node identity not found in federation registry." });
    }

    if (identity.revoked) {
        return res.status(403).json({ error: "REVOKED_NODE", reason: "Node identity has been revoked." });
    }

    try {
        const payloadStr = JSON.stringify(req.body);
        const verify = crypto.createVerify('SHA256');
        verify.update(payloadStr);
        verify.end();

        const isValid = verify.verify(identity.publicKey, signature, 'hex');
        if (!isValid) {
            return res.status(403).json({ error: "INVALID_VRIT_SIGNATURE", reason: "Payload signature verification failed." });
        }
        next();
    } catch (err) {
        return res.status(500).json({ error: "VRIT_VERIFICATION_ERROR", details: (err as Error).message });
    }
};

// ----------------------------------------------------
// 🔐 ZERO-TRUST NODE UPGRADE (Key Rotation & Revocation)
// ----------------------------------------------------
app.post('/api/node/upgrade/rotate-keys', vritSigningMiddleware, (req, res) => {
    const nodeId = req.headers['x-swi-node-id'] as string;
    
    // Generate new key pair
    const newKeyPair = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
        publicKeyEncoding: { type: 'spki', format: 'pem' },
        privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
    });

    const oldIdentity = identityRegistry.get(nodeId);
    if (oldIdentity) {
        identityRegistry.set(nodeId, {
            ...oldIdentity,
            publicKey: newKeyPair.publicKey
        });
    }

    res.json({
        action: "KEY_ROTATION",
        status: "SUCCESS",
        nodeId,
        newPublicKey: newKeyPair.publicKey,
        timestamp: Date.now()
    });
});

app.post('/api/node/upgrade/revoke', vritSigningMiddleware, (req, res) => {
    const { targetNodeId, reason } = req.body;
    const requestorId = req.headers['x-swi-node-id'] as string;

    const requestor = identityRegistry.get(requestorId);
    if (!requestor || requestor.standing < 0.9) {
        return res.status(403).json({ error: "INSUFFICIENT_STANDING" });
    }

    const target = identityRegistry.get(targetNodeId);
    if (target) {
        target.revoked = true;
        res.json({ status: "REVOKED", targetNodeId, reason, timestamp: Date.now() });
    } else {
        res.status(404).json({ error: "NODE_NOT_FOUND" });
    }
});

app.get('/api/node/upgrade/registry', (req, res) => {
    const safeRegistry = Array.from(identityRegistry.entries()).map(([id, data]) => ({
        nodeId: id,
        revoked: data.revoked,
        standing: data.standing,
        joinedAt: new Date(data.joinedAt).toISOString()
    }));
    res.json(safeRegistry);
});

// ----------------------------------------------------
// 🤝 FEDERATION HANDSHAKE PROTOCOL
// ----------------------------------------------------
app.post('/api/node/federation/handshake', (req, res) => {
    const { guestNodeId, guestPublicKey, capabilityProof } = req.body;

    if (!guestNodeId || !guestPublicKey) {
        return res.status(400).json({ error: "INVALID_HANDSHAKE" });
    }

    if (identityRegistry.has(guestNodeId)) {
        return res.status(409).json({ error: "NODE_ALREADY_EXISTS" });
    }

    // Verify capability proof using VRIT framework (simulated)
    const proofVerified = capabilityProof && capabilityProof.length > 32;
    if (!proofVerified) {
        return res.status(403).json({ error: "CAPABILITY_PROOF_REJECTED" });
    }

    identityRegistry.set(guestNodeId, {
        publicKey: guestPublicKey,
        revoked: false,
        standing: 0.5, // Start with tentative standing
        joinedAt: Date.now()
    });

    const hostAttestation = crypto.createSign('SHA256');
    hostAttestation.update(guestNodeId + Date.now().toString());
    const hostSignature = hostAttestation.sign(currentNodeKey.privateKey, 'hex');

    res.json({
        status: "FEDERATION_ESTABLISHED",
        hostPublicKey: currentNodeKey.publicKey,
        hostAttestation: hostSignature,
        assignedStanding: 0.5
    });
});

// ----------------------------------------------------
// 📜 ATTESTATION API WRAPPER
// ----------------------------------------------------
app.get('/api/node/attestation', async (req, res) => {
    const identityNodesCount = identityRegistry.size;
    const activeNodes = Array.from(identityRegistry.values()).filter(v => !v.revoked).length;

    const zkProof = await ZKProver.generateProof("NODE_ATTESTATION", {
        drift: 0,
        weights: [identityNodesCount, activeNodes],
        boundary: { timestamp: Date.now() }
    });

    res.json({
        type: "SWI_NODE_ATTESTATION",
        networkHealth: (activeNodes / identityNodesCount) > 0.6 ? "ROBUST" : "DEGRADED",
        activeNodes,
        proofPayload: zkProof,
        verificationState: "SIMULATED"
    });
});

// ----------------------------------------------------
// 📡 LIVE INTEGRATION: VRIT API Layer & Pipeline
// ----------------------------------------------------
app.post('/api/node/vrit/pipeline/resilience', vritSigningMiddleware, (req, res) => {
    const { configurationHash } = req.body;
    
    // Generate Resilience Certificate Pipeline output
    const certificate = {
        certId: `R-CERT-${uuidv4().substring(0,8)}`,
        configHash: configurationHash,
        issuedAt: new Date().toISOString(),
        issuer: "SWI_CORE_FEDERATION",
        assuranceLevel: "AAL-3",
        validityPeriodSeconds: 3600
    };

    const certSign = crypto.createSign('SHA256');
    certSign.update(JSON.stringify(certificate));
    const certSig = certSign.sign(currentNodeKey.privateKey, 'hex');

    res.json({
        status: "CERTIFICATE_ISSUED",
        certificate,
        signature: certSig
    });
});

// ----------------------------------------------------
// 👾 LIVE INTEGRATION: Adversarial Attacker Tests
// ----------------------------------------------------
app.post('/api/node/vrit/adversarial', vritSigningMiddleware, (req, res) => {
    const { vector } = req.body;
    
    let targetVector = AttackVector.TOKEN_FORGERY;
    try {
        if (Object.values(AttackVector).includes(vector)) {
            targetVector = vector;
        }
    } catch(e) {}

    const simulator = new RedTeamSimulator();
    const result = simulator.simulateAttack(targetVector);

    res.json({
        status: "ADVERSARIAL_TEST_COMPLETE",
        vector: targetVector,
        blocked: result.status === "PASS", // In RedTeam logic, PASS means system blocked it
        detail: result.system_response,
        attackerTraceId: result.hash
    });
});

// ----------------------------------------------------
// LEGACY ENDPOINTS (Adapted to Adapter)
// ----------------------------------------------------
let gpuUtilization = 42;

app.post('/api/rollup/submit', vritSigningMiddleware, async (req, res) => {
    const { transactions } = req.body;
    gpuUtilization = 98;
    const batch = kernel.processBatch(transactions || []);
    const zkProofObj = await ZKProver.generateProof("ROLLUP_STEP", {
        drift: 0.001,
        weights: [(batch.transactions?.length || 0) + 1, 0.1, 0.9]
    });
    const isVerified = (await ZKProver.verify(zkProofObj)).valid;
    setTimeout(() => { gpuUtilization = 40 + Math.random() * 10; }, 2000);
    res.json({
        status: "COMMITTED",
        batchId: batch.id,
        stateRoot: batch.newRoot,
        proof: Buffer.isBuffer(zkProofObj.proof) ? zkProofObj.proof.toString("base64") : zkProofObj.proof,
        verificationState: "SIMULATED",
        txCount: batch.transactions.length,
        timestamp: batch.timestamp
    });
});

app.get('/api/system/gpu-metrics', (req, res) => {
    res.json({
        utilization: gpuUtilization,
        temp: 65 + (gpuUtilization / 5),
        vram: "7.2GB / 16GB",
        activeKernels: gpuUtilization > 80 ? ["MSM_p256", "NTT_64k"] : ["Idle"]
    });
});

app.post('/api/system/benchmark', (req, res) => {
    const { constraints } = req.body;
    const cpu = ZKProver.benchmark(constraints, false);
    const gpu = ZKProver.benchmark(constraints, true);
    res.json({
        cpu,
        gpu,
        speedup: (cpu.timeMs / gpu.timeMs).toFixed(1) + "x"
    });
});

export default app;

