# SWI v3.5 Enterprise Deployment Blueprint
# Provider: AWS (EKS + MSK + RDS)

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.23"
    }
  }
}

# 🏗️ VPC Module: Multi-Region Network
module "vpc" {
  source = "terraform-aws-modules/vpc/aws"
  name   = "swi-production-vpc"
  cidr   = "10.0.0.0/16"

  azs             = ["us-east-1a", "us-east-1b", "eu-west-1a"]
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  public_subnets  = ["10.0.101.0/24", "10.0.102.0/24", "10.0.103.0/24"]

  enable_nat_gateway = true
  single_nat_gateway = false
}

# 🚢 EKS Cluster: Control Plane & Replay Nodes
module "eks" {
  source          = "terraform-aws-modules/eks/aws"
  cluster_name    = "swi-control-plane"
  cluster_version = "1.28"
  vpc_id          = module.vpc.vpc_id
  subnet_ids      = module.vpc.private_subnets

  eks_managed_node_groups = {
    control_plane = {
      min_size     = 3
      max_size     = 5
      desired_size = 3
      instance_types = ["t3.large"]
      labels = {
         role = "governance"
      }
    }
    replay_nodes = {
      min_size     = 5
      instance_types = ["c6i.xlarge"]
      labels = {
         role = "replay"
      }
    }
  }
}

# 🌊 MSK (Kafka): Event Stream Spine
resource "aws_msk_cluster" "swi_stream" {
  cluster_name           = "swi-event-spine"
  kafka_version          = "3.4.0"
  number_of_broker_nodes = 3

  broker_node_group_info {
    instance_type   = "kafka.m5.large"
    client_subnets  = module.vpc.private_subnets
    security_groups = [aws_security_group.msk_sg.id]
  }
}

resource "aws_security_group" "msk_sg" {
  name   = "swi-msk-access"
  vpc_id = module.vpc.vpc_id
  ingress {
    from_port = 9092
    to_port   = 9092
    protocol  = "tcp"
    cidr_blocks = module.vpc.private_subnets
  }
}
