export interface ReceiptData {
  envelope: {
    corridor_id: string;
    envelope_id: string;
  };
  decision: string;
  reason?: string;
  hash: string;
}

export function createReceipt(data: ReceiptData) {
  return {
    corridor_id: data.envelope.corridor_id,
    decision: data.decision,
    envelope_id: data.envelope.envelope_id,
    timestamp: Date.now(),
    reason: data.reason || "OK",
    ledger_hash: data.hash,
    spec_id: "SNYDER_RUNTIME_V1"
  };
}
