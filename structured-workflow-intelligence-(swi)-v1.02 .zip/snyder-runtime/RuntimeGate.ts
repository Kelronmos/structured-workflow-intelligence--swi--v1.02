import { AuthorityEnvelope } from "./AuthorityEnvelope";

export class RuntimeGate {
  evaluate(action: unknown, envelope?: AuthorityEnvelope, ledgerOk = true) {

    if (!envelope) {
      return this.refuse("NO_ENVELOPE");
    }

    if (Date.now() > envelope.t_expiry) {
      return this.refuse("EXPIRED_AUTHORITY");
    }

    if (!envelope.cost_owner || !envelope.rollback_plan_id) {
      return this.refuse("NO_ROLLBACK_BOUND");
    }

    if (!ledgerOk) {
      return this.refuse("LEDGER_OFFLINE");
    }

    return this.execute(action, envelope);
  }

  refuse(reason: string) {
    return { decision: "REFUSE", reason };
  }

  execute(action: unknown, envelope: AuthorityEnvelope) {
    return { decision: "EXECUTE", action, envelope };
  }
}
