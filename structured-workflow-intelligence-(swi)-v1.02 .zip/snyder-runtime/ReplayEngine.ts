import { AuthorityEnvelope } from "./AuthorityEnvelope";
import { RuntimeGate } from "./RuntimeGate";

export class ReplayEngine {
  replay(receipt: { action: unknown; decision: string }, envelope: AuthorityEnvelope) {
    const gate = new RuntimeGate();

    const result = gate.evaluate(
      receipt.action,
      envelope,
      true
    );

    return result.decision === receipt.decision;
  }
}
