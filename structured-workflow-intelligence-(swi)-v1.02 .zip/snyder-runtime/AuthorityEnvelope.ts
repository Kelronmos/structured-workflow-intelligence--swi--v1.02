export interface AuthorityEnvelope {
  envelope_id: string;
  authority_id: string;
  corridor_id: string;

  scope: unknown;

  cost_owner: string;
  rollback_owner: string;
  rollback_plan_id: string;
  stop_right_holder: string;

  t_issue: number;
  t_expiry: number;

  spec_id: "SNYDER_RUNTIME_V1";
}
