# SWI GitOps Production Blueprint: Directory Structure & Configuration

This blueprint outlines the repository structure required to deploy the SWI Cryptographic Trust Infrastructure across multiple regions using ArgoCD and Helm.

## 1. Directory Structure

```text
gitops-swi-infrastructure/
├── apps/
│   ├── swi-core/                   # Core trust engine & API gateway
│   │   ├── base/                   # Base Helm chart configuration
│   │   ├── overlays/
│   │   │   ├── af-south-1/         # Primary region configurations
│   │   │   ├── eu-west-1/          # Secondary region configurations
│   │   │   └── us-east-1/          # Tertiary region configurations
│   ├── swi-ledger/                 # immudb and Merkle tree engine
│   └── swi-verifier/               # Transparency log & public verification APIs
├── charts/
│   ├── swi-core/                   # Custom Helm chart
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/
│   │       ├── deployment.yaml
│   │       ├── service.yaml
│   │       ├── ingress.yaml
│   │       └── networkpolicy.yaml
│   ├── swi-ledger/
│   └── swi-verifier/
├── argocd/                         # ArgoCD configurations
│   ├── projects/                   # ArgoCD AppProject manifests
│   │   └── swi-system.yaml
│   ├── applicationsets/            # Multi-region deployment automation
│   │   └── swi-global-appset.yaml
│   └── bootstrap/                  # ArgoCD initial installation scripts
├── policies/                       # Policy-as-Code (OPA/Gatekeeper)
│   ├── authz/
│   │   └── rbac.rego               # RBAC policies for API gateway
│   ├── admission/
│   │   ├── require-uve.yaml        # Validates pods have UVE metadata limits
│   │   └── require-provenance.rego # Ensure images have SLSA provenance
│   └── compliance/
│       └── iso27001-controls.yaml  
└── infrastructure/                 # Terraform / Crossplane resources
    ├── aws/
    │   ├── kms.yaml                # KMS key provisioning
    │   ├── cloudhsm.yaml           # CloudHSM cluster definitions
    │   └── s3-worm.yaml            # Object Lock S3 buckets
    └── gcp/                        # (If multi-cloud)
```

## 2. Multi-Region ArgoCD ApplicationSet (Example)

`argocd/applicationsets/swi-global-appset.yaml`

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: swi-global
  namespace: argocd
spec:
  generators:
  - list:
      elements:
      - cluster: af-south-1-cluster
        url: https://af-south-1-api.k8s.local
        env: prod
        region: af-south-1
      - cluster: eu-west-1-cluster
        url: https://eu-west-1-api.k8s.local
        env: prod
        region: eu-west-1
  template:
    metadata:
      name: 'swi-core-{{region}}'
    spec:
      project: swi-system
      source:
        repoURL: 'https://github.com/swi/gitops.git'
        targetRevision: HEAD
        path: 'apps/swi-core/overlays/{{region}}'
      destination:
        server: '{{url}}'
        namespace: swi-system
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
        syncOptions:
        - CreateNamespace=true
```

## 3. Security Policy-as-Code (OPA Example)

`policies/admission/require-provenance.rego`

```rego
package k8s.admission

deny[msg] {
  input.request.kind.kind == "Pod"
  image := input.request.object.spec.containers[_].image
  not has_slsa_provenance(image)
  msg := sprintf("Image %v denied: missing cryptographically verified SLSA provenance", [image])
}

has_slsa_provenance(image) {
  # Logic to interface with SWI Verifier or Cosign to check image signatures
  # during admission control. This acts as the final enforcement point.
  true # Placeholder logic
}
```

## 4. Operational Guidelines

1. **Immutable Configuration:** All changes to the production environment must be merged into the `main` branch of the GitOps repository.
2. **KMS & HSM Binding:** The Kubernetes workloads use IAM roles (IRSA) to communicate with AWS KMS, ensuring the pods don't hold static keys, but delegate signing to the hardware module.
3. **Continuous Verification:** ArgoCD continuously monitors the live cluster state against the Git repository, auto-healing any configuration drift.
