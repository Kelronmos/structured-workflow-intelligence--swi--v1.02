# SWI Merkle-Tree Global Audit Ledger (MTGAL) Specification
**Version 1.0**

## 1. Introduction
The Merkle-Tree Global Audit Ledger (MTGAL) delivers blockchain-grade data integrity and chronological immutability without the complexity of consensus protocols or tokenomics. By leveraging hardware security modules (HSM), immudb, and WORM storage, MTGAL ensures that historical system data is mathematically immutable and independently verifiable.

## 2. Cryptographic Construction

### 2.1 Event Normalization
Every system action is encapsulated into a JSON event. Before hashing, the event MUST undergo strict canonicalization.
* Formatted strictly as UTF-8.
* Keys sorted alphabetically.
* No whitespace between key-value pairs (minified).
* Arrays maintain indexed order.

### 2.2 Canonical Event Hashing Rule
The Leaf Hash for any Event `E` is defined as:
```text
L(E) = SHA-256( Canonicalize(E) )
```

### 2.3 Merkle Tree Aggregation
Events are aggregated into batches (either time-based, e.g., every 5 seconds, or count-based, e.g., every 10,000 events).
1. Collect ordered leaf hashes: `[H_1, H_2, ... H_n]`.
2. Pairwise hash: `Parent = SHA-256( Left_Child + Right_Child )`.
3. If an odd number of nodes exists at any level, the final node is duplicated to form a pair.
4. Recurse until exactly one node remains: The **Merkle Root**.

### 2.4 Cryptographic Anchoring
The Merkle Root is anchored via hardware signature.
```text
Signature_Material = UTF8( Root_Hash + ":" + Anchor_Timestamp + ":" + Signing_Key_ID )
Root_Signature = ECDSA_SIGN( SHA-256(Signature_Material), CloudHSM_Private_Key )
```

## 3. Storage and Persistence
* **Immudb Ledger:** The Root Hash, Signature, and an array of Leaf Hashes are appended to an `immudb` operational ledger. Immudb natively maintains an append-only hash chain.
* **WORM Storage:** A JSON manifest of the batch (Events + Tree Structure + Root Anchor) is written to AWS S3 Object Lock configured for Compliance Mode (1-year minimum retention), preventing unauthorized deletion.
* **Transparency Log:** The Root Anchor is forwarded to a Rekor-like transparency log to establish public timestamping and prevent split-view attacks.

## 4. Multi-Region Synchronization

### 4.1 Topology
* **Primary Region (e.g., Africa):** Ingests events, computes Merkle trees, signs roots, and persists to primary storage.
* **Mirror Regions (e.g., EU, US):** Read-only replicas.

### 4.2 Consistency Protocol
1. Primary commits the batch to immudb and WORM storage.
2. Primary publishes the `Anchor Sync Event` to a cross-region message broker.
3. Mirrors ingest the Sync Event, verifying the HSM signature.
4. Mirrors fetch the underlying WORM batch and recompute the Merkle tree locally.
5. If `Local_Root == Global_Root`, the mirror commits the batch to its local immudb instance.
6. If a mismatch occurs, the mirror region is logically quarantined and an alert is dispatched.

## 5. Independent Verification CLI Workflow
An external auditor can verify the SWI system using the `swi-verifier` CLI without relying on internal SWI APIs.

### 5.1 Verification Steps
1. **Download Envelope:** The auditor downloads the Universal Verification Envelope containing the target event.
2. **Fetch Audit Batch:** The CLI retrieves the specific WORM storage manifest containing the batch of events for that time window.
3. **Recompute Leaf:** The CLI canonicalizes and hashes the isolated event, matching it to `H_x`.
4. **Rebuild Tree:** The CLI uses the sibling hashes from the manifest to recompute the Merkle path.
5. **Verify Root:** Matches the computed root against the `Root_Hash` in the anchor.
6. **Verify Signature:** Validates the ECDSA signature of the root using the public key published in the Trust Root Registry.
7. **Verify Log Inclusion:** Queries the external Transparency Log to ensure the root was publicly witnessed.

### 5.2 Completion
If all mathematical proofs resolve to `true`, the system guarantees the artifact existed at the specified time, originated from SWI, and has not been altered by any entity (including SWI administrators).
