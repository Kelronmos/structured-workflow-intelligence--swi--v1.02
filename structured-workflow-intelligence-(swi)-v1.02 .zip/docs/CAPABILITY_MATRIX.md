# SWI Capability Matrix

| Module | Status | Description |
|---|---|---|
| ZK Proof Validation | SIMULATED | Validates execution traces using zkp. simulated in current phase. |
| Verification Gate | PARTIAL | Validates authority and evidence tokens prior to execution. |
| Audit Ledger | IMPLEMENTED | Local Merkle-ountain-range ledgering for events. |
| Consensus Engine | PARTIAL | Aggregates decisions from local nodes for agreement. |
| Documentation Sync | IMPLEMENTED | Keeps architectural specs mapped to real executions. |
| Deterministic Replay | PARTIAL | Allows replaying a transaction from trace. |
