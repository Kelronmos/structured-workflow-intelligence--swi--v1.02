# 🛡️ SWI HSM Isolation & Signing Authority Spec
# ENVIRONMENT=REVIEW_ONLY
# NON_PRODUCTION=true
# ROTATE_AFTER_REVIEW=true

## 🔐 The "Proof vs Authority" Boundary
In SWI v2.1, the **Trust Root** (Mathematical Authority) is strictly isolated. 
The system is designed so that even a root-level kernel compromise cannot extract the original HSM-backed authority keys.

### 📜 Security Guarantee
1. **No Authority Leak**: Signing keys ($k_{auth}$) never enter the execution memory.
2. **Deterministic Receipts**: The kernel generates ZK-receipts ($\pi$) that prove a computation followed Rule $R$, without exposing the signing actor.
3. **Lineage Preservation**: Every block in the continuity ledger is anchored to a temporary **Review Chain** that inherits authority via a one-way bridge.

## 🧱 Signing Layers
| Layer | Material | Exposure |
| :--- | :--- | :--- |
| **L0: Authority** | Hardware-bound RSA-4096 | ZERO |
| **L1: Consensus** | Ephemeral Review Keys | Sandbox Only |
| **L2: Witness** | User Biometric Signatures | Local Buffer |

## 🔄 Rotation Policy
All materials in `/mock-keys` must be rotated immediately following any external review or security audit.
