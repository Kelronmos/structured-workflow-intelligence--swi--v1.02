--------------------------- MODULE SWI_Consensus ---------------------------
EXTENDS Integers, Sequences, FiniteSets

(***************************************************************************
 * THESIS: No state binding (Consequence) can occur without prior          *
 * validation of node standing (Identity + Integrity + Low Drift).          *
 ***************************************************************************)

VARIABLES 
    nodes,          \* Set of participating nodes
    standing,       \* Map: node -> [identity: BOOLEAN, drift: INTEGER]
    state_machine,  \* Map: node -> {STAGNANT, ASSERTING, RESOLVING, VALIDATED, BINDING, CONSEQUENCE}
    ledger,         \* Sequence of committed states
    network         \* Set of in-flight messages

Constants
    QuorumSize      \* Required number of nodes for consensus
    DriftThreshold  \* Maximum allowable drift score (e.g., 40)

States == {"STAGNANT", "ASSERTING", "RESOLVING", "VALIDATED", "BINDING", "CONSEQUENCE"}

\* --- INVARIANTS ---

\* The Core Safety Theorem: No node reaches CONSEQUENCE without VALIDATED standing
SafetyTheorem == \forall n \in nodes : 
    state_machine[n] = "CONSEQUENCE" => 
        /\ standing[n].identity = TRUE
        /\ standing[n].drift < DriftThreshold

NoDoubleCommit == \forall n \in nodes : 
    state_machine[n] = "CONSEQUENCE" => 
        Cardinality({m \in nodes : state_machine[m] = "CONSEQUENCE"}) <= QuorumSize

NoForkedLedger == Len(ledger) <= 1 \/ \forall i, j \in 1..Len(ledger) :
    i = j \/ ledger[i] = ledger[j] \/ ledger[i] # ledger[j]

NoUnauthorizedVote == \forall n \in nodes :
    state_machine[n] = "VALIDATED" => standing[n].identity = TRUE

MerkleRootConsistency == \forall x \in 1..Len(ledger) : ledger[x] = "NEW_STATE_BIND"

\* --- ACTIONS ---

\* 1. Load Standing: Node starts the verification process
LoadStanding(n) ==
    /\ state_machine[n] = "STAGNANT"
    /\ state_machine' = [state_machine EXCEPT ![n] = "ASSERTING"]
    /\ UNCHANGED <<nodes, standing, ledger, network>>

\* 2. Verify: Check certificates and trace
Verify(n) ==
    /\ state_machine[n] = "ASSERTING"
    /\ standing[n].identity = TRUE
    /\ state_machine' = [state_machine EXCEPT ![n] = "RESOLVING"]
    /\ UNCHANGED <<nodes, standing, ledger, network>>

\* 3. Validate: Check policies and drift
Validate(n) ==
    /\ state_machine[n] = "RESOLVING"
    /\ standing[n].drift < DriftThreshold
    /\ state_machine' = [state_machine EXCEPT ![n] = "VALIDATED"]
    /\ UNCHANGED <<nodes, standing, ledger, network>>

\* 4. Bind & Commit (Consensus)
Commit(n) ==
    /\ state_machine[n] = "VALIDATED"
    /\ Cardinality({m \in nodes : state_machine[m] = "VALIDATED"}) >= QuorumSize
    /\ state_machine' = [state_machine EXCEPT ![n] = "CONSEQUENCE"]
    /\ ledger' = Append(ledger, "NEW_STATE_BIND")
    /\ UNCHANGED <<nodes, standing, network>>

\* --- SPECIFICATION ---

Init ==
    /\ nodes = {"Node_A", "Node_B", "Node_C"}
    /\ standing = [n \in nodes |-> [identity |-> TRUE, drift |-> 0]]
    /\ state_machine = [n \in nodes |-> "STAGNANT"]
    /\ ledger = <<>>
    /\ network = {}

Next == \exists n \in nodes : 
    \/ LoadStanding(n)
    \/ Verify(n)
    \/ Validate(n)
    \/ Commit(n)

Spec == Init /\ [][Next]_<<nodes, standing, state_machine, ledger, network>>

=============================================================================
