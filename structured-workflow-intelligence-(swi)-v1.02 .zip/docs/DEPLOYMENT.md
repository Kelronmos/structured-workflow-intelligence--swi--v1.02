# 🚀 SWI Production Deployment Guide

## Prerequisites
- Docker & Docker Compose
- Node.js 20+
- Python 3.9+ (for simulators)

## Quick Start (Local Production)

1. **Spin up the Core Stack**:
   ```bash
   docker-compose up -d
   ```
   This will start the Node.js SWI Kernel, Kafka, and the observability stack.

2. **Verify Kernel Health**:
   ```bash
   curl http://localhost:3000/api/health
   ```

3. **Run the Drift Simulator**:
   ```bash
   pip install requests  # if using external connectivity
   python3 infra/simulation/swi_simulator.py
   ```

## Repository Structure

- `/swi-core`: The high-integrity kernel logic (TypeScript).
- `/infra`: Production infrastructure as code (Docker, Prometheus, Simulation).
- `/src`: Frontend React application (The Observation Layer).
- `/docs`: Formal specifications and architecture diagrams.
- `/scripts`: CI/CD "Autonomous Governor" scripts.

## Monitoring
- **Prometheus**: `http://localhost:9090` (Scraping kernel metrics).
- **Grafana**: `http://localhost:3001` (Visualizing stability scores).
- **Dashboard**: `http://localhost:3000` (The Meta-Observer).
