# Audit Scope

- `swi-core/trust/*`
- `swi-core/crypto/*`
- `swi-core/execution/*`
- `src/services/RuntimeTraceService.ts`

Any component making execution claims, updating consensus, or verifying proofs falls strictly within the audit scope.
