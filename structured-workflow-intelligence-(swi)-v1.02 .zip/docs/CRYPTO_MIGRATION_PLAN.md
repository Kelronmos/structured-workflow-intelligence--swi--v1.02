# SWI Production-Grade Crypto Migration Plan
(ZK Proof System + PBFT Upgrade Path)

This plan assumes a transition from prototype/simulated cryptography → production-verifiable systems without breaking the existing SWI architecture.

## 0. Migration Principle

Two non-negotiable rules:

* **No hybrid trust states in production**
    * either “verified cryptographically” or “rejected”
    * no fallback simulation paths in core logic
* **Separation of layers**
    * `core/` → production cryptography only
    * `dev/` → experiments, mocks, simulators
    * `test/` → adversarial + property tests

## 1. Target Final Architecture

**Cryptographic Stack Target**
```text
Application Layer
   ↓
Consensus Layer (PBFT + crypto finality)
   ↓
Proof Layer (ZK + signature proofs)
   ↓
State Layer (Merkle commitments)
   ↓
Storage Layer
```

## 2. ZK SYSTEM MIGRATION

### 2.1 Current State (Problem)
* Simulated proof generation
* Hash-based “fake ZK”
* No circuit constraints
* No verifier backend

### 2.2 Target State
Support real proving system integration:

* **Option A** (recommended for production SWI)
    * Halo2 (Plonkish arithmetization)
    * Strong Rust integration
    * No trusted setup dependency (or minimal)
* **Option B**
    * arkworks Groth16 (mature, widely audited)
    * Trusted setup required per circuit
* **Option C** (future-proof)
    * Noir (Aztec stack)
    * Developer-friendly DSL + proven backend

### 2.3 Migration Steps

#### Step 1 — Abstract Proof Interface
```rust
pub trait ZkProver {
    fn prove(inputs: PublicInputs, witness: Witness) -> Proof;
    fn verify(proof: Proof, inputs: PublicInputs) -> bool;
}
```
No implementation yet exposed to app layer.

#### Step 2 — Circuit Isolation Layer
Move all logic into: `/zk/circuits/`
Define:
* transaction validity circuit
* state transition circuit
* signature inclusion circuit

#### Step 3 — Replace simulation engine
Remove:
* hash-based “proof generator”
* mock HMAC proofs
* deterministic fake outputs

Replace with:
`halo2_prover.rs` & `halo2_verifier.rs`
or arkworks equivalent.

#### Step 4 — CI enforcement upgrade
CI must enforce:
* `simulate()` forbidden in `/core`
* mock proof forbidden entirely
* proof verification must call real backend

#### Step 5 — ZK correctness tests
Add:
* invalid witness rejection tests
* adversarial proof mutation tests
* replay attack resistance tests

**ZK Completion Criteria**
✔ Real proof objects (non-hash-based)
✔ Circuit constraints defined
✔ External verifier correctness
✔ No simulation paths in production

## 3. PBFT MIGRATION

### 3.1 Current State (Problem)
* Mock signature verification
* Boolean or empty-check validation
* No Byzantine fault tolerance enforcement

### 3.2 Target PBFT Model
SWI should implement:
`PRE-PREPARE → PREPARE → COMMIT → FINALIZE`
with cryptographic gating at every stage.

### 3.3 Required Upgrade Components
**1. Signature-based authentication layer**
Use: Ed25519 (fast + standard) OR secp256k1 (if blockchain compatibility required)
`fn verify_message(msg, sig, pubkey) -> bool`

**2. Replace mock verifier**
Current: `proof.proof.is_empty()`
Replace with: real signature verification, optional ZK proof verification (if required per transaction)

**3. Add quorum validation**
PBFT requirement: $n \ge 3f + 1$
Enforce: 2/3+ voting threshold for commit, rejection of malformed quorum sets

**4. State transition security gate**
Every block must pass:
Transaction validity + Signature verification + Merkle inclusion proof + ZK validity (optional layer) → PBFT consensus acceptance

### 3.4 Fault handling model
Must explicitly handle:
* equivocation detection
* replay protection
* signature mismatch rejection
* quorum inconsistency rollback

**PBFT Completion Criteria**
✔ No mock verification paths
✔ Byzantine quorum enforced
✔ Deterministic finality model
✔ Cryptographically signed messages only

## 4. MERKLE + STATE COMMITMENT UPGRADE

### Required invariant
Every state transition must satisfy:
`state_t → Merkle(root_t) → verified → state_t+1`

### Implementation requirements
* Sparse Merkle Tree (authenticated state)
* Inclusion proof mandatory per transaction
* No direct state mutation without proof

## 5. FORMAL VERIFICATION INTEGRATION

### Required upgrade to TLA+
Must enforce:
* PBFT safety invariant
* no double-finality
* no invalid state transitions
* quorum correctness

### CI requirement
* `tlc2` must run on every commit
* failure = build failure

Add model outputs:
* invariant trace logs
* counterexample rejection logs
* liveness verification outputs

## 6. SECURITY TRANSITION PHASES

**Phase 1 — Isolation (Safe)**
* introduce real crypto interfaces
* keep simulation in dev only

**Phase 2 — Replacement**
* ZK engine replaced
* PBFT verifier replaced
* Merkle enforcement added

**Phase 3 — Enforcement**
* CI blocks all mocks
* formal verification required
* no bypass paths allowed

**Phase 4 — External validation**
* independent audit readiness
* reproducible builds
* witness publication

## 7. FINAL SYSTEM GUARANTEE MODEL
After migration, SWI should satisfy:

**Cryptographic guarantees**
* correctness via ZK proofs
* authenticity via signatures
* integrity via Merkle roots

**Consensus guarantees**
* PBFT finality under Byzantine conditions
* deterministic block finalization

**Verification guarantees**
* machine-checkable formal model (TLA+)
* CI-enforced invariants
* reproducible audit artifacts

## 8. RISK REDUCTION OUTCOME
After full migration:

| Area | Before | After |
| :--- | :--- | :--- |
| ZK system | simulated | cryptographically valid |
| PBFT | mocked | Byzantine-secure |
| Merkle state | partial | enforced invariant |
| Trust flags | present | eliminated |
| Formal methods | passive | CI-enforced |
