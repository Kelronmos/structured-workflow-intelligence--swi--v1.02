# Known Limitations

- **Simulated ZK**: Currently relies on `ZkSnarkRangeProofMock`. The real zero-knowledge circuits (Noir/Arkworks) are pending.
- **Node Sync**: Dependent on local memory and Kafka (if connected). Full distributed consensus requires 4+ nodes.
- **Graph Dependencies**: Modules 16-20 added to process graph execution but real trace logic within them is simplified.
