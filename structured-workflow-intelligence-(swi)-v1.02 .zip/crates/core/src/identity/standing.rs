use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct SecurityStanding {
    pub score: f32,
    pub level: String,
}
