use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PlatformIdentity {
    pub platform_name: String,
    pub version: String,
    pub build: String,
    pub git_commit: String,
    pub environment: String,
    pub security_standing: f32,
    pub truth_kernel_hash: String,
    pub policy_version: String,
}
