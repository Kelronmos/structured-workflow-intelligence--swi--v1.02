use serde::{Deserialize, Serialize};
use uuid::Uuid;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ReplayId(pub String);

impl ReplayId {
    pub fn new() -> Self { Self(Uuid::new_v4().to_string()) }
}
