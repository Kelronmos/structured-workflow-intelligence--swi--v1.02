pub trait Replayable {
    fn replay(&self) -> Result<(), crate::errors::SWIError>;
}
