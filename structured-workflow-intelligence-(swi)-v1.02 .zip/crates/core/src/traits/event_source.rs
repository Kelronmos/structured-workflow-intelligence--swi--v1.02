pub trait EventSource {
    fn emit(&self) -> String;
}
