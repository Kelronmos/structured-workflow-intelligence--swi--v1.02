pub trait Auditable {
    fn to_audit_event(&self) -> String;
}
