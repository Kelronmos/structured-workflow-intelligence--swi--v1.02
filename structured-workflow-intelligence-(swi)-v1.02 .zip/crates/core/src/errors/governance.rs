use serde::{Deserialize, Serialize};
use thiserror::Error;
use super::ErrorContext;

#[derive(Error, Debug, Serialize, Deserialize)]
#[error("Governance Error: {message}")]
pub struct GovernanceError {
    pub message: String,
    pub context: ErrorContext,
}
