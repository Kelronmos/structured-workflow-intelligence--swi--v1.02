use serde::{Deserialize, Serialize};
use thiserror::Error;
use super::ErrorContext;

#[derive(Error, Debug, Serialize, Deserialize)]
#[error("Audit Error: {message}")]
pub struct AuditError {
    pub message: String,
    pub context: ErrorContext,
}
