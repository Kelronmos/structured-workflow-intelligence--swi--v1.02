pub mod governance;
pub mod audit;
pub mod security;
pub mod validation;

use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ErrorContext {
    pub timestamp: i64,
    pub module: String,
    pub severity: u8,
    pub evidence_id: Option<String>,
    pub replay_id: Option<String>,
}

#[derive(Error, Debug, Serialize, Deserialize)]
pub enum SWIError {
    #[error(transparent)]
    Governance(#[from] governance::GovernanceError),
    #[error(transparent)]
    Audit(#[from] audit::AuditError),
    #[error(transparent)]
    Security(#[from] security::SecurityError),
    #[error(transparent)]
    Validation(#[from] validation::ValidationError),
}
