use serde::{Deserialize, Serialize};
use thiserror::Error;
use super::ErrorContext;

#[derive(Error, Debug, Serialize, Deserialize)]
#[error("Security Error: {message}")]
pub struct SecurityError {
    pub message: String,
    pub context: ErrorContext,
}
