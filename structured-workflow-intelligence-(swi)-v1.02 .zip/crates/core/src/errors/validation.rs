use serde::{Deserialize, Serialize};
use thiserror::Error;
use super::ErrorContext;

#[derive(Error, Debug, Serialize, Deserialize)]
#[error("Validation Error: {message}")]
pub struct ValidationError {
    pub message: String,
    pub context: ErrorContext,
}
