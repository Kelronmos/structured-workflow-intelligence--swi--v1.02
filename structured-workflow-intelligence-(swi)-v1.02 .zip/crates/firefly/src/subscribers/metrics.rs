use crate::bus::subscriber::Subscriber;
use crate::events::FireflyEvent;
use crate::metrics::engine::MetricsEngine;
use async_trait::async_trait;
use serde_json::Value;
use std::sync::Arc;

pub struct MetricsSubscriber {
    engine: Arc<MetricsEngine>,
}

impl MetricsSubscriber {
    pub fn new(engine: Arc<MetricsEngine>) -> Self {
        Self { engine }
    }
}

#[async_trait]
impl Subscriber for MetricsSubscriber {
    fn id(&self) -> &str {
        "metrics_subscriber"
    }

    fn subscribe(&self) -> Vec<String> {
        vec!["*".to_string()]
    }

    async fn handle(&self, event: &FireflyEvent<Value>) -> Result<(), crate::bus::event_bus::BusError> {
        self.engine.record_event();
        if event.event_type == "PromptRejected" {
            self.engine.record_refusal();
        }
        Ok(())
    }
}
