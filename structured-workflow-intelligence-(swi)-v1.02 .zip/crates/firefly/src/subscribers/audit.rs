use crate::bus::subscriber::Subscriber;
use crate::events::FireflyEvent;
use async_trait::async_trait;
use serde_json::Value;
use logging::structured::log_info;

pub struct AuditSubscriber;

#[async_trait]
impl Subscriber for AuditSubscriber {
    fn id(&self) -> &str {
        "audit_subscriber"
    }

    fn subscribe(&self) -> Vec<String> {
        vec!["*".to_string()] // Subscribe to all events
    }

    async fn handle(&self, event: &FireflyEvent<Value>) -> Result<(), crate::bus::event_bus::BusError> {
        log_info(
            &event.module,
            &format!("Event received: {} ({})", event.event_id, event.event_type),
            Some(event.clone())
        );
        Ok(())
    }
}
