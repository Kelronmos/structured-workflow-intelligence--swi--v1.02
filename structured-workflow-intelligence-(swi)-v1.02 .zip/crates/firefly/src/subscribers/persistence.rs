use crate::bus::subscriber::Subscriber;
use crate::events::FireflyEvent;
use crate::persistence::append_only::AppendOnlyStore;
use async_trait::async_trait;
use serde_json::Value;
use std::sync::Arc;
use storage::traits::Repository;

pub struct PersistenceSubscriber {
    store: Arc<AppendOnlyStore>,
}

impl PersistenceSubscriber {
    pub fn new(store: Arc<AppendOnlyStore>) -> Self {
        Self { store }
    }
}

#[async_trait]
impl Subscriber for PersistenceSubscriber {
    fn id(&self) -> &str {
        "persistence_subscriber"
    }

    fn subscribe(&self) -> Vec<String> {
        vec!["*".to_string()]
    }

    async fn handle(&self, event: &FireflyEvent<Value>) -> Result<(), crate::bus::event_bus::BusError> {
        let _ = self.store.save(&event.event_id, event.clone()).await;
        Ok(())
    }
}
