use crate::events::FireflyEvent;
use serde_json::Value;
use std::sync::Arc;
use tokio::sync::Mutex;
use storage::traits::{Repository, StorageError};
use async_trait::async_trait;

// In a real implementation this would write to a database or append-only file
pub struct AppendOnlyStore {
    events: Arc<Mutex<Vec<FireflyEvent<Value>>>>,
}

impl AppendOnlyStore {
    pub fn new() -> Self {
        Self {
            events: Arc::new(Mutex::new(Vec::new())),
        }
    }

    pub async fn append(&self, event: &FireflyEvent<Value>) {
        let mut events = self.events.lock().await;
        events.push(event.clone());
    }

    pub async fn get_all(&self) -> Vec<FireflyEvent<Value>> {
        let events = self.events.lock().await;
        events.clone()
    }
}

#[async_trait]
impl Repository<FireflyEvent<Value>> for AppendOnlyStore {
    async fn get(&self, id: &str) -> Result<Option<FireflyEvent<Value>>, StorageError> {
        let events = self.events.lock().await;
        Ok(events.iter().find(|e| e.event_id == id).cloned())
    }

    async fn save(&self, _id: &str, item: FireflyEvent<Value>) -> Result<(), StorageError> {
        self.append(&item).await;
        Ok(())
    }

    async fn delete(&self, _id: &str) -> Result<(), StorageError> {
        Err(StorageError::Backend("AppendOnlyStore does not support deletion".into()))
    }
}
