pub mod evidence;
pub mod policy;
pub mod replay;
pub mod audit;
pub mod drift;
pub mod certification;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FireflyEvent<T> {
    pub event_id: String,
    pub timestamp: i64,
    pub module: String,
    pub event_type: String,
    pub payload: T,
    pub correlation_id: Option<String>,
    pub causation_id: Option<String>,
    pub parent_event_id: Option<String>,
    pub evidence_id: Option<String>,
    pub replay_id: Option<String>,
    pub trace_id: Option<String>,
    pub severity: u8,
    pub signature: Option<String>,
}
