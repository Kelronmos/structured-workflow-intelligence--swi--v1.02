use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplayCompleted {
    pub trace_id: String,
    pub success: bool,
    pub match_score: f32,
}
