use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CertificationIssued {
    pub cert_id: String,
    pub level: String,
}
