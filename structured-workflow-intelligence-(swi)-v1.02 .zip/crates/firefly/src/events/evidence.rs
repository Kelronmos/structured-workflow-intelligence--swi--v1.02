use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvidenceCreated {
    pub source: String,
    pub data_hash: String,
}
