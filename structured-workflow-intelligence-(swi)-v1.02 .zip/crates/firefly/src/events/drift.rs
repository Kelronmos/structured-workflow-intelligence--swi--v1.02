use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DriftDetected {
    pub expected_hash: String,
    pub actual_hash: String,
    pub deviation_score: f32,
}
