use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use tokio::sync::RwLock;

pub struct MetricsEngine {
    pub total_events: AtomicUsize,
    pub replay_queue: AtomicUsize,
    pub refusals: AtomicUsize,
    pub warnings: AtomicUsize,
    pub errors: AtomicUsize,
    
    // Using RwLock for floats or more complex types
    pub current_drift: Arc<RwLock<f32>>,
    pub average_drift: Arc<RwLock<f32>>,
    pub security_standing: Arc<RwLock<f32>>,
    pub integrity_score: Arc<RwLock<f32>>,
}

impl MetricsEngine {
    pub fn new() -> Self {
        Self {
            total_events: AtomicUsize::new(0),
            replay_queue: AtomicUsize::new(0),
            refusals: AtomicUsize::new(0),
            warnings: AtomicUsize::new(0),
            errors: AtomicUsize::new(0),
            
            current_drift: Arc::new(RwLock::new(0.0)),
            average_drift: Arc::new(RwLock::new(0.0)),
            security_standing: Arc::new(RwLock::new(1.0)),
            integrity_score: Arc::new(RwLock::new(1.0)),
        }
    }

    pub fn record_event(&self) {
        self.total_events.fetch_add(1, Ordering::Relaxed);
    }

    pub fn record_refusal(&self) {
        self.refusals.fetch_add(1, Ordering::Relaxed);
    }
}
