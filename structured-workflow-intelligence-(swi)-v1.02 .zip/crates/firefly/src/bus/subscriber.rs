use crate::events::FireflyEvent;
use async_trait::async_trait;
use serde_json::Value;

#[async_trait]
pub trait Subscriber: Send + Sync {
    fn id(&self) -> &str;
    fn subscribe(&self) -> Vec<String>; // Return list of event_types to subscribe to
    async fn handle(&self, event: &FireflyEvent<Value>) -> Result<(), crate::bus::event_bus::BusError>;
}
