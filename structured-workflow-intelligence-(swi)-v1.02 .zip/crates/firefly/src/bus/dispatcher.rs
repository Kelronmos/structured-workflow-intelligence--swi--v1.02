// Dispatcher pattern implementation where producers interact with dispatcher
// which then publishes to the bus.

use crate::bus::event_bus::FireflyBus;
use crate::events::FireflyEvent;
use serde::Serialize;
use std::sync::Arc;

pub struct EventDispatcher {
    bus: Arc<FireflyBus>,
}

impl EventDispatcher {
    pub fn new(bus: Arc<FireflyBus>) -> Self {
        Self { bus }
    }

    pub async fn dispatch<T: Serialize>(&self, event: FireflyEvent<T>) -> Result<(), crate::bus::event_bus::BusError> {
        self.bus.publish(event).await
    }
}
