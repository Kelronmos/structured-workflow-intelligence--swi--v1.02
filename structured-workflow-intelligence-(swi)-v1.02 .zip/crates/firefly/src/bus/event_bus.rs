use crate::bus::registry::SubscriberRegistry;
use crate::events::FireflyEvent;
use serde::Serialize;
use serde_json::Value;
use std::sync::Arc;
use thiserror::Error;
use uuid::Uuid;
use chrono::Utc;

#[derive(Error, Debug)]
pub enum BusError {
    #[error("Serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    #[error("Handler error: {0}")]
    Handler(String),
}

pub struct FireflyBus {
    pub registry: Arc<SubscriberRegistry>,
}

impl FireflyBus {
    pub fn new() -> Self {
        Self {
            registry: Arc::new(SubscriberRegistry::new()),
        }
    }

    pub async fn publish<T: Serialize>(&self, mut event: FireflyEvent<T>) -> Result<(), BusError> {
        if event.event_id.is_empty() {
            event.event_id = Uuid::new_v4().to_string();
        }
        if event.timestamp == 0 {
            event.timestamp = Utc::now().timestamp_millis();
        }

        let payload_value = serde_json::to_value(&event.payload)?;
        let generic_event = FireflyEvent {
            event_id: event.event_id.clone(),
            timestamp: event.timestamp,
            module: event.module.clone(),
            event_type: event.event_type.clone(),
            payload: payload_value,
            correlation_id: event.correlation_id.clone(),
            causation_id: event.causation_id.clone(),
            parent_event_id: event.parent_event_id.clone(),
            evidence_id: event.evidence_id.clone(),
            replay_id: event.replay_id.clone(),
            trace_id: event.trace_id.clone(),
            severity: event.severity,
            signature: event.signature.clone(),
        };

        let subscribers = self.registry.get_subscribers(&generic_event.event_type).await;
        for subscriber in subscribers {
            if let Err(e) = subscriber.handle(&generic_event).await {
                eprintln!("Error handling event by subscriber {}: {:?}", subscriber.id(), e);
            }
        }

        Ok(())
    }
}
