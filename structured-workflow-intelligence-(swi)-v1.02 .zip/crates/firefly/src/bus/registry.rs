use crate::bus::subscriber::Subscriber;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;

pub struct SubscriberRegistry {
    subscribers: Arc<RwLock<HashMap<String, Vec<Arc<dyn Subscriber>>>>>,
}

impl SubscriberRegistry {
    pub fn new() -> Self {
        Self {
            subscribers: Arc::new(RwLock::new(HashMap::new())),
        }
    }

    pub async fn register(&self, subscriber: Arc<dyn Subscriber>) {
        let mut subs = self.subscribers.write().await;
        for event_type in subscriber.subscribe() {
            subs.entry(event_type).or_insert_with(Vec::new).push(subscriber.clone());
        }
    }

    pub async fn get_subscribers(&self, event_type: &str) -> Vec<Arc<dyn Subscriber>> {
        let subs = self.subscribers.read().await;
        let mut result = subs.get(event_type).cloned().unwrap_or_default();
        if let Some(catch_all) = subs.get("*") {
            result.extend(catch_all.iter().cloned());
        }
        result
    }
}
