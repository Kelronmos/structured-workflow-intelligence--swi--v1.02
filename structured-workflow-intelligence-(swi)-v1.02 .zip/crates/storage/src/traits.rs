use async_trait::async_trait;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum StorageError {
    #[error("Not found")]
    NotFound,
    #[error("Backend error: {0}")]
    Backend(String),
}

#[async_trait]
pub trait Repository<T> {
    async fn get(&self, id: &str) -> Result<Option<T>, StorageError>;
    async fn save(&self, id: &str, item: T) -> Result<(), StorageError>;
    async fn delete(&self, id: &str) -> Result<(), StorageError>;
}
