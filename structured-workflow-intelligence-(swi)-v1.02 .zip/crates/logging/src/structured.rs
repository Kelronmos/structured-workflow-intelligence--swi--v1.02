use serde::Serialize;
use chrono::Utc;

#[derive(Debug, Serialize)]
pub struct LogEntry<T> {
    pub timestamp: String,
    pub level: String,
    pub module: String,
    pub message: String,
    pub payload: Option<T>,
}

pub fn log_info<T: Serialize>(module: &str, message: &str, payload: Option<T>) {
    let entry = LogEntry {
        timestamp: Utc::now().to_rfc3339(),
        level: "INFO".to_string(),
        module: module.to_string(),
        message: message.to_string(),
        payload,
    };
    if let Ok(json) = serde_json::to_string(&entry) {
        println!("{}", json);
    }
}
