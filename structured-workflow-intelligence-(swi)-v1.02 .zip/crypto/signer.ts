import crypto from "crypto";
import fs from "fs";
import path from "path";

// Assuming keys are in /keys/ relative to root, 
// if not, adjust the path to wherever the keys are.
const privateKeyPath = path.join(process.cwd(), "swi-core", "keys", "private.pem");

export function sign(data: string) {
  if (!fs.existsSync(privateKeyPath)) {
    throw new Error("Private key not found at " + privateKeyPath);
  }
  const privateKey = fs.readFileSync(privateKeyPath);
  const signer = crypto.createSign("RSA-SHA256");
  signer.update(data);
  return signer.sign(privateKey, "hex");
}
