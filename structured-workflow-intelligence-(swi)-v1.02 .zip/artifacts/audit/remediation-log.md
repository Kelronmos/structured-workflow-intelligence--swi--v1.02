# Remediation Log
- Replaced Mock SNARK verifier with Groth16.
- Introduced real signatures.