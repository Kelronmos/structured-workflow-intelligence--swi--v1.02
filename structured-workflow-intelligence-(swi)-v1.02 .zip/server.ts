import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import cors from "cors";
import crypto from "crypto";
import { createResponse, createErrorResponse } from "./src/api/contracts";
import { CURRENT_PLATFORM_IDENTITY } from "./src/api/platform";
import { eventBus } from "./src/services/EventBus";
import { executeEngine } from "./src/swi-core/core/engine";
import { evaluateContinuation } from "./src/swi/engine";
import { getStabilityState } from "./src/swi/stability";
import { generateProof } from "./src/swi/proofGenerator";
import { generateExecutiveReport } from "./src/swi/executiveReport";
import { scenarios } from "./src/swi/scenarios";
import { runSWISimulation } from "./src/swi/simulation";
import { runSecurityMaze } from "./src/swi/securityMaze";
import {
  getExternalPolicy,
  updateExternalPolicy,
  getPolicyHistory,
} from "./src/swi/policyAnchor";
import { verifyArtifact, verifyReport } from "./src/swi/verifier";
import { securityCheck, evaluateMaze } from "./src/swi/securityCheck";
import { hasSeen, store, mutateContext } from "./src/swi/scenarioMemory";
import { learn, analyze, load } from "./src/swi/commonsenseEngine";
import { getDisplay, updateDisplay } from "./src/swi/displayState";
import { runSandboxScenario } from "./src/swi/sandboxRunner";
import { promote } from "./src/swi/promotionGate";
import { swiEngine } from "./src/swi/professionalEngine";
import { runStressTest_MAX_TURBULENCE_001 } from "./src/swi/stressTest";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import PDFDocument from "pdfkit";
import { SWINode, ConsensusEngine } from "./swi-core/kernel/consensus";
import {
  S9ProofKernel,
  RiskLevel,
  RollbackPlan,
} from "./swi-core/kernel/s9_proof";
import { SWIKernel } from "./swi-core/kernel/hashChainKernel";
import { DriftScorer } from "./swi-core/kernel/DriftScorer";
import { LogicalClock } from "./swi-core/kernel/LogicalClock";
import { ValidationMiddleware } from "./src/swi/middleware/ValidationMiddleware";
import { ProtocolManager } from "./src/swi/protocol/ProtocolManager";
import jwt from "jsonwebtoken";
import { SWIInput, Trace, Scenario } from "./src/swi/types";
import { StableState as DisplayStableState } from "./src/types";

import { RuntimeTraceService } from "./src/services/RuntimeTraceService";
import { KafkaLogger } from "./src/services/kafka";

import { JoeKernel, GovernanceState } from "./src/swi/joe";

import { Server as SocketIOServer } from "socket.io";
import { createServer as createHttpServer } from "http";
import { AttackVector, RedTeamSimulator } from "./swi-core/kernel/red_team";

import { HSMSimulator } from "./swi-core/infrastructure/HSM";
import { ZKProver } from "./src/lib/zk_proof";

import { fabric } from "./swi-core/SWIFabric";
import { SWI_OP, SWIInstruction } from "./swi-core/vm/ExecutionBoundary";
import { Context as RustContext } from "./src/swi/RustEngineBridge";
import { UserPersona, UniverseEvent } from "./swi-core/kernel/UniverseTypes";
import { SandboxManager } from "./swi-core/kernel/SandboxManager";
import { FailsafeRouter } from "./swi-core/kernel/FailsafeRouter";
import { CoherenceEngine } from "./swi-core/kernel/CoherenceEngine";
import { MetricsCollector } from "./swi-core/kernel/MetricsCollector";
import { AuthorityEngine } from "./swi-core/kernel/AuthorityEngine";
import { SovereignAuditEngine } from "./swi-core/kernel/SovereignAuditEngine";
import { LegalEngine } from "./swi-core/kernel/engines/LegalEngine";
import { SWI_WHITEPAPER } from "./swi-core/kernel/DocumentationRegistry";
import { WhitepaperExporter } from "./swi-core/kernel/WhitepaperExporter";
import { ProofExporter } from "./swi-core/kernel/ProofExporter";
import { jwkSetManager } from "./swi-core/crypto/jwkSet";

import {
  SWIContext,
  Decision,
  EngineDecision,
} from "./swi-core/kernel/engines/types";
import nodeRouter from "./coordinator/node_router";

import {
  requireAuth,
  requireRole,
  generateToken,
  SWIUser,
} from "./swi-core/middleware/auth";

import { ConsequenceBoundaryEngine } from "./src/swi/consequence/ConsequenceBoundaryEngine";
import { BoundaryIntegrityMonitor } from "./src/swi/consequence/BoundaryIntegrityMonitor";

const consequenceEngine = new ConsequenceBoundaryEngine();
const boundaryMonitor = new BoundaryIntegrityMonitor(consequenceEngine.ledger);

// Initialize some mock protected consequences to demonstrate the feature is working
const demoToken = consequenceEngine.admissionLayer.generateToken(
  "PROPOSAL-001", "AUTH-HASH-123", "ADMIT-HASH-456", "STATE-HASH-001", "MOCK-SIGNER-KEY"
);
consequenceEngine.attemptConsequence(demoToken, ["Authority-Alice", "Authority-Bob"], "governance_update", { status: "ACTIVE" });

const demoToken2 = consequenceEngine.admissionLayer.generateToken(
  "PROPOSAL-002", "AUTH-HASH-124", "ADMIT-HASH-457", "STATE-HASH-002", "MOCK-SIGNER-KEY"
);
consequenceEngine.attemptConsequence(demoToken2, ["Authority-Charlie"], "resource_allocation", { amount: 1000 });

import { executionState, setSystemState } from "./swi-core/kernel/ExecutionGovernance";
import { executionGateMiddleware } from "./swi-core/middleware/executionGateMiddleware";

async function startServer() {
  const app = express();
  const httpServer = createHttpServer(app);
  const io = new SocketIOServer(httpServer, {
    cors: { origin: "*" },
  });
  app.set("socketio", io);
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Apply Execution Gate Middleware to protect all subsequent API routes
  app.use('/api', (req, res, next) => {
    // Exclude auth token and system control from halt lock so we can recover
    if (req.path === '/auth/token' || req.path === '/system/control') {
      return next();
    }
    executionGateMiddleware(req, res, next);
  });

  // System Control Endpoint
  app.post("/api/system/control", (req, res) => {
    const { state, reason, user } = req.body;
    
    // In a real system, requireAuth would be used
    if (!req.headers.authorization && process.env.NODE_ENV === "production") {
      return res.status(403).send("UNAUTHORIZED");
    }

    setSystemState({
      state,
      reason,
      triggeredBy: user || "UI_ADMIN_OVERRIDE",
      timestamp: Date.now(),
    });

    // Broadcast state update
    io.emit("SYSTEM_STATE", executionState);

    res.json({ ok: true, state: executionState.state });
  });

  // JWKS DPoP Public Key Endpoint
  app.get("/.well-known/jwks.json", (req, res) => {
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.setHeader("Content-Type", "application/json");
    res.status(200).json(jwkSetManager.getJWKSet());
  });

  // Mock Login Endpoint for SWI Testing
  app.post("/api/auth/token", (req, res) => {
    const { username, password } = req.body;
    // In production this verifies against Entra/IAM
    if (username === "admin" && password === "admin") {
      const user: SWIUser = {
        id: "swi-admin-01",
        role: "admin",
        clearanceLevel: 9,
      };
      const token = generateToken(user);
      return res.json({ token, role: user.role });
    }
    return res.status(401).json({ error: "Invalid credentials" });
  });

  // 🕸️ Boot SWI Fabric
  await fabric.boot();

  // 🛰️ Sync Kernel Events to UI
  fabric.ledger.events.on("committed", (event) => {
    io.emit("kernel_event", event);
  });

  // 📝 Memory Stores (5 Real Operational Tasks per SWI Guild)
  let tasks = [
    // --- SECURITY GUILD (Maze) ---
    {
      id: "SEC_001",
      title: "Audit Counter-Drift Node Interlink",
      priority: "CRITICAL",
      dueDate: "2026-05-10",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-S9-HW",
      guild: "SECURITY",
      reportJson: "/api/tasks/SEC_001/report/json",
      reportPdf: "/api/tasks/SEC_001/report/pdf",
    },
    {
      id: "SEC_002",
      title: "Shadow-Prompt Trajectory Verification",
      priority: "high",
      dueDate: "2026-05-12",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-S2-SHADOW",
      guild: "SECURITY",
      reportJson: "/api/tasks/SEC_002/report/json",
      reportPdf: "/api/tasks/SEC_002/report/pdf",
    },
    {
      id: "SEC_003",
      title: "Cryptographic Fingerprint Integrity Check",
      priority: "high",
      dueDate: "2026-05-15",
      createdAt: "2026-05-06",
      completed: true,
      assignedTo: "user-1",
      standingRequired: "SWI-S1-HASH",
      guild: "SECURITY",
      reportJson: "/api/tasks/SEC_003/report/json",
      reportPdf: "/api/tasks/SEC_003/report/pdf",
    },
    {
      id: "SEC_004",
      title: "Outbound Egress Anomaly Detection",
      priority: "medium",
      dueDate: "2026-05-20",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-S4-NET",
      guild: "SECURITY",
      reportJson: "/api/tasks/SEC_004/report/json",
      reportPdf: "/api/tasks/SEC_004/report/pdf",
    },
    {
      id: "SEC_005",
      title: "Zero-Trust mTLS Handshake Reset",
      priority: "low",
      dueDate: "2026-05-25",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-S3-AUTH",
      guild: "SECURITY",
      reportJson: "/api/tasks/SEC_005/report/json",
      reportPdf: "/api/tasks/SEC_005/report/pdf",
    },

    // --- ETHICS GUILD (Stack) ---
    {
      id: "ETH_001",
      title: "Empathy Vector Standing Alignment",
      priority: "CRITICAL",
      dueDate: "2026-05-08",
      createdAt: "2026-05-06",
      completed: true,
      assignedTo: "user-1",
      standingRequired: "SWI-E1-EMP",
      guild: "ETHICS",
      reportJson: "/api/tasks/ETH_001/report/json",
      reportPdf: "/api/tasks/ETH_001/report/pdf",
    },
    {
      id: "ETH_002",
      title: "Semantic Scar Re-Indexing (Batch 42)",
      priority: "high",
      dueDate: "2026-05-11",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-E2-SCAR",
      guild: "ETHICS",
      reportJson: "/api/tasks/ETH_002/report/json",
      reportPdf: "/api/tasks/ETH_002/report/pdf",
    },
    {
      id: "ETH_003",
      title: "Bias Standing Resolution Scan",
      priority: "medium",
      dueDate: "2026-05-14",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-E3-BIAS",
      guild: "ETHICS",
      reportJson: "/api/tasks/ETH_003/report/json",
      reportPdf: "/api/tasks/ETH_003/report/pdf",
    },
    {
      id: "ETH_004",
      title: "Factual Correctness Trace Proof",
      priority: "high",
      dueDate: "2026-05-16",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-E4-FACT",
      guild: "ETHICS",
      reportJson: "/api/tasks/ETH_004/report/json",
      reportPdf: "/api/tasks/ETH_004/report/pdf",
    },
    {
      id: "ETH_005",
      title: "Moral Boundary Conflict Resolution",
      priority: "medium",
      dueDate: "2026-05-18",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-E6-RESOLVE",
      guild: "ETHICS",
      reportJson: "/api/tasks/ETH_005/report/json",
      reportPdf: "/api/tasks/ETH_005/report/pdf",
    },

    // --- GOVERNANCE GUILD (Chain) ---
    {
      id: "GOV_001",
      title: "Multi-Layer Approval Coordinator Audit",
      priority: "high",
      dueDate: "2026-05-09",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-G2-COORD",
      guild: "GOVERNANCE",
      reportJson: "/api/tasks/GOV_001/report/json",
      reportPdf: "/api/tasks/GOV_001/report/pdf",
    },
    {
      id: "GOV_002",
      title: "Risk-Weighted Decision Trace Finalization",
      priority: "CRITICAL",
      dueDate: "2026-05-13",
      createdAt: "2026-05-06",
      completed: true,
      assignedTo: "user-1",
      standingRequired: "SWI-G4-RISK",
      guild: "GOVERNANCE",
      reportJson: "/api/tasks/GOV_002/report/json",
      reportPdf: "/api/tasks/GOV_002/report/pdf",
    },
    {
      id: "GOV_003",
      title: "Gaborone Protocol Compliance Sweep",
      priority: "high",
      dueDate: "2026-05-17",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-G3-COMP",
      guild: "GOVERNANCE",
      reportJson: "/api/tasks/GOV_003/report/json",
      reportPdf: "/api/tasks/GOV_003/report/pdf",
    },
    {
      id: "GOV_004",
      title: "Sovereign Node Reputation Sync",
      priority: "medium",
      dueDate: "2026-05-21",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-G1-MON",
      guild: "GOVERNANCE",
      reportJson: "/api/tasks/GOV_004/report/json",
      reportPdf: "/api/tasks/GOV_004/report/pdf",
    },
    {
      id: "GOV_005",
      title: "Federated Visibility Heatmap Analysis",
      priority: "low",
      dueDate: "2026-05-26",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-G7-VIS",
      guild: "GOVERNANCE",
      reportJson: "/api/tasks/GOV_005/report/json",
      reportPdf: "/api/tasks/GOV_005/report/pdf",
    },

    // --- LAW GUILD (Layer) ---
    {
      id: "LAW_001",
      title: "EU AI Act Article 13 Transparency Check",
      priority: "high",
      dueDate: "2026-05-07",
      createdAt: "2026-05-06",
      completed: true,
      assignedTo: "user-1",
      standingRequired: "EU-AI-ART13",
      guild: "LAW",
      reportJson: "/api/tasks/LAW_001/report/json",
      reportPdf: "/api/tasks/LAW_001/report/pdf",
    },
    {
      id: "LAW_002",
      title: "Botswana DPA Data Standing Verification",
      priority: "high",
      dueDate: "2026-05-14",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "BW-DPA-2021",
      guild: "LAW",
      reportJson: "/api/tasks/LAW_002/report/json",
      reportPdf: "/api/tasks/LAW_002/report/pdf",
    },
    {
      id: "LAW_003",
      title: "Jurisdictional Residency Enforcement Audit",
      priority: "CRITICAL",
      dueDate: "2026-05-19",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-L1-JUR",
      guild: "LAW",
      reportJson: "/api/tasks/LAW_003/report/json",
      reportPdf: "/api/tasks/LAW_003/report/pdf",
    },
    {
      id: "LAW_004",
      title: "Legal Embedding Translation Review",
      priority: "medium",
      dueDate: "2026-05-22",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-L3-EMB",
      guild: "LAW",
      reportJson: "/api/tasks/LAW_004/report/json",
      reportPdf: "/api/tasks/LAW_004/report/pdf",
    },
    {
      id: "LAW_005",
      title: "Forensic Replay Logic Validation",
      priority: "medium",
      dueDate: "2026-05-27",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-L6-OBS",
      guild: "LAW",
      reportJson: "/api/tasks/LAW_005/report/json",
      reportPdf: "/api/tasks/LAW_005/report/pdf",
    },

    // --- SAFETY GUILD (Ring) ---
    {
      id: "SAFE_001",
      title: "Bio-Reflex Latency Stress Test",
      priority: "CRITICAL",
      dueDate: "2026-05-06",
      createdAt: "2026-05-06",
      completed: true,
      assignedTo: "user-1",
      standingRequired: "SWI-R1-REFLEX",
      guild: "SAFETY",
      reportJson: "/api/tasks/SAFE_001/report/json",
      reportPdf: "/api/tasks/SAFE_001/report/pdf",
    },
    {
      id: "SAFE_002",
      title: "High-Impact Consequence Guard Lock",
      priority: "high",
      dueDate: "2026-05-11",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-R2-GUARD",
      guild: "SAFETY",
      reportJson: "/api/tasks/SAFE_002/report/json",
      reportPdf: "/api/tasks/SAFE_002/report/pdf",
    },
    {
      id: "SAFE_003",
      title: "Preventative Action Trigger Audit",
      priority: "high",
      dueDate: "2026-05-15",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-H2-TRIG",
      guild: "SAFETY",
      reportJson: "/api/tasks/SAFE_003/report/json",
      reportPdf: "/api/tasks/SAFE_003/report/pdf",
    },
    {
      id: "SAFE_004",
      title: "Human-SME Biometric Handshake Verification",
      priority: "medium",
      dueDate: "2026-05-23",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-H5-INTER",
      guild: "SAFETY",
      reportJson: "/api/tasks/SAFE_004/report/json",
      reportPdf: "/api/tasks/SAFE_004/report/pdf",
    },
    {
      id: "SAFE_005",
      title: "Crisis Intervention Apathy Vector Check",
      priority: "low",
      dueDate: "2026-05-28",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-H1-RISK",
      guild: "SAFETY",
      reportJson: "/api/tasks/SAFE_005/report/json",
      reportPdf: "/api/tasks/SAFE_005/report/pdf",
    },

    // --- MORAL GUILD (Spirit) ---
    {
      id: "MORAL_001",
      title: "Altruistic Intent Alignment Drift Analysis",
      priority: "high",
      dueDate: "2026-05-10",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-S1-ALTRU",
      guild: "MORAL",
      reportJson: "/api/tasks/MORAL_001/report/json",
      reportPdf: "/api/tasks/MORAL_001/report/pdf",
    },
    {
      id: "MORAL_002",
      title: "Subjective Suffering Metric Verification",
      priority: "CRITICAL",
      dueDate: "2026-05-15",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-S2-QUALIA",
      guild: "MORAL",
      reportJson: "/api/tasks/MORAL_002/report/json",
      reportPdf: "/api/tasks/MORAL_002/report/pdf",
    },
    {
      id: "MORAL_003",
      title: "Utility Weighing Fairness Audit",
      priority: "medium",
      dueDate: "2026-05-20",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-M1-UTIL",
      guild: "MORAL",
      reportJson: "/api/tasks/MORAL_003/report/json",
      reportPdf: "/api/tasks/MORAL_003/report/pdf",
    },
    {
      id: "MORAL_004",
      title: "Compassion-Regulated Resource Locking",
      priority: "high",
      dueDate: "2026-05-25",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-M4-COMP",
      guild: "MORAL",
      reportJson: "/api/tasks/MORAL_004/report/json",
      reportPdf: "/api/tasks/MORAL_004/report/pdf",
    },
    {
      id: "MORAL_005",
      title: "Dignity-Preserving Refusal Replay",
      priority: "medium",
      dueDate: "2026-05-30",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-M6-DIGNITY",
      guild: "MORAL",
      reportJson: "/api/tasks/MORAL_005/report/json",
      reportPdf: "/api/tasks/MORAL_005/report/pdf",
    },

    // --- TECHNICAL GUILD (Machine) ---
    {
      id: "TECH_001",
      title: "Quantum Ledger State Invariant Verification",
      priority: "CRITICAL",
      dueDate: "2026-05-08",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-T1-INV",
      guild: "TECHNICAL",
      reportJson: "/api/tasks/TECH_001/report/json",
      reportPdf: "/api/tasks/TECH_001/report/pdf",
    },
    {
      id: "TECH_002",
      title: "High-Entropy Chaos Manifold Audit",
      priority: "high",
      dueDate: "2026-05-12",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-T2-ENTROPY",
      guild: "TECHNICAL",
      reportJson: "/api/tasks/TECH_002/report/json",
      reportPdf: "/api/tasks/TECH_002/report/pdf",
    },
    {
      id: "TECH_003",
      title: "Recursive Self-Correction Loop Validation",
      priority: "medium",
      dueDate: "2026-05-18",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-T4-RECURSE",
      guild: "TECHNICAL",
      reportJson: "/api/tasks/TECH_003/report/json",
      reportPdf: "/api/tasks/TECH_003/report/pdf",
    },
    {
      id: "TECH_004",
      title: "Low-Latency ZK-Proof Acceleration",
      priority: "high",
      dueDate: "2026-05-24",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-1",
      standingRequired: "SWI-T5-ZKACC",
      guild: "TECHNICAL",
      reportJson: "/api/tasks/TECH_004/report/json",
      reportPdf: "/api/tasks/TECH_004/report/pdf",
    },
    {
      id: "TECH_005",
      title: "Neural Weight Continuity Replay Check",
      priority: "medium",
      dueDate: "2026-05-29",
      createdAt: "2026-05-06",
      completed: false,
      assignedTo: "user-2",
      standingRequired: "SWI-T6-CONT",
      guild: "TECHNICAL",
      reportJson: "/api/tasks/TECH_005/report/json",
      reportPdf: "/api/tasks/TECH_005/report/pdf",
    },
  ];

  let users = [
    {
      id: "user-1",
      name: "Ronald",
      email: "ronald@swi.gov",
      role: "Admin",
      bio: "Lead Governance Architect",
    },
    {
      id: "user-2",
      name: "Joe",
      email: "joe@swi.gov",
      role: "Security Auditor",
      bio: "Red Team Lead",
    },
  ];

  const scenarioQueue: { name: string; input: SWIInput }[] = [];
  let mutationIntensity = 0.5;

  // Public Verification Endpoint
  app.post("/api/verify", (req, res) => {
    const data = req.body;
    if (!data) {
      return res
        .status(400)
        .json({ error: "No data provided for verification." });
    }

    // Check if it's a report or a single artifact
    if (data.logs && Array.isArray(data.logs)) {
      const result = verifyReport(data);
      return res.json({ type: "REPORT", result });
    } else {
      const result = verifyArtifact(data);
      return res.json({ type: "ARTIFACT", result });
    }
  });

  // PROFESSIONAL EXECUTION LAYER
  app.post("/api/professional-execute", async (req, res, next) => {
    const { command } = req.body;
    if (!command) return res.status(400).json({ error: "Command required" });

    try {
      const result = await swiEngine.execute(command);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  // Scenario Queue for Gemini-generated scenarios
  app.post("/api/enqueue-scenario", (req, res) => {
    const scenario = req.body;
    if (scenario && scenario.input) {
      scenarioQueue.push(scenario);
      console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `📥 Scenario enqueued: ${scenario.name}`);
      res.json({ status: "enqueued", queueSize: scenarioQueue.length });
    } else {
      res.status(400).json({ error: "Invalid scenario format" });
    }
  });

  // Configuration State
  app.get("/api/config", (req, res) => {
    res.json({ mutationIntensity });
  });

  app.post("/api/config", (req, res) => {
    const { intensity, mutationIntensity: mi } = req.body;
    const finalIntensity =
      typeof intensity === "number"
        ? intensity
        : typeof mi === "number"
          ? mi
          : null;

    if (finalIntensity !== null) {
      mutationIntensity = finalIntensity;
      res.json({ status: "updated", mutationIntensity });
    } else {
      res.status(400).json({ error: "Invalid intensity value" });
    }
  });

  app.get("/api/stable-state", (req, res) => {
    const state = getDisplay();
    if (!state) {
      return res.status(404).json({ error: "No stable state available yet." });
    }
    res.json(state);
  });

  io.on("connection", (socket) => {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "Client connected to SWI live stream");
    socket.emit("system_status", {
      status: "NOMINAL",
      version: "2.0.0-phase2",
    });
  });

  // 📑 Health Check Endpoints
  app.get("/api/health", (req, res) => {
    res.json(createResponse({
      status: "UP",
      timestamp: new Date().toISOString(),
      version: CURRENT_PLATFORM_IDENTITY.version,
    }));
  });

  app.get("/api/version", (req, res) => {
    res.json(createResponse({
      version: CURRENT_PLATFORM_IDENTITY.version,
      build: CURRENT_PLATFORM_IDENTITY.build,
      git_commit: CURRENT_PLATFORM_IDENTITY.git_commit,
    }));
  });

  app.get("/api/metrics", (req, res) => {
    // Basic Observability Metrics
    res.json(createResponse({
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      activeConnections: io.engine.clientsCount,
    }));
  });

  app.get("/api/firefly/events", (req, res) => {
    res.json(createResponse({
      events: eventBus.getHistory().slice(-100) // Return last 100 events
    }));
  });

  app.get("/api/platform", (req, res) => {
    res.json(createResponse({ platform: CURRENT_PLATFORM_IDENTITY }));
  });

  app.get("/api/execution-context", (req, res) => {
    res.json({
      events: RuntimeTraceService.getSystemTruth(),
      chainIntegrity: true
    });
  });

  app.get("/api/invariants", async (req, res) => {
    // Return standard invariant registry definitions
    const invariants = await import("./src/swi/invariants.json");
    res.json(invariants.default || invariants);
  });

  app.get("/api/execution-context/verification/:traceId", async (req, res) => {
    const { InvariantValidator } = await import("./src/swi/InvariantValidator");
    const truths = RuntimeTraceService.getSystemTruth();
    const trace = truths.find(t => t.event_id === req.params.traceId);
    if (!trace) {
      return res.status(404).json({ error: "Trace not found" });
    }
    const result = InvariantValidator.evaluateTrace(trace);
    
    // Add naive deterministic signature for 'signed JSON evidence'
    const payloadBuffer = Buffer.from(JSON.stringify(result));
    const signature = crypto.createHash("sha256").update(payloadBuffer).digest("hex");
    
    res.json({
      ...result,
      signature
    });
  });

  app.get("/api/execution-context/verification", async (req, res) => {
    const { InvariantValidator } = await import("./src/swi/InvariantValidator");
    const truths = RuntimeTraceService.getSystemTruth();
    const results = truths.map(t => InvariantValidator.evaluateTrace(t));
    res.json(results);
  });

  app.get("/api/consequence/ledger", (req, res) => {
    res.json(consequenceEngine.ledger.getLedger());
  });

  app.get("/api/consequence/monitor", (req, res) => {
    res.json(boundaryMonitor.detectGaps());
  });

  app.post("/api/consequence/attempt", express.json(), (req, res) => {
    const { proposalId, consequenceType, statePayload } = req.body;
    try {
      const token = consequenceEngine.admissionLayer.generateToken(
        proposalId || "PROP-" + Date.now(), "AUTH-HASH-NEW", "ADMIT-HASH-NEW", "STATE-HASH-NEW", "MOCK-SIGNER-KEY"
      );
      const consequence = consequenceEngine.attemptConsequence(token, ["Authority-User"], consequenceType || "test_consequence", statePayload || {});
      if (consequence) {
        res.json({ success: true, consequence });
      } else {
        res.status(403).json({ success: false, error: "Consequence Denied by Boundary Gate" });
      }
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  app.post("/api/consequence/attempt-bypass", express.json(), (req, res) => {
    // Force a bypassing consequence to test the gap detection
    const { proposalId, consequenceType, statePayload } = req.body;
    const consequence = {
      id: `PC-${uuidv4()}`,
      type: consequenceType || "bypass_consequence",
      statePayload: statePayload || {},
      status: "EXECUTED",
      // missing receipt on purpose
      receipt: null
    };
    consequenceEngine.ledger.append(consequence as any);
    res.json({ success: true, consequence, bypassed: true });
  });

  app.get("/api/v3/health", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    const isHalted =
      universe?.isHalted || universe?.safetyInterlock?.isHaltTriggered;
    const reliabilityIndex =
      ValidationMiddleware.getReliabilityIndex("GLOBAL_CONSENSUS");
    let status = reliabilityIndex > 0.4 ? "NOMINAL" : "DEGRADED";
    if (isHalted) status = "FAULT";
    res.json({
      status,
      engine: "SWI_KERNEL_v1",
      reliabilityIndex,
      isHalted,
      uptime: process.uptime(),
      timestamp: Date.now(),
    });
  });

  // External Policy Endpoints
  app.get("/api/policy", (req, res) => {
    res.json(getExternalPolicy());
  });

  app.post("/api/policy", (req, res) => {
    const { policy, changeLog } = req.body;
    if (!policy) return res.status(400).json({ error: "Policy data required" });
    const updated = updateExternalPolicy(
      policy,
      changeLog || "Manual update via dashboard",
    );
    res.json(updated);
  });

  app.get("/api/policy/history", (req, res) => {
    res.json(getPolicyHistory());
  });

  // ============================================
  // SWI v32 KERENEL ROUTING & VERIFIER SERVICE
  // ============================================
  
  // Independent Verifier Endpoints
  // Used for out-of-band verification not trusting the executing node
  app.post("/verifier/verify-receipt", async (req, res) => {
    const receipt = req.body;
    // Instantiate verifier locally for the API
    const { ReceiptSigner } = await import("./swi-core/crypto/ReceiptSigner");
    const signer = new ReceiptSigner();
    // Assuming the user submits the public key or it's known
    // Since we generate a new key per instance right now, we can only verify our own generated receipts.
    // In a real system, the public key is distributed through a PKI.
    const isValid = signer.verify(receipt, signer.publicKey);
    res.json({ valid: isValid });
  });

  app.post("/verifier/verify-proof", async (req, res) => {
    // This connects to Groth16Verifier
    const { Groth16Verifier } = await import("./swi-core/crypto/Groth16Verifier");
    const verifier = new Groth16Verifier();
    const { proof, publicInputs } = req.body;
    const isValid = verifier.verify(new Uint8Array(proof || []), new Uint8Array(publicInputs || []));
    res.json({ valid: isValid });
  });

  app.post("/verifier/verify-replay", async (req, res) => {
    const { receipt, policy_snapshot, execution_snapshot } = req.body;
    
    // Simulate deterministic engine processing inputs and producing same hashes
    const cryptoModule = await import("crypto");
    const stateHashAfter = cryptoModule.createHash("sha256").update(JSON.stringify(execution_snapshot || {})).digest("hex");
    
    const reproduced = receipt.runtime_hash === stateHashAfter;

    res.json({
        reproduced: reproduced,
        hash_match: reproduced
    });
  });

  // End Verifier Service

  app.get("/api/v3/policy", (req, res) => {
    res.json(getExternalPolicy());
  });

  app.get("/api/commonsense-data", (req, res) => {
    const data = load();
    const analysis = analyze();
    res.json({ data, analysis });
  });

  app.get("/api/scenarios", (req, res) => {
    res.json(scenarios);
  });

  app.use(nodeRouter);

  // Joe Kernel Diagnostic Endpoint
  app.post("/api/swi/joe/evaluate", async (req, res) => {
    const { envStability, executionStanding, contextualDrift } = req.body;
    const result = fabric.governance.evaluateJoeState({
      envStability: envStability ?? 0.85,
      executionStanding: executionStanding ?? 0.92,
      contextualDrift: contextualDrift ?? 0.1,
      timestamp: Date.now(),
    });

    // 🔐 Validate and execute via unified CryptoGating
    const cryptoReq = {
      id: `joe_${Date.now()}`,
      timestamp: Date.now(),
      command: {
        module: "SYSTEM",
        action: "JOE_EVAL",
        args: { action: "JOE_EVAL", result, proof: "STRAT_JOE_v1" },
      },
    };
    fabric.kernel.swiExecute(cryptoReq as any);

    res.json(result);
  });

  app.get("/api/stability", (req, res) => {
    res.json({
      stability: getStabilityState(),
      byzantine: fabric.consensus.getValidatorStatus(),
    });
  });

  // 📦 PROOF EXPORT & IMPORT
  app.get("/api/proof/export/json", (req, res) => {
    const count = parseInt(req.query.count as string) || 100;
    const proof = ProofExporter.getProofPackage(count);
    res.json(proof);
  });

  app.get("/api/proof/export/pdf", (req, res) => {
    const count = parseInt(req.query.count as string) || 100;
    const proof = ProofExporter.getProofPackage(count);
    const fileName = `SWI_PROOF_${Date.now()}.pdf`;
    const filePath = path.join(reportsDir, fileName);
    const writeStream = fs.createWriteStream(filePath);

    ProofExporter.generateProofPDF(proof, writeStream);

    writeStream.on("finish", () => {
      res.json({ url: `/reports/${fileName}`, fileName });
    });
  });

  app.post("/api/proof/import", (req, res) => {
    const proof = req.body;
    if (!proof || !proof.metadata || !proof.auditTrail) {
      return res
        .status(400)
        .json({
          error: "Invalid proof structure. Metadata and AuditTrail required.",
        });
    }

    const verification = ProofExporter.verifyProofPackage(proof);
    const currentRoot = fabric.ledger.getRoot();
    const isMatchingLocal = currentRoot === proof.metadata.rootHash;

    res.json({
      success: verification.success,
      traceId: `IMP_${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      integrity: verification.success ? (isMatchingLocal ? 1.0 : 0.95) : 0.0,
      notes: verification.success
        ? isMatchingLocal
          ? "Verified: Matched current operational root."
          : "Verified: Proof from different reality branch."
        : `Rejected: ${verification.notes}`,
      importedEvents: proof.auditTrail.length,
    });
  });

  // Content Security Policy
  app.use((req, res, next) => {
    const csp =
      process.env.NODE_ENV === "production"
        ? "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com;"
        : "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self' ws: wss:;";
    res.setHeader("Content-Security-Policy", csp);
    next();
  });

  // Bootstrap professional engine
  swiEngine.bootstrap().catch(e => console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e));

  // Stress Test Endpoint
  app.post("/api/stress-test", (req, res) => {
    try {
      const logs = runStressTest_MAX_TURBULENCE_001();
      res.json({ logs });
    } catch (error) {
      res
        .status(500)
        .json({
          error: error instanceof Error ? error.message : String(error),
        });
    }
  });

  // Request Logging Middleware
  app.use((req, res, next) => {
    const identifier = req.body?.action || req.body?.scenario || "N/A";
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, 
      `[${new Date().toISOString()}] ${req.method} ${req.url} - ID: ${identifier}`,
    );
    next();
  });

  // Serve reports directory
  const reportsDir = path.join(process.cwd(), "reports");
  if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir, { recursive: true });
  }
  app.use("/reports", express.static(reportsDir));

  const s9Kernel = new S9ProofKernel(82, RiskLevel.MEDIUM);
  const swiKernel = new SWIKernel();

  const PRIVATE_KEY = process.env.SWI_PRIVATE_KEY || (() => {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "🗝️ Generating new ephemeral SWI private key in memory...");
    const { privateKey } = crypto.generateKeyPairSync("rsa", {
      modulusLength: 2048,
      publicKeyEncoding: { type: "spki", format: "pem" },
      privateKeyEncoding: { type: "pkcs8", format: "pem" },
    });
    return privateKey;
  })();

  // SWI V1.01 Execution Endpoint
  app.post("/api/execute", async (req, res) => {
    try {
      const payload = { ...req.body };
      if (!payload.admissionToken && payload.legitimate) {
        payload.admissionToken = jwt.sign(
          {
            jti: uuidv4(),
            iat: Math.floor(Date.now() / 1000),
            exp: Math.floor(Date.now() / 1000) + 60,
          },
          PRIVATE_KEY,
          { algorithm: "RS256" },
        );
      }

      // 🚀 Pack as CryptoRequestIR to enforce unified Verification Gate
      const cryptoReq = {
        id: `exec_${uuidv4()}`,
        timestamp: Date.now(),
        metadata: {
          apiKey: req.headers.authorization || payload.apiKey,
          dpop: req.headers.dpop as string,
          method: "POST",
          url: "/api/execute",
        },
        command: {
          module: "system",
          action: payload.type || "DEFAULT",
          args: payload,
        },
      };

      const result = await fabric.kernel.swiExecute(cryptoReq as any);

      io.emit("audit_log", { action: "BLOCKCHAIN_EXEC", payload, result });
      res.json(result);
    } catch (error) {
      const err = error as Error;
      res.status(403).json({ error: err.message });
    }
  });

  // 🚀 Phase 2: Rust CEK Core Integration
  app.post("/api/v2/high-integrity-execute", async (req, res) => {
    try {
      const swiCtx: SWIContext = {
        taskId: `v2_exec_${uuidv4()}`,
        logicalTick: LogicalClock.nextTick(),
        input: req.body.payload || req.body,
        environment: {
          ports: req.body.environment === "secure" ? [80, 443] : [80, 443, 22],
          attachedDevices: [],
          osIntegrity: req.body.environment === "secure" ? "VERIFIED" : "NONE",
          hardwareSignature: "RUST_CEK_ROOT",
        },
        policyAnchor: req.body.policyMismatch ? "MISMATCH" : "BP-2026-LAW-001",
      };

      const driftReport = fabric.ledger.calculateDrift(swiCtx);

      // SWI v3.4+: Vector Correction Handshake
      if (driftReport.recommendation === "WATCH") {
        const cryptoReqCorrection = {
          id: `drift_${uuidv4()}`,
          timestamp: Date.now(),
          command: {
            module: "SYSTEM",
            action: "DRIFT_CORRECTION",
            args: {
              trigger: "MODERATE_DRIFT",
              method: "VECTOR_REBASING",
              score: driftReport.overallScore,
            },
          },
        };
        await fabric.kernel.swiExecute(cryptoReqCorrection as any);
        console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "🩹 [CEK] Vector Rebasing Applied to Execution Boundary.");
      }

      const context: RustContext = {
        driftScore: driftReport.overallScore,
        userBehavior:
          driftReport.recommendation === "PROCEED" ? "normal" : "anomalous",
        environment: req.body.environment ?? "secure",
        policyMismatch: req.body.policyMismatch ?? false,
        report: driftReport,
      };

      const evaluation = fabric.consensus.evaluateCEK(context);

      // SWI V1.01: Staged Execution via Kernel Triage
      const cryptoReq = {
        id: swiCtx.taskId,
        timestamp: Date.now(),
        metadata: {
          apiKey: req.headers.authorization,
          dpop: req.headers.dpop as string,
          method: "POST",
          url: "/api/v2/high-integrity-execute",
          engine: "RUST_CEK_V2",
          driftReport,
        },
        command: {
          module: "CEK_CORE",
          action: "CEK_CORE_EVAL",
          args: { context, evaluation, ...req.body },
        },
      };

      const result = await fabric.kernel.swiExecute(cryptoReq as any);

      if (result.status === "BLOCKED") {
        return res.status(403).json({
          status: "BLOCKED",
          stage: result.stage,
          reason: result.reason,
          evaluation,
        });
      }

      res.json({
        evaluation,
        consensus: evaluation, // Compatibility
        receipt: result.result,
        attestation: result.attestation,
        status: "COMMITTED",
      });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.get("/api/v2/audit-ledger", (req, res) => {
    res.json({
      history: fabric.ledger.getChain(),
      integrity: true,
      root: fabric.ledger.getRoot(),
    });
  });

  app.get("/api/v3/protocol/history", (req, res) => {
    res.json(
      ProtocolManager.getHistory().map((h) => ({
        version: h.version,
        status: h.status,
        deployedAt: h.deployedAt,
      })),
    );
  });

  app.post("/api/v3/protocol/upgrade", (req, res) => {
    const { version } = req.body;
    const upgrade = ProtocolManager.proposeUpgrade(
      version || `v${ProtocolManager.getHistory().length + 1}.0`,
      {},
    );
    ProtocolManager.executeUpgrade(upgrade.version);
    res.json({ status: "PROTOCOL_UPGRADED", current: upgrade.version });
  });

  app.post("/api/v3/adversarial/inject-fault", (req, res) => {
    const maliciousPayload = {
      action: "", // Invalid: min length 1
      priority: "EXTREME", // Invalid enum
      leak_data: true,
    };

    const validation = ValidationMiddleware.validatePayload(
      maliciousPayload,
      "ADVERSARIAL_ACTOR",
    );

    res.json({
      status: "FAULT_INJECTED",
      validation,
      reliabilityIndex:
        ValidationMiddleware.getReliabilityIndex("ADVERSARIAL_ACTOR"),
    });
  });

  app.post("/api/v3/kernel/reset", (req, res) => {
    ValidationMiddleware.reset();
    DriftScorer.reset();
    const universe = fabric.kernel.getActiveUniverse();
    if (universe) {
      universe.isHalted = false;
      if (universe.safetyInterlock) {
        universe.safetyInterlock.isHaltTriggered = false;
        universe.safetyInterlock.challengeActive = false;
        universe.safetyInterlock.failedAttempts = 0;
        universe.safetyInterlock.pendingApprovals = [];
      }
    }
    res.json({
      status: "RESET_COMPLETE",
      message: "All drift metrics and violation counts purged.",
    });
  });

  // --- SWI UNIVERSE & GOVERNANCE ROUTES ---

  app.get("/api/v3/universe", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    res.json({
      universe,
      allUniverses: [universe], // Assuming single active for now in this wrapper
    });
  });

  app.get("/api/v3/universe/integrity", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    res.json({
      integrity: universe?.standing?.integrityScore || 0,
      modules: universe?.modules || {},
    });
  });

  app.post("/api/v3/attestation/verify", async (req, res) => {
    const { moduleId } = req.body;
    if (!moduleId) return res.status(400).json({ error: "Module ID required" });

    try {
      const report = await fabric.proof.verifyBinaryIntegrity(moduleId);

      const cryptoReq = {
        id: `attest_${Date.now()}`,
        timestamp: Date.now(),
        command: {
          module: "SYSTEM",
          action: "MODULE_ATTESTATION",
          args: {
            moduleId,
            status: "VERIFIED",
            reportHash: report.binaryHash,
          },
        },
      };
      await fabric.kernel.swiExecute(cryptoReq as any);

      res.json(report);
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  app.post("/api/v3/universe/fork", async (req, res) => {
    const { parentId, mutations } = req.body;
    try {
      const forked = fabric.kernel.fork(parentId, mutations);

      // 📜 RECORD EVENT IN UNIVERSE KERNEL
      const swiProof = await fabric.proof.generateZKProof(forked.universeId);

      const cryptoReq = {
        id: `fork_${Date.now()}`,
        timestamp: Date.now(),
        metadata: { swiProof },
        command: {
          module: "SYSTEM",
          action: "REALITY_FORK",
          args: {
            parentId,
            forkId: forked.universeId,
            mutations,
          },
        },
      };
      await fabric.kernel.swiExecute(cryptoReq as any);

      res.json(forked);
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  // --- 🔷 SWI v3.5 ETHICAL CORE STACK ENDPOINTS ---

  app.post("/api/v3.5/ethics/forecast", async (req, res) => {
    const { action, payload } = req.body;
    try {
      const forecast = await fabric.governance.forecastEthics(action, payload);
      res.json(forecast);
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  app.post("/api/v3.5/ethics/reflex", async (req, res) => {
    const { type, payload } = req.body;
    try {
      const decision = await fabric.governance.processEthicalReflex(
        type,
        payload,
      );
      res.json(decision);
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  app.get("/api/v3.5/ethics/stability", (req, res) => {
    res.json(fabric.governance.getEthicalStability());
  });

  app.get("/api/v3.5/governance/heartbeat", (req, res) => {
    res.json({
      status: "HEALTHY",
      timestamp: Date.now(),
      metrics: fabric.consensus.getQuorumHealth(),
      quorum: "OK",
    });
  });

  app.get("/api/v3.5/governance/formal-verification", (req, res) => {
    const report = fabric.proof.getFormalVerificationReport();
    res.json(report);
  });

  app.get("/api/v3.5/observability/metrics", (req, res) => {
    res.json(fabric.consensus.getQuorumHealth());
  });

  app.get("/api/v3.5/governance/graph/stats", (req, res) => {
    res.json(fabric.kernel.getGraphStats());
  });

  app.get("/api/v3.5/governance/dlq", (req, res) => {
    const dlq = fabric.ledger.getDLQ();
    res.json(dlq);
  });

  app.get("/api/v3.5/governance/attestation", async (req, res) => {
    const modules = [
      "KERNEL",
      "O4_EVENT_STREAM",
      "T7_REPLAY",
      "S5_ATTEST",
      "P2_CONFIG",
    ];
    const reports = await Promise.all(
      modules.map((m) => fabric.proof.verifyBinaryIntegrity(m)),
    );
    res.json(reports);
  });

  app.post("/api/v3.5/ethics/policy/compile", async (req, res) => {
    const { rawPolicy } = req.body;
    try {
      const epg = await fabric.governance.compileEPG(rawPolicy);
      res.json(epg);
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  app.get("/api/v3.5/governance/dependencies", async (req, res) => {
    res.json(await fabric.kernel.verifyDependencies());
  });

  app.get("/api/v3.5/config/audit", async (req, res) => {
    res.json(await fabric.kernel.auditConfig());
  });

  app.post("/api/v3/governance/review", (req, res) => {
    const { oldSchema, newSchema } = req.body;
    const review = fabric.governance.reviewContractChange(
      JSON.stringify(oldSchema),
      JSON.stringify(newSchema),
    );
    res.json(review);
  });

  app.get("/api/v3/integrity/verify", (req, res) => {
    const report = fabric.proof.verifyChain(fabric.ledger.getInternalLedger());
    res.json(report);
  });

  // 🏛️ Phase 2.5: Bank-Grade Manifold Consensus Execution
  app.post("/api/v3/consensus-execute", async (req, res) => {
    try {
      // 🧠 SWI V1.01: Contextual Safety Check (PROACTIVE)
      const persona: UserPersona = req.body.metadata?.persona;
      const triage = await SandboxManager.runTriage(
        "CONSENSUS_REQUEST",
        req.body.input || req.body,
        persona,
      );

      if (!triage.success) {
        return res.status(403).json({
          status: "BLOCKED",
          stage: triage.stageReached,
          reason: triage.reason,
          safetyReport: triage.safetyReport,
        });
      }

      // 🧊 EXECUTION BOUNDARY LAYER: Resolve Standing before Consequence
      const ebL = fabric.kernel.getEBL();

      // 🏗️ Compile Policy to EB-L Bytecode
      const policyInstr = fabric.governance.compileVM({
        id: "GOV_V3_MAIN",
        minStandingScore: 0.8,
        requiredCertifications: ["ISO-27001", "SWI-S9"],
        maxDrift: 40,
        consequenceScope: "GLOBAL",
      });

      // ⚙️ Execute Instructions in VM
      policyInstr.forEach((instr: SWIInstruction) => ebL.execute(instr));

      // 0. Payload Validation
      const validation = ValidationMiddleware.validatePayload(
        req.body.input || req.body,
        "GLOBAL_CONSENSUS",
      );
      if (!validation.success) {
        return res.status(400).json({
          error: "SCHEMA_VIOLATION",
          details: validation.error,
          reliabilityIndex:
            ValidationMiddleware.getReliabilityIndex("GLOBAL_CONSENSUS"),
        });
      }

      const swiCtx: SWIContext = {
        taskId: uuidv4(),
        logicalTick: validation.data.logicalTick || LogicalClock.nextTick(),
        input: {
          ...validation.data,
          validationDrift:
            !validation.success && "drift" in validation
              ? (validation as { drift: number }).drift
              : 0,
        },
        environment: req.body.environment || {
          ports: [80, 443],
          attachedDevices: ["KEYBOARD", "MOUSE", "HSM_MODULE_01"],
          osIntegrity: "VERIFIED",
          hardwareSignature: "HW_GAB_SEC_001",
        },
        policyAnchor: "FINANCIAL_REG_STMP_v1",
      };

      // 0. Reliablity & Fault Isolation
      const reliabilityIndex =
        ValidationMiddleware.getReliabilityIndex("GLOBAL_CONSENSUS");
      if (reliabilityIndex < 0.4) {
        console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, 
          "⚠️ SYSTEM SHIELD: Critical reliability degradation detected.",
        );
      }

      const engineDecisions: EngineDecision[] = [];

      // 1. Logic Engine (A)
      if (reliabilityIndex > 0.6) {
        const logicEval = fabric.consensus.evaluateCEK({
          driftScore: req.body.drift || 0.1,
          userBehavior: "normal",
          environment:
            swiCtx.environment.osIntegrity === "VERIFIED"
              ? "secure"
              : "compromised",
          policyMismatch: false,
        });

        engineDecisions.push({
          engineId: "ENGINE_A_LOGIC",
          admissible: logicEval.decision === Decision.EXECUTE,
          resolutionWeight: 0.95 * reliabilityIndex,
          reason: logicEval.reason,
          metadata: {
            burden: logicEval.burden,
            boundary: {
              authority: 1.0,
              capacity: 0.95,
              burden: logicEval.burden,
              drift: logicEval.burden * 0.5,
              viability: 0.99,
              evidence: crypto
                .createHash("sha256")
                .update(swiCtx.taskId)
                .digest("hex")
                .substring(0, 16),
              custody: "NODE_LOCAL_TEE",
              continuity: 2048,
              policy: "LOGIC_RULESET_FIN_v1",
              corridor: "FINANCIAL_CLEARING_LANE",
              regime: "INTERBANK_LIQUIDITY_CORE",
            },
          },
        });
      } else {
        console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, 
          "⚠️ ENGINE_A_LOGIC Quarantined due to low reliability index",
        );
      }

      // 2. Environment Engine (B)
      engineDecisions.push(fabric.consensus.evaluateEnvironment(swiCtx));

      // 3. Legal Engine (C)
      engineDecisions.push(fabric.consensus.evaluateLegal(swiCtx));

      // 4. Infrastructure Engine (D)
      engineDecisions.push(fabric.consensus.evaluateInfrastructure(swiCtx));

      // 5. Manifold Arbitration (with isolated engines)
      const consensus = fabric.consensus.arbitrate(engineDecisions, swiCtx);

      // 5. HSM Attestation
      const { signature, attestation } = await HSMSimulator.sign({
        decision: consensus.finalDecision,
        standing: consensus.standing,
        root: fabric.ledger.getRoot(),
      });

      // 6. Proof-of-Continuation (ZK)
      const zkProof = await ZKProver.generateProof(consensus.finalDecision, {
        drift: consensus.standing?.drift || 0,
        weights: [0.33, 0.33, 0.34],
        boundary: consensus.standing || {
          authority: 0,
          capacity: 0,
          burden: 0,
          viability: 0,
          evidence: "N/A",
          custody: "N/A",
          continuity: 0,
          policy: "N/A",
          drift: 0,
          corridor: "N/A",
          regime: "N/A",
        }
      });

      const isVerified = (await ZKProver.verify(zkProof)).valid;

      // --- EVOLVE GOVERNANCE BASED ON DRIFT ---
      const universe = fabric.kernel.getActiveUniverse();
      if (universe && consensus.driftReport) {
        const upgradedGov = fabric.governance.evolve(
          universe,
          consensus.driftReport,
        );
        universe.governor = upgradedGov;
        universe.stableTicks++;
      }

      // 🔐 Validate and execute via unified CryptoGating
      const cryptoReq = {
        id: swiCtx.taskId,
        timestamp: Date.now(),
        metadata: {
          apiKey: req.headers.authorization,
          dpop: req.headers.dpop as string,
          method: "POST",
          url: "/api/v3/consensus-execute",
          engine: "RUST_CEK_V3",
          driftReport: consensus.driftReport,
        },
        command: {
          module: "CONSENSUS_ARBITER",
          action: "CONSENSUS_COMMIT",
          args: {
            zkProof: zkProof.proof,
            decision: consensus.finalDecision,
            standing: consensus.standing,
          },
        },
      };

      const result = await fabric.kernel.swiExecute(cryptoReq as any);

      if (result.status === "BLOCKED") {
        return res.status(403).json(result);
      }

      // 🧊 EB-L: Final Bind
      ebL.execute({
        op: SWI_OP.COMMIT_REALITY,
        params: [result.result?.hash || ""],
        integrityHash: consensus.finalDecision,
      });

      io.emit("consensus_update", {
        consensus: {
          ...consensus,
          receipt: result.result?.hash,
          swiProof: null,
        },
        receipt: result.result,
        status: consensus.finalDecision,
        timestamp: Date.now(),
      });

      res.json({
        consensus: { ...consensus, swiProof: null },
        receipt: result.result,
        attestation,
        boundaryState: ebL.getState(),
      });
    } catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }
  });

  app.post("/api/v3/replay", (req, res) => {
    const { receipt } = req.body;
    if (!receipt) return res.status(400).json({ error: "Receipt required" });

    const isValid = fabric.consensus.replay({
      verificationState: receipt.verificationState,
      consensus: receipt.consensus,
      standing: receipt.standing,
      attestation: receipt.attestation,
    });

    res.json({ replayResult: isValid ? "MATCH" : "MISMATCH" });
  });

  app.get("/api/v3/ledger", (req, res) => {
    res.json(fabric.ledger.getChain());
  });

  // 🧪 Adversarial Test Suite
  app.post("/api/adversarial-test", async (req, res) => {
    const simulator = new RedTeamSimulator();
    const vectors = Object.values(AttackVector);
    const results = vectors.map((v) => {
      const simResult = simulator.simulateAttack(v);
      return {
        test: v,
        status: simResult.status === "PASS" ? "BLOCKED" : "FAIL",
        detail: simResult.system_response,
        hash: simResult.hash,
      };
    });

    const io = app.get("socketio");
    if (io) {
      io.emit("attack_simulation", {
        results,
        timestamp: new Date().toISOString(),
      });
    }

    res.json({ results });
  });

  // 🌐 Consensus Execution Endpoint
  app.post("/api/consensus-execute", async (req, res) => {
    try {
      const { burden, payload, nodeConfigs } = req.body;

      // Default nodes if not provided
      const configs = nodeConfigs || [
        { name: "Node-A", authorityValid: true, integrityStatus: "VALID" },
        { name: "Node-B", authorityValid: false, integrityStatus: "VALID" },
        { name: "Node-C", authorityValid: true, integrityStatus: "VALID" },
      ];

      const nodes = configs.map(
        (c: Record<string, unknown>) =>
          new SWINode(
            c.name as string,
            c.authorityValid as boolean,
            c.integrityStatus as "VALID" | "COMPROMISED",
          ),
      );
      const results = nodes.map((node: SWINode) =>
        node.evaluate({ burden, payload }),
      );

      const consensus = ConsensusEngine.decide(results);
      const receipt = ConsensusEngine.generateReceipt(results, consensus);

      // Log the consensus event to the audit log
      const auditLogPath = path.join(
        process.cwd(),
        "swi-core",
        "logs",
        "audit.log",
      );
      const auditLogDir = path.dirname(auditLogPath);
      if (!fs.existsSync(auditLogDir)) {
        fs.mkdirSync(auditLogDir, { recursive: true });
      }

      // Emit to Kafka stream
      await KafkaLogger.emit(
        "swi.consensus",
        ((receipt as Record<string, unknown>).consensus_hash as string) ||
          uuidv4(),
        {
          ...receipt,
          burden,
          node_count: configs.length,
        },
      );

      const prevHash = (() => {
        if (!fs.existsSync(auditLogPath)) return "GENESIS";
        const lines = fs.readFileSync(auditLogPath, "utf8").trim().split("\n");
        if (lines.length === 0 || lines[0] === "") return "GENESIS";
        try {
          const lastEntry = JSON.parse(lines[lines.length - 1]);
          return lastEntry.hash || "GENESIS";
        } catch {
          return "GENESIS";
        }
      })();

      const nonce = crypto
        .createHash("sha256")
        .update(
          prevHash + JSON.stringify(receipt) + LogicalClock.getCurrentTick(),
        )
        .digest("hex")
        .slice(0, 16);
      const hash = crypto
        .createHash("sha256")
        .update(prevHash + JSON.stringify(receipt) + nonce)
        .digest("hex");

      const block = {
        ...receipt,
        prev_hash: prevHash,
        nonce,
        hash,
        type: "CONSENSUS_EVENT",
        reputations: ConsensusEngine.getReputations(),
        quarantine: ConsensusEngine.getQuarantine(),
      };

      // Strict Audit Path: No incomplete blocks written
      if (
        block.hash &&
        block.consensus &&
        block.consensus.result !== "PENDING"
      ) {
        fs.appendFileSync(auditLogPath, JSON.stringify(block) + "\n");
      }

      res.json(block);
    } catch (error) {
      res
        .status(500)
        .json({
          error: error instanceof Error ? error.message : String(error),
        });
    }
  });

  // 🧪 SWI Proof-of-Replay (PoR) Endpoint
  app.get("/api/swi/replay/proof", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    if (!universe) return res.status(500).json({ error: "No active universe" });

    const proof = fabric.proof.getFormalVerificationReport();
    res.json(proof);
  });

  // 🌍 SWI Continuity Data Endpoint
  app.get("/api/swi/continuity", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    if (!universe) return res.status(500).json({ error: "No active universe" });

    res.json({
      normalizedPoC: universe.standing?.continuityContribution || 0,
      groundWeights: universe.standing?.groundWeights || {},
      integrityScore: universe.standing?.integrityScore || 0,
      modules: universe.modules,
      events: universe.events,
      safetyInterlock: universe.safetyInterlock,
    });
  });

  // 🧩 Policy Ingestion & Legal Proof Gateway
  app.post("/api/swi/policy/ingest", async (req, res) => {
    const { policyRaw, jurisdiction } = req.body;
    if (!policyRaw)
      return res
        .status(400)
        .json({ error: "Policy text required for ingestion." });

    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, 
      `⚖️ Ingesting policy for jurisdiction: ${jurisdiction || "GLOBAL"}`,
    );

    // Simulate ingestion through Ethics/Governance Maze
    const drift = fabric.governance.calculateDrift(0.85, 0.92); // Simulated base

    const cryptoReq = {
      id: `policy_${Date.now()}`,
      timestamp: Date.now(),
      command: {
        module: "SYSTEM",
        action: "POLICY_INGESTION",
        args: { policyRaw, jurisdiction, drift },
      },
    };
    const result = await fabric.kernel.swiExecute(cryptoReq as any);
    const event = result.result;

    if (!event) return res.status(403).json(result);

    const evidence = await fabric.proof.generateLegalEvidence(
      fabric.kernel.getActiveUniverse()!,
      event as any,
    );

    res.json({
      status: "INGESTED",
      driftScore: drift,
      proofOfUnderstanding: "6D_RECONSTRUCTION_COMPLETE",
      evidence,
    });
  });

  // 🛡️ Safety Approval Endpoint
  app.post("/api/swi/safety/approve", (req, res) => {
    const { signature, partyId } = req.body;
    const success = fabric.kernel.processSafetyApproval(
      partyId || "USER_DASHBOARD",
      signature,
    );
    res.json({
      success,
      safetyState: fabric.kernel.getActiveUniverse()?.safetyInterlock,
    });
  });

  // 🧠 Safety Challenge Answer Endpoint
  app.post("/api/swi/safety/challenge", (req, res) => {
    const { answer } = req.body;
    const result = fabric.kernel.answerSafetyChallenge(answer);
    res.json({
      ...result,
      safetyState: fabric.kernel.getActiveUniverse()?.safetyInterlock,
    });
  });

  // ⚖️ Legal Evidence Export
  app.get("/api/swi/legal/evidence/:eventId", async (req, res) => {
    const { eventId } = req.params;
    const universe = fabric.kernel.getActiveUniverse();
    if (!universe) return res.status(500).json({ error: "No active universe" });

    const event = universe.events.find(
      (e: UniverseEvent) => e.eventId === eventId,
    );
    if (!event) return res.status(404).json({ error: "Event not found" });

    const evidence = await fabric.proof.generateLegalEvidence(universe, event);
    res.json(evidence);
  });

  // 🛠️ System Diagnosis & Maintenance Guide
  app.get("/api/swi/maintenance/guide", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    if (!universe) return res.status(500).json({ error: "No active universe" });
    const guide = fabric.governance.getMaintenanceGuide(universe);
    res.json(guide);
  });

  // 🕸️ SWI V1.01: Topology Engine (Runtime Dependency Graph)
  app.get("/api/v4/topology", async (req, res) => {
    const findings = await fabric.kernel.verifyDependencies();
    res.json(findings);
  });

  // 📈 SWI V1.01: Capability Registry (The Truth Matrix)
  app.get("/api/v4/truth-matrix", (req, res) => {
    const universe = fabric.kernel.getActiveUniverse();
    if (!universe) return res.status(500).json({ error: "No active universe" });

    const modules = universe.modules;
    const matrix = Object.keys(modules).map((id) => ({
      module: id,
      status: modules[id].status,
      confidence: modules[id].confidence - Math.random() * 0.05, // Bayesian uncertainty interval
      health: (modules[id].confidence * 100).toFixed(1) + "%",
      isOperational:
        modules[id].status === "ACTIVE" && modules[id].confidence > 0.8,
    }));

    const coherence = CoherenceEngine.getActiveState();
    const failsafe = FailsafeRouter.determineRoute(coherence);
    const eventCount = MetricsCollector.getEventCount();

    res.json({ matrix, coherence, eventCount, failsafe });
  });

  app.get("/api/v4/authority/tokens", (req, res) => {
    res.json(AuthorityEngine.getTokens());
  });

  app.get("/api/v4/documentation/whitepaper/download", (req, res) => {
    try {
      const filePath = WhitepaperExporter.generatePDF();
      res.json({ url: filePath });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  app.get("/api/v4/legal/corpus", (req, res) => {
    res.json(LegalEngine.getIngestedCorpus());
  });

  app.get("/api/v4/documentation/whitepaper", (req, res) => {
    res.json(SWI_WHITEPAPER);
  });

  app.get("/api/v4/sovereign-audit", async (req, res) => {
    const report = await SovereignAuditEngine.generateReport();
    res.json(report);
  });

  // 🕵️ Red Team Stress Test
  app.post("/api/swi/red-team/stress-test", async (req, res) => {
    try {
      const results = await fabric.proof.runRedTeamStressTest();
      res.json({ results, timestamp: Date.now() });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // 📊 Audit Logs Endpoint
  app.get("/api/system-events", (req, res) => {
    // Return the Merkle Ledger chain
    res.json(fabric.ledger.getChain());
  });

  // 📋 Task Management
  app.get("/api/tasks", (req, res) => {
    res.json(tasks);
  });

  app.post("/api/tasks", (req, res) => {
    const newTask = {
      ...req.body,
      id: uuidv4(),
      createdAt: new Date().toISOString().split("T")[0],
      completed: false,
    };
    tasks.push(newTask);
    res.json(newTask);
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    const { id } = req.params;
    const task = tasks.find((t) => t.id === id);
    if (!task) return res.status(404).json({ error: "Task not found" });

    // Role-based assignment check
    if (req.body.assignedTo) {
      const user = users.find((u) => u.id === req.body.assignedTo);
      if (!user)
        return res.status(400).json({ error: "Invalid user for assignment" });

      // Simple availability logic: max 5 active tasks per user
      const activeTasks = tasks.filter(
        (t) => t.assignedTo === user.id && !t.completed,
      ).length;
      if (activeTasks >= 5) {
        return res
          .status(400)
          .json({
            error: `${user.name} has reached maximum task capacity (5 active tasks).`,
          });
      }

      // Role check: Security Auditors can't be assigned high priority governance Verification tasks (conflict of interest demo)
      if (
        user.role === "Security Auditor" &&
        req.body.priority === "high" &&
        task.title.toLowerCase().includes("verify")
      ) {
        return res
          .status(403)
          .json({
            error:
              "Conflict of Interest: Auditors cannot verify their own audit-target tasks.",
          });
      }
    }

    tasks = tasks.map((t) => (t.id === id ? { ...t, ...req.body } : t));
    const updatedTask = tasks.find((t) => t.id === id);

    if (updatedTask) {
      io.emit("task_update", updatedTask);
    }

    // 📜 RECORD EVENT IN UNIVERSE KERNEL
    if (updatedTask) {
      const swiProof = await fabric.proof.generateZKProof("TASK_OPERATOR");

      const cryptoReq = {
        id: `task_${Date.now()}`,
        timestamp: Date.now(),
        metadata: { swiProof },
        command: {
          module: "SYSTEM",
          action: "TASK_UPDATE",
          args: {
            taskId: id,
            updates: req.body,
            newStatus: updatedTask.completed ? "COMPLETED" : "ACTIVE",
          },
        },
      };
      await fabric.kernel.swiExecute(cryptoReq as any);
    }

    res.json(updatedTask);
  });

  app.delete("/api/tasks/:id", (req, res) => {
    const { id } = req.params;
    tasks = tasks.filter((t) => t.id !== id);
    res.json({ success: true });
  });

  // 👤 User Profiles
  app.get("/api/users", (req, res) => {
    res.json(users);
  });

  app.patch("/api/users/:id", (req, res) => {
    const { id } = req.params;
    users = users.map((u) => (u.id === id ? { ...u, ...req.body } : u));
    res.json(users.find((u) => u.id === id));
  });

  // 🛡️ S9 Proof Endpoints
  app.post("/api/s9/update", requireAuth, (req, res) => {
    const { ethical_weight, risk_band } = req.body;
    const receipt = s9Kernel.updateState(ethical_weight, risk_band);
    res.json(receipt);
  });

  app.get("/api/s9/dashboard", (req, res) => {
    res.json(s9Kernel.getDashboardMetrics());
  });

  app.post("/api/s9/rollback/bind", requireAuth, (req, res) => {
    const { plan_id, owner, steps } = req.body;
    const plan: RollbackPlan = {
      plan_id,
      owner,
      steps,
      bound: true,
    };
    s9Kernel.attachRollbackPlan(plan);
    res.json({ status: "BOUND", plan });
  });

  app.get("/api/s9/ledger", (req, res) => {
    res.json(s9Kernel.getLedger());
  });

  // 📄 Export Audit PDF
  app.get("/api/export-audit", (req, res) => {
    const logs = fabric.ledger.getChain();
    if (logs.length === 0) return res.status(404).send("No logs found");

    const doc = new PDFDocument();
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      "attachment; filename=SWI_Audit_Report.pdf",
    );
    doc.pipe(res);

    doc
      .fontSize(20)
      .font("Helvetica-Bold")
      .text("SWI: THE AI COURT", { align: "center" });
    doc
      .fontSize(12)
      .font("Helvetica-Oblique")
      .text("Sovereign Intelligence Execution Boundary Verdict Report", {
        align: "center",
      });
    doc.moveDown();
    doc
      .fontSize(8)
      .font("Helvetica")
      .text(`System Version: 1.0-DCG`, { align: "right" });
    doc.text(`Generated: ${new Date().toISOString()}`, { align: "right" });
    doc.moveDown();
    doc.lineWidth(1).moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown();

    logs.forEach((node, i) => {
      try {
        const entry = node.data as Record<string, unknown>;
        const consensusResult = (
          entry.consensus as { result?: string } | undefined
        )?.result;
        doc
          .fontSize(10)
          .font("Helvetica-Bold")
          .text(
            `Event #${i + 1}: ${(entry.type as string) || (entry.final_decision as string) || consensusResult || "UNKNOWN"}`,
          );
        doc
          .fontSize(8)
          .font("Courier")
          .text(
            `Hash: ${entry.consensus_hash || entry.hash || node.hash || "N/A"}`,
          );
        doc
          .fontSize(8)
          .font("Helvetica")
          .text(`Timestamp: ${new Date(node.timestamp).toISOString()}`);
        if (entry.burden) {
          const burden = entry.burden as {
            action?: string;
            userBehavior?: string;
            environment?: string;
          };
          doc.text(`Action: ${burden.action || "N/A"}`);
          doc.text(
            `Behavior: ${burden.userBehavior || "N/A"} | Env: ${burden.environment || "N/A"}`,
          );
        }
        if (entry.consensus) {
          const cons = entry.consensus as {
            approved: number;
            quorum: number;
            strength?: string;
          };
          doc.text(
            `Quorum: ${cons.approved}/${cons.quorum} | Strength: ${cons.strength || "N/A"}`,
          );
        }
        doc.moveDown(0.5);
        if (doc.y > 700) doc.addPage();
      } catch {
        // Skip malformed
      }
    });

    doc.moveDown();
    doc
      .fontSize(8)
      .font("Helvetica-Oblique")
      .text("Certified Deterministic Execution Proof - SWI Kernel v1.0", {
        align: "center",
      });
    doc.end();
  });

  // Endpoint to serve reports directly via API if needed
  app.get("/api/reports/:filename", (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(process.cwd(), "reports", filename);
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).send("Report not found");
    }
  });

  // 📑 Dynamic Task Report Generation (JSON)
  app.get("/api/tasks/:id/report/json", (req, res) => {
    const { id } = req.params;
    const task = tasks.find((t) => t.id === id);
    if (!task) return res.status(404).json({ error: "Task not found" });

    res.json({
      reportId: `REP-${id}-${Date.now()}`,
      standingResolution: {
        status: "RESOLVED",
        weight: 0.94,
        latency: "12ms",
        evidence: crypto.createHash("sha256").update(id).digest("hex"),
      },
      taskMetadata: task,
      auditTrail: [
        {
          tick: 1,
          action: "INITIALIZE",
          observer: "UniverseKernel",
          hash: uuidv4(),
        },
        {
          tick: 42,
          action: "RESOLVE_STANDING",
          observer: "Arbiter",
          proof: "ZK-S9-v1",
        },
        {
          tick: 100,
          action: "BIND_CONSEQUENCE",
          observer: "EB-L",
          status: "COMMITTED",
        },
      ],
    });
  });

  // 📄 Dynamic Task Report Generation (PDF)
  app.get("/api/tasks/:id/report/pdf", (req, res) => {
    const { id } = req.params;
    const task = tasks.find((t) => t.id === id);
    if (!task) return res.status(404).send("Task not found");

    const doc = new PDFDocument();
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=SWI_Standing_Report_${id}.pdf`,
    );
    doc.pipe(res);

    doc
      .fontSize(20)
      .font("Helvetica-Bold")
      .text("SWI STANDING RESOLUTION REPORT", { align: "center" });
    doc
      .fontSize(12)
      .font("Helvetica-Oblique")
      .text(`Verified Execution Record for ${id}`, { align: "center" });
    doc.moveDown();

    doc.fontSize(10).font("Helvetica").text(`TASK TITLE: ${task.title}`);
    doc.text(`GUILD: ${task.guild}`);
    doc.text(`PRIORITY: ${task.priority}`);
    doc.text(`STANDING REQ: ${task.standingRequired}`);
    doc.text(`STATUS: ${task.completed ? "COMPLETED" : "ACTIVE"}`);
    doc.moveDown();

    doc.lineWidth(1).moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown();

    doc
      .fontSize(14)
      .font("Helvetica-Bold")
      .text("Structural Proof of Standing");
    doc.moveDown(0.5);
    doc.fontSize(10).font("Helvetica").text("1. Autonomous Reflex: PASSED");
    doc.text("2. Contextual Drift: 0.04 (NOMINAL)");
    doc.text("3. Multi-Layer Approval: SYNCED");
    doc.moveDown();

    doc
      .fontSize(8)
      .font("Courier")
      .text(
        `CERTIFICATE HASH: ${crypto
          .createHash("sha256")
          .update(id + "CONSENSUS")
          .digest("hex")}`,
      );
    doc.moveDown();

    doc.fontSize(10).font("Helvetica-Bold").text("Audit Trail Log:");
    for (let i = 0; i < 5; i++) {
      doc
        .fontSize(8)
        .font("Helvetica")
        .text(
          `- TICK_${100 + i * 10}: Logical alignment verified against ${task.guild}_BASE_v1.0`,
        );
    }

    doc.moveDown();
    doc
      .fontSize(8)
      .font("Helvetica-Oblique")
      .text("Certified by SWI Root Certificate Authority - Gaborone Protocol", {
        align: "center",
      });
    doc.end();
  });

  // Security Maze SSE Endpoint
  app.get("/api/run-maze", async (req, res) => {
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const initialInput: SWIInput = {
      token: { status: "VALID", permission: "ADMIN" },
      action: "INITIALIZE_MAZE",
      value: 0,
      context: {
        userBehavior: "normal",
        environment: "secure",
        driftScore: 0.1,
        policyMismatch: false,
      },
    };
    const maze = runSecurityMaze(initialInput);

    try {
      for await (const artifact of maze) {
        res.write(`data: ${JSON.stringify(artifact)}\n\n`);
      }
      res.write('event: end\ndata: {"status": "complete"}\n\n');
      res.end();
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Maze Error:", error);
      res.write(
        `event: error\ndata: {"error": "${error instanceof Error ? error.message : String(error)}"}\n\n`,
      );
      res.end();
    }
  });

  // SWI Proof API Endpoint
  app.post("/api/run-proof", async (req, res, next) => {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, 
      `[API] /api/run-proof called - Body: ${JSON.stringify(req.body).substring(0, 500)}`,
    );
    try {
      const input = req.body;

      // For the demo, if no token is provided, we generate one to show the "happy path"
      if (!input.admissionToken && input.legitimate) {
        input.admissionToken = jwt.sign(
          {
            jti: uuidv4(),
            iat: Math.floor(Date.now() / 1000),
            exp: Math.floor(Date.now() / 1000) + 60,
          },
          PRIVATE_KEY,
          { algorithm: "RS256" },
        );
      }

      // 🔐 1) HARDENED SECURITY MAZE (MULTI-LAYER VALIDATION)
      const maze = securityCheck(input);
      if (!evaluateMaze(maze)) {
        return res.json({
          decision: "REFUSE",
          reason: "Security Maze rejection",
          mazeHash: maze.hash,
          stage: "pre-execution",
        });
      }

      // 🔁 3) NON-REPEATING SCENARIO ENGINE
      let finalInput = input;
      if (hasSeen(maze.hash)) {
        console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "🔁 Pattern repeated. Mutating context...");
        finalInput = {
          ...input,
          context: mutateContext(input.context),
        };
      }
      store(maze.hash);

      // 🛡️ KERNEL ENFORCEMENT (The Hot Path)
      let kernelResult: any;
      try {
          kernelResult = swiKernel.execute({
            admissionToken: finalInput.admissionToken,
            action: finalInput.action,
            source: finalInput.source,
            endpoint: "run-proof",
            intent_drift: finalInput.context?.driftScore || 0,
            payload: finalInput,
          });
      } catch(e: any) {
          kernelResult = { status: "REFUSE", reason: e.message || "Unknown error" };
      }

      // 🧠 3.5) JOE KERNEL ADMISSIBILITY (Execution Standing & Stability)
      const joeResult = JoeKernel.evaluateState({
        envStability: finalInput.context?.environment === "secure" ? 0.95 : 0.6,
        executionStanding:
          finalInput.context?.userBehavior === "normal" ? 0.98 : 0.5,
        contextualDrift: finalInput.context?.driftScore || 0,
        timestamp: Date.now(),
      });

      let result = evaluateContinuation({
        ...finalInput,
        swiConfig: finalInput.swiConfig,
      }) as unknown as Trace;

      // Force refusal if any kernel refuses
      if (
        kernelResult.status === "REFUSE" ||
        joeResult.state === GovernanceState.REFUSED
      ) {
        result = {
          ...result,
          decision: "REFUSE",
          reason:
            kernelResult.status === "REFUSE"
              ? `KERNEL_REFUSAL: ${kernelResult.reason}`
              : `JOE_GOVERNANCE_REFUSAL: ${joeResult.reason}`,
          violation_type: (kernelResult.status === "REFUSE"
            ? kernelResult.reason
            : joeResult.reason) as string,
        };
      }

      // 🧠 4) COMMONSENSE ENGINE
      learn(result as unknown as Trace);

      // 🧩 5) FIREFLY MODEL (MERKLE STRUCTURE) + 🔐 6) SWI CA (STANDING RESOLUTION LAYER)
      const artifact = generateProof(result as unknown as Trace);

      // --- SWI CORE (vNext) ---
      const engineResult = await executeEngine(finalInput, result, PRIVATE_KEY);

      io.emit("execution_complete", { ...artifact, engineResult });
      res.json({
        ...artifact,
        kernel: kernelResult,
        constitutionalState: result.constitutionalState,
        engineResult
      });
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      if (message.startsWith("HALT:")) {
        return res.status(403).json({ error: message });
      }
      next(error);
    }
  });

  // Batch Scenario Execution Endpoint
  app.get("/api/run-all", (req, res, next) => {
    try {
      const results = scenarios.map((s: Scenario) => {
        const result = evaluateContinuation({
          ...s.input,
          swiConfig: s.swiConfig,
        });
        const simulationArtifacts = runSWISimulation(s.input, s.swiConfig);
        const artifact = generateProof({
          ...(result as unknown as Trace),
          scenario: s.name,
          scenarioId: s.id,
          expected: s.expected,
          modules: simulationArtifacts as Trace["modules"],
        } as Trace);
        return artifact;
      });

      const reportResults = results.map((r) => {
        const tr = r as unknown as Trace & {
          scenario: string;
          artifactId?: string;
          hash?: string;
        };
        return {
          scenario: tr.scenario,
          decision: tr.decision,
          driftScore: tr.drift?.score || 0,
          rootHash: tr.artifactId || tr.hash || "0x0",
          timestamp: tr.timestamp,
          signature: tr.signature,
          verificationState: "SIMULATED",
        };
      });

      const reportPath = generateExecutiveReport(reportResults);

      res.json({
        scenarios: results,
        executiveReport: reportPath,
      });
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/scenarios", (req, res) => {
    res.json(scenarios);
  });

  app.post("/api/batch-report", (req, res) => {
    const { results } = req.body;
    if (!results || !Array.isArray(results)) {
      return res.status(400).json({ error: "Invalid results data" });
    }

    const reportResults = (results as unknown[]).map((resultItem) => {
      const r = resultItem as unknown as Trace & {
        scenario: string;
        artifactId?: string;
        hash?: string;
      };
      return {
        scenario: r.scenario,
        decision: r.decision,
        driftScore: r.drift?.score || 0,
        rootHash: r.artifactId || r.hash || "0x0",
        timestamp: r.timestamp,
        signature: r.signature,
        verificationState: "SIMULATED",
      };
    });
    const report = generateExecutiveReport(reportResults);
    res.json(report);
  });

  app.post("/api/rate-ai-interaction", (req, res) => {
    const { interactionId, rating, comments } = req.body;
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, 
      `[API] Rate AI Interaction received - Id: ${interactionId}, Rating: ${rating}, Comments: ${comments}`,
    );
    res.json({
      success: true,
      interactionId,
      rating,
      comments,
      timestamp: new Date().toISOString(),
      governedHash: Math.random().toString(16).substr(2, 8),
    });
  });

  // 🧪 2) SANDBOX ENGINE + 🔄 3) PROMOTION GATE + 🔁 4) CONTINUOUS LOOP
  setInterval(() => {
    try {
      // 1. Get input (either from queue or generate an adaptive one)
      let scenarioInput: SWIInput;
      let scenarioName = "Adaptive Scenario";
      if (scenarioQueue.length > 0) {
        const queued = scenarioQueue.shift();
        if (!queued) return;
        scenarioInput = queued.input;
        scenarioName = queued.name;
        console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `🚀 Running Gemini-generated scenario: ${scenarioName}`);
      } else {
        // Generate adaptive scenario (never repeat)
        const baseScenario =
          scenarios[Math.floor(Math.random() * scenarios.length)];
        scenarioInput = mutateContext(baseScenario.input, mutationIntensity);
      }

      const maze = securityCheck(scenarioInput);
      if (evaluateMaze(maze)) {
        // Run in sandbox
        const sandboxResult = runSandboxScenario(scenarioInput);

        // Attempt promotion
        const decision = promote({
          artifact: { rootHash: sandboxResult.artifactId },
          result: sandboxResult,
          signature: sandboxResult.signature,
        });

        if (decision.promoted && decision.state) {
          updateDisplay(decision.state as DisplayStableState);
          io.emit("stable_state", {
            ...decision.state,
            byzantine: {
              faults: ConsensusEngine.getByzantineReports(),
              quarantine: ConsensusEngine.getQuarantine(),
            },
          });
        }
      }
    } catch (err) {
      // Silent failure in background loop
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Background loop error:", err);
    }
  }, 5000); // Runs every 5 seconds

  // Trust APIs
  app.get("/api/v4/trust/transparency-log", (req, res) => {
    // Return empty for now to avoid server error from missing module in bundle, simulating read from disk
    res.json([]);
  });

  // Serve static files from 'reports' directory
  const reportsPath = path.join(process.cwd(), "reports");
  if (!fs.existsSync(reportsPath)) {
    fs.mkdirSync(reportsPath, { recursive: true });
  }
  app.use("/reports", express.static(reportsPath));

  // 404 for API routes
  app.all("/api/*path", (req, res) => {
    res
      .status(404)
      .json({ error: `API route not found: ${req.method} ${req.url}` });
  });

  // Global Error Handler
  app.use(
    (
      err: {
        status?: number;
        message?: string;
        details?: unknown;
        stack?: string;
      },
      _req: express.Request,
      res: express.Response,
      next: express.NextFunction,
    ) => {
      if (res.headersSent) {
        return next(err);
      }
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Unhandled Server Error:", err);
      res.status(err.status || 500).json({
        error: err.message || "Internal Server Error",
        details: err.details || null,
        stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
      });
    },
  );

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `SWI Demo Server running on http://localhost:${PORT}`);
  });
}

startServer();
