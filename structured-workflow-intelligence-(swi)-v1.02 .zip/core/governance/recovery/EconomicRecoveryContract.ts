import { RecoveryEscrow } from "./RecoveryEscrow";
import { RollbackAuthorityEngine } from "./RollbackAuthorityEngine";
import { CostOwnershipRegistry } from "./CostOwnershipRegistry";
import { RecoveryDecision } from "./RecoveryDecision";

export interface RecoveryResult {
  erc_checked: boolean;
  erc_available: boolean;
  recovery_path: string | null;
  rollback_owner: string | null;
  cost_owner: string | null;
  status: "resolved" | "halted";
  recovery_id: string | null;
}

export class EconomicRecoveryContract {
  private escrow = new RecoveryEscrow();
  private rollbackEngine = new RollbackAuthorityEngine();
  private costRegistry = new CostOwnershipRegistry();
  private decisionEngine = new RecoveryDecision();

  public evaluateRecovery(haltId: string, reason: string, request: Record<string, unknown>): RecoveryResult {
    // Determine if this halt class is economically recoverable
    const isRecoverable = this.decisionEngine.isRecoverableClass(reason);

    if (!isRecoverable) {
      return {
        erc_checked: true,
        erc_available: false,
        recovery_path: null,
        rollback_owner: null,
        cost_owner: null,
        status: "halted",
        recovery_id: null
      };
    }

    // Try to resolve owners from request or default to dev_treasury for recoverable issues
    let costOwner = request.cost_owner || (request.payload as any)?.details?.cost_owner || "dev_treasury";
    let rollbackOwner = request.rollback_owner || (request.payload as any)?.details?.rollback_owner || "dev_treasury";

    // Validate ownership capability
    const canRecover = 
      this.costRegistry.validateOwner(costOwner as string) && 
      this.rollbackEngine.verifyAuthority(rollbackOwner as string);

    if (canRecover) {
      const recoveryId = `REC-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      
      // Execute the escrow reservation
      this.escrow.reserveRecoveryFunds(recoveryId, costOwner as string, reason);

      return {
        erc_checked: true,
        erc_available: true,
        recovery_path: "economic_escrow_deduction",
        rollback_owner: rollbackOwner as string,
        cost_owner: costOwner as string,
        status: "resolved",
        recovery_id: recoveryId
      };
    }

    return {
      erc_checked: true,
      erc_available: false,
      recovery_path: null,
      rollback_owner: null,
      cost_owner: null,
      status: "halted",
      recovery_id: null
    };
  }
}
