export class RecoveryDecision {
    private recoverableClasses: Set<string>;
  
    constructor() {
      // These are non-integrity violations that can be solved economically
      this.recoverableClasses = new Set([
        "MISSING_COST_OWNER_BOUND",
        "MISSING_ROLLBACK_OWNER_BOUND",
        "GOVERNANCE_LEASE_EXPIRED",
        "TREASURY_ROUTING_ERROR",
        "DRIFT_EXCEEDS_CAPACITY", // Drift spike can be recoverable if escrow covers it
        "DRIFT_EXCEEDED_THRESHOLD"
      ]);
    }
  
    public isRecoverableClass(reason: string): boolean {
      // Existential threats like "MANIFEST_TAMPERED", "KERNEL_BYPASS_DETECTED" are NOT here
      return this.recoverableClasses.has(reason);
    }
  }
  
