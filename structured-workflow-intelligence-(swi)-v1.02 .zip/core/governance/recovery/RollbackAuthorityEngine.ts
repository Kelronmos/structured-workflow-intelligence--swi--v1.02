export class RollbackAuthorityEngine {
    private authorizedEntities: Set<string>;
  
    constructor() {
      this.authorizedEntities = new Set(["dev_treasury", "swi_federation_reserve", "admin"]);
    }
  
    public verifyAuthority(entityId: string): boolean {
      return this.authorizedEntities.has(entityId);
    }
  }
  
