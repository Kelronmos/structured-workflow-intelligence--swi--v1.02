import { SignJWT, jwtVerify } from "jose";

/**
 * JWT Lifecycle Management & Signing Boundary
 * 
 * - Authority: External HSM / Vault only.
 * - Expiry: Short-lived (e.g., 15m) to force rotation.
 * - Key Management: Externalized (not embedded in code).
 */
export class AuthManager {
  private secret: Uint8Array;

  constructor(secretBase64: string) {
    if (!secretBase64) {
      throw new Error("Missing JWT signing secret securely provided by Vault.");
    }
    this.secret = Uint8Array.from(Buffer.from(secretBase64, "base64"));
  }

  async generateToken(payload: any, expiresIn = "15m"): Promise<string> {
    return new SignJWT(payload)
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime(expiresIn)
      .sign(this.secret);
  }

  async verifyToken(token: string): Promise<any> {
    const { payload } = await jwtVerify(token, this.secret);
    return payload;
  }
}
