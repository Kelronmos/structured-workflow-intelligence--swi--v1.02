import { hash } from "./crypto";
import { stableStringify } from "./stableStringify";
import { KernelEvent } from "./types";

export class ReplayValidator {

  static verify(events: KernelEvent[]): boolean {
    let prevHash = "GENESIS";

    for (let i = 0; i < events.length; i++) {
      const event = events[i];

      // structural integrity checks
      if (event.index !== i) return false;
      if (event.prevHash !== prevHash) return false;

      const reconstructed = {
        index: event.index,
        type: event.type,
        payload: event.payload,
        prevHash: event.prevHash
      };

      const computedHash = hash(
        prevHash + stableStringify(reconstructed)
      );

      if (computedHash !== event.stateHash) {
        return false;
      }

      prevHash = event.stateHash;
    }

    return true;
  }

  static recomputeFinalHash(events: KernelEvent[]): string {
    let prevHash = "GENESIS";

    for (const event of events) {
      prevHash = event.stateHash;
    }

    return prevHash;
  }
}
