import { hash } from "./crypto";
import { stableStringify } from "./stableStringify";
import { KernelEvent } from "./types";

export class Kernel {
  private events: KernelEvent[] = [];
  private lastHash = "GENESIS";

  append(type: string, payload: unknown): KernelEvent {
    const index = this.events.length;

    const eventBody = {
      index,
      type,
      payload,
      prevHash: this.lastHash
    };

    const stateHash = hash(
      this.lastHash + stableStringify(eventBody)
    );

    const event: KernelEvent = {
      ...eventBody,
      stateHash
    };

    this.events.push(event);
    this.lastHash = stateHash;

    return event;
  }

  getEvents(): KernelEvent[] {
    return [...this.events];
  }

  getLastHash(): string {
    return this.lastHash;
  }

  reset(): void {
    this.events = [];
    this.lastHash = "GENESIS";
  }
}
