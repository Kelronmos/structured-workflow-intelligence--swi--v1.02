export interface KernelEvent {
  index: number;
  type: string;
  payload: unknown;

  prevHash: string;
  stateHash: string;
}
