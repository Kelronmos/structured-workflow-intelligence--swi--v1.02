import { PolicyEngine, defaultPolicies } from "./engine";

export function runPolicyTests() {
  const engine = new PolicyEngine(defaultPolicies);
  
  const testCases = [
    {
      name: "Normal user execution",
      state: {},
      event: { type: "EXECUTE", payload: { user: "admin", command: "ls" } },
      expected: true
    },
    {
      name: "Root user execution block",
      state: {},
      event: { type: "EXECUTE", payload: { user: "root", command: "rm -rf" } },
      expected: false
    }
  ];

  let passed = 0;
  for (const tc of testCases) {
    const result = engine.evaluate(tc.state, tc.event);
    if (result.allowed === tc.expected) {
      passed++;
    } else {
      console.error(`[POLICY TEST FAILED] ${tc.name}`);
    }
  }
  
  console.log(`[POLICY TESTS] Passed ${passed}/${testCases.length} cases.`);
  return passed === testCases.length;
}
