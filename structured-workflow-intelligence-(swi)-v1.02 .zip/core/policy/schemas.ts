import { z } from "zod";

export const PolicyRuleSchemaV1 = z.object({
  id: z.string(),
  description: z.string(),
  version: z.string().default("1.0.0"),
  conditions: z.array(z.any())
});
