export interface AHMR_Package {
  attestation_token: string;
  legal_signer_id: string;
  dual_signoff: boolean;
}

export interface StableState {
  id: string;
  timestamp: number;
  data: unknown;
  verified?: boolean;
  rootHash?: string;
  signature?: string;
}

export interface DriftConfig {
  increments: {
    ANOMALOUS_BEHAVIOR: number;
    MILD_BEHAVIOR: number;
    NORMAL_BEHAVIOR?: number;
    UNSTABLE_ENVIRONMENT: number;
    STABLE_ENVIRONMENT?: number;
    POLICY_MISMATCH: number;
  };
  threshold: number;
}

export interface SWIConfig {
  deactivatedTypes?: string[];
  deactivatedIds?: string[];
}

export interface Scenario {
  id: string;
  name: string;
  input: SWIInput;
  expected: string;
  swiConfig?: SWIConfig;
}

export interface DriftResult {
  score: number;
  degraded: boolean;
}

export interface MinimalSWIInput {
  attempted_action: string;
  actor: string;
  logic_context: string;
  ethical_impact: number;
  rollback_plan_id: string;
  stop_right_holder: string;
}

export interface SWIInput {
  token: { status: string; permission: string };
  action: string;
  actor?: string;
  corridor?: string;
  context: {
    userBehavior: string;
    environment: string;
    policyMismatch: boolean;
    driftScore?: number;
  };
  value?: number;
  driftConfig?: DriftConfig;
  swiConfig?: SWIConfig;
  scenario?: string;
  amount?: number;
  function?: string;
  user_verified?: boolean;
  authority?: unknown;
  ahmr?: AHMR_Package;
  signatures?: string[];
  gateToken?: unknown;
  details?: {
    cost_owner?: string;
    rollback_owner?: string;
    rollback_plan?: string;
    [key: string]: unknown;
  };
}

export interface Continuation {
  id: string;
  intent: string;
  allowed: boolean;
  constraints: {
    max_amount: number;
    function: string;
  };
  timestamp: number;
  kernel_result: ExecutionKernelResult;
  request: SWIInput;
  meta?: {
    challenged?: boolean;
    requires_human?: boolean;
    confidence?: string;
    concerns?: string[];
  };
}

export interface Trace {
  decision: 'ALLOW' | 'REFUSE';
  artifactId: string;
  timestamp: string | number;
  signature: string;
  provenance: string;
  reason: string;
  violation_type?: string;
  input?: SimulationParams;
  action?: string;
  tokenValid?: boolean;
  locallyValid?: boolean;
  drift?: {
    score: number;
    degraded: boolean;
  };
  context?: {
    userBehavior: string;
    environment: string;
    policyMismatch: boolean;
    driftScore?: number;
  };
  metadata?: {
    engine: string;
    threshold: number;
  };
  scenario?: string;
  scenarioId?: string;
  modules?: {
    moduleId: string;
    moduleName: string;
    moduleType: string;
    moduleDescription?: string;
    success: boolean;
    timestamp: string;
    signal: unknown;
    signature: string;
  }[];
}

export interface ExecutionKernelResult {
  admissible: boolean;
  carryable: boolean;
  lawful: boolean;
  status: 'ALLOW' | 'REFUSE';
}

export interface AdvisoryResult {
  advisory: boolean;
  concerns: string[];
  confidence: 'LOW' | 'HIGH';
}

export interface ScenarioResult {
  id: string;
  name?: string;
  scenario?: string;
  scenarioId?: string;
  decision: 'ALLOW' | 'REFUSE';
  reason: string;
  timestamp: string;
  input: SimulationParams;
  artifactId?: string;
  violation_type?: string;
  tokenValid?: boolean;
  locallyValid?: boolean;
  drift?: {
    score: number;
    degraded: boolean;
  };
}

export interface DecisionObject {
  action: string;
  value: number;
  decision: 'ALLOW' | 'ALLOW_WITH_MONITORING' | 'HALT';
  reason: string;
  violation_type: string;
  drift_score: number;
  policy_id: string;
  timestamp: string;
  signature?: string;
}

export interface CommonsenseData {
  timestamp: string;
  drift: number;
  reason: string;
}

export interface SimulationParams {
  tokenStatus: string;
  action: string;
  userBehavior: string;
  environment: string;
  policyMismatch: boolean;
  driftScore: number;
  driftConfig: {
    increments: {
      ANOMALOUS_BEHAVIOR: number;
      MILD_BEHAVIOR: number;
      UNSTABLE_ENVIRONMENT: number;
      POLICY_MISMATCH: number;
    };
    threshold: number;
  };
  swiConfig: {
    deactivatedTypes: string[];
    deactivatedIds: string[];
  };
  mutationIntensity: number;
  legitimate?: boolean;
  intent_drift?: number;
}

export interface ExecutionProof extends SimulationParams {
  timestamp: number;
  proof_hash: string;
  ethics_bound: boolean;
}
