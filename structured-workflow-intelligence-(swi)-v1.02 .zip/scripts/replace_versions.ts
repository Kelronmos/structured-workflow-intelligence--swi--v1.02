import fs from "fs";
import path from "path";

function walk(dir: string, callback: (filepath: string) => void) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const p = path.join(dir, file);
    if (fs.statSync(p).isDirectory()) {
      if (file !== "node_modules" && file !== "dist" && file !== ".git") {
        walk(p, callback);
      }
    } else {
      if (
        !p.endsWith(".png") &&
        !p.endsWith(".jpg") &&
        !p.endsWith(".webm") &&
        !p.endsWith(".mp4") &&
        !p.endsWith(".ico")
      ) {
        callback(p);
      }
    }
  }
}

walk(".", (p) => {
  try {
    let content = fs.readFileSync(p, "utf8");
    let changed = false;

    let newContent = content.replace(/v4\.7/g, "V1.01");
    newContent = newContent.replace(/v4\.7/gi, "V1.01");
    newContent = newContent.replace(/v1-01/g, "v1-01");

    if (content !== newContent) {
      fs.writeFileSync(p, newContent);
      console.log("Updated " + p);
    }
  } catch (e) {}
});
