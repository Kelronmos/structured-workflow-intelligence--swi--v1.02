import crypto from "crypto";
import fs from "fs";
import path from "path";

const targetDirs = ["dist", "build", "artifacts"];

function hashFile(filePath) {
  const data = fs.readFileSync(filePath);
  return crypto.createHash("sha256").update(data).digest("hex");
}

function walk(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;

  for (const file of fs.readdirSync(dir)) {
    const full = path.join(dir, file);
    const stat = fs.statSync(full);

    if (stat.isDirectory()) {
      results = results.concat(walk(full));
    } else {
      results.push(full);
    }
  }
  return results;
}

const hashes = [];

for (const dir of targetDirs) {
  const files = walk(dir);
  for (const f of files) {
    hashes.push(hashFile(f));
  }
}

hashes.sort();

const merkleRoot = crypto
  .createHash("sha256")
  .update(hashes.join(""))
  .digest("hex");

const output = {
  timestamp: new Date().toISOString(),
  merkleRoot,
  fileCount: hashes.length
};

fs.mkdirSync("artifacts", { recursive: true });
fs.writeFileSync(
  "artifacts/.hashseal.json",
  JSON.stringify(output, null, 2)
);

console.log("MERKLE_ROOT:", merkleRoot);
