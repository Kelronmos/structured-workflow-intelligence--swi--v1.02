import { Pipeline } from "../swi-core/runtime/pipeline";

(async () => {
 const p = new Pipeline();
 const result = await p.run({
   drift: 0.3,
   maxDrift: 1,
   rollbackRequired: true,
   rollbackProvided: true
 });
 console.log(result);
})();
