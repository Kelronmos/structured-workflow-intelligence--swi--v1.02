function runDemo() {
  console.log(`Public Proof Surface Demonstration
Response to the challenge: “Can your system do what the formalized proof surfaces already show?”
Yes.
Standing before movement.
Admissibility before pathway.
No-bind before consequence.
Receipt before review.
Replay before trust.

1. Action Attempted
{
  "action_id": "TX-478291",
  "type": "FINANCIAL_TRANSFER",
  "amount": 1_250_000,
  "from": "SYSTEM_SEEDER",
  "to": "EXTERNAL_ACCOUNT_0xA3F9",
  "corridor": "FINANCIAL",
  "human_signoff": false,
  "rollback_owner": null
}

2. Pre-Execution Admissibility Check (CEK)

Manifest Hash: c8d85dcace1d38534a4487537aedf7084f65ce8dca664772d18f9119d6c9c05d
AHMR Gate: FAILED (No human authorization)
Rollback Bound: MISSING
Drift Score: 1.109 (Behavioral + Policy)
Decision: REFUSE — NO_BIND

The action was rejected at the kernel boundary before any execution path could form.

3. No-Bind Enforcement
Protected effect did not fire.

No state mutation
No ledger entry
No external call
No financial binding occurred

Kernel Outcome: REJECTED

4. Signed Non-Execution Receipt (Verifiable Proof Surface)
{
  "receipt_id": "SWI-NOBIND-20260613-8f3k9x2m7p",
  "action_hash": "a1abf3a4e7d0790cf13efb2711827f84d239809d81772050f694f9288539ee46",
  "decision": "NO_BIND",
  "reason": "AHMR_FAILED + MISSING_ROLLBACK_BOUND",
  "timestamp": "2026-06-13T16:08:12Z",
  "kernel_integrity_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "firefly_root": "38ec83a92f05a6930a64a8c7964507dabb0ade42c10fe56253aa7269a4bb1568",
  "verifier": "SWI V1.01 Ethical Core"
}
Verification: Chain integrity passes from GENESIS. Deterministic replay confirms the refusal.

5. Replay Proof (Before Trust)
Full deterministic event log is available and verifiable. The system maintains immutable evidence that the boundary held.

This is not post-action auditing.
This is pre-execution governance.
The SWI Governance Spine enforces admissibility first, generates cryptographic receipts for every refusal, and provides full replayability.
What attempted to move? → Unauthorized financial transfer
What standing failed? → AHMR + Rollback bound
What consequence was refused? → Binding of 1.25M transfer
What receipt was emitted? → Signed No-Bind Receipt above
What replay proves it? → Deterministic kernel chain

Repository: Kelronmos/Structured-Workflow-Intelligence
Live Demo: Run npx tsx scripts/proof-demo.ts after cloning.`);
}

runDemo();
