#!/bin/bash
set -e

echo "Compiling Circom..."
mkdir -p build keys
circom circuits/swi_drift.circom --r1cs --wasm --sym -o build

echo "Powers of Tau..."
snarkjs powersoftau new bn128 12 keys/pot12_0000.ptau -f
snarkjs powersoftau contribute keys/pot12_0000.ptau keys/pot12.ptau -e="swi"

echo "Groth16 setup..."
snarkjs groth16 setup build/swi_drift.r1cs keys/pot12.ptau keys/zkey_0.zkey
snarkjs zkey contribute keys/zkey_0.zkey keys/zkey_final.zkey -e="swi-final"

echo "Export verification key..."
snarkjs zkey export verificationkey keys/zkey_final.zkey keys/verification_key.json

echo "DONE"
