import fs from "fs";
import path from "path";

function walk(dir: string, callback: (filepath: string) => void) {
  const files = fs.readdirSync(dir);
  for (const file of files) {
    const p = path.join(dir, file);
    if (fs.statSync(p).isDirectory()) {
      if (!["node_modules", "dist", ".git"].includes(file)) {
        walk(p, callback);
      }
    } else {
      if (p.match(/\.(ts|tsx|js|jsx|json|md|html|sh|bat)$/)) {
        callback(p);
      }
    }
  }
}

let found = 0;
walk(".", (p) => {
  try {
    let content = fs.readFileSync(p, "utf8");
    let changed = false;

    // Check for "V1.01", "V1.01", "V1.01"
    let newContent = content.replace(/v4\.7/gi, "V1.01");
    newContent = newContent.replace(/v4\.9/gi, "V1.01");
    newContent = newContent.replace(/v5\.0/gi, "V1.01");
    newContent = newContent.replace(/SWI v1\.01/gi, "SWI V1.01");

    if (content !== newContent) {
      fs.writeFileSync(p, newContent);
      console.log("Updated " + p);
      found++;
    }
  } catch (e) {}
});

console.log("Total files updated:", found);
