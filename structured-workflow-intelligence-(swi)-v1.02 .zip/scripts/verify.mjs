import fs from "fs";

const file = "artifacts/.hashseal.json";

if (!fs.existsSync(file)) {
  console.error("Missing hashseal artifact");
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(file, "utf-8"));

if (!data.merkleRoot) {
  console.error("Invalid seal: missing merkle root");
  process.exit(1);
}

console.log("VERIFY OK");
console.log("MERKLE:", data.merkleRoot);
