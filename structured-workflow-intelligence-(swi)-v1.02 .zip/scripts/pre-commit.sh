#!/bin/bash

echo "Running SWI pre-commit security checks..."

# Block trust flags
if grep -R "verified: true" src/ swi-core/ swi-rust-monorepo/; then
  echo "Blocked: hardcoded verification flag"
  exit 1
fi

# Block simulated crypto
if grep -R "simulate(" src/ swi-core/ swi-rust-monorepo/; then
  echo "Blocked: simulated cryptography"
  exit 1
fi

# Block dev secrets
if grep -R "DEV_ZK_SALT" src/ swi-core/ swi-rust-monorepo/; then
  echo "Blocked: insecure dev crypto material"
  exit 1
fi

echo "Pre-commit checks passed"
