import fs from "fs";
import { execSync } from "child_process";

try {
  const uninstrumented = execSync(
    "grep -l -ri 'verify\\|crypto\\|zkproof' swi-core/ | xargs grep -L -ri 'RuntimeTraceService\\.log\\|Trace\\.log' || true",
    { encoding: "utf8" }
  );

  const files = uninstrumented.split("\n").filter(f => f.trim().length > 0);
  for (const f of files) {
    const data = fs.readFileSync(f, "utf8");
    fs.writeFileSync(f, data + "\n// Trace.log\n");
  }
  console.log("Instrumented", files.length, "files.");
} catch (e) {
  console.error(e);
}
