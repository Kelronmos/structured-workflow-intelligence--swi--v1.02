const fs = require("fs");
const crypto = require("crypto");

function hashFile(path) {
  const data = fs.readFileSync(path);
  return crypto.createHash("sha256").update(data).digest("hex");
}

const manifest = JSON.parse(fs.readFileSync("manifest.json"));

let failed = false;

for (const file of manifest.files) {
  if (!fs.existsSync(file.path)) {
    console.error(`❌ FILE NOT FOUND: ${file.path}`);
    failed = true;
    continue;
  }
  const computed = hashFile(file.path);

  if (computed !== file.hash) {
    console.error(`❌ HASH MISMATCH: ${file.path}`);
    failed = true;
  } else {
    console.log(`✅ VERIFIED: ${file.path}`);
  }
}

if (failed) {
  console.error("Integrity check FAILED — aborting build.");
  process.exit(1);
}

console.log("🔐 SWI Integrity Verified.");
