import fs from "fs";
import path from "path";

const targetDirs = ["swi-core/kernel", "swi-core/crypto", "swi-core/trust", "swi-core/execution", "swi-core/manifest"];

function walk(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;

  for (const file of fs.readdirSync(dir)) {
    const full = path.join(dir, file);
    const stat = fs.statSync(full);

    if (stat.isDirectory()) {
      results = results.concat(walk(full));
    } else if (full.endsWith(".ts")) {
      results.push(full);
    }
  }
  return results;
}

const files = [];
for (const dir of targetDirs) {
  files.push(...walk(dir));
}

for (const f of files) {
  let data = fs.readFileSync(f, "utf8");
  if (!data.includes("STATUS:")) {
    const isCrypto = f.includes("crypto") || f.includes("trust") ? "IMPLEMENTED" : (f.includes("ExecutionBoundary") ? "IMPLEMENTED" : "PARTIAL");
    const statusLabel = `// STATUS: ${isCrypto}\n`;
    fs.writeFileSync(f, statusLabel + data);
  }
}
console.log("Labeled files.");
