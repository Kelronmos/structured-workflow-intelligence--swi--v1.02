#!/usr/bin/env node

// In a real monorepo this would be: import { TruthKernel } from "truth-kernel";
import { TruthKernel } from "../src/kernel/TruthKernel";
import { generateKeyPair } from "../src/crypto/signature";

console.log("SWI CLI Initialized");

const keys = generateKeyPair();
const kernel = new TruthKernel(keys);

kernel.execute("TEST", { hello: "world" });

console.log("Exported Genesis Chain:", kernel.exportChain());
