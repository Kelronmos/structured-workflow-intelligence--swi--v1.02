import fs from "fs";
import nacl from "tweetnacl";
import util from "tweetnacl-util";

const keypair = nacl.sign.keyPair();

const receipt = {
  receiptId: "receipt-" + Date.now(),
  requestHash: "req-hash-abc",
  decisionHash: "dec-hash-def",
  policyVersion: "v1.0",
  timestamp: Date.now(),
  previousReceiptHash: "prev-hash-123",
};

const payloadToSign = `${receipt.receiptId}:${receipt.requestHash}:${receipt.decisionHash}:${receipt.policyVersion}:${receipt.timestamp}:${receipt.previousReceiptHash}`;
const msgUint8 = util.decodeUTF8(payloadToSign);
const sigUint8 = nacl.sign.detached(msgUint8, keypair.secretKey);

const fullReceipt = {
  ...receipt,
  signature: util.encodeBase64(sigUint8),
  publicKey: util.encodeBase64(keypair.publicKey),
  hash: "simulated-receipt-hash",
};

fs.writeFileSync(
  "receipt.swi",
  JSON.stringify({ receipt: fullReceipt }, null, 2),
);
console.log(`Generated receipt with hash: ${fullReceipt.hash}`);
