import { SimulatedKafka } from "../swi-core/infrastructure/Queue";
import { MerkleLedger } from "../swi-core/infrastructure/MerkleLedger";

interface ExecutionMessage {
  data: {
    hash: string;
    [key: string]: unknown;
  };
}

/**
 * Node Simulator
 * Simulates an independent execution node in the SWI mesh.
 */
class SWINode {
  private ledger = new MerkleLedger();
  private eventBus = SimulatedKafka.getInstance();
  private nodeId: string;

  constructor(id: string) {
    this.nodeId = id;
    console.log(`[NODE_${this.nodeId}] Initialized simulation node.`);
  }

  public start() {
    // Listen for global consensus events
    this.eventBus.consume("EXECUTION_COMMIT", (msg: ExecutionMessage) => {
      console.log(
        `[NODE_${this.nodeId}] 📥 Syncing ledger with block: ${msg.data.hash.substring(0, 12)}...`,
      );

      // Verification logic
      const isValid = this.verifyBlock(msg.data);
      if (isValid) {
        console.log(
          `[NODE_${this.nodeId}] ✅ Block valid. Committing to local storage.`,
        );
      } else {
        console.error(
          `[NODE_${this.nodeId}] 🚨 SYNC_ERROR: Invalid block hash detected!`,
        );
      }
    });

    // Periodically propose health heartbeat
    setInterval(() => {
      this.eventBus.produce("NODE_HEARTBEAT", {
        nodeId: this.nodeId,
        status: "ACTIVE",
        load: Math.random(),
      });
    }, 5000);
  }

  private verifyBlock(data: { hash?: string }): boolean {
    // In a real system, compute shard hash
    return !!data.hash;
  }
}

// Spawn simulation cluster
console.log("🚀 Spawning SWI Mesh Simulator (Distributed Mode)...");
const nodes = ["ORION_1", "VEGA_2", "SIRIUS_3"].map((id) => new SWINode(id));
nodes.forEach((n) => n.start());

process.on("SIGINT", () => {
  console.log("\n🛑 Simulation Terminated.");
  process.exit();
});
