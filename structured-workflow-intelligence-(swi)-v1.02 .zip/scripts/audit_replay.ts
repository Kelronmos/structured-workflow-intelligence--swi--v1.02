import { SWIArbiter as Arbiter } from "../swi-core/Arbiter";
import { ZKProver } from "../src/lib/zk_proof";
import fs from "fs";

/**
 * Audit Replay Tool (CLI)
 * Verifies a Merkle Receipt against the formal manifold constraints.
 */
async function verifyReceipt(receiptPath: string) {
  try {
    if (!fs.existsSync(receiptPath)) {
      console.error(`❌ Error: Receipt file not found at ${receiptPath}`);
      process.exit(1);
    }

    const receipt = JSON.parse(fs.readFileSync(receiptPath, "utf8"));
    const arbiter = new Arbiter();

    console.log("--------------------------------------------------");
    console.log("🔍 SWI Audit Replay Engine");
    console.log(`📂 Receipt: ${receipt.hash}`);
    console.log(`📅 Committed: ${new Date(receipt.timestamp).toISOString()}`);
    console.log("--------------------------------------------------");

    // 1. ZK Verification
    console.log("Step 1: Verifying ZK Proof-of-Continuation...");
    const zkResult = await ZKProver.verify({
      proof: receipt.data?.zkProof || receipt.proof,
      publicInput: receipt.data?.consensus?.finalDecision || receipt.decision,
      timestamp: receipt.timestamp,
      verificationState: "SIMULATED",
      commitment: "any",
    } as any);
    const isZkValid = zkResult.valid;

    if (isZkValid) {
      console.log("✅ ZK Proof Verified");
    } else {
      console.error("❌ ZK Proof FAILED");
    }

    // 2. Manifold Replay
    console.log("Step 2: Replaying Execution Manifold...");
    const replayResult = arbiter.replay({
      isVerified: isZkValid,
      verificationState: "SIMULATED",
      consensus: receipt.data?.consensus || receipt.consensus,
      standing: receipt.data?.standing || receipt.standing,
      attestation: receipt.data?.attestation || receipt.attestation,
    });

    if (replayResult) {
      console.log("✅ Manifold Integrity Confirmed");
    } else {
      console.error("❌ Manifold Integrity VOID: State Divergence Detected");
    }

    console.log("--------------------------------------------------");
    console.log(
      replayResult && isZkValid
        ? "🌟 FINAL VERDICT: AUDIT PASSED"
        : "🚨 FINAL VERDICT: AUDIT FAILED",
    );
    console.log("--------------------------------------------------");
  } catch (e) {
    console.error("❌ Fatal Replay Error:", (e as Error).message);
    process.exit(1);
  }
}

const path = process.argv[2];
if (!path) {
  console.log("Usage: npx tsx scripts/audit_replay.ts <path_to_receipt.json>");
  process.exit(0);
}

verifyReceipt(path);
