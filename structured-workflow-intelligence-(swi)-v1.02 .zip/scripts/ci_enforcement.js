const fs = require("fs");
const path = require("path");

const args = process.argv.slice(2);
const codebase = path.join(__dirname, "../swi-core");

function checkForbiddenImports(dir) {
    let hasError = false;
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isDirectory()) {
            if (checkForbiddenImports(fullPath)) hasError = true;
        } else if (fullPath.endsWith(".ts") && !fullPath.includes("tests") && !fullPath.includes("dev") && !fullPath.includes("simulation")) {
            const content = fs.readFileSync(fullPath, "utf-8");
            if (content.includes("ZkSnarkRangeProofMock") || content.includes("simulate")) {
                console.error(`[CI_FAIL] Forbidden mock or simulation import found in runtime path: ${fullPath}`);
                hasError = true;
            }
        }
    }
    return hasError;
}

console.log("Running SWI v32 Architectural CI Enforcement...");

const hasMockImports = checkForbiddenImports(codebase);

if (hasMockImports) {
    console.error("CI failed due to architectural violations.");
    process.exit(1);
}

console.log("CI Passed: No mock proofs found in authority paths.");

