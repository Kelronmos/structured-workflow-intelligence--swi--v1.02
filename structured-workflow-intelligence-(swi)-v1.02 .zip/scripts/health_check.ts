import { Kernel } from "../core/kernel/kernel";
import { ReplayValidator } from "../core/kernel/replay_validator";

function runHealthCheck() {
  console.log(
    "[HEALTH CHECK] Starting Deterministic Event Replay Validation...",
  );

  const kernel = new Kernel();

  kernel.append("BOOT", { integrity: "ok" });
  kernel.append("EXECUTE", { command: "load_module", target: "governance" });
  kernel.append("EXECUTE", { command: "user_action", user: "admin" });

  const events = kernel.getEvents();
  console.log(`[HEALTH CHECK] Generated ${events.length} events.`);

  const isValid = ReplayValidator.verify(events);

  if (isValid) {
    console.log(
      "[HEALTH CHECK] SUCCESS: Event chain is deterministically valid.",
    );
    console.log(`[HEALTH CHECK] Final State Hash: ${kernel.getLastHash()}`);
    process.exit(0);
  } else {
    console.error("[HEALTH CHECK] FAILURE: Event chain validation failed.");
    process.exit(1);
  }
}

runHealthCheck();
