import fs from "fs";
import nacl from "tweetnacl";
import util from "tweetnacl-util";
import {
  getRoot,
  buildMerkleTree,
  generateProof,
  verifyProof,
} from "../swi-core/truth/merkle";
import { verifySystem } from "../swi-core/truth/registry";

// Ensure js-sha256 is imported if needed, but the merkle.js already exports what we need.

async function verifyReceipt(receipt: any): Promise<boolean> {
  const payloadToSign = `${receipt.receiptId}:${receipt.requestHash}:${receipt.decisionHash}:${receipt.policyVersion}:${receipt.timestamp}:${receipt.previousReceiptHash}`;
  const msgUint8 = util.decodeUTF8(payloadToSign);
  const sigUint8 = util.decodeBase64(receipt.signature);
  const pubUint8 = util.decodeBase64(receipt.publicKey);

  return nacl.sign.detached.verify(msgUint8, sigUint8, pubUint8);
}

async function verifyBatch(batch: any[], root: string) {
  const tree = buildMerkleTree(batch.map((b) => JSON.stringify(b)));

  if (!tree) throw new Error("Batch is empty");

  if (getRoot(tree) !== root) {
    throw new Error("ROOT_MISMATCH");
  }

  for (let i = 0; i < batch.length; i++) {
    const proof = generateProof(tree, i);
    const ok = verifyProof(JSON.stringify(batch[i]), proof, root);

    if (!ok) throw new Error(`INVALID_BATCH_ITEM ${i}`);
  }

  return true;
}

async function main() {
  const file = process.argv[2];
  if (!file) throw new Error("Missing .swi file");

  const data = JSON.parse(fs.readFileSync(file, "utf8"));

  if (data.transparencyRegistry) {
    console.log(`Verifying Full SWI Target VM Audit Chain...`);
    const { stateRoot, chainValid } = verifySystem(data.transparencyRegistry);
    console.log("Full VM Executed from genesis event 0 without errors.");
    console.log(`Chain Cryptographic Links Valid: ${chainValid}`);
    console.log(`State Derived Truth Root ID: ${stateRoot}`);
    console.log("");
  }

  // Check if it's a batch or a single receipt
  if (data.batch && data.merkleRoot) {
    console.log(`Verifying SWI Batch of ${data.batch.length} receipts...`);
    const batchOk = await verifyBatch(data.batch, data.merkleRoot);
    if (!batchOk) process.exit(1);

    // Also verify all individual signatures in the batch
    for (const receipt of data.batch) {
      if (!receipt.signature || !receipt.publicKey) continue; // For test stubs that might lack them
      const sigValid = await verifyReceipt(receipt);
      if (!sigValid) {
        console.error(`Signature invalid for receipt ${receipt.receiptId}`);
        process.exit(1);
      }
    }

    console.log(
      "OK: Batch cryptographically verified (Merkle Proofs + Ed25519 Signatures)",
    );
    process.exit(0);
  } else {
    // Single receipt verification
    const receipt = data.receipt || data;
    const signatureValid = await verifyReceipt(receipt);

    console.log("Receipt ID:", receipt.receiptId);
    console.log("Signature:", signatureValid ? "VALID (Ed25519)" : "INVALID");

    if (!signatureValid) process.exit(1);

    console.log("OK: cryptographically verified");
  }
}

main().catch((err) => {
  console.error("Verification failed:", err.message);
  process.exit(1);
});
