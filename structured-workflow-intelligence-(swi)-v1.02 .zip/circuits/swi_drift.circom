pragma circom 2.1.6;

template LessThan(n) {
    assert(n <= 252);
    signal input in[2];
    signal output out;

    component n2b = Num2Bits(n+1);

    n2b.in <== in[0] + (1<<n) - in[1];

    out <== 1-n2b.out[n];
}

template Num2Bits(n) {
    signal input in;
    signal output out[n];
    var lc1=0;

    var e2=1;
    for (var i = 0; i<n; i++) {
        out[i] <-- (in >> i) & 1;
        out[i] * (out[i] -1 ) === 0;
        lc1 += out[i] * e2;
        e2 = e2+e2;
    }

    lc1 === in;
}


template DriftCheck() {
 signal input drift;
 signal input maxDrift;
 signal input rollbackRequired;
 signal input rollbackProvided;
 signal output valid;

 component lt = LessThan(32);
 lt.in[0] <== drift;
 lt.in[1] <== maxDrift;

 signal driftOk;
 driftOk <== lt.out;

 signal rollbackOk;
 rollbackOk <== (rollbackRequired * rollbackProvided) + (1 - rollbackRequired);

 valid <== driftOk * rollbackOk;
}

component main = DriftCheck();
