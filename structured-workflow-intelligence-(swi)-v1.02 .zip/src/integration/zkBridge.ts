import { ZKAuditEngine } from "../zk/ZKAuditEngine";
import { TruthKernel } from "../kernel/TruthKernel";

export class ZKBridge {
  zk: ZKAuditEngine;
  kernel: TruthKernel;

  constructor(zk: ZKAuditEngine, kernel: TruthKernel) {
    this.zk = zk;
    this.kernel = kernel;
  }

  executePrivate(eventType: string, payload: any) {
    const witness = {
      input: payload,
      executionTrace: [] as any[],
    };

    const commitment = this.zk.commit(payload);

    const result = this.kernel.execute(eventType, payload);

    witness.executionTrace.push(result);

    const proof = this.zk.prove(witness);

    return {
      commitment,
      proof,
      result: {
        hash: result.hash,
        timestamp: result.timestamp,
      },
    };
  }
}
