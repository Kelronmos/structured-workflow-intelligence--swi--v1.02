import { PBFTNode } from "../consensus/PBFTNode";

export class ConsensusBridge {
  node: PBFTNode;

  constructor(node: PBFTNode) {
    this.node = node;
  }

  submitBatch(batchRoot: string, sequence: number) {
    this.node.prePrepare(sequence, batchRoot);
  }

  isFinalized(digest: string, threshold: number = 2) {
    // simplified check
    return true; // PBFT node would track commitSet in real system
  }
}
