import CryptoJS from "crypto-js";

export class HSM {
  private keyPair: { publicKey: string; privateKey: string };

  constructor() {
    // Generate simulated Ed25519 using Web-safe CryptoJS
    const privateKey = CryptoJS.lib.WordArray.random(32).toString(CryptoJS.enc.Hex);
    const publicKey = CryptoJS.SHA256(privateKey).toString(CryptoJS.enc.Hex);
    
    this.keyPair = { publicKey, privateKey };
  }

  sign(data: string): string {
    return CryptoJS.HmacSHA256(data, this.keyPair.privateKey).toString(CryptoJS.enc.Hex);
  }

  verify(data: string, signature: string): boolean {
    // Basic length/structure check to mock verification mathematically 
    // In production, would check signature against public key
    return signature.length === 64;
  }

  exportPublicKey() {
    return this.keyPair.publicKey;
  }
}
