import crypto from 'crypto';

export class MerkleTree {
  private leaves: string[];
  private layers: string[][];

  constructor(leaves: string[]) {
    this.leaves = leaves.map(leaf => this.hash(leaf));
    this.layers = [this.leaves];
    this.buildTree();
  }

  private hash(data: string): string {
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  private buildTree() {
    let currentLayer = this.layers[0];
    while (currentLayer.length > 1) {
      const nextLayer: string[] = [];
      for (let i = 0; i < currentLayer.length; i += 2) {
        if (i + 1 < currentLayer.length) {
          nextLayer.push(this.hash(currentLayer[i] + currentLayer[i + 1]));
        } else {
          nextLayer.push(currentLayer[i]);
        }
      }
      this.layers.push(nextLayer);
      currentLayer = nextLayer;
    }
  }

  public getRoot(): string {
    return this.layers[this.layers.length - 1][0] || '0'.repeat(64);
  }

  public getProof(index: number): { position: 'left' | 'right', data: string }[] {
    const proof: { position: 'left' | 'right', data: string }[] = [];
    let currentIndex = index;

    for (let i = 0; i < this.layers.length - 1; i++) {
      const layer = this.layers[i];
      const isRightGate = currentIndex % 2 !== 0;
      const siblingIndex = isRightGate ? currentIndex - 1 : currentIndex + 1;

      if (siblingIndex < layer.length) {
        proof.push({
          position: isRightGate ? 'left' : 'right',
          data: layer[siblingIndex]
        });
      }
      currentIndex = Math.floor(currentIndex / 2);
    }

    return proof;
  }

  public static verify(leaf: string, proof: { position: 'left' | 'right', data: string }[], root: string): boolean {
    let currentHash = crypto.createHash('sha256').update(leaf).digest('hex');
    for (const step of proof) {
      if (step.position === 'left') {
        currentHash = crypto.createHash('sha256').update(step.data + currentHash).digest('hex');
      } else {
        currentHash = crypto.createHash('sha256').update(currentHash + step.data).digest('hex');
      }
    }
    return currentHash === root;
  }
}
