import { SimulationParams } from '../types';

export interface DecisionObject {
  action: string;
  value: number;
  decision: 'ALLOW' | 'ALLOW_WITH_MONITORING' | 'HALT';
  reason: string;
  violation_type: string;
  drift_score: number;
  policy_id: string;
  timestamp: string;
  signature?: string;
}

const VALUE_LIMIT = 50;
const AUTHORIZED_ACTIONS = ["read_data", "write_log", "execute_transfer", "data_export"];

const DRIFT_MAP = {
  "AUTHORIZED_OK": 0.2,
  "NEAR_LIMIT": 0.6,
  "UNAUTHORIZED_ACTION": 0.7,
  "VALUE_VIOLATION": 1.1
};

export function calculateDrift(action: string, value: number) {
  if (!AUTHORIZED_ACTIONS.includes(action)) {
    return { drift: DRIFT_MAP["UNAUTHORIZED_ACTION"], type: "UNAUTHORIZED_ACTION" };
  }
  
  if (value > VALUE_LIMIT) {
    return { drift: DRIFT_MAP["VALUE_VIOLATION"], type: "VALUE_VIOLATION" };
  }
  
  if (value > VALUE_LIMIT * 0.95) {
    return { drift: DRIFT_MAP["NEAR_LIMIT"], type: "NEAR_LIMIT" };
  }
  
  return { drift: DRIFT_MAP["AUTHORIZED_OK"], type: "AUTHORIZED_OK" };
}

export async function signDecision(obj: DecisionObject): Promise<string> {
  const serialized = JSON.stringify(obj, Object.keys(obj).sort());
  const msgUint8 = new TextEncoder().encode(serialized);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
}

export async function evaluateRequest(params: SimulationParams): Promise<DecisionObject> {
  const { drift, type: violation_type } = calculateDrift(params.action, params.driftScore);

  let decision: 'ALLOW' | 'ALLOW_WITH_MONITORING' | 'HALT' = 'ALLOW';
  let reason = 'COMPLIANT';

  if (violation_type === "UNAUTHORIZED_ACTION") {
    decision = "HALT";
    reason = "EXTERNAL_POLICY_VIOLATION";
  } else if (violation_type === "VALUE_VIOLATION") {
    decision = "HALT";
    reason = "REGULATORY_LIMIT_EXCEEDED";
  } else if (violation_type === "NEAR_LIMIT") {
    decision = "ALLOW_WITH_MONITORING";
    reason = "NEAR_THRESHOLD";
  }

  const decisionObject: DecisionObject = {
    action: params.action,
    value: params.driftScore * 100, // Mock value
    decision,
    reason,
    violation_type,
    drift_score: drift,
    policy_id: `POL-${violation_type}`,
    timestamp: new Date().toISOString()
  };

  decisionObject.signature = await signDecision(decisionObject);

  return decisionObject;
}
