export function logWithTimestamp(message: string, level: 'info' | 'warn' | 'error' = 'info') {
  const timestamp = new Date().toISOString().substring(0, 19) + 'Z';
  const prefix = `[${timestamp}]`;

  switch (level) {
    case 'error':
      console.error(`${prefix} ${message}`);
      break;
    case 'warn':
      console.warn(`${prefix} ${message}`);
      break;
    case 'info':
    default:
      console.log(`${prefix} ${message}`);
      break;
  }
}

const originalFetch = typeof window !== 'undefined' ? window.fetch : fetch;

export async function fetchWithAudit(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const correlationId = `req-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
  const method = init?.method || 'GET';
  const url = typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url;

  logWithTimestamp(`[AUDIT] [${correlationId}] Starting ${method} request to ${url}`, 'info');
  const startTime = performance.now();

  try {
    const response = await originalFetch(input, init);
    const duration = performance.now() - startTime;
    logWithTimestamp(`[AUDIT] [${correlationId}] Completed ${method} request to ${url} with status ${response.status} in ${duration.toFixed(2)}ms`, 'info');
    return response;
  } catch (error) {
    const duration = performance.now() - startTime;
    const isNetworkError = error instanceof Error && (error.message === 'Failed to fetch' || error.message.includes('fetch') || error.message.includes('Failed to parse URL'));
    const level = isNetworkError ? 'warn' : 'error';
    logWithTimestamp(`[AUDIT] [${correlationId}] Failed ${method} request to ${url} in ${duration.toFixed(2)}ms: ${error instanceof Error ? error.message : String(error)}`, level);
    throw error;
  }
}
