import { create } from "zustand";

export type SystemState = "LIVE" | "HALTED" | "DEGRADED" | "LOCKED";
export type SystemHealthStatus = "HEALTHY" | "COMPROMISED" | "UNKNOWN";

export interface SystemControlState {
  state: SystemState;
  reason?: string;
  triggeredBy?: string;
  timestamp: number;
}

export interface SystemHealthState {
  status: SystemHealthStatus;
  lastChecked: number | null;
  message?: string;
}

interface ControlStore {
  system: SystemControlState;
  health: SystemHealthState;
  setSystem: (state: SystemControlState) => void;
  setHealth: (state: SystemHealthState) => void;
}

export const useSystemStore = create<ControlStore>((set) => ({
  system: {
    state: "LIVE",
    timestamp: Date.now(),
  },
  health: {
    status: "UNKNOWN",
    lastChecked: null,
  },
  setSystem: (state) => set({ system: state }),
  setHealth: (state) => set({ health: state }),
}));
