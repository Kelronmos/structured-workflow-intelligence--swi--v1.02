export async function hash_step(stepData: any, previousHash: string = "0".repeat(64)): Promise<string> {
  const encoder = new TextEncoder();
  const dataString = JSON.stringify(stepData) + previousHash;
  const data = encoder.encode(dataString);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

import nacl from 'tweetnacl';
import util from 'tweetnacl-util';
import { Receipt, VerificationResult } from '../../swi-core/truth/TruthKernel';

/**
 * A standalone, independent utility designed to verify an Ed25519-signed SWI Receipt.
 * This can be run outside of the SWI Kernel, fulfilling the independent validation requirement.
 */
export function verifyReceiptSignature(receipt: Receipt): VerificationResult {
  if (!receipt.signature || !receipt.publicKey) {
    return { valid: false, reason: "Missing signature or public key on receipt" };
  }

  try {
    const payloadToSign = `${receipt.receiptId}:${receipt.requestHash}:${receipt.decisionHash}:${receipt.policyVersion}:${receipt.timestamp}:${receipt.previousReceiptHash}`;
    const msgUint8 = util.decodeUTF8(payloadToSign);
    const sigUint8 = util.decodeBase64(receipt.signature);
    const pubUint8 = util.decodeBase64(receipt.publicKey);
    
    const isValid = nacl.sign.detached.verify(msgUint8, sigUint8, pubUint8);
    
    if (isValid) {
      return { valid: true, reason: "Ed25519 Signature Verified Independently" };
    } else {
      return { valid: false, reason: "Invalid Ed25519 Signature Match" };
    }
  } catch (err) {
    return { valid: false, reason: `Verification threw error: ${(err as Error).message}` };
  }
}
