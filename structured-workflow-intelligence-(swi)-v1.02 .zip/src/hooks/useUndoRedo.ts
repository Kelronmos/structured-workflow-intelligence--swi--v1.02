import { useState, useCallback } from 'react';

export function useUndoRedo<T>(initialState: T) {
  const [undoRedoState, setUndoRedoState] = useState({
    present: initialState,
    history: [initialState],
    index: 0
  });

  const update = useCallback((newState: T | ((prev: T) => T)) => {
    setUndoRedoState(prev => {
      const resolvedState = typeof newState === 'function' 
        ? (newState as (prev: T) => T)(prev.present) 
        : newState;

      if (JSON.stringify(resolvedState) === JSON.stringify(prev.present)) return prev;

      const newHistory = prev.history.slice(0, prev.index + 1);
      newHistory.push(resolvedState);
      const finalHistory = newHistory.length > 50 ? newHistory.slice(1) : newHistory;

      return {
        present: resolvedState,
        history: finalHistory,
        index: finalHistory.length - 1
      };
    });
  }, []);

  const undo = useCallback(() => {
    setUndoRedoState(prev => {
      if (prev.index > 0) {
        const newIndex = prev.index - 1;
        return {
          ...prev,
          present: prev.history[newIndex],
          index: newIndex
        };
      }
      return prev;
    });
  }, []);

  const redo = useCallback(() => {
    setUndoRedoState(prev => {
      if (prev.index < prev.history.length - 1) {
        const newIndex = prev.index + 1;
        return {
          ...prev,
          present: prev.history[newIndex],
          index: newIndex
        };
      }
      return prev;
    });
  }, []);

  return {
    state: undoRedoState.present,
    update,
    undo,
    redo,
    canUndo: undoRedoState.index > 0,
    canRedo: undoRedoState.index < undoRedoState.history.length - 1,
    history: undoRedoState.history,
    index: undoRedoState.index
  };
}
