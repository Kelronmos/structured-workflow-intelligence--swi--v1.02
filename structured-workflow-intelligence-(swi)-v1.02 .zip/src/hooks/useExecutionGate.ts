import { useSystemStore } from "../lib/systemStore";

export function useExecutionGate() {
  const system = useSystemStore((s) => s.system);

  const assertLive = () => {
    if (system.state === "HALTED") {
      throw new Error("SWI_EXECUTION_HALTED");
    }

    if (system.state === "LOCKED") {
      throw new Error("SWI_SYSTEM_LOCKED");
    }
  };

  return {
    system,
    assertLive,
    isHalted: system.state === "HALTED"
  };
}
