import { TrustAnchor } from "../crypto/trust_anchor";

export class BootChainGuard {
  private knownGoodKernelHash: string;

  constructor(knownGoodKernelHash: string) {
    this.knownGoodKernelHash = knownGoodKernelHash;
  }

  verifyBoot(anchor: TrustAnchor): { valid: boolean; reason?: string } {
    if (!anchor.signature.startsWith("tpm2_sig")) {
      return { valid: false, reason: "Invalid TPM signature format" };
    }

    if (anchor.kernelHash !== this.knownGoodKernelHash) {
      return { valid: false, reason: "PCR derived Kernel Hash mismatch. Possible RootKit or unauthorized image." };
    }

    return { valid: true };
  }
}
