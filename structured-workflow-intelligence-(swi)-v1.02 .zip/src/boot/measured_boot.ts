import { TrustAnchor } from "../crypto/trust_anchor";

export class MeasuredBootTPM {
  private pcrs: Map<number, string> = new Map();
  private key: string = "HARDWARE_ROOT_KEY_MOCK";

  constructor() {
    // Initialize PCRs with 0s
    for(let i=0; i<10; i++){
      this.pcrs.set(i, "0000000000000000000000000000000000000000000000000000000000000000");
    }
  }

  // Simulates TPM_Extend: PCR_new = Hash(PCR_old || measurement)
  extend(pcrIndex: number, measurement: string) {
    const current = this.pcrs.get(pcrIndex) || "";
    const extended = this.mockSha256(current + measurement);
    this.pcrs.set(pcrIndex, extended);
  }

  readPcr(pcrIndex: number): string {
    return this.pcrs.get(pcrIndex) || "0000000000000000000000000000000000000000000000000000000000000000";
  }

  // Simulated measure of a system component
  measure(pcrIndex: number, component: string, measurement: string) {
    this.extend(pcrIndex, measurement);
  }

  generateAnchor(): TrustAnchor {
    const pcr0 = this.readPcr(0);
    const pcr1 = this.readPcr(1);
    const pcr2 = this.readPcr(2);
    const pcr7 = this.readPcr(7);
    const pcr8 = this.readPcr(8);

    const kernelHash = this.mockSha256(pcr0 + pcr1 + pcr2 + pcr7 + pcr8);

    return {
      pcrs: new Map(this.pcrs),
      kernelHash,
      signature: this.tpmSign(kernelHash)
    };
  }

  // Deterministic 64-char pseudo-hash for visualization
  private mockSha256(input: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let i = 0; i < input.length; i++) {
        let ch = input.charCodeAt(i);
        h1 = Math.imul(h1 ^ ch, 2654435761);
        h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    
    const h3 = Math.imul(h1, 0x85ebca6b);
    const h4 = Math.imul(h2, 0xc2b2ae35);
    
    // Convert to hex and pad to 64 chars
    const hex = [h1, h2, h3, h4, ~h1, ~h2, ~h3, ~h4].map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
    return hex;
  }

  private tpmSign(x: string) {
    return `tpm2_sig(${this.key}:${x.substring(0, 16)}...)`;
  }
}
