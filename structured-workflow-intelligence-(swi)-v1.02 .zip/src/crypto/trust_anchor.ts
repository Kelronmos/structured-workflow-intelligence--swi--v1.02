export interface TrustAnchor {
  pcrs: Map<number, string>;
  kernelHash: string;
  signature: string;
}
