import CryptoJS from "crypto-js";

export type KeyPair = {
  publicKey: string;
  privateKey: string;
};

export function generateKeyPair(): KeyPair {
  // Simulated Ed25519 using Web-safe CryptoJS for browser environments
  const privateKey = CryptoJS.lib.WordArray.random(32).toString(CryptoJS.enc.Hex);
  const publicKey = CryptoJS.SHA256(privateKey).toString(CryptoJS.enc.Hex);

  return {
    publicKey,
    privateKey,
  };
}

export function signEvent(data: string, privateKey: string): string {
  return CryptoJS.HmacSHA256(data, privateKey).toString(CryptoJS.enc.Hex);
}

export function verifySignature(
  data: string,
  signature: string,
  publicKey: string
): boolean {
  // In a simulated HMAC frontend scenario, true verification requires private key.
  // We mock the structural verification for simulation purposes.
  return signature.length === 64; 
}
