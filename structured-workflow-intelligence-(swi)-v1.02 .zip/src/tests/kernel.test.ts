import { describe, it } from "vitest";
import * as fc from "fast-check";
import { createKernel } from "../kernel/init";
import { Syscall } from "../kernel/types";

describe("Kernel Syscall Invariants", () => {
  it("no unauthorized memory writes", () => {
    fc.assert(
      fc.property(fc.integer({ min: 0, max: 10 }), (addr) => {
        const kernel = createKernel();

        const result = kernel.step({
          type: "memory_write",
          pid: 1,
          addr,
          value: 123
        });

        const proc = kernel.state.processes.get(1)!;

        // Ensure capabilities logic matches reality
        if (!proc.capabilities.has("MEMORY_WRITE")) {
          return result === false;
        }

        return proc.memoryRoot.has(addr);
      })
    );
  });

  it("halt is terminal", () => {
    const kernel = createKernel();

    kernel.step({ type: "halt", pid: 1, reason: "test" });

    const before = kernel.integrityHash();

    kernel.step({
      type: "memory_write",
      pid: 1,
      addr: 1,
      value: 99
    });

    const after = kernel.integrityHash();

    return before === after;
  });

  it("replay log is deterministic", () => {
    const kernel1 = createKernel();
    const kernel2 = createKernel();

    const ops: Syscall[] = [
      { type: "memory_write", pid: 1, addr: 1, value: 1 },
      { type: "memory_write", pid: 1, addr: 2, value: 2 }
    ];

    for (const op of ops) kernel1.step(op);
    for (const op of ops) kernel2.step(op);

    return kernel1.integrityHash() === kernel2.integrityHash();
  });
});
