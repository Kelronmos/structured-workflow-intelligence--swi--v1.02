import * as fc from "fast-check";
import { createKernel } from "../kernel/init";
import { Syscall } from "../kernel/types";
import { describe, it } from 'vitest';

describe("Kernel Property-Based Tests", () => {
    it("PROPERTY 1 — No unauthorized memory mutation", () => {
        fc.assert(
            fc.property(fc.array(fc.integer({ min: 1, max: 20 }), { minLength: 5, maxLength: 10 }), (ops) => {
                const kernel = createKernel();

                for (const _ of ops) {
                    const syscall: Syscall = {
                        type: "memory_write",
                        pid: 1,
                        addr: Math.floor(Math.random() * 50),
                        value: Math.floor(Math.random() * 1000)
                    };

                    kernel.step(syscall);
                }

                const process = kernel.state.processes.get(1)!;

                // invariant: only valid capability writes succeed
                const hasWriteCap = process.capabilities.has("MEMORY_WRITE");

                if (!hasWriteCap) {
                    return process.memoryRoot.size === 0;
                }

                return true;
            })
        );
    });

    it("PROPERTY 2 — Capability enforcement is stable", () => {
        fc.assert(
            fc.property(fc.integer({ min: 1, max: 10 }), (pid) => {
                const kernel = createKernel();

                const before = kernel.state.processes.get(1)!.capabilities.has(
                    "MEMORY_WRITE"
                );

                kernel.step({
                    type: "memory_write",
                    pid,
                    addr: 1,
                    value: 42
                });

                const after = kernel.state.processes.get(1)!.capabilities.has(
                    "MEMORY_WRITE"
                );

                return before === after;
            })
        );
    });

    it("PROPERTY 3 — Deterministic replay hash stability", () => {
        fc.assert(
            fc.property(fc.array(fc.integer({ min: 0, max: 100 }), { minLength: 5, maxLength: 15 }), (seq) => {
                const kernel1 = createKernel();
                const kernel2 = createKernel();

                const build = (k: any) => {
                    for (const v of seq) {
                        k.step({
                            type: "memory_write",
                            pid: 1,
                            addr: v,
                            value: v * 2
                        });
                    }
                    return k.integrityHash();
                };

                return build(kernel1) === build(kernel2);
            })
        );
    });

    it("PROPERTY 4 — Process isolation (no cross-process memory overwrite)", () => {
        fc.assert(
            fc.property(fc.integer({ min: 2, max: 5 }), (spawnCount) => {
                const kernel = createKernel();

                // spawn processes
                for (let i = 0; i < spawnCount; i++) {
                    kernel.step({
                        type: "spawn",
                        pid: 1
                    });
                }

                const pids = Array.from(kernel.state.processes.keys());

                if (pids.length < 2) return true;

                const p1 = kernel.state.processes.get(pids[0])!;
                const p2 = kernel.state.processes.get(pids[1])!;

                p1.memoryRoot.set(1, 999);

                // invariant: memory is not shared reference
                return !p2.memoryRoot.has(1);
            })
        );
    });

    it("PROPERTY 5 — HALT is terminal", () => {
        fc.assert(
            fc.property(fc.integer({ min: 1, max: 10 }), (n) => {
                const kernel = createKernel();

                kernel.step({
                    type: "halt",
                    pid: 1,
                    reason: "test"
                });

                const beforeHash = kernel.integrityHash();

                for (let i = 0; i < n; i++) {
                    kernel.step({
                        type: "memory_write",
                        pid: 1,
                        addr: i,
                        value: i
                    });
                }

                const afterHash = kernel.integrityHash();

                return beforeHash === afterHash;
            })
        );
    });

    it("PROPERTY 6 — No privilege escalation through syscall abuse", () => {
        fc.assert(
            fc.property(fc.integer({ min: 1, max: 10 }), (addr) => {
                const kernel = createKernel();

                const p = kernel.state.processes.get(1)!;
                p.capabilities.delete("MEMORY_WRITE");

                const result = kernel.step({
                    type: "memory_write",
                    pid: 1,
                    addr,
                    value: 123
                });

                const memory = p.memoryRoot.get(addr);

                return result === false && memory === undefined;
            })
        );
    });
});
