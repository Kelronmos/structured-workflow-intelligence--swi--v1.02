export type DecisionState = "APPROVE" | "DENY" | "REVIEW" | "REQUIRE_HUMAN";

const validStates: DecisionState[] = [
  "APPROVE",
  "DENY",
  "REVIEW",
  "REQUIRE_HUMAN",
];

export function validateDecisionState(state: string) {
  if (!validStates.includes(state as DecisionState)) {
    console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "[FIREWALL BLOCK]: Invalid governance state", state);
    return false;
  }

  return true;
}
