import React, { useState, useMemo, useEffect } from "react";
import { ChevronLeft, ChevronRight, CheckSquare, Square } from "lucide-react";
import { AuditEvent } from "../../audit/types";

// Helper to determine severity based on event type
function getSeverity(event: AuditEvent): "INFO" | "WARNING" | "CRITICAL" {
  if (event.type === "DRIFT_DETECTED") return "CRITICAL";
  if (event.payload?.severity) return event.payload.severity;
  return "INFO";
}

export function AuditTrailPanel({ 
  filteredLedger,
  selectedIds,
  onToggleSelect,
  onSelectAll
}: { 
  filteredLedger: AuditEvent[];
  selectedIds: Set<string>;
  onToggleSelect: (id: string, e: React.MouseEvent) => void;
  onSelectAll: () => void;
}) {
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const itemsPerPage = 10;

  const totalPages = Math.ceil((filteredLedger?.length || 0) / itemsPerPage);
  const paginatedEvents = useMemo(() => {
    const sorted = [...(filteredLedger || [])].reverse(); // latest first
    const start = (currentPage - 1) * itemsPerPage;
    return sorted.slice(start, Math.min(start + itemsPerPage, sorted.length));
  }, [filteredLedger, currentPage]);

  useEffect(() => {
    setCurrentPage(1);
    setExpandedId(null);
  }, [filteredLedger]);

  const allSelected = selectedIds.size === filteredLedger.length && filteredLedger.length > 0;
  const someSelected = selectedIds.size > 0 && !allSelected;

  return (
    <div className="p-4 bg-[#1a1a1a] border border-[#E4E3E0]/20 rounded-md flex flex-col h-[500px]">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-sm font-semibold uppercase tracking-widest font-mono text-[#E4E3E0]">Audit Ledger</h2>
        <button 
          onClick={onSelectAll}
          className="flex items-center space-x-2 text-xs font-mono text-gray-400 hover:text-[#E4E3E0] transition-colors"
        >
          {allSelected ? <CheckSquare className="w-4 h-4 text-blue-400" /> : someSelected ? <CheckSquare className="w-4 h-4 text-blue-400/50" /> : <Square className="w-4 h-4" />}
          <span>Select All Filtered</span>
        </button>
      </div>

      <div className="flex-1 overflow-auto space-y-2 pr-2">
        {paginatedEvents.map((e) => {
          const severity = getSeverity(e);
          const isSelected = selectedIds.has(e.id);
          const bg = isSelected 
            ? "bg-blue-500/10 border-blue-500/30" 
            : severity === "CRITICAL" ? "bg-red-500/10 border-red-500/20" : severity === "WARNING" ? "bg-yellow-500/10 border-yellow-500/20" : "bg-[#2a2a2a] border-[#E4E3E0]/10";
          const textColor = severity === "CRITICAL" ? "text-red-400" : severity === "WARNING" ? "text-yellow-400" : "text-[#E4E3E0]";
          const isExpanded = expandedId === e.id;

          return (
            <div 
              key={e.id} 
              className={`p-2 rounded border text-xs cursor-pointer transition-colors ${bg} hover:border-[#E4E3E0]/40`}
              onClick={() => setExpandedId(isExpanded ? null : e.id)}
            >
              <div className="flex justify-between items-start mb-1">
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={(evt) => onToggleSelect(e.id, evt)}
                    className="mt-0.5"
                  >
                    {isSelected ? <CheckSquare className="w-3.5 h-3.5 text-blue-400" /> : <Square className="w-3.5 h-3.5 text-gray-500" />}
                  </button>
                  <span className={`font-mono font-bold ${textColor}`}>{e.type}</span>
                </div>
                <span className="text-gray-500">{new Date(e.timestamp).toLocaleTimeString()}</span>
              </div>
              <div className="text-gray-400 font-mono break-all text-[10px] pl-5.5">
                hash: {e.hash}
              </div>
              
              {isExpanded ? (
                <div className="mt-3 pt-3 border-t border-[#E4E3E0]/10 overflow-x-auto pl-5.5">
                  <div className="font-mono text-gray-500 mb-1 uppercase tracking-wider text-[9px]">Execution Parameters & Metadata</div>
                  <pre className="text-[#E4E3E0] text-[10px] bg-[#141414] p-2 rounded border border-[#E4E3E0]/10 max-h-32 overflow-auto">
                    {JSON.stringify(e.payload, null, 2)}
                  </pre>
                  <div className="mt-2 text-[9px] text-gray-600 font-mono">
                    ID: {e.id}
                  </div>
                </div>
              ) : (
                <div className="text-gray-300 truncate mt-1 pl-5.5">
                  {JSON.stringify(e.payload)}
                </div>
              )}
            </div>
          );
        })}
        {paginatedEvents.length === 0 && (
          <div className="text-xs text-gray-500 text-center py-4">No audit events found.</div>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-[#E4E3E0]/10 pt-3">
        <div className="text-xs text-gray-500 font-mono">
          Total: {filteredLedger?.length || 0}
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1 rounded bg-[#2a2a2a] disabled:opacity-50 text-[#E4E3E0] hover:bg-[#3a3a3a]"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs text-gray-400 font-mono">
            {currentPage} / {Math.max(1, totalPages)}
          </span>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages || totalPages === 0}
            className="p-1 rounded bg-[#2a2a2a] disabled:opacity-50 text-[#E4E3E0] hover:bg-[#3a3a3a]"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
