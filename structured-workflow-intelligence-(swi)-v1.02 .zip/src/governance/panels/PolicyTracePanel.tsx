import React from "react";
import { policyRegistry } from "../../policy/registry";

export function PolicyTracePanel() {
  return (
    <div className="p-4 bg-surface border border-border rounded-md">
      <h2 className="text-sm font-semibold">Policy Registry</h2>

      <div className="mt-2 space-y-2 text-xs">
        {policyRegistry.map((p) => (
          <div key={p.id} className="border-b border-border pb-1">
            <div className="text-text-primary">{p.id}</div>
            <div className="text-text-muted">
              priority: {p.priority} | effect: {p.effect}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
