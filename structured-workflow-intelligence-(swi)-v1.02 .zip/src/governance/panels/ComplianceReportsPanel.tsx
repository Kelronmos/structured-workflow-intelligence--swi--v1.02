import React, { useState } from 'react';
import jsPDF from 'jspdf';
import { FileText, Download } from 'lucide-react';
import { AuditEvent } from '../../audit/types';

export function ComplianceReportsPanel({ ledger }: { ledger: AuditEvent[] }) {
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePDF = () => {
    setIsGenerating(true);
    setTimeout(() => {
      try {
        const doc = new jsPDF();
        
        // Header
        doc.setFont("helvetica", "bold");
        doc.setFontSize(22);
        doc.text("ISO 42001 Compliance Report", 20, 20);
        
        doc.setFontSize(12);
        doc.setFont("helvetica", "normal");
        doc.text(`Generated on: ${new Date().toISOString()}`, 20, 30);
        doc.text(`Total Audit Telemetry Records: ${ledger.length}`, 20, 38);

        // Calculate some basic stats
        const criticalCount = ledger.filter(l => l.type === "DRIFT_DETECTED" || l.payload?.severity === "CRITICAL").length;
        const routineCount = ledger.length - criticalCount;
        
        doc.text(`Routine Operations Logged: ${routineCount}`, 20, 46);
        doc.text(`Critical Interventions / Anomalies: ${criticalCount}`, 20, 54);

        doc.setLineWidth(0.5);
        doc.line(20, 60, 190, 60);

        // Attestations
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.text("Signed Execution Attestations", 20, 72);

        doc.setFontSize(10);
        doc.setFont("courier", "normal");

        // Filter to some 'signed' looking events or rule evaluations to demo
        const attestations = ledger.filter(l => l.type.includes("POLICY") || l.type.includes("RULE") || l.type === "DECISION_EVALUATED").slice(0, 15);
        
        let yPos = 82;
        if (attestations.length === 0) {
            doc.text("No policy enforcement attestations recorded yet.", 20, yPos);
        }

        attestations.forEach((att, idx) => {
            if (yPos > 270) {
                doc.addPage();
                yPos = 20;
            }
            doc.text(`[${new Date(att.timestamp).toLocaleTimeString()}] ${att.type}`, 20, yPos);
            doc.text(`HASH: ${att.hash.substring(0, 40)}...`, 24, yPos + 5);
            yPos += 12;
        });

        doc.save(`ISO42001_Compliance_Summary_${new Date().getTime()}.pdf`);
      } catch (err) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to generate PDF", err);
      } finally {
        setIsGenerating(false);
      }
    }, 500); // UI simulation
  };

  return (
    <div className="p-8 border border-[#E4E3E0]/20 rounded-md bg-[#1a1a1a] flex flex-col items-center justify-center min-h-[400px]">
      <div className="w-16 h-16 bg-[#2a2a2a] rounded-full flex items-center justify-center mb-6">
         <FileText className="w-8 h-8 text-[#E4E3E0]" />
      </div>
      
      <h2 className="text-xl font-bold uppercase tracking-widest font-mono text-[#E4E3E0] mb-2 text-center">Compliance Reporting</h2>
      <p className="text-gray-400 text-sm max-w-lg text-center mb-8">
        Generate immutable, cryptographically-backed execution summaries to demonstrate ongoing adherence to ISO 42001 AI Management System standards.
      </p>

      <div className="flex flex-col gap-4 w-full max-w-sm">
        <div className="bg-[#141414] p-4 rounded border border-[#E4E3E0]/10 flex justify-between items-center">
            <div>
              <div className="text-sm font-bold text-[#E4E3E0] font-mono">ISO 42001 Attestation Summary</div>
              <div className="text-xs text-gray-500">Includes last 24h of signed telemetry</div>
            </div>
            <button 
              onClick={generatePDF}
              disabled={isGenerating}
              className="p-2 bg-[#E4E3E0] text-[#141414] rounded hover:bg-white transition-colors disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
            </button>
        </div>
      </div>
    </div>
  );
}
