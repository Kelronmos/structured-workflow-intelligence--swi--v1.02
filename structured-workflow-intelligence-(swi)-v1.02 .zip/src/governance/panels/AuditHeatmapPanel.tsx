import React, { useMemo } from 'react';
import { AuditEvent } from '../../audit/types';

function getSeverity(event: AuditEvent): "INFO" | "WARNING" | "CRITICAL" {
  if (event.type === "DRIFT_DETECTED") return "CRITICAL";
  if (event.payload?.severity) return event.payload.severity;
  return "INFO";
}

export function AuditHeatmapPanel({ ledger }: { ledger: AuditEvent[] }) {
  // Generate a matrix of 24 hours x 4 quadrants (15 min intervals)
  const heatmapData = useMemo(() => {
    const data: { [hour: string]: { [quadrant: string]: { count: number, maxSeverity: "INFO" | "WARNING" | "CRITICAL" } } } = {};
    
    const now = new Date();
    // Initialize
    for (let i = 23; i >= 0; i--) {
      const h = new Date(now.getTime() - i * 3600000).getHours();
      data[h] = {
        "0-14": { count: 0, maxSeverity: "INFO" },
        "15-29": { count: 0, maxSeverity: "INFO" },
        "30-44": { count: 0, maxSeverity: "INFO" },
        "45-59": { count: 0, maxSeverity: "INFO" },
      };
    }

    const twentyFourHoursAgo = now.getTime() - 24 * 3600000;

    ledger.forEach(event => {
      const eventTime = new Date(event.timestamp).getTime();
      if (eventTime >= twentyFourHoursAgo) {
        const d = new Date(event.timestamp);
        const h = d.getHours();
        const m = d.getMinutes();
        const severity = getSeverity(event);
        
        let quad = "0-14";
        if (m >= 15 && m < 30) quad = "15-29";
        else if (m >= 30 && m < 45) quad = "30-44";
        else if (m >= 45) quad = "45-59";

        if (data[h] && data[h][quad]) {
          data[h][quad].count += 1;
          // promote severity if higher
          if (severity === "CRITICAL" || (severity === "WARNING" && data[h][quad].maxSeverity === "INFO")) {
             data[h][quad].maxSeverity = severity;
          }
        }
      }
    });

    // Create an ordered array for plotting
    const hours = [];
    for (let i = 23; i >= 0; i--) {
      const hDate = new Date(now.getTime() - i * 3600000);
      const h = hDate.getHours();
      hours.push(h);
    }

    return { hours, data };
  }, [ledger]);

  const getColor = (count: number, maxSeverity: string) => {
    if (count === 0) return "bg-[#2a2a2a]";
    // Anomaly clusters or critical severity
    if (maxSeverity === "CRITICAL" || count > 10) return "bg-red-500/80 shadow-[0_0_8px_rgba(239,68,68,0.5)]";
    if (maxSeverity === "WARNING" || count > 5) return "bg-yellow-500/80";
    // base info depending on intensity
    if (count > 2) return "bg-[#E4E3E0]/60";
    return "bg-[#E4E3E0]/30";
  };

  return (
    <div className="p-4 bg-[#1a1a1a] border border-[#E4E3E0]/20 rounded-md flex flex-col h-[300px]">
      <h2 className="text-sm font-semibold uppercase tracking-widest font-mono text-[#E4E3E0] mb-4">24H Anomaly Heatmap</h2>
      
      <div className="flex-1 overflow-x-auto flex flex-col justify-end">
        <div className="flex justify-between items-end gap-1 mb-2">
          {heatmapData.hours.map((hour, idx) => (
            <div key={`${hour}-${idx}`} className="flex flex-col gap-1 w-full flex-1 min-w-[20px]">
              {["45-59", "30-44", "15-29", "0-14"].map(q => {
                const cell = heatmapData.data[hour][q];
                return (
                  <div 
                    key={q} 
                    className={`h-6 rounded-sm ${getColor(cell.count, cell.maxSeverity)} transition-colors tooltip-trigger relative`}
                    title={`Time: ${hour.toString().padStart(2, '0')}:${q} | Events: ${cell.count} | Max Risk: ${cell.maxSeverity}`}
                  ></div>
                );
              })}
              <span className="text-[10px] text-gray-500 font-mono mt-1 text-center truncate">{hour}h</span>
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex justify-end gap-4 mt-2 text-[10px] font-mono text-gray-400">
         <div className="flex items-center gap-1"><div className="w-3 h-3 bg-[#2a2a2a] rounded-sm"></div> No Event</div>
         <div className="flex items-center gap-1"><div className="w-3 h-3 bg-[#E4E3E0]/40 rounded-sm"></div> Routine</div>
         <div className="flex items-center gap-1"><div className="w-3 h-3 bg-yellow-500/80 rounded-sm"></div> Warning</div>
         <div className="flex items-center gap-1"><div className="w-3 h-3 bg-red-500/80 rounded-sm shadow-[0_0_4px_rgba(239,68,68,0.5)]"></div> Critical / Anomaly</div>
      </div>
    </div>
  );
}
