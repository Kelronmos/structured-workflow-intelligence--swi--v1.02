import React from "react";
import { runAdversarialSuite } from "../../adversarial/testRunner";

export function AdversarialPanel() {
  const run = async () => {
    const result = await runAdversarialSuite();
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, result);
  };

  return (
    <div className="p-4 bg-surface border border-border rounded-md">
      <h2 className="text-sm font-semibold">Adversarial Testing</h2>

      <button
        className="mt-2 px-3 py-1 bg-red-500/20 text-red-500 rounded text-xs font-semibold"
        onClick={run}
      >
        Run Stress Suite
      </button>
    </div>
  );
}
