import React, { useState, useEffect, useMemo } from 'react';
import { getLedger } from '../../audit/ledger';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export function AuditChartPanel() {
  const [ledger, setLedger] = useState(getLedger());

  useEffect(() => {
    const interval = setInterval(() => {
      setLedger(getLedger());
    }, 5000); // 5s poll for 24h chart
    return () => clearInterval(interval);
  }, []);

  const chartData = useMemo(() => {
    // Group by hour instead of minute for a 24-hour chart
    const grouped = new Map<string, { volume: number, policyEvents: number }>();
    
    // Initialize last 24 hours
    const now = new Date();
    for (let i = 23; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 3600000);
      const key = `${d.getHours().toString().padStart(2, '0')}:00`;
      grouped.set(key, { volume: 0, policyEvents: 0 });
    }

    const twentyFourHoursAgo = now.getTime() - 24 * 3600000;

    ledger.forEach(event => {
      const eventTime = new Date(event.timestamp).getTime();
      // Only include last 24 hours
      if (eventTime >= twentyFourHoursAgo) {
        const d = new Date(event.timestamp);
        const key = `${d.getHours().toString().padStart(2, '0')}:00`;
        
        if (!grouped.has(key)) {
           grouped.set(key, { volume: 0, policyEvents: 0 });
        }
        
        const current = grouped.get(key)!;
        current.volume += 1;

        // Policy enforcement logic: drift, rules checked, etc.
        const isPolicyEvent = event.type.includes('POLICY') || event.type === 'DRIFT_DETECTED' || event.type === 'DECISION_EVALUATED' || event.payload?.policyId;
        if (isPolicyEvent) {
          current.policyEvents += 1;
        }
      }
    });

    return Array.from(grouped.entries()).map(([time, data]) => ({
      time,
      "Log Volume": data.volume,
      "Policy Events": data.policyEvents
    }));
    
  }, [ledger]);

  return (
    <div className="p-4 bg-[#1a1a1a] border border-[#E4E3E0]/20 rounded-md flex flex-col h-[300px]">
      <h2 className="text-sm font-semibold uppercase tracking-widest font-mono text-[#E4E3E0] mb-4">24H Activity: Volume vs Policy Enforcement</h2>
      <div className="flex-1 w-full relative">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="time" stroke="#888" fontSize={10} tickMargin={10} />
            <YAxis stroke="#888" fontSize={10} allowDecimals={false} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1a1a1a', borderColor: '#333', fontSize: '12px' }}
              itemStyle={{ color: '#E4E3E0' }}     
            />
            <Legend wrapperStyle={{ fontSize: '11px', color: '#888' }} />
            <Line 
              type="monotone" 
              dataKey="Log Volume" 
              stroke="#E4E3E0" 
              strokeWidth={2}
              dot={{ r: 2, fill: '#1a1a1a', stroke: '#E4E3E0', strokeWidth: 1 }}
              activeDot={{ r: 4, fill: '#E4E3E0' }}
              isAnimationActive={false}
            />
            <Line 
              type="monotone" 
              dataKey="Policy Events" 
              stroke="#ef4444" 
              strokeWidth={2}
              strokeDasharray="4 4"
              dot={{ r: 2, fill: '#1a1a1a', stroke: '#ef4444', strokeWidth: 1 }}
              activeDot={{ r: 4, fill: '#ef4444' }}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
