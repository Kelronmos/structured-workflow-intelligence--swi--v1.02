import { TruthKernel } from "../kernel/TruthKernel";

export class SWIClient {
  kernel: TruthKernel;

  constructor(kernel: TruthKernel) {
    this.kernel = kernel;
  }

  submit(event: any) {
    return this.kernel.execute("EVENT", event);
  }
}
