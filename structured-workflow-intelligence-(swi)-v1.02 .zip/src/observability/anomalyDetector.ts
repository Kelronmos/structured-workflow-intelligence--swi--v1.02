import { getMetrics } from "./metrics";
import { emitAlert } from "./alerts";

const THRESHOLDS = {
  DRIFT_WARNING: 3,
  DRIFT_CRITICAL: 10,
  SIGNATURE_FAILURE: 1,
  LEDGER_FAILURE: 1,
};

export function checkAnomalies() {
  const metrics = getMetrics();

  if (metrics.events.driftDetected >= THRESHOLDS.DRIFT_CRITICAL) {
    emitAlert("CRITICAL", `Drift events exceeded critical threshold (${metrics.events.driftDetected})`);
  } else if (metrics.events.driftDetected >= THRESHOLDS.DRIFT_WARNING) {
    emitAlert("WARNING", `Drift events exceeded warning threshold (${metrics.events.driftDetected})`);
  }

  if (metrics.events.signatureFailures >= THRESHOLDS.SIGNATURE_FAILURE) {
    emitAlert("CRITICAL", `Signature failure detected (${metrics.events.signatureFailures})`);
  }

  if (metrics.events.ledgerFailures >= THRESHOLDS.LEDGER_FAILURE) {
    emitAlert("CRITICAL", `Ledger integrity failure detected (${metrics.events.ledgerFailures})`);
  }
}
