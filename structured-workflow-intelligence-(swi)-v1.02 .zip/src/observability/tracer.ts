export interface Span {
  id: string;
  name: string;
  startTime: number;
  endTime?: number;
  duration?: number;
  tags?: Record<string, string>;
  error?: Error;
}

const spans: Map<string, Span> = new Map();

export function startSpan(name: string, tags?: Record<string, string>): Span {
  const span: Span = {
    id: crypto.randomUUID(),
    name,
    startTime: Date.now(),
    tags,
  };
  spans.set(span.id, span);
  return span;
}

export function endSpan(id: string, error?: Error): Span | undefined {
  const span = spans.get(id);
  if (span) {
    span.endTime = Date.now();
    span.duration = span.endTime - span.startTime;
    if (error) {
      span.error = error;
    }
  }
  return span;
}

export function getSpans(): Span[] {
  return Array.from(spans.values());
}
