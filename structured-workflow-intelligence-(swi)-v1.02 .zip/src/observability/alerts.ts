export interface Alert {
  id: string;
  type: "CRITICAL" | "WARNING" | "INFO";
  message: string;
  timestamp: number;
}

const alerts: Alert[] = [];

export function emitAlert(type: Alert["type"], message: string) {
  const alert: Alert = {
    id: crypto.randomUUID(),
    type,
    message,
    timestamp: Date.now(),
  };
  alerts.push(alert);
  console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, `[ALERT][${type}] ${message}`);
  return alert;
}

export function getAlerts(): Alert[] {
  return [...alerts];
}
