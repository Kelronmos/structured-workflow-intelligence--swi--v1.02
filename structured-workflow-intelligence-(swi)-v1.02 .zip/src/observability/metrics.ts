export interface MetricsStore {
  decisions: {
    approvals: number;
    denials: number;
    reviews: number;
    humanRequired: number;
  };
  events: {
    driftDetected: number;
    signatureFailures: number;
    ledgerFailures: number;
  };
}

const metrics: MetricsStore = {
  decisions: {
    approvals: 0,
    denials: 0,
    reviews: 0,
    humanRequired: 0,
  },
  events: {
    driftDetected: 0,
    signatureFailures: 0,
    ledgerFailures: 0,
  },
};

export function incrementDecision(type: "APPROVE" | "DENY" | "REVIEW" | "REQUIRE_HUMAN") {
  if (type === "APPROVE") metrics.decisions.approvals++;
  if (type === "DENY") metrics.decisions.denials++;
  if (type === "REVIEW") metrics.decisions.reviews++;
  if (type === "REQUIRE_HUMAN") metrics.decisions.humanRequired++;
}

export function incrementEvent(type: "DRIFT" | "SIGNATURE_FAILURE" | "LEDGER_FAILURE") {
  if (type === "DRIFT") metrics.events.driftDetected++;
  if (type === "SIGNATURE_FAILURE") metrics.events.signatureFailures++;
  if (type === "LEDGER_FAILURE") metrics.events.ledgerFailures++;
}

export function getMetrics(): MetricsStore {
  return { ...metrics };
}
