export interface AdversarialSummary {
  totalAttacks: number;
  detected: number;
  mitigated: number;
  criticalFailures: number;
}

export interface CanonicalResult {
  id: string;
  timestamp: number;
  input: any;

  decision: {
    status: "ALLOW" | "BLOCK" | "REVIEW";
    confidence: number;
  };

  evidence: {
    rulesTriggered: string[];
    adversarialResults: AdversarialSummary;
    systemStateHash: string;
  };

  integrity: {
    hash: string;
    previousHash?: string;
  };
}
