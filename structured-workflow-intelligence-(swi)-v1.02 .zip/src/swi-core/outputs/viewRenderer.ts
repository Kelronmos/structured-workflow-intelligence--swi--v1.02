import { CanonicalResult } from './canonicalReport';
import { AttestationType } from '../attestations/attestationCore';
import { signAttestation } from '../attestations/signer';

export function generateView(canonical: CanonicalResult, type: AttestationType, privateKey: string) {
  const signature = signAttestation(canonical.integrity.hash, privateKey);
  
  return {
    canonicalId: canonical.id,
    viewType: type,
    ref: 'canonical-report.json',
    signature,
    timestamp: Date.now()
  };
}
