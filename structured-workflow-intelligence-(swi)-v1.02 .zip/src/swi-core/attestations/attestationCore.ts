export type AttestationType =
  | "TRACE_VIEW"
  | "PROOF_VIEW"
  | "AUDIT_VIEW";

export interface Attestation {
  type: AttestationType;
  canonicalId: string;
  signature: string;
  timestamp: number;
}
