import { cryptoSign } from '../cryptoUtils';

export function signAttestation(
  canonicalHash: string,
  privateKey: string
): string {
  return cryptoSign(canonicalHash + privateKey);
}
