import { Attestation } from './attestationCore';
import { validateSignature } from '../cryptoUtils';

export function verifyAttestation(att: Attestation): boolean {
  return validateSignature(att.signature, att.canonicalId);
}
