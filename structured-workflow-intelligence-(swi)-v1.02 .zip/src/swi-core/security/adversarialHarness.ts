export interface AttackCase {
  id: string;
  type: "replay" | "byzantine" | "drift" | "forgery" | "fuzz";
  payload: unknown;
}

export interface AttackResult {
  caseId: string;
  detected: boolean;
  mitigationTriggered: boolean;
  severity: "low" | "medium" | "high";
}
