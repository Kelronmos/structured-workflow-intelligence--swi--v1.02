function loadPolicyRules() {
  return [
    {
      id: "rule-1",
      evaluate: (input: any, state: any) => true
    },
    {
      id: "rule-2",
      evaluate: (input: any, state: any) => input && input.valid !== false
    }
  ];
}

export function evaluatePolicy(input: any, state: any) {
  const rules = loadPolicyRules();

  return rules.map(rule => ({
    ruleId: rule.id,
    passed: rule.evaluate(input, state),
  }));
}
