export function cryptoSign(data: string): string {
  // Mock crypto signature for attestation
  return `sig_${Buffer.from(data).toString('base64').substring(0, 32)}`;
}

export function validateSignature(signature: string, payload: string): boolean {
  // Mock verification
  return signature.startsWith('sig_');
}
