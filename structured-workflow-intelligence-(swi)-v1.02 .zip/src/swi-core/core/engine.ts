import { CanonicalResult } from '../outputs/canonicalReport';
import { evaluatePolicy } from '../governance/policyEngine';
import { runFuzzSuite } from '../security/fuzzRunner';
import { generateView } from '../outputs/viewRenderer';
import { cryptoSign } from '../cryptoUtils';

export async function executeEngine(input: any, systemState: any, privateKey: string) {
  // 1. Evaluate Governance Policies
  const policyResults = evaluatePolicy(input, systemState);
  const rulesTriggered = policyResults.filter(r => !r.passed).map(r => r.ruleId);
  const status = rulesTriggered.length > 0 ? "BLOCK" : "ALLOW";
  
  // 2. Draft Canonical Result Base
  const canonicalId = `cr-${Date.now()}`;
  const systemStateHash = cryptoSign(JSON.stringify(systemState));
  
  const baseCanonical: CanonicalResult = {
    id: canonicalId,
    timestamp: Date.now(),
    input,
    decision: {
      status,
      confidence: rulesTriggered.length === 0 ? 0.99 : 0.4
    },
    evidence: {
      rulesTriggered,
      adversarialResults: {
        totalAttacks: 0,
        detected: 0,
        mitigated: 0,
        criticalFailures: 0
      },
      systemStateHash
    },
    integrity: {
      hash: ""
    }
  };

  // 3. Security & Adversarial Harness (Fuzzing)
  const attackResults = await runFuzzSuite(baseCanonical);
  
  baseCanonical.evidence.adversarialResults = {
    totalAttacks: attackResults.length,
    detected: attackResults.filter(r => r.detected).length,
    mitigated: attackResults.filter(r => r.mitigationTriggered).length,
    criticalFailures: attackResults.filter(r => r.severity === 'high' && !r.mitigationTriggered).length
  };
  
  // 4. Finalize Canonical Integrity Hash
  baseCanonical.integrity.hash = cryptoSign(JSON.stringify(baseCanonical.evidence));

  // 5. Generate Output Views (Attestations)
  const traceView = generateView(baseCanonical, "TRACE_VIEW", privateKey);
  const proofView = generateView(baseCanonical, "PROOF_VIEW", privateKey);
  const auditView = generateView(baseCanonical, "AUDIT_VIEW", privateKey);

  return {
    canonicalReport: baseCanonical,
    views: {
      trace: traceView,
      proof: proofView,
      audit: auditView
    }
  };
}
