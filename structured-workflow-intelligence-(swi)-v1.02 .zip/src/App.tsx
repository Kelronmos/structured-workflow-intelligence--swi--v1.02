import React, { useState } from 'react';
import { PlatformProvider } from './contexts/PlatformContext';
import { DashboardShell } from './components/dashboard/DashboardShell';
import { AuditLogView } from './components/dashboard/AuditLogView';
import { FireflyDashboard } from './components/dashboard/FireflyDashboard';
import { TruthKernel } from './components/dashboard/TruthKernel';

export default function App() {
  const [route, setRoute] = useState("firefly");

  return (
    <PlatformProvider>
      <DashboardShell activeRoute={route} onNavigate={setRoute}>
        {route === "firefly" && <FireflyDashboard />}
        {route === "truth-kernel" && <TruthKernel />}
        {route === "audit" && <AuditLogView />}
        {route === "security" && <div className="text-gray-400 p-8 text-center border border-gray-800 border-dashed rounded">Security Module (Stub)</div>}
        {route === "settings" && <div className="text-gray-400 p-8 text-center border border-gray-800 border-dashed rounded">Platform Config (Stub)</div>}
      </DashboardShell>
    </PlatformProvider>
  );
}
