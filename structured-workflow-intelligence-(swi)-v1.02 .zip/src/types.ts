import { DriftReport } from "../swi-core/kernel/DriftTypes";

export interface Trace {
  decision: 'ALLOW' | 'REFUSE' | 'EXECUTE' | 'HALT' | 'ESCALATE' | 'REDIRECT';
  artifactId: string;
  timestamp: string | number;
  signature: string;
  provenance: string;
  reason: string;
  violation_type?: string;
  input?: SimulationParams;
  action?: string;
  tokenValid?: boolean;
  locallyValid?: boolean;
  drift?: {
    score: number;
    degraded: boolean;
    report?: DriftReport;
  };
  context?: {
    userBehavior: string;
    environment: string;
    policyMismatch: boolean;
  };
  metadata?: {
    engine: string;
    threshold: number;
  };
  scenario?: string;
  scenarioId?: string;
  modules?: {
    moduleId: string;
    moduleName: string;
    moduleType: string;
    moduleDescription?: string;
    success: boolean;
    timestamp: string;
    signal: unknown;
    signature: string;
  }[];
}

export interface ScenarioResult {
  id: string;
  name?: string;
  scenario?: string;
  scenarioId?: string;
  decision: 'ALLOW' | 'REFUSE';
  reason: string;
  timestamp: string;
  input: SimulationParams;
  artifactId?: string;
  violation_type?: string;
  tokenValid?: boolean;
  locallyValid?: boolean;
  drift?: {
    score: number;
    degraded: boolean;
  };
}

export interface DecisionObject {
  action: string;
  value: number;
  decision: 'ALLOW' | 'ALLOW_WITH_MONITORING' | 'HALT';
  reason: string;
  violation_type: string;
  drift_score: number;
  policy_id: string;
  timestamp: string;
  signature?: string;
}

export interface CommonsenseData {
  timestamp: string;
  drift: number;
  reason: string;
}

export interface TransactionBlock {
  status: string;
  hash: string;
  request?: {
    event_id?: string;
    actor?: string;
  };
  drift_calculated: number;
  causalPath?: string[];
  decision?: string;
  reason?: string;
  swiProof?: {
    nodeId: string;
    boundaryState: string;
    proof: string;
    publicSignals: string[];
  };
}

export interface StableState extends Partial<Trace> {
  verificationState: string;
  rootHash: string;
  signature: string;
}

export interface SimulationParams {
  tokenStatus: string;
  action: string;
  userBehavior: string;
  environment: string;
  policyMismatch: boolean;
  driftScore: number;
  driftConfig: {
    increments: {
      ANOMALOUS_BEHAVIOR: number;
      MILD_BEHAVIOR: number;
      UNSTABLE_ENVIRONMENT: number;
      POLICY_MISMATCH: number;
    };
    threshold: number;
  };
  swiConfig: {
    deactivatedTypes: string[];
    deactivatedIds: string[];
  };
  mutationIntensity?: number;
  legitimate?: boolean;
  intent_drift?: number;
}
