import crypto from 'crypto';

export interface TransparencyLogEntry {
  log_index: number;
  artifact_hash: string | null;
  merkle_root: string | null;
  signature: string;
  public_key: string;
  timestamp: string;
}

// In-memory transparency log simulation
const tlog: TransparencyLogEntry[] = [];

export function appendToTransparencyLog(entry: Omit<TransparencyLogEntry, 'log_index' | 'timestamp'>): TransparencyLogEntry {
  const logEntry: TransparencyLogEntry = {
    ...entry,
    log_index: tlog.length + 1,
    timestamp: new Date().toISOString()
  };
  tlog.push(logEntry);
  return logEntry;
}

export function getTransparencyLog(): TransparencyLogEntry[] {
  return tlog;
}

export function verifyLogInclusion(logIndex: number, hash: string): boolean {
  const entry = tlog.find(e => e.log_index === logIndex);
  if (!entry) return false;
  return entry.artifact_hash === hash || entry.merkle_root === hash;
}
