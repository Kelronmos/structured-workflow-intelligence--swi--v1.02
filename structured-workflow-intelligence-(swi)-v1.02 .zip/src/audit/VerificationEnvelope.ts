export interface VerificationEnvelope {
  proofId: string;
  generatedAt: string;
  verifiedAt: string;
  signerId: string;
  signerType: "human" | "service" | "pipeline";
  algorithm: "SHA256" | "SHA512";
  hash: string;
  signature: string;
  verificationStatus: "VERIFIED" | "FAILED" | "PENDING";
  auditTrailId: string;
  sourceVersion: string;
}
