import { appendEvent } from "../ledger";

export async function recordDecision(decision: any) {
  return appendEvent({
    id: crypto.randomUUID(),
    type: "DECISION_EVALUATED",
    timestamp: Date.now(),
    actor: "SYSTEM",
    refId: decision.id,
    payload: decision,
  });
}
