import crypto from 'crypto';

export function canonicalizeJson(obj: any): string {
  if (typeof obj !== 'object' || obj === null) return JSON.stringify(obj);
  if (Array.isArray(obj)) return `[${obj.map(canonicalizeJson).join(',')}]`;
  const keys = Object.keys(obj).sort();
  return `{${keys.map(k => `${JSON.stringify(k)}:${canonicalizeJson(obj[k])}`).join(',')}}`;
}

export function hashLeaf(event: any): string {
  const canonical = canonicalizeJson(event);
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

export function buildMerkleTree(hashes: string[]): string {
  if (hashes.length === 0) return crypto.createHash('sha256').update('').digest('hex');
  if (hashes.length === 1) return hashes[0];
  
  const nextLevel: string[] = [];
  for (let i = 0; i < hashes.length; i += 2) {
    const left = hashes[i];
    const right = i + 1 < hashes.length ? hashes[i+1] : hashes[i]; // Duplicate last node if odd
    nextLevel.push(crypto.createHash('sha256').update(left + right).digest('hex'));
  }
  
  return buildMerkleTree(nextLevel);
}

export interface MerkleRootRecord {
  merkle_root: string;
  tree_size: number;
  timestamp: string;
  signed_by: string;
  signature: string;
  transparency_log_index: string | number;
}

export function generateRootAnchor(events: any[]): MerkleRootRecord {
  const hashes = events.map(hashLeaf);
  const root = buildMerkleTree(hashes);
  const timestamp = new Date().toISOString();
  
  const signatureMaterial = `${root}:${timestamp}:kms:alias/swi-root`;
  const signature = crypto.createHash('sha512').update(signatureMaterial).digest('base64');

  return {
    merkle_root: root,
    tree_size: events.length,
    timestamp,
    signed_by: "kms:alias/swi-root",
    signature,
    transparency_log_index: `tlog-${Date.now()}`
  };
}
