import { AuditEvent } from "./types";
import { hashEvent } from "./hash";

let ledger: AuditEvent[] = [];

export async function appendEvent(
  event: Omit<AuditEvent, "hash" | "prevHash">
) {
  const prevHash = ledger.length
    ? ledger[ledger.length - 1].hash
    : "GENESIS";
  const fullEvent: Omit<AuditEvent, "hash"> = {
    ...event,
    prevHash,
  };
  const hash = await hashEvent(fullEvent);
  const finalEvent: AuditEvent = { ...fullEvent, hash };
  ledger.push(finalEvent);
  return finalEvent;
}

export function getLedger() {
  return [...ledger];
}
