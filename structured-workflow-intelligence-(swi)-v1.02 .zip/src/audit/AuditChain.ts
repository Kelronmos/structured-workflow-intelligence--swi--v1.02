import crypto from 'crypto';

export function createAuditRecord(
  previousHash:string,
  payload:any
) {

  const record = {
    timestamp:new Date().toISOString(),
    previousHash,
    payload
  };

  const hash = crypto
    .createHash("sha256")
    .update(JSON.stringify(record))
    .digest("hex");

  return {
    ...record,
    hash
  };
}
