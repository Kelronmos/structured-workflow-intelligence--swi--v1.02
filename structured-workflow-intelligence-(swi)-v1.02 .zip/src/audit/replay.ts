import { getLedger } from "./ledger";

export function replayLedger() {
  const ledger = getLedger();
  const reconstructed = {
    decisions: [] as any[],
    driftEvents: [] as any[],
    bootEvents: [] as any[],
  };

  for (const event of ledger) {
    switch (event.type) {
      case "DECISION_EVALUATED":
        reconstructed.decisions.push(event.payload);
        break;
      case "DRIFT_DETECTED":
        reconstructed.driftEvents.push(event.payload);
        break;
      case "BOOT_VERIFIED":
        reconstructed.bootEvents.push(event.payload);
        break;
    }
  }

  return reconstructed;
}
