export type AuditEventType =
  | "DECISION_EVALUATED"
  | "POLICY_APPLIED"
  | "DRIFT_DETECTED"
  | "BOOT_VERIFIED"
  | "SIGNATURE_CHECK";

export interface AuditEvent {
  id: string;
  type: AuditEventType;
  timestamp: number;
  actor: "SYSTEM" | "HUMAN";
  refId: string;
  payload: Record<string, any>;
  prevHash: string;
  hash: string;
}
