import crypto from 'crypto';

export interface UVEnvelope {
  artifact_id: string;
  type: string;
  payload: any;
  payload_hash: string;
  timestamp: string;
  signing_key_id: string;
  signature: string;
  transparency_log_entry?: string;
  sbom_ref?: string;
  provenance_ref?: string;
  revocation_status: "valid" | "revoked";
}

export function createEnvelope(payload: any, type: string = "swi-export"): UVEnvelope {
  const payloadStr = typeof payload === "string" ? payload : JSON.stringify(payload);
  const payloadHash = crypto.createHash('sha256').update(payloadStr).digest('hex');
  const timestamp = new Date().toISOString();
  
  // Simulated signature with dummy Root Key
  const signatureMaterial = `${payloadHash}:${timestamp}:root-v3`;
  const signature = crypto.createHash('sha512').update(signatureMaterial).digest('base64');
  
  return {
    artifact_id: crypto.randomUUID(),
    type,
    payload,
    payload_hash: payloadHash,
    timestamp,
    signing_key_id: "kid:root-v3",
    signature,
    transparency_log_entry: `rekor:simulated-${Date.now()}`,
    sbom_ref: "sbom:sha256:abcd1234efgh5678", // Would map to actual SBOM
    provenance_ref: "slsa:build-4.8.0",
    revocation_status: "valid"
  };
}

export function verifyEnvelope(envelope: UVEnvelope): boolean {
  if (envelope.revocation_status === "revoked") return false;

  const payloadStr = typeof envelope.payload === "string" ? envelope.payload : JSON.stringify(envelope.payload);
  const rehashed = crypto.createHash('sha256').update(payloadStr).digest('hex');
  
  if (rehashed !== envelope.payload_hash) return false;

  const expectedSigMaterial = `${envelope.payload_hash}:${envelope.timestamp}:${envelope.signing_key_id.replace('kid:', '')}`;
  const expectedSig = crypto.createHash('sha512').update(expectedSigMaterial).digest('base64');

  return expectedSig === envelope.signature;
}
