type MessageType = "PRE-PREPARE" | "PREPARE" | "COMMIT";

type Message = {
  view: number;
  sequence: number;
  digest: string;
  sender: string;
  type: MessageType;
};

export class PBFTNode {
  id: string;
  peers: PBFTNode[] = [];

  view: number = 0;
  log: Message[] = [];

  prepareSet: Map<string, Set<string>> = new Map();
  commitSet: Map<string, Set<string>> = new Map();

  constructor(id: string) {
    this.id = id;
  }

  connect(peer: PBFTNode) {
    this.peers.push(peer);
  }

  // PRIMARY NODE
  prePrepare(sequence: number, digest: string) {
    const msg: Message = {
      view: this.view,
      sequence,
      digest,
      sender: this.id,
      type: "PRE-PREPARE",
    };

    this.broadcast(msg);
  }

  receive(msg: Message) {
    this.log.push(msg);

    if (msg.type === "PRE-PREPARE") {
      this.handlePrepare(msg);
    }

    if (msg.type === "PREPARE") {
      this.handleCommit(msg);
    }

    if (msg.type === "COMMIT") {
      this.finalize(msg);
    }
  }

  private handlePrepare(msg: Message) {
    this.broadcast({
      ...msg,
      type: "PREPARE",
      sender: this.id,
    });
  }

  private handleCommit(msg: Message) {
    const key = msg.digest;

    if (!this.prepareSet.has(key)) {
      this.prepareSet.set(key, new Set());
    }

    this.prepareSet.get(key)!.add(msg.sender);

    if (this.prepareSet.get(key)!.size >= this.quorum()) {
      this.broadcast({
        ...msg,
        type: "COMMIT",
        sender: this.id,
      });
    }
  }

  private finalize(msg: Message) {
    const key = msg.digest;

    if (!this.commitSet.has(key)) {
      this.commitSet.set(key, new Set());
    }

    this.commitSet.get(key)!.add(msg.sender);
  }

  private broadcast(msg: Message) {
    for (const peer of this.peers) {
      peer.receive(msg);
    }
  }

  private quorum() {
    return Math.floor(((this.peers.length + 1) * 2) / 3);
  }
}
