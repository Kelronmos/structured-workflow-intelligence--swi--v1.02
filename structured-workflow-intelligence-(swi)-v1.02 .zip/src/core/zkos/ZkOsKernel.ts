import { hashEvent } from "../../audit/hash";

export type ProcessStatus = "Ready" | "Running" | "Waiting" | "Halted";

export enum Syscall {
  ReadMemory = "ReadMemory",
  WriteMemory = "WriteMemory",
  SendMessage = "SendMessage",
  ReceiveMessage = "ReceiveMessage",
  CreateProcess = "CreateProcess",
  HaltProcess = "HaltProcess",
}

export enum Capability {
  MemoryRead = "MemoryRead",
  MemoryWrite = "MemoryWrite",
  ProcessCreate = "ProcessCreate",
  NetSend = "NetSend",
}

export interface Process {
  pid: number;
  pc: number;
  memoryRoot: string;
  capabilityRoot: string;
  status: ProcessStatus;
  capabilities: Capability[];
}

export interface Message {
  from: number;
  to: number;
  payloadHash: string;
}

export interface KernelTrace {
  cycle: number;
  runningPid: number;
  stateRootBefore: string;
  stateRootAfter: string;
  action: string;
}

export interface KernelState {
  cycle: number;
  processes: Process[];
  schedulerTick: number;
  messageQueue: Message[];
  traces: KernelTrace[];
  globalStateRoot: string;
}

export class ZkOsKernel {
  private state: KernelState;

  constructor() {
    this.state = {
      cycle: 0,
      processes: [],
      schedulerTick: 0,
      messageQueue: [],
      traces: [],
      globalStateRoot: "GENESIS",
    };
  }

  public getSnapshot(): KernelState {
    return JSON.parse(JSON.stringify(this.state));
  }

  public async initGenesisProcess() {
    const p: Process = {
      pid: 1,
      pc: 0,
      memoryRoot: "GENESIS_MEM",
      capabilityRoot: "GENESIS_CAP",
      status: "Ready",
      capabilities: [Capability.MemoryRead, Capability.MemoryWrite, Capability.ProcessCreate, Capability.NetSend],
    };
    this.state.processes.push(p);
    this.state.globalStateRoot = await this.hashState();
  }

  private async hashState() {
    const encoder = new TextEncoder();
    const data = encoder.encode(JSON.stringify({
      cycle: this.state.cycle,
      processes: this.state.processes.map(p => ({ pid: p.pid, mem: p.memoryRoot, cap: p.capabilityRoot, status: p.status })),
      tick: this.state.schedulerTick
    }));
    const digest = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, "0")).join("");
  }

  public nextProcessIndex(): number {
    if (this.state.processes.length === 0) return -1;
    return this.state.schedulerTick % this.state.processes.length;
  }

  private checkCapability(process: Process, capability: Capability): boolean {
    return process.capabilities.includes(capability);
  }

  public async tick() {
    if (this.state.processes.length === 0) return;

    this.state.cycle += 1;
    const processIndex = this.nextProcessIndex();
    const currentProcess = this.state.processes[processIndex];

    const stateRootBefore = this.state.globalStateRoot;

    if (currentProcess.status !== "Halted") {
      currentProcess.status = "Running";
      currentProcess.pc += 1;
      
      // Simulate deterministic changes to memory root
      currentProcess.memoryRoot = (await this.hashState()).substring(0, 16);
      currentProcess.status = "Waiting"; // yield
    }

    this.state.schedulerTick += 1;
    this.state.globalStateRoot = await this.hashState();

    this.state.traces.push({
      cycle: this.state.cycle,
      runningPid: currentProcess.pid,
      stateRootBefore,
      stateRootAfter: this.state.globalStateRoot,
      action: `Executed PC ${currentProcess.pc}`
    });
  }

  public async fork(parentPid: number, childPid: number) {
    const parent = this.state.processes.find(p => p.pid === parentPid);
    if (!parent) throw new Error("Parent not found");

    if (!this.checkCapability(parent, Capability.ProcessCreate)) {
      throw new Error("Capability check failed: ProcessCreate");
    }

    const child: Process = {
      pid: childPid,
      pc: 0,
      memoryRoot: parent.memoryRoot,
      capabilityRoot: parent.capabilityRoot,
      status: "Ready",
      capabilities: [...parent.capabilities],
    };

    const stateRootBefore = this.state.globalStateRoot;
    this.state.processes.push(child);
    this.state.cycle += 1;
    this.state.globalStateRoot = await this.hashState();

    this.state.traces.push({
      cycle: this.state.cycle,
      runningPid: parentPid,
      stateRootBefore,
      stateRootAfter: this.state.globalStateRoot,
      action: `Forked Child PID ${childPid}`
    });
  }
}
