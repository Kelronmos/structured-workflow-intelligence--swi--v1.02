import { ConcreteState, AbstractState, Decision } from "./types";

export function getAbstractRepresentation(c: ConcreteState): AbstractState {
  // R(c)
  return {
    valid: c.policy.admissible && c.auth.score >= 0.8 && c.continuityGraph.valid,
    instability: c.instabilityDetector.triggered,
    decision: c.decisionEngine.current,
    receipt: c.receiptEngine.last
  };
}

// PO1 — Safety Preservation
// [](decision_concrete = "EXECUTE" => Valid( R(concrete_state) ))
export function checkSafetyPreservation(c: ConcreteState): boolean {
  if (c.decisionEngine.current === "EXECUTE") {
    const R_c = getAbstractRepresentation(c);
    return R_c.valid;
  }
  return true; // Trivially true if not EXECUTE
}

// PO2 — HALT LIFTING
// [](instability_concrete => decision_concrete = "HALT")
export function checkHaltLifting(c: ConcreteState): boolean {
  if (c.instabilityDetector.triggered) {
    return c.decisionEngine.current === "HALT";
  }
  return true;
}

// PO3 — REFUSAL CLOSURE
// []( ~Valid(R(c)) => decision_concrete # "EXECUTE" )
export function checkRefusalClosure(c: ConcreteState): boolean {
  const R_c = getAbstractRepresentation(c);
  if (!R_c.valid) {
    return c.decisionEngine.current !== "EXECUTE";
  }
  return true;
}

export function verifyStateInvariants(c: ConcreteState): {
  safetyPreservation: boolean;
  haltLifting: boolean;
  refusalClosure: boolean;
  allHold: boolean;
} {
  const safetyPreservation = checkSafetyPreservation(c);
  const haltLifting = checkHaltLifting(c);
  const refusalClosure = checkRefusalClosure(c);
  
  return {
    safetyPreservation,
    haltLifting,
    refusalClosure,
    allHold: safetyPreservation && haltLifting && refusalClosure
  };
}
