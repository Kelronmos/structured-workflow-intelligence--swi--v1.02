export type Decision = "EXECUTE" | "REFUSE" | "HALT";

export interface Input {
  action: string;
  payload: any;
  signature?: string;
}

export interface AbstractState {
  valid: boolean;
  instability: boolean;
  decision: Decision | null;
  receipt: string | null;
}

export interface ConcreteState {
  instabilityDetector: { triggered: boolean; update: (c: ConcreteState, input: Input) => void };
  policy: { admissible: boolean; evaluate: (c: ConcreteState, input: Input) => void };
  auth: { score: number; update: (input: Input) => void };
  continuityGraph: { valid: boolean; validate: () => void };
  decisionEngine: { current: Decision | null };
  receiptEngine: { last: string | null; generate: (c: ConcreteState) => string };
}
