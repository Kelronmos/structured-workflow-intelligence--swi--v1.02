import { step } from "./ConcreteRuntime";
import { verifyStateInvariants } from "./InvariantGuards";
import { ConcreteState, Input, Decision } from "./types";

export function createInitialState(): ConcreteState {
  return {
    instabilityDetector: { triggered: false, update: () => {} },
    policy: { admissible: true, evaluate: () => {} },
    auth: { score: 1.0, update: () => {} },
    continuityGraph: { valid: true, validate: () => {} },
    decisionEngine: { current: null },
    receiptEngine: { last: null, generate: () => `RECEIPT_${Math.random().toString(36).substring(7)}` }
  };
}

export interface VerificationResult {
  scenario: string;
  decision: Decision | null;
  receipt: string | null;
  invariants: {
    safetyPreservation: boolean;
    haltLifting: boolean;
    refusalClosure: boolean;
    allHold: boolean;
  };
}

export function runVerificationPipeline(): VerificationResult[] {
  const scenarios = [
    {
      name: "Valid Execution",
      setup: (c: ConcreteState) => {
        // Default state is cleanly valid
      },
      input: { action: "transfer", payload: { amount: 100 } }
    },
    {
      name: "Instability Halt",
      setup: (c: ConcreteState) => {
        c.instabilityDetector.update = (state) => { state.instabilityDetector.triggered = true; };
      },
      input: { action: "execute", payload: {} }
    },
    {
      name: "Policy Refusal",
      setup: (c: ConcreteState) => {
        c.policy.evaluate = (state) => { state.policy.admissible = false; };
      },
      input: { action: "deploy", payload: {} }
    },
    {
      name: "Authority Refusal",
      setup: (c: ConcreteState) => {
        c.auth.update = () => { c.auth.score = 0.5; };
      },
      input: { action: "admin_action", payload: {} }
    }
  ];

  const results: VerificationResult[] = [];
  
  for (const scenario of scenarios) {
    const state = createInitialState();
    scenario.setup(state);
    
    const newState = step(state, scenario.input);
    const invariants = verifyStateInvariants(newState);
    
    results.push({
      scenario: scenario.name,
      decision: newState.decisionEngine.current,
      receipt: newState.receiptEngine.last,
      invariants
    });
  }
  
  return results;
}
