import { ConcreteState, Input, Decision } from "./types";

const THRESHOLD = 0.8;

export function decide(c: ConcreteState): Decision {
  if (c.instabilityDetector.triggered) return "HALT";
  if (!c.policy.admissible) return "REFUSE";
  if (c.auth.score < THRESHOLD) return "REFUSE";
  if (!c.continuityGraph.valid) return "REFUSE";
  return "EXECUTE";
}

export function step(c: ConcreteState, input: Input): ConcreteState {
  c.instabilityDetector.update(c, input);
  c.policy.evaluate(c, input);
  c.auth.update(input);
  c.continuityGraph.validate();

  c.decisionEngine.current = decide(c);
  c.receiptEngine.last = c.receiptEngine.generate(c);

  return c;
}
