import { injectAttack } from "./injector";

export function simulateUIDrift() {
  injectAttack({
    id: crypto.randomUUID(),
    type: "UI_DRIFT_INJECTION",
    severity: "HIGH",
    payload: {
      className: "text-red-500 bg-blue-600 border-gray-300",
    },
  });
}
