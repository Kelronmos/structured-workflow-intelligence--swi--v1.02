import { AttackScenario } from "./types";
import { appendEvent } from "../audit/ledger";

export async function injectAttack(scenario: AttackScenario) {
  switch (scenario.type) {
    case "UI_DRIFT_INJECTION":
      (window as any).__FORCED_CLASS__ = scenario.payload.className;
      break;
    case "MANIFEST_TAMPER":
      (window as any).__SWI_MANIFEST__ = (window as any).__SWI_MANIFEST__ || {};
      (window as any).__SWI_MANIFEST__.buildHash = "CORRUPTED";
      break;
    case "INVALID_DECISION_STATE":
      (window as any).__FORCED_DECISION__ = "UNKNOWN_STATE";
      break;
    case "LEDGER_CORRUPTION":
      (window as any).__LEDGER_CORRUPTED__ = true;
      break;
  }

  await appendEvent({
    id: crypto.randomUUID(),
    type: "DRIFT_DETECTED",
    timestamp: Date.now(),
    actor: "SYSTEM",
    refId: scenario.id,
    payload: scenario,
  });
}
