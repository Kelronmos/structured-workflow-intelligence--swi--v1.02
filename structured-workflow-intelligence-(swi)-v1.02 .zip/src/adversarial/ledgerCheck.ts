import { getLedger } from "../audit/ledger";

export function verifyLedgerIntegrity() {
  const ledger = getLedger();

  for (let i = 1; i < ledger.length; i++) {
    const prev = ledger[i - 1];
    const current = ledger[i];

    if (current.prevHash !== prev.hash) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "[LEDGER CORRUPTION DETECTED]");
      return false;
    }
  }

  return true;
}
