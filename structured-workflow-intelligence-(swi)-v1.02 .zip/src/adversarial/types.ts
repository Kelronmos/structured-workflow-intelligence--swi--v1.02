export type AttackType =
  | "MANIFEST_TAMPER"
  | "SIGNATURE_MISMATCH"
  | "UI_DRIFT_INJECTION"
  | "INVALID_DECISION_STATE"
  | "LEDGER_CORRUPTION";

export interface AttackScenario {
  id: string;
  type: AttackType;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  payload: any;
}
