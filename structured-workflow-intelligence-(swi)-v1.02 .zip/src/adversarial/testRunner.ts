import { injectAttack } from "./injector";
import { verifyLedgerIntegrity } from "./ledgerCheck";

export async function runAdversarialSuite() {
  console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "[TEST] Starting adversarial suite...");

  await injectAttack({
    id: "attack-1",
    type: "MANIFEST_TAMPER",
    severity: "CRITICAL",
    payload: {},
  });

  await injectAttack({
    id: "attack-2",
    type: "UI_DRIFT_INJECTION",
    severity: "HIGH",
    payload: {
      className: "text-red-500",
    },
  });

  const ledgerOk = verifyLedgerIntegrity();

  return {
    ledgerOk,
    status: ledgerOk ? "PASSED" : "FAILED",
  };
}
