import { v4 as uuidv4 } from "uuid";

export interface SystemEvent {
  eventId: string;
  timestamp: number;
  sourceModule: string;
  eventType: string;
  correlationId: string;
  evidenceId?: string;
  replayId?: string;
  payload?: any;
}

type EventHandler = (event: SystemEvent) => void;

class FireflyEventBus {
  private subscribers: Map<string, EventHandler[]> = new Map();
  private history: SystemEvent[] = [];

  subscribe(eventType: string, handler: EventHandler) {
    if (!this.subscribers.has(eventType)) {
      this.subscribers.set(eventType, []);
    }
    this.subscribers.get(eventType)!.push(handler);
  }

  publish(eventInput: Omit<SystemEvent, "eventId" | "timestamp" | "correlationId"> & { correlationId?: string }) {
    const event: SystemEvent = {
      ...eventInput,
      eventId: uuidv4(),
      timestamp: Date.now(),
      correlationId: eventInput.correlationId || uuidv4(),
    };
    
    this.history.push(event);

    const handlers = this.subscribers.get(event.eventType) || [];
    const catchAllHandlers = this.subscribers.get("*") || [];

    for (const handler of [...handlers, ...catchAllHandlers]) {
      try {
        handler(event);
      } catch (err) {
        console.error(`Error in event handler for ${event.eventType}`, err);
      }
    }
    
    return event;
  }

  getHistory() {
    return this.history;
  }
}

export const eventBus = new FireflyEventBus();
