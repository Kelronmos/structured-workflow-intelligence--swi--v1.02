
import fs from 'fs';
import path from 'path';

export interface KafkaEvent {
  topic: string;
  partition: number;
  offset: number;
  timestamp: string;
  key: string;
  value: unknown;
}

export class KafkaLogger {
  private static logPath = path.join(process.cwd(), 'swi-core', 'logs', 'kafka_stream.log');

  static async emit(topic: string, key: string, value: Record<string, unknown>): Promise<void> {
    const event: KafkaEvent = {
      topic,
      partition: 0,
      offset: Date.now(), // Simulated offset
      timestamp: new Date().toISOString(),
      key,
      value
    };

    const logsDir = path.dirname(this.logPath);
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir, { recursive: true });
    }

    fs.appendFileSync(this.logPath, JSON.stringify(event) + '\n');
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[KAFKA] Emitted to ${topic}: ${key}`);
  }

  static getStream(topic?: string): KafkaEvent[] {
    if (!fs.existsSync(this.logPath)) return [];
    
    const lines = fs.readFileSync(this.logPath, 'utf8').split('\n').filter(Boolean);
    const events = lines.map(l => JSON.parse(l) as KafkaEvent);
    
    if (topic) {
      return events.filter(e => e.topic === topic);
    }
    return events;
  }
}
