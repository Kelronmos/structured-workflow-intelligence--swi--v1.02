import { GoogleGenAI } from "@google/genai";
import { SimulationParams } from "../types";

let ai: GoogleGenAI | null = null;
const apiKey = (import.meta as any).env?.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
if (apiKey && apiKey !== "demo_mode") {
  ai = new GoogleGenAI({ apiKey });
}

export async function generateNovelScenario(): Promise<Partial<SimulationParams>> {
  if (!ai) {
    return {
      tokenStatus: "valid",
      action: "user_login",
      userBehavior: "normal",
      environment: "stable",
      policyMismatch: false,
      driftScore: 0.1
    };
  }
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a novel security simulation scenario for a SWI (Security and Workflow Integrity) system. Return a JSON object with the following fields: tokenStatus ('valid' or 'invalid'), action ('execute_transfer', 'data_export', 'system_reboot', 'user_login'), userBehavior ('normal', 'anomalous', 'mild'), environment ('stable', 'unstable'), policyMismatch (boolean), and driftScore (number between 0 and 1).",
      config: {
        responseMimeType: "application/json",
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI service");
    
    return JSON.parse(text);
  } catch (error: any) {
    throw new Error("CRYPTO_BACKEND_UNAVAILABLE: Admissible execution aborted. " + error.message);
  }
}
