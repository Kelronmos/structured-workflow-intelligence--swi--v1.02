import * as crypto from "crypto";

export interface TraceEvidence {
  signature: string;
  rollback_possible: boolean;
  source: string;
  timestamp: string;
}

export interface CanonicalTrace {
  event_id: string;
  decision: "ACCEPT" | "HALT";
  policy_hash: string;
  state_hash_before: string;
  state_hash_after: string;
  proof_ref: string;
  evidence: TraceEvidence;
  prev_hash: string;
  trace_hash: string;
}

export class RuntimeTraceService {
  private static events: CanonicalTrace[] = [];
  
  private static hashTrace(traceData: Omit<CanonicalTrace, 'trace_hash' | 'prev_hash' | 'evidence'>, prevHash: string, evidence: TraceEvidence): string {
     return crypto.createHash('sha256')
       .update(JSON.stringify(traceData) + prevHash + JSON.stringify(evidence))
       .digest('hex');
  }

  public static commitTrace(traceInput: Omit<CanonicalTrace, 'trace_hash' | 'prev_hash' | 'evidence'>, evidenceSource: string, rollbackAllowed: boolean): void {
    const prevHash = this.events.length > 0 ? this.events[this.events.length - 1].trace_hash : "0".repeat(64);
    
    // Create Evidence
    const timestamp = new Date().toISOString();
    const evidenceSigPayload = traceInput.event_id + timestamp + evidenceSource;
    const evidence: TraceEvidence = {
       signature: crypto.createHash('sha256').update(evidenceSigPayload).digest('hex'),
       rollback_possible: rollbackAllowed,
       source: evidenceSource,
       timestamp
    };

    const trace_hash = this.hashTrace(traceInput, prevHash, evidence);

    const fullTrace: CanonicalTrace = {
        ...traceInput,
        evidence,
        prev_hash: prevHash,
        trace_hash
    };

    // Singular, immutable source of truth
    this.events.push(Object.freeze(fullTrace));
  }
  
  public static getTrace(eventId: string): CanonicalTrace | undefined {
    return this.events.find(e => e.event_id === eventId);
  }

  public static getSystemTruth(): CanonicalTrace[] {
    return [...this.events];
  }
}
