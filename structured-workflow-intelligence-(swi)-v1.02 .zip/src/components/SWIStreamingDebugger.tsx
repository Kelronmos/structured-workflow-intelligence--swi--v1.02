import React, { useEffect, useState } from "react";
import { Activity, ShieldCheck, AlertTriangle } from "lucide-react";

type Event = {
  type: string;
  status?: string;
  score?: number;
  docId?: string;
  timestamp?: number;
};

// Simulated WebSocket provider for the mock
function runMockWebSocket(onMessage: (msg: { data: string }) => void) {
  let isCancelled = false;
  
  const eventsToEmit = [
    { type: "LOAD", timestamp: Date.now() },
    { type: "CANONICALIZE", domHash: "sha256:8f3a91..." },
    { type: "RENDER", layoutHash: "sha256:c2b8..." },
    { type: "FONT_CHECK", fontHash: "sha256:d1a2..." },
    { type: "HASH_COMPUTED", contentHash: "sha256:4ea8f1..." },
    { type: "SIGNATURE_VERIFY", status: "PASS" },
    { type: "LEDGER_QUERY", ledgerPointer: "ledger://SWI/chain/881A" },
    { type: "LEDGER_RESULT", status: "VALID" },
    { type: "ANOMALY_SCORE", score: 0.12 },
    { type: "FINAL_VERDICT", status: "ACCEPT" }
  ];

  let i = 0;
  const interval = setInterval(() => {
    if (isCancelled || i >= eventsToEmit.length) {
      clearInterval(interval);
      return;
    }
    const evt = { ...eventsToEmit[i], timestamp: Date.now() };
    onMessage({ data: JSON.stringify(evt) });
    i++;
  }, 1000);

  return () => {
    isCancelled = true;
    clearInterval(interval);
  };
}

export default function SWIStreamingDebugger({
  socketUrl = "mock"
}: {
  socketUrl?: string;
}) {
  const [events, setEvents] = useState<Event[]>([]);
  const [graphState, setGraphState] = useState<any>({});

  const updateGraph = (event: Event) => {
    setGraphState((prev: any) => {
      switch (event.type) {
        case "LOAD":
          return { ...prev, doc: "LOADED" };

        case "CANONICALIZE":
          return { ...prev, canonical: event };

        case "RENDER":
          return { ...prev, render: event };

        case "HASH_COMPUTED":
          return { ...prev, hash: event };

        case "SIGNATURE_VERIFY":
          return { ...prev, signature: event.status };

        case "LEDGER_RESULT":
          return { ...prev, ledger: event.status };

        case "FINAL_VERDICT":
          return { ...prev, verdict: event.status };

        default:
          return prev;
      }
    });
  };

  useEffect(() => {
    // If it's the mock, run the mock WebSocket
    if (socketUrl === "mock") {
       return runMockWebSocket((msg) => {
         const event: Event = JSON.parse(msg.data);
         setEvents((prev) => [...prev, event]);
         updateGraph(event);
       });
    }

    const ws = new WebSocket(socketUrl);

    ws.onmessage = (msg) => {
      const event: Event = JSON.parse(msg.data);

      setEvents((prev) => [...prev, event]);
      updateGraph(event);
    };

    return () => ws.close();
  }, [socketUrl]);

  return (
    <div className="flex bg-[#141414] text-[#E4E3E0] min-h-[500px] border border-white/10" style={{ fontFamily: "monospace" }}>

      {/* LEFT: LIVE EVENT STREAM */}
      <div className="w-[30%] border-r border-[#333] flex flex-col">
        <h3 className="text-xs font-bold uppercase tracking-widest text-cyan-400 p-4 border-b border-[#333] flex items-center gap-2">
            <Activity className="w-4 h-4" /> Live Event Stream
        </h3>

        <div className="flex-1 overflow-y-auto p-2">
          {events.map((e, i) => (
            <div key={i} className="p-2 border-b border-white/5 text-[10px] animate-in fade-in slide-in-from-left-2">
              <span className="font-bold text-white/80">{e.type}</span>
              {e.status ? <span className={`ml-2 ${e.status === 'PASS' || e.status === 'VALID' || e.status === 'ACCEPT' ? 'text-emerald-400' : 'text-red-400'}`}>→ {e.status}</span> : ""}
              {e.score !== undefined ? <span className="ml-2 text-fuchsia-400">(score: {e.score})</span> : ""}
              <div className="text-[8px] text-white/30 mt-1">{new Date(e.timestamp || Date.now()).toISOString()}</div>
            </div>
          ))}
        </div>
      </div>

      {/* CENTER: LIVE GRAPH */}
      <div className="w-[40%] p-4 flex flex-col">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#E4E3E0] border-b border-[#333] pb-4 mb-4">Verification Graph</h3>

        <pre className="flex-1 bg-[#111] p-4 text-[10px] text-emerald-300 border border-emerald-500/20 overflow-auto shadow-[inset_0_0_20px_rgba(16,185,129,0.05)]">
          {JSON.stringify(graphState, null, 2)}
        </pre>
      </div>

      {/* RIGHT: TRUST STATE */}
      <div className="w-[30%] border-l border-[#333] flex flex-col bg-[#0a0a0a]">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#E4E3E0] p-4 border-b border-[#333] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-fuchsia-400" /> Trust State
        </h3>

        <div className="p-4 space-y-4">
            <div className="bg-[#111] border border-white/10 p-3">
                <p className="text-[10px] font-bold text-white/50 mb-1 uppercase">Signature</p>
                <div className={`text-sm font-black ${
                    graphState.signature === 'PASS' ? 'text-emerald-400' : 
                    graphState.signature === 'FAIL' ? 'text-red-400' : 'text-white/20'
                }`}>
                    {graphState.signature || "PENDING"}
                </div>
            </div>

            <div className="bg-[#111] border border-white/10 p-3">
                <p className="text-[10px] font-bold text-white/50 mb-1 uppercase">Ledger</p>
                <div className={`text-sm font-black ${
                    graphState.ledger === 'VALID' ? 'text-blue-400' :
                    graphState.ledger ? 'text-orange-400' : 'text-white/20'
                }`}>
                    {graphState.ledger || "PENDING"}
                </div>
            </div>

            <div className="bg-[#111] border border-white/10 p-3 relative overflow-hidden">
                <p className="text-[10px] font-bold text-white/50 mb-1 uppercase relative z-10">Verdict</p>
                <div className={`text-xl font-black relative z-10 ${
                    graphState.verdict === 'ACCEPT' ? 'text-emerald-500' :
                    graphState.verdict === 'REJECT' ? 'text-red-500' :
                    graphState.verdict === 'QUARANTINE' ? 'text-orange-500' : 'text-white/20'
                }`}>
                    {graphState.verdict || "AWAITING"}
                </div>
            </div>
        </div>
      </div>

    </div>
  );
}
