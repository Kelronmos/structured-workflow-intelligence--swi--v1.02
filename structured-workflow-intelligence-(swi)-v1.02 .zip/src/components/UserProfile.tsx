import React, { useState, useEffect } from 'react';
import { User, Mail, Shield, Edit3, Save, X, Fingerprint, Activity } from 'lucide-react';
import AuthPanel from './AuthPanel';
import { useAuthState } from 'react-firebase-hooks/auth';
import { auth, db } from '../firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface UserProfileData {
  id: string;
  name: string;
  email: string;
  role: string;
  bio: string;
}

export default function UserProfile() {
  const [user, authLoading, authError] = useAuthState(auth);
  const [profile, setProfile] = useState<UserProfileData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<UserProfileData | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setLoading(true);
      const docRef = doc(db, 'users', user.uid);
      getDoc(docRef).then(docSnap => {
        if (docSnap.exists()) {
          const data = docSnap.data() as UserProfileData;
          setProfile(data);
          setEditData(data);
        } else {
          const newProfile = {
            id: user.uid,
            name: user.email?.split('@')[0] || 'Unknown Origin',
            email: user.email || '',
            role: 'Operator',
            bio: 'Standard identity profile.'
          };
          setProfile(newProfile);
          setEditData(newProfile);
        }
        setLoading(false);
      });
    } else {
      setProfile(null);
      setEditData(null);
    }
  }, [user]);

  const handleSave = async () => {
    if (!editData || !user) return;
    try {
      const docRef = doc(db, 'users', user.uid);
      await setDoc(docRef, editData, { merge: true });
      setProfile(editData);
      setIsEditing(false);
    } catch (e: any) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
      alert('Failed to save profile: ' + e.message);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold uppercase tracking-tighter">Identity Management</h2>
          <p className="text-xs opacity-50 uppercase tracking-widest">Authentication & Access Control</p>
        </div>
      </div>

      <AuthPanel />

      {(loading || authLoading) && <div className="p-8 text-center font-mono text-sm animate-pulse">Synchronizing Identity...</div>}

      {!authLoading && user && profile && !loading && (
        <div className="bg-white dark:bg-[#1A1A1A] border border-[#141414]/10 dark:border-[#E4E3E0]/10 p-8 space-y-8 relative overflow-hidden mt-8">
          <div className="absolute top-4 right-4 z-10">
            <button 
              onClick={() => setIsEditing(!isEditing)}
              className="p-2 border bg-black text-white hover:bg-black/80 transition-colors"
            >
              {isEditing ? <X className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
            </button>
          </div>
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
            <Fingerprint className="w-32 h-32" />
          </div>

          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
              <User className="w-12 h-12 text-blue-500" />
            </div>
            <div className="space-y-1 w-full max-w-xs relative z-10">
              {isEditing ? (
                <div className="space-y-2">
                  <input 
                    value={editData?.name} 
                    onChange={e => setEditData({...editData!, name: e.target.value})}
                    className="bg-transparent border-b border-blue-500 text-2xl font-bold uppercase tracking-tighter w-full focus:outline-none"
                    placeholder="Name"
                  />
                  <input 
                    value={editData?.role} 
                    onChange={e => setEditData({...editData!, role: e.target.value})}
                    className="bg-transparent border-b border-blue-500 text-xs font-mono opacity-80 uppercase tracking-widest w-full focus:outline-none"
                    placeholder="Role"
                  />
                </div>
              ) : (
                <>
                  <h3 className="text-2xl font-bold uppercase tracking-tighter">{profile.name}</h3>
                  <p className="text-xs font-mono opacity-40 uppercase tracking-widest">{profile.role}</p>
                </>
              )}
            </div>
          </div>

          <div className="grid gap-6 relative z-10">
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold opacity-40 flex items-center gap-2">
                <Mail className="w-3 h-3" /> Email Address
              </label>
              <p className="text-sm font-mono">{profile.email}</p>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-bold opacity-40 flex items-center gap-2">
                <Shield className="w-3 h-3" /> Governance Bio
              </label>
              {isEditing ? (
                <textarea 
                  value={editData?.bio} 
                  onChange={e => setEditData({...editData!, bio: e.target.value})}
                  className="bg-black text-white border border-white/20 text-sm w-full focus:outline-none p-2 h-24"
                />
              ) : (
                <p className="text-sm opacity-70 leading-relaxed font-mono">{profile.bio}</p>
              )}
            </div>
          </div>

          {isEditing && (
            <button 
              onClick={handleSave}
              className="w-full relative z-10 bg-blue-600 text-white py-3 text-xs font-bold uppercase tracking-widest hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" /> Save Profile Changes
            </button>
          )}
        </div>
      )}

      {user && (
        <div className="grid grid-cols-2 gap-4 mt-8">
          <div className="p-4 border border-[#141414]/10 dark:border-[#E4E3E0]/10 bg-white dark:bg-[#1A1A1A] space-y-2">
            <div className="flex items-center gap-2 text-green-500">
              <Activity className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase">System Status</span>
            </div>
            <p className="text-xs opacity-50">Identity bound to cryptographic key pair. All actions audited.</p>
          </div>
          <div className="p-4 border border-[#141414]/10 dark:border-[#E4E3E0]/10 bg-white dark:bg-[#1A1A1A] space-y-2">
            <div className="flex items-center gap-2 text-blue-500">
              <Shield className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase">Security Level</span>
            </div>
            <p className="text-xs opacity-50">Authenticated Operator. Actions are processed through the Fail-Safe Kernel.</p>
          </div>
        </div>
      )}
    </div>
  );
}
