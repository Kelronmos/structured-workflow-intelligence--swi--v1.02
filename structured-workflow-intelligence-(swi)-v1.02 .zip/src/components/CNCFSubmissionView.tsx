import React, { useState } from "react";
import {
  FileText,
  ShieldCheck,
  Server,
  CloudLightning,
  GitBranch,
  Network,
  Activity,
  Lock,
  Archive,
  Download,
  Terminal,
  CheckCircle2,
  GitCommit
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function CNCFSubmissionView() {
  const [activeTab, setActiveTab] = useState<"WHITEPAPER" | "ARCHITECTURE" | "SRE" | "DR" | "GITOPS">("WHITEPAPER");
  const [downloading, setDownloading] = useState(false);

  const handleDownloadPack = () => {
    setDownloading(true);
    setTimeout(() => {
      setDownloading(false);
      alert("Platform bundle downloaded successfully (Simulated)");
    }, 2000);
  };

  const tabs = [
    { id: "WHITEPAPER", label: "Executive Whitepaper", icon: FileText },
    { id: "ARCHITECTURE", label: "C4 Architecture", icon: Network },
    { id: "SRE", label: "SRE Runbooks", icon: Terminal },
    { id: "DR", label: "Disaster Recovery", icon: CloudLightning },
    { id: "GITOPS", label: "GitOps Foundation", icon: GitBranch },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start gap-8 bg-[#0a0f1c] text-white p-8 border border-indigo-500/20 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 blur-[120px] pointer-events-none"></div>
         <div className="space-y-4 relative z-10 w-full">
            <div className="flex items-center gap-3">
               <div className="p-2 bg-indigo-500/20 text-indigo-400 border border-indigo-500/50 rounded-lg">
                  <Archive className="w-6 h-6" />
               </div>
               <div>
                  <h2 className="text-xl font-black uppercase tracking-widest text-[#E4E3E0]">
                     SWI Platform Engineering Framework
                  </h2>
                  <p className="text-xs font-mono opacity-60 uppercase tracking-widest">CNCF Submission-Grade Package v3.0</p>
               </div>
            </div>
            <p className="text-sm opacity-80 max-w-3xl text-indigo-100/70 border-l-2 border-indigo-500/50 pl-4 leading-relaxed font-serif">
               A compliance-focused distributed trust, provenance, and decision-support execution platform.
               This bundle contains the official architecture specifications, SRE runbooks, and disaster 
               recovery protocols required for SOC2/ISO27001 production environments.
            </p>
         </div>
         <div className="relative z-10 whitespace-nowrap">
            <button
               onClick={handleDownloadPack}
               disabled={downloading}
               className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg font-black text-xs uppercase tracking-widest transition-all disabled:opacity-50"
            >
               {downloading ? <span className="animate-pulse">Packaging...</span> : <><Download className="w-4 h-4" /> Download Full CNCF Pack</>}
            </button>
         </div>
      </div>

      {/* Navigation */}
      <div className="flex gap-2 border-b border-white/10 pb-4 overflow-x-auto custom-scrollbar">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "px-4 py-2 text-xs font-bold uppercase tracking-widest whitespace-nowrap flex items-center gap-2 transition-all",
              activeTab === tab.id ? "bg-white/10 text-white border-b-2 border-indigo-500" : "text-white/40 hover:text-white/80"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="bg-[#141414] border border-white/10 p-6 md:p-10 text-white min-h-[500px]">
        {activeTab === "WHITEPAPER" && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
             <div className="border-b border-white/10 pb-6">
                <h3 className="text-2xl font-black uppercase tracking-widest mb-4">Executive Summary</h3>
                <p className="text-white/70 font-serif leading-relaxed text-sm md:text-base max-w-4xl">
                  The Support & Witness Integrity (SWI) Platform is an event-sourced, cryptographically verifiable, 
                  decision-support distributed analytics system. It provides deterministically replayable simulation states, 
                  ensuring that every advisory recommendation, policy simulation, and identity verification is permanently auditable across 
                  a decentralized enterprise ledger architecture.
                </p>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="space-y-4">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-[0.2em] flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4" /> Core Capabilities
                  </h4>
                  <ul className="space-y-3 font-mono text-[11px] text-white/60">
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-400 mt-1" /> Deterministic replay of system state</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-400 mt-1" /> Cryptographic document provenance DAG</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-400 mt-1" /> OPA-driven policy simulation & decision support</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-400 mt-1" /> Multi-region distributed consistency</li>
                    <li className="flex items-start gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-400 mt-1" /> Zero-trust identity via SPIFFE/SPIRE</li>
                  </ul>
               </div>

               <div className="space-y-4">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-[0.2em] flex items-center gap-2">
                    <Lock className="w-4 h-4" /> Compliance Mapping
                  </h4>
                  <div className="space-y-4">
                     <div className="p-3 bg-white/5 border border-white/10 rounded">
                        <strong className="text-xs font-bold uppercase tracking-wider text-white">SOC2 Alignment</strong>
                        <p className="text-[10px] text-white/50 mt-1">Immutable event ledger, OpenTelemetry monitoring, GitOps change management.</p>
                     </div>
                     <div className="p-3 bg-white/5 border border-white/10 rounded">
                        <strong className="text-xs font-bold uppercase tracking-wider text-white">ISO27001 Alignment</strong>
                        <p className="text-[10px] text-white/50 mt-1">Vault/KMS key management, least privilege enforcement, cryptographic controls.</p>
                     </div>
                  </div>
               </div>
             </div>
          </div>
        )}

        {activeTab === "ARCHITECTURE" && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
             <h3 className="text-2xl font-black uppercase tracking-widest mb-2 border-b border-white/10 pb-4">C4 Architecture Model</h3>
             
             <div className="bg-black/50 border border-indigo-500/30 p-6 rounded-lg font-mono text-xs md:text-sm text-indigo-300 whitespace-pre overflow-x-auto">
{`🌍 LEVEL 1 — SYSTEM CONTEXT
[External Users & Auditor APIs] 
          │
          ▼
╔═════════════════════════════════╗
║         SWI Platform            ║
╚═════════════════════════════════╝
          │
          ▼
[S3 Storage] [Vault/KMS] [SIEM]


🧩 LEVEL 2 — CONTAINER MODEL
┌────────────────────────────┐
│   Control Plane (Go)       │
├────────────────────────────┤
│   Signing Service (Rust)   │
│   Verification (Rust)      │
│   Graph Engine (Go)        │
├────────────────────────────┤
│   Kafka Event Backbone     │
│   Ledger (Aurora DB)       │
└────────────────────────────┘`}
             </div>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border border-white/10 bg-white/5 text-[11px]">
                   <strong className="text-white block mb-2 uppercase tracking-widest border-b border-white/10 pb-2">Signing Service</strong>
                   <span className="text-white/60">Canonical hash ingestion, Ed25519 generation, HSM key retrieval.</span>
                </div>
                <div className="p-4 border border-white/10 bg-white/5 text-[11px]">
                   <strong className="text-white block mb-2 uppercase tracking-widest border-b border-white/10 pb-2">Verifier Service</strong>
                   <span className="text-white/60">Signature validation, ledger reconciliation, OPA policy evaluation.</span>
                </div>
                <div className="p-4 border border-white/10 bg-white/5 text-[11px]">
                   <strong className="text-white block mb-2 uppercase tracking-widest border-b border-white/10 pb-2">Control Plane</strong>
                   <span className="text-white/60">Service registration, policy distribution, cluster orchestration.</span>
                </div>
             </div>
          </div>
        )}

        {activeTab === "SRE" && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
             <h3 className="text-2xl font-black uppercase tracking-widest mb-2 border-b border-white/10 pb-4">SRE & Incident Runbooks</h3>
             
             <div className="space-y-6">
                <div className="border border-red-500/30 bg-red-500/5 p-5">
                   <div className="flex items-center gap-3 mb-4 text-red-400">
                      <Activity className="w-5 h-5" />
                      <h4 className="font-bold uppercase tracking-widest text-sm">Incident: Trust Drift Detected</h4>
                   </div>
                   <ol className="list-decimal list-inside space-y-3 font-mono text-[11px] text-white/70">
                      <li><strong>Check:</strong> <span className="text-indigo-300">ledger_consistency_index {'<'} threshold</span> on Grafana.</li>
                      <li><strong>Trigger Replay:</strong> Execute <span className="text-indigo-300">swi replay --from timestamp --region all</span>.</li>
                      <li><strong>Isolate:</strong> Quarantine affected nodes via Control Plane API.</li>
                      <li><strong>Recompute:</strong> Trigger DAG deterministic rebuild.</li>
                   </ol>
                </div>

                <div className="border border-amber-500/30 bg-amber-500/5 p-5">
                   <div className="flex items-center gap-3 mb-4 text-amber-400">
                      <Server className="w-5 h-5" />
                      <h4 className="font-bold uppercase tracking-widest text-sm">Alert: Kafka Partition Loss</h4>
                   </div>
                   <ol className="list-decimal list-inside space-y-3 font-mono text-[11px] text-white/70">
                      <li><strong>Acknowledge:</strong> PagerDuty trigger for Redpanda/MSK sync drop.</li>
                      <li><strong>Verify:</strong> Check MirrorMaker2 cross-region replication lag.</li>
                      <li><strong>Repair:</strong> Spin up fresh broker, Kafka auto-rebalance will sync from Aurora Ledger.</li>
                   </ol>
                </div>
             </div>
          </div>
        )}

        {activeTab === "DR" && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
             <h3 className="text-2xl font-black uppercase tracking-widest mb-2 border-b border-white/10 pb-4">Disaster Recovery Protocol</h3>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                   <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-[0.2em]">Multi-Region Topology</h4>
                   <ul className="space-y-2 text-xs font-mono text-white/70">
                     <li className="p-2 bg-white/5 border border-white/10"><strong>Region A (Primary):</strong> us-east-1</li>
                     <li className="p-2 bg-white/5 border border-white/10"><strong>Region B (Active Failover):</strong> eu-west-1</li>
                     <li className="p-2 bg-white/5 border border-white/10"><strong>Region C (Compliance Mirror):</strong> af-south-1</li>
                   </ul>
                </div>
                <div className="space-y-4">
                   <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-[0.2em]">Failover Rules</h4>
                   <ul className="space-y-2 text-xs font-mono text-white/70">
                     <li className="p-2 bg-white/5 border border-white/10">Kafka mirrored via MirrorMaker2</li>
                     <li className="p-2 bg-white/5 border border-white/10">Ledger replication async + quorum validation</li>
                     <li className="p-2 bg-white/5 border border-white/10">Control plane is stateless (redeployable)</li>
                     <li className="p-2 bg-white/5 border border-white/10">ArgoCD enforces drift correction automatically</li>
                   </ul>
                </div>
             </div>

             <div className="p-5 border border-indigo-500/30 bg-indigo-500/10 text-indigo-200 text-xs font-mono">
                <strong>EVENT REPLAY ENGINE:</strong><br/><br/>
                If a region suffers catastrophic data loss, the system reconstructs state using:<br/>
                <span className="text-white font-bold">Event Log → Deterministic Reducer → Graph State → Verification Result</span>
             </div>
          </div>
        )}

        {activeTab === "GITOPS" && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
             <h3 className="text-2xl font-black uppercase tracking-widest mb-2 border-b border-white/10 pb-4">GitOps & Security Layer</h3>
             
             <div className="bg-[#0a0a0a] p-6 border border-white/10 rounded text-[11px] font-mono text-white/60 space-y-4">
                <div className="flex gap-4 items-center">
                   <GitCommit className="w-4 h-4 text-emerald-400" />
                   <span>Git Commit (Authored)</span>
                </div>
                <div className="w-px h-4 bg-white/20 ml-2"></div>
                <div className="flex gap-4 items-center">
                   <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                   <span>CI Build (GitHub Actions) + SLSA Attestation</span>
                </div>
                <div className="w-px h-4 bg-white/20 ml-2"></div>
                <div className="flex gap-4 items-center">
                   <Lock className="w-4 h-4 text-emerald-400" />
                   <span>Container Signing (Cosign) & SBOM generation (Syft)</span>
                </div>
                <div className="w-px h-4 bg-white/20 ml-2"></div>
                <div className="flex gap-4 items-center">
                   <Server className="w-4 h-4 text-emerald-400" />
                   <span>ArgoCD Sync to Kubernetes (Runtime Verification Gate)</span>
                </div>
             </div>

             <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div className="p-3 border border-white/10 text-center"><span className="text-indigo-400 font-black block text-sm">mTLS</span><span className="text-[9px] uppercase text-white/50">Istio/Linkerd</span></div>
                <div className="p-3 border border-white/10 text-center"><span className="text-indigo-400 font-black block text-sm">SPIFFE</span><span className="text-[9px] uppercase text-white/50">Workload ID</span></div>
                <div className="p-3 border border-white/10 text-center"><span className="text-indigo-400 font-black block text-sm">SLSA L3</span><span className="text-[9px] uppercase text-white/50">Supply Chain</span></div>
                <div className="p-3 border border-white/10 text-center"><span className="text-indigo-400 font-black block text-sm">OPA</span><span className="text-[9px] uppercase text-white/50">Policy Code</span></div>
             </div>
          </div>
        )}
      </div>

       <div className="flex justify-end pt-4">
          <ProofArtifacts
              id="cncf-platform"
              title="CNCF Enterprise Submission Pack"
              data={{
                  framework: "SWI-CNCF-V3.0",
                  components: "Helm, Terraform, ArgoCD, Rust, Go",
                  auditor_status: "READY"
              }}
              variant="always-dark"
          />
       </div>
    </div>
  );
}
