import React from "react";
import {
  Heart,
  ShieldAlert,
  Scale,
  Users,
  Hammer,
  Eye,
  AlertOctagon,
  UserCheck,
  Brain
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function HumanGovernancePillarsView() {
  const pillars = [
    {
      id: "1",
      icon: Heart,
      title: "Human Dignity Pillar",
      color: "text-rose-400",
      bgCol: "bg-rose-500/10",
      borderCol: "border-rose-500/30",
      rule: "HumanDignity > SystemEfficiency",
      desc: "Every person remains human before being treated as data, threat score, political category, or optimization variable."
    },
    {
      id: "2",
      icon: ShieldAlert,
      title: "Accountability Pillar",
      color: "text-amber-400",
      bgCol: "bg-amber-500/10",
      borderCol: "border-amber-500/30",
      rule: "No invisible authority.",
      desc: "Every critical action must answer: Who approved this? Under what policy? Can it be reviewed? Can it be challenged?"
    },
    {
      id: "3",
      icon: Brain,
      title: "Reflection Pillar",
      color: "text-purple-400",
      bgCol: "bg-purple-500/10",
      borderCol: "border-purple-500/30",
      rule: "No immediate escalation.",
      desc: "High-impact actions enter: pause, review, consequence analysis, human oversight. (The 3-Minute Reflection Gate)."
    },
    {
      id: "4",
      icon: Users,
      title: "Community Pillar",
      color: "text-blue-400",
      bgCol: "bg-blue-500/10",
      borderCol: "border-blue-500/30",
      rule: "Systems cannot understand society without society participating.",
      desc: "People need representation in policy review, safety review, ethics review, audit visibility, and appeal mechanisms."
    },
    {
      id: "5",
      icon: Hammer,
      title: "Structure Heal Pillar",
      color: "text-emerald-400",
      bgCol: "bg-emerald-500/10",
      borderCol: "border-emerald-500/30",
      rule: "Healing cannot be forced, and help cannot be denied.",
      desc: "The system should support recovery, not punishment obsession. Goals: de-escalation, mediation, repair, reconciliation."
    },
    {
      id: "6",
      icon: Eye,
      title: "Truth & Transparency Pillar",
      color: "text-cyan-400",
      bgCol: "bg-cyan-500/10",
      borderCol: "border-cyan-500/30",
      rule: "False certainty is dangerous.",
      desc: "The system must admit uncertainty, degraded states, failed checks, incomplete evidence, and partial confidence."
    },
    {
      id: "7",
      icon: AlertOctagon,
      title: "Halt Pillar",
      color: "text-red-500",
      bgCol: "bg-red-500/10",
      borderCol: "border-red-500/50",
      rule: "A trustworthy system must know when not to proceed.",
      desc: "If governance integrity fails, safety chain is broken, or accountability is unknown, high-risk execution MUST stop."
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full">
          <div className="flex items-center gap-3">
            <UserCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              SWI Human Governance Pillars
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-80 max-w-3xl text-emerald-100/70 border-l-2 border-emerald-500/50 pl-3">
            A healthy SWI-style civic structure needs human pillars at the center. 
            Execution serves governance, governance serves people, and people remain the center.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
         {pillars.map((pillar) => (
           <div key={pillar.id} className="bg-[#141414] border border-white/10 p-5 flex flex-col hover:border-white/20 transition-colors">
              <div className="flex items-center gap-3 border-b border-white/10 pb-3 mb-3">
                 <div className={cn("p-2 rounded-sm border", pillar.bgCol, pillar.borderCol)}>
                    <pillar.icon className={cn("w-4 h-4", pillar.color)} />
                 </div>
                 <div>
                   <div className="text-[10px] font-black uppercase tracking-widest text-white/50">{pillar.id}. Pillar</div>
                   <div className={cn("text-[11px] font-bold uppercase", pillar.color)}>{pillar.title}</div>
                 </div>
              </div>
              <div className="flex-1 space-y-3">
                 <div className="text-[9px] font-mono bg-white/5 border border-white/10 p-2 text-white/70">
                    <span className="font-bold opacity-50 mr-2">RULE:</span>
                    {pillar.rule}
                 </div>
                 <div className="text-[9px] font-mono text-white/50 leading-relaxed">
                   {pillar.desc}
                 </div>
              </div>
           </div>
         ))}
         
         {/* The Core Model */}
         <div className="bg-[#0a0a0a] border border-emerald-500/30 p-5 lg:col-span-2 flex flex-col justify-center items-center text-center space-y-4 shadow-[0_0_20px_rgba(16,185,129,0.05)]">
            <h3 className="text-[11px] font-bold text-emerald-400 uppercase tracking-widest">
               The Core Governance Model
            </h3>
            
            <div className="flex flex-col items-center space-y-2 text-[10px] font-mono text-white/70">
               <div className="bg-emerald-500/20 text-emerald-400 font-bold px-6 py-1.5 border border-emerald-500/30 w-48">HUMANS</div>
               <div className="text-emerald-500/50">↑</div>
               <div className="bg-white/10 px-6 py-1.5 border border-white/20 w-48">GOVERNANCE</div>
               <div className="text-white/30">↑</div>
               <div className="bg-white/5 px-6 py-1.5 border border-white/10 w-48">VERIFICATION</div>
               <div className="text-white/20">↑</div>
               <div className="bg-black px-6 py-1.5 border border-white/5 text-white/40 w-48">OBSERVABILITY</div>
               <div className="text-white/10">↑</div>
               <div className="bg-black px-6 py-1.5 border border-white/5 text-white/30 w-48">EXECUTION</div>
            </div>
         </div>
      </div>
      
      {/* Footer Statement */}
      <div className="bg-[#141414] border border-white/10 p-6 flex flex-col items-center justify-center text-center">
         <div className="text-[11px] text-emerald-400 font-bold uppercase tracking-widest mb-3 border-b border-emerald-500/30 pb-2">
           Healthiest SWI Position
         </div>
         <p className="text-[10px] font-mono text-white/60 max-w-4xl italic leading-relaxed">
           "SWI is a human-centered governance and integrity framework designed to introduce accountability, verification, reflection, and safety boundaries into high-impact technical systems while preserving human dignity, oversight, and recovery pathways."
         </p>
      </div>

    </div>
  );
}
