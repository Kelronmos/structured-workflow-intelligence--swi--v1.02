import { execution_gate, PolicyContext, StateContext } from "./ExecutionGate";
import { RuntimeTraceService, CanonicalTrace } from "../services/RuntimeTraceService";
import * as crypto from "crypto";

export class SwIKernel {
  private currentState: any = {};
  
  private hashState(state: any): string {
    return crypto.createHash("sha256").update(JSON.stringify(state)).digest("hex");
  }

  private hashEvent(event: any): string {
    return crypto.createHash("sha256").update(JSON.stringify(event)).digest("hex");
  }

  // Event -> validate -> execute -> commit -> seal -> emit trace
  public processEvent(event: any, policy: PolicyContext): CanonicalTrace | null {
    const eventId = this.hashEvent(event);
    const stateHashBefore = this.hashState(this.currentState);

    // 1. validate
    const stateContext: StateContext = {
      integrity: { valid: true }, // Simple assumption for simulation
      hash: () => stateHashBefore,
    };

    const decision = execution_gate(event, stateContext, policy);

    let stateHashAfter = stateHashBefore;
    
    if (decision === "ACCEPT") {
      // 2. execute
      const nextState = { ...this.currentState, ...event.payload };
      
      // 3. commit
      this.currentState = nextState;
      stateHashAfter = this.hashState(this.currentState);
    }

    // 4. seal (Generate proof reference, deferred conceptually to proof_generator)
    // This proof_ref points to the derivative artifact that proves this state transition
    const proofRef = `proof://${eventId}:${stateHashAfter}`;

    // 5. emit trace
    RuntimeTraceService.commitTrace({
      event_id: eventId,
      decision,
      policy_hash: policy.hash(),
      state_hash_before: stateHashBefore,
      state_hash_after: stateHashAfter,
      proof_ref: proofRef
    }, "SWI_KERNEL", decision === "ACCEPT");

    return RuntimeTraceService.getTrace(eventId) || null;
  }

  public getState() {
    return this.currentState;
  }
}
