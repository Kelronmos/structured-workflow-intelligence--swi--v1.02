import { cn } from '@/src/lib/utils';
import { Settings2, RotateCcw, RotateCw, Upload, Sparkles, RefreshCw, ShieldCheck, Activity, Fingerprint, AlertTriangle, CheckCircle2, Save, Bookmark } from 'lucide-react';
import { useRef, useState, useEffect } from 'react';
import { SimulationParams, DecisionObject, Trace } from '../types';
import { useUndoRedo } from '../hooks/useUndoRedo';
import { evaluateRequest } from '../lib/decisionEngine';

interface ControlPanelProps {
  params: SimulationParams;
  setParams: (params: SimulationParams) => void;
  onImport?: (scenarios: Trace[]) => void;
  onGenerateAi?: () => void;
  aiLoading?: boolean;
  loading?: boolean;
}

export default function ControlPanel({ 
  params: activeParams, 
  setParams, 
  onImport,
  onGenerateAi,
  aiLoading,
  loading
}: ControlPanelProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Robust state management with undo/redo for the "Draft" state
  const { 
    state: draftParams, 
    update: updateDraft, 
    undo, 
    redo, 
    canUndo, 
    canRedo 
  } = useUndoRedo<SimulationParams>(activeParams);

  const [decision, setDecision] = useState<DecisionObject | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [presets, setPresets] = useState<{ name: string, params: SimulationParams }[]>(() => {
    const savedPresets = localStorage.getItem('swi_presets');
    if (savedPresets) {
      try {
        return JSON.parse(savedPresets);
      } catch (e) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to load presets:", e);
      }
    }
    return [];
  });
  const [showPresetSave, setShowPresetSave] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');

  const savePreset = () => {
    if (!newPresetName.trim()) return;
    const newPresets = [...presets, { name: newPresetName, params: draftParams }];
    setPresets(newPresets);
    localStorage.setItem('swi_presets', JSON.stringify(newPresets));
    setNewPresetName('');
    setShowPresetSave(false);
  };

  const deletePreset = (index: number) => {
    const newPresets = presets.filter((_, i) => i !== index);
    setPresets(newPresets);
    localStorage.setItem('swi_presets', JSON.stringify(newPresets));
  };

  const loadPreset = (preset: { name: string, params: SimulationParams }) => {
    updateDraft(preset.params);
  };

  const lastSyncedRef = useRef<string>("");

  // Sync draft with active params if they change from outside (e.g. presets or AI generation)
  useEffect(() => {
    const activeString = JSON.stringify(activeParams);
    const draftString = JSON.stringify(draftParams);
    
    if (activeString !== draftString && activeString !== lastSyncedRef.current) {
      lastSyncedRef.current = activeString;
      updateDraft(activeParams);
    }
  }, [activeParams, draftParams, updateDraft]);

  // Evaluate draft params to produce a Decision Object
  useEffect(() => {
    const evaluate = async () => {
      setIsEvaluating(true);
      const result = await evaluateRequest(draftParams);
      setDecision(result);
      setIsEvaluating(false);
    };
    
    const timer = setTimeout(evaluate, 300); // Debounce evaluation
    return () => clearTimeout(timer);
  }, [draftParams]);

  const updateParam = (key: keyof SimulationParams, value: string | number | boolean | object) => {
    updateDraft({ ...draftParams, [key]: value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const scenarios = Array.isArray(json) ? json : [json];
        if (onImport) onImport(scenarios);
      } catch (err) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to parse JSON:", err);
      }
    };
    reader.readAsText(file);
  };

  const updateDriftConfig = (key: string, value: number) => {
    const newConfig = { ...draftParams.driftConfig };
    if (key === 'threshold') {
      newConfig.threshold = value;
    } else {
      newConfig.increments = { ...newConfig.increments, [key]: value };
    }
    updateParam('driftConfig', newConfig);
  };

  const updateSWIConfig = (type: string) => {
    const currentDeactivated = draftParams.swiConfig?.deactivatedTypes || [];
    const newDeactivated = currentDeactivated.includes(type)
      ? currentDeactivated.filter((t: string) => t !== type)
      : [...currentDeactivated, type];
    
    updateParam('swiConfig', {
      ...draftParams.swiConfig,
      deactivatedTypes: newDeactivated
    });
  };

  const handleCommit = () => {
    setParams({ ...draftParams, legitimate: true } as SimulationParams);
  };

  const MODULE_TYPES = ['premodule', 'security', 'ethics', 'governance', 'law', 'safety', 'ops'];

  return (
    <div className="space-y-6">
      {/* Undo/Redo & Import */}
      <div className="flex items-center justify-between border-b pb-4 border-[#141414]/10 dark:border-[#E4E3E0]/10">
        <div className="flex gap-2">
          <button
            onClick={undo}
            disabled={!canUndo}
            className={cn(
              "p-2 border border-[#141414] dark:border-[#E4E3E0]/20 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-20 transition-all",
            )}
            title="Undo"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
          <button
            onClick={redo}
            disabled={!canRedo}
            className={cn(
              "p-2 border border-[#141414] dark:border-[#E4E3E0]/20 hover:bg-black/5 dark:hover:bg-white/5 disabled:opacity-20 transition-all",
            )}
            title="Redo"
          >
            <RotateCw className="w-3 h-3" />
          </button>
          <button
            onClick={() => setShowPresetSave(!showPresetSave)}
            className={cn(
              "p-2 border border-[#141414] dark:border-[#E4E3E0]/20 hover:bg-black/5 dark:hover:bg-white/5 transition-all",
              showPresetSave && "bg-black/10 dark:bg-white/10"
            )}
            title="Save Preset"
          >
            <Save className="w-3 h-3" />
          </button>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={onGenerateAi}
            disabled={aiLoading || loading}
            className={cn(
              "flex items-center gap-1.5 px-2 py-1 text-[9px] uppercase font-bold border rounded transition-all",
              "border-yellow-600 text-yellow-700 hover:bg-yellow-50 dark:border-yellow-500/50 dark:text-yellow-500 dark:hover:bg-yellow-500/10",
              (aiLoading || loading) && "opacity-50 cursor-not-allowed"
            )}
          >
            {aiLoading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
            AI Scenario
          </button>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-3 py-2 border border-[#141414] dark:border-[#E4E3E0]/20 text-[10px] uppercase font-bold hover:bg-black/5 dark:hover:bg-white/5"
          >
            <Upload className="w-3 h-3" />
            Import
          </button>
        </div>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept=".json" 
          className="hidden" 
        />
      </div>

      {/* Preset Save Dialog */}
      {showPresetSave && (
        <div className="p-4 border border-[#141414] dark:border-[#E4E3E0]/20 bg-black/5 dark:bg-white/5 space-y-3 animate-in fade-in slide-in-from-top-2">
          <label className="text-[10px] uppercase font-bold opacity-60">Save Current Configuration as Preset</label>
          <div className="flex gap-2">
            <input 
              type="text"
              placeholder="PRESET NAME..."
              value={newPresetName}
              onChange={(e) => setNewPresetName(e.target.value)}
              className="flex-1 bg-transparent border border-[#141414] dark:border-[#E4E3E0]/20 p-2 text-[10px] uppercase font-bold focus:outline-none"
            />
            <button 
              onClick={savePreset}
              className="px-4 py-2 bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] text-[10px] uppercase font-bold"
            >
              Save
            </button>
          </div>
        </div>
      )}

      {/* Presets List */}
      {presets.length > 0 && (
        <div className="space-y-2">
          <label className="text-[10px] uppercase font-bold opacity-40 flex items-center gap-2">
            <Bookmark className="w-3 h-3" />
            Saved Presets
          </label>
          <div className="flex flex-wrap gap-2">
            {presets.map((preset, i) => (
              <div key={i} className="group relative">
                <button
                  onClick={() => loadPreset(preset)}
                  className="px-3 py-1.5 border border-[#141414] dark:border-[#E4E3E0]/20 text-[9px] uppercase font-bold hover:bg-black/5 dark:hover:bg-white/5 transition-all"
                >
                  {preset.name}
                </button>
                <button 
                  onClick={() => deletePreset(i)}
                  className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Decision Object Preview (Canonical Decision Object) */}
      <div className={cn(
        "p-4 border border-dashed relative overflow-hidden transition-all duration-500",
        decision?.decision === 'HALT' ? "border-red-500/50 bg-red-500/5" : 
        decision?.decision === 'ALLOW_WITH_MONITORING' ? "border-yellow-500/50 bg-yellow-500/5" :
        "border-green-500/50 bg-green-500/5"
      )}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className={cn(
              "w-4 h-4",
              decision?.decision === 'HALT' ? "text-red-500" : 
              decision?.decision === 'ALLOW_WITH_MONITORING' ? "text-yellow-500" :
              "text-green-500"
            )} />
            <span className="text-[10px] uppercase font-bold tracking-widest">Decision Object</span>
          </div>
          {isEvaluating && <Activity className="w-3 h-3 animate-pulse opacity-50" />}
        </div>

        <div className="space-y-2 font-mono text-[8px] uppercase tracking-tight">
          <div className="flex justify-between">
            <span className="opacity-40">Decision:</span>
            <span className={cn(
              "font-bold",
              decision?.decision === 'HALT' ? "text-red-500" : 
              decision?.decision === 'ALLOW_WITH_MONITORING' ? "text-yellow-500" :
              "text-green-500"
            )}>{decision?.decision || 'EVALUATING...'}</span>
          </div>
          <div className="flex justify-between">
            <span className="opacity-40">Reason:</span>
            <span>{decision?.reason || '...'}</span>
          </div>
          <div className="flex justify-between">
            <span className="opacity-40">Drift Score:</span>
            <span>{decision?.drift_score.toFixed(2) || '0.00'}</span>
          </div>
          <div className="flex justify-between">
            <span className="opacity-40">Policy ID:</span>
            <span>{decision?.policy_id || '...'}</span>
          </div>
          <div className="pt-2 border-t border-black/5 dark:border-white/5">
            <div className="flex items-center gap-1 opacity-40 mb-1">
              <Fingerprint className="w-2 h-2" />
              <span>Cryptographic Signature</span>
            </div>
            <div className="truncate opacity-60 font-mono text-[7px]">
              {decision?.signature || 'GENERATING SIGNATURE...'}
            </div>
          </div>
        </div>

        {/* Pre-Execution Commit Enforcement */}
        <button
          onClick={handleCommit}
          className={cn(
            "w-full mt-4 py-2 text-[10px] uppercase font-bold border transition-all flex items-center justify-center gap-2",
            decision?.decision === 'HALT' 
              ? "bg-red-700 text-white border-red-700 hover:bg-red-800" 
              : "bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] border-[#141414] dark:border-[#E4E3E0] hover:opacity-90"
          )}
        >
          {decision?.decision === 'HALT' ? <AlertTriangle className="w-3 h-3" /> : <CheckCircle2 className="w-3 h-3" />}
          Commit & Execute
        </button>
      </div>

      <div className="space-y-4">
        <label className="text-[10px] uppercase font-bold tracking-widest opacity-40 block">Cryptographic State</label>
        <div className="grid grid-cols-2 gap-2">
          {['valid', 'invalid'].map((status) => (
            <button
              key={status}
              onClick={() => updateParam('tokenStatus', status)}
              className={cn(
                "py-2 text-[10px] uppercase font-bold border transition-all",
                draftParams.tokenStatus === status 
                  ? "bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] border-[#141414] dark:border-[#E4E3E0]" 
                  : "border-[#141414] dark:border-[#E4E3E0]/20 hover:bg-black/5 dark:hover:bg-white/5"
              )}
            >
              Token: {status}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <label className="text-[10px] uppercase font-bold tracking-widest opacity-40 block">Action Context</label>
        <select 
          value={draftParams.action}
          onChange={(e) => updateParam('action', e.target.value)}
          className={cn(
            "w-full p-2 bg-transparent border text-xs uppercase font-bold focus:outline-none transition-colors",
            "border-[#141414] dark:border-[#E4E3E0]/20 text-[#141414] dark:text-[#E4E3E0]"
          )}
        >
          <option value="execute_transfer" className="bg-white dark:bg-[#141414]">Execute Transfer</option>
          <option value="admin_override" className="bg-white dark:bg-[#141414]">Admin Override</option>
          <option value="data_export" className="bg-white dark:bg-[#141414]">Data Export</option>
          <option value="read_data" className="bg-white dark:bg-[#141414]">Read Data</option>
          <option value="write_log" className="bg-white dark:bg-[#141414]">Write Log</option>
        </select>
      </div>

      <div className={cn(
        "space-y-4 pt-4 border-t",
        "border-[#141414]/10 dark:border-[#E4E3E0]/10"
      )}>
        <label className="text-[10px] uppercase font-bold tracking-widest opacity-40 block">SWI Module Config (Deactivate)</label>
        <div className="flex flex-wrap gap-1">
          {MODULE_TYPES.map((type) => (
            <button
              key={type}
              onClick={() => updateSWIConfig(type)}
              className={cn(
                "px-2 py-1 text-[8px] uppercase font-bold border transition-all",
                draftParams.swiConfig?.deactivatedTypes?.includes(type)
                  ? "bg-red-700 text-white border-red-700"
                  : "border-[#141414] dark:border-[#E4E3E0]/20 opacity-40 hover:opacity-100"
              )}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className={cn(
        "space-y-4 pt-4 border-t",
        "border-[#141414]/10 dark:border-[#E4E3E0]/10"
      )}>
        <label className="text-[10px] uppercase font-bold tracking-widest opacity-40 block">CEK Drift Factors</label>
        
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-xs uppercase tracking-tight">User Behavior</span>
            <div className="flex gap-1">
              {['normal', 'anomalous'].map((v) => (
                <button
                  key={v}
                  onClick={() => updateParam('userBehavior', v)}
                  className={cn(
                    "px-2 py-1 text-[9px] uppercase font-bold border transition-colors",
                    draftParams.userBehavior === v 
                      ? "bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] border-[#141414] dark:border-[#E4E3E0]" 
                      : "border-[#141414] dark:border-[#E4E3E0]/20 opacity-40 hover:opacity-100"
                  )}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs uppercase tracking-tight">Environment</span>
            <div className="flex gap-1">
              {['stable', 'unstable'].map((v) => (
                <button
                  key={v}
                  onClick={() => updateParam('environment', v)}
                  className={cn(
                    "px-2 py-1 text-[9px] uppercase font-bold border transition-colors",
                    draftParams.environment === v 
                      ? "bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] border-[#141414] dark:border-[#E4E3E0]" 
                      : "border-[#141414] dark:border-[#E4E3E0]/20 opacity-40 hover:opacity-100"
                  )}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-xs uppercase tracking-tight">Policy Mismatch</span>
            <button
              onClick={() => updateParam('policyMismatch', !draftParams.policyMismatch)}
              className={cn(
                "px-3 py-1 text-[9px] uppercase font-bold border transition-colors",
                draftParams.policyMismatch 
                  ? "bg-red-700 text-white border-red-700" 
                  : "border-[#141414] dark:border-[#E4E3E0]/20 opacity-40 hover:opacity-100"
              )}
            >
              {draftParams.policyMismatch ? 'Detected' : 'None'}
            </button>
          </div>

          <div className="space-y-1 pt-2">
            <div className="flex justify-between text-[9px] uppercase font-bold">
              <span className="opacity-60">Drift Score (Security Maze)</span>
              <span className={cn(draftParams.driftScore >= 0.7 ? "text-red-500" : "text-green-500")}>
                {draftParams.driftScore.toFixed(2)}
              </span>
            </div>
            <input 
              type="range" min="0.0" max="1.0" step="0.01"
              value={draftParams.driftScore}
              onChange={(e) => updateParam('driftScore', parseFloat(e.target.value))}
              className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
            />
          </div>

          <div className="space-y-1 pt-2">
            <div className="flex justify-between text-[9px] uppercase font-bold">
              <span className="opacity-60">Mutation Intensity</span>
              <span>{draftParams.mutationIntensity?.toFixed(2) || "1.00"}</span>
            </div>
            <input 
              type="range" min="0.1" max="2.0" step="0.1"
              value={draftParams.mutationIntensity || 1.0}
              onChange={(e) => updateParam('mutationIntensity', parseFloat(e.target.value))}
              className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
            />
          </div>
        </div>
      </div>

      {/* Advanced Drift Tuning */}
      <div className={cn(
        "space-y-4 pt-4 border-t",
        "border-[#141414]/10 dark:border-[#E4E3E0]/10"
      )}>
        <div className="flex items-center gap-2 opacity-40">
          <Settings2 className="w-3 h-3" />
          <label className="text-[10px] uppercase font-bold tracking-widest block">Drift Sensitivity Tuning</label>
        </div>

        <div className="space-y-4">
          <div className="space-y-1">
            <div className="flex justify-between text-[9px] uppercase font-bold">
              <span className="opacity-60">Drift Threshold</span>
              <span>{draftParams.driftConfig.threshold.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0.1" max="1.0" step="0.05"
              value={draftParams.driftConfig.threshold}
              onChange={(e) => updateDriftConfig('threshold', parseFloat(e.target.value))}
              className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-[9px] uppercase font-bold">
              <span className="opacity-60">Anomalous Behavior Incr.</span>
              <span>{draftParams.driftConfig.increments.ANOMALOUS_BEHAVIOR.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0.1" max="1.0" step="0.05"
              value={draftParams.driftConfig.increments.ANOMALOUS_BEHAVIOR}
              onChange={(e) => updateDriftConfig('ANOMALOUS_BEHAVIOR', parseFloat(e.target.value))}
              className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-[9px] uppercase font-bold">
              <span className="opacity-60">Unstable Env Incr.</span>
              <span>{draftParams.driftConfig.increments.UNSTABLE_ENVIRONMENT.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0.1" max="1.0" step="0.05"
              value={draftParams.driftConfig.increments.UNSTABLE_ENVIRONMENT}
              onChange={(e) => updateDriftConfig('UNSTABLE_ENVIRONMENT', parseFloat(e.target.value))}
              className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
