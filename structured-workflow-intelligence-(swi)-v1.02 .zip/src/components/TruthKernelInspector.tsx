import React, { useState, useEffect } from "react";
import jsPDF from "jspdf";
import { Shield, ShieldAlert, Cpu, CheckCircle2, History, Link, FileKey, Database, BadgeCheck, QrCode, Camera, Download, ListChecks, ServerCrash, FileText, X } from "lucide-react";
import { cn } from "../lib/utils";
import { globalTruthKernel, Receipt, ReplayResult, VerificationResult } from "../../swi-core/truth/TruthKernel";
import { verifyReceiptSignature } from "../lib/crypto";
import { QRCodeSVG } from "qrcode.react";
import { verifySystem } from "../../swi-core/truth/registry";
import { verifyRefinement } from "../../swi-core/truth/refinement";

// Sub-component for FSK-v2 Debugger
function FSK2Debugger() {
  type KernelMode = "NORMAL" | "DEGRADED" | "HALT" | "RECOVERY";
  type CostGuardianTransaction = {
    id: string;
    txHash: string;
    costOwnerId: string;
    projectedCost: number;
    resourceMetrics: string;
    currency: string;
    budgetThreshold?: number;
    status: "BINDING_ACTIVE" | "PENDING_APPROVAL" | "LIQUIDATED";
    timestamp: string;
  };
  type StateHistoryEvent = {
    id: string;
    triggerReason: string;
    snapshotId: string;
    previousMode: KernelMode;
    newMode: KernelMode;
    timestamp: string;
  };

  const [currentMode, setCurrentMode] = useState<KernelMode>("NORMAL");
  const [activeTransactions, setActiveTransactions] = useState<CostGuardianTransaction[]>([]);
  const [history, setHistory] = useState<StateHistoryEvent[]>([
    {
      id: "init-genesis",
      triggerReason: "SYSTEM_BOOTSTRAP",
      snapshotId: "snap_genesis_0000",
      previousMode: "NORMAL",
      newMode: "NORMAL",
      timestamp: new Date().toISOString()
    }
  ]);

  useEffect(() => {
    // Simulate active cost guardian transactions
    const txs: CostGuardianTransaction[] = [
      {
        id: "tx-gov-1001",
        txHash: "0x89a3f234",
        costOwnerId: "DEPT_SECURITY_OPS",
        projectedCost: 4.50,
        resourceMetrics: "12ms CPU, 45KB RAM",
        currency: "USD",
        budgetThreshold: 10,
        status: "BINDING_ACTIVE",
        timestamp: new Date().toISOString()
      },
      {
        id: "tx-gov-1002",
        txHash: "0x12b9cfdf",
        costOwnerId: "ML_TRAINING_PIPELINE",
        projectedCost: 1540.00,
        resourceMetrics: "4 GPU hrs, 12GB VRAM",
        currency: "USD",
        budgetThreshold: 1800,
        status: "PENDING_APPROVAL",
        timestamp: new Date(Date.now() - 50000).toISOString()
      }
    ];
    setActiveTransactions(txs);
  }, []);

  const triggerStateTransition = (targetMode: KernelMode) => {
    if (currentMode === targetMode) return;

    let reason = "MANUAL_OVERRIDE";
    if (targetMode === "HALT") reason = "UNBOUND_GOVERNANCE_DETECTED";
    else if (targetMode === "RECOVERY") reason = "SAGA_COMPENSATION_INVOKED";
    else if (targetMode === "DEGRADED") reason = "ELEVATED_RISK_HEURISTIC";
    else if (targetMode === "NORMAL") reason = "SYSTEM_STABILIZED";

    const newEvent: StateHistoryEvent = {
      id: "ev-" + Math.random().toString(36).substr(2, 9),
      triggerReason: reason,
      snapshotId: "snap_" + Math.random().toString(16).substring(2, 10),
      previousMode: currentMode,
      newMode: targetMode,
      timestamp: new Date().toISOString()
    };

    setHistory(prev => [newEvent, ...prev]);
    setCurrentMode(targetMode);
  };

  const liquidateAnchor = (id: string) => {
    setActiveTransactions(prev => prev.map(tx => tx.id === id ? { ...tx, status: "LIQUIDATED" } : tx));
  };

  const getModeColor = (mode: KernelMode) => {
    switch(mode) {
      case "NORMAL": return "text-emerald-400 bg-emerald-500/10 border-emerald-500/30";
      case "DEGRADED": return "text-yellow-400 bg-yellow-500/10 border-yellow-500/30";
      case "HALT": return "text-red-500 bg-red-500/10 border-red-500/30";
      case "RECOVERY": return "text-purple-400 bg-purple-500/10 border-purple-500/30";
    }
  };

  return (
    <div className="bg-[#141414] border border-[#222] p-6 rounded-lg text-white font-mono shadow-xl mt-6">
      <div className="flex items-center justify-between border-b border-[#333] pb-4 mb-6">
        <div>
          <h2 className="text-lg font-bold tracking-[0.2em] uppercase flex items-center gap-2">
            <Cpu className="w-5 h-5 text-blue-500" />
            FSK-v2 Kernel Debugger
          </h2>
          <p className="text-xs text-gray-400 mt-1">Live telemetry for Fail-Safe Kernel v2 state transitions & Cost Guardian bounds.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500">Kernel State Control Layer</h3>
          
          <div className={cn("flex flex-col gap-2 p-4 rounded border transition-colors", getModeColor(currentMode))}>
            <div className="flex justify-between items-center">
              <span className="text-xs uppercase font-bold tracking-widest text-inherit opacity-80">Active Mode</span>
              {currentMode === "NORMAL" && <CheckCircle2 className="w-5 h-5" />}
              {currentMode === "DEGRADED" && <ShieldAlert className="w-5 h-5" />}
              {currentMode === "HALT" && <ServerCrash className="w-5 h-5" />}
              {currentMode === "RECOVERY" && <History className="w-5 h-5" />}
            </div>
            <div className="text-2xl font-bold tracking-widest">{currentMode}</div>
            <div className="text-[10px] opacity-70 mt-1">
              {currentMode === "NORMAL" && "System fully operational. All execution pipelines hot."}
              {currentMode === "DEGRADED" && "Limited execution. Elevated risk heuristic detected."}
              {currentMode === "HALT" && "MANDATORY BLOCK. All mutations frozen. No cost generation allowed."}
              {currentMode === "RECOVERY" && "Saga compensations & CRDT reconciliation active."}
            </div>
          </div>

          <div className="bg-[#0A0A0A] p-3 rounded border border-[#333]">
            <div className="text-xs text-gray-400 mb-2 uppercase tracking-wide">Inject Transition Signal</div>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => triggerStateTransition("NORMAL")}
                className="px-2 py-1.5 rounded bg-[#111] border border-emerald-500/30 text-emerald-400 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Restore (Normal)
              </button>
              <button 
                onClick={() => triggerStateTransition("DEGRADED")}
                className="px-2 py-1.5 rounded bg-[#111] border border-yellow-500/30 text-yellow-400 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Degrade
              </button>
              <button 
                onClick={() => triggerStateTransition("HALT")}
                className="px-2 py-1.5 rounded bg-[#111] border border-red-500/30 text-red-500 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Panic / Halt
              </button>
              <button 
                onClick={() => triggerStateTransition("RECOVERY")}
                className="px-2 py-1.5 rounded bg-[#111] border border-purple-500/30 text-purple-400 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Start Recovery
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500 flex justify-between items-center">
            <span>Cost Guardian Anchors</span>
            {currentMode === 'HALT' && <span className="text-[10px] text-red-500 bg-red-500/10 px-2 py-0.5 rounded font-bold tracking-widest border border-red-500/20">FROZEN</span>}
          </h3>

          <div className="bg-[#0A0A0A] rounded border border-[#333] overflow-hidden flex flex-col h-full max-h-[350px]">
            <div className="overflow-y-auto custom-scrollbar flex-1 relative min-h-[160px]">
              {activeTransactions.length === 0 ? (
                 <div className="absolute inset-0 flex items-center justify-center text-xs text-gray-600">No active financial anchors.</div>
              ) : (
                <div className="flex flex-col">
                  {activeTransactions.map(tx => {
                    const isApproachingThreshold = tx.budgetThreshold && (tx.projectedCost / tx.budgetThreshold > 0.8);
                    return (
                    <div key={tx.id} className={cn("p-3 border-b border-[#222] last:border-0 hover:bg-[#111] transition-colors relative", currentMode === 'HALT' ? 'opacity-50 grayscale' : '')}>
                      {isApproachingThreshold && (
                        <div className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-500 mr-2 mt-2 animate-pulse" title="Approaching Budget Threshold" />
                      )}
                      <div className="flex justify-between items-start mb-2 pr-4">
                        <span className="text-xs font-bold text-gray-300">{tx.costOwnerId}</span>
                        <div className="text-right">
                          <span className={cn("text-xs font-bold block", tx.projectedCost > 1000 ? "text-yellow-400" : "text-gray-400")}>
                            ${tx.projectedCost.toFixed(2)} {tx.currency}
                            {tx.budgetThreshold && <span className="text-gray-600 font-normal ml-1">/ ${tx.budgetThreshold}</span>}
                          </span>
                          <span className="text-[9px] text-gray-500">{tx.resourceMetrics}</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-blue-400 truncate w-24 sm:w-28 font-mono">{tx.txHash}</span>
                        <div className="flex items-center gap-2">
                          {isApproachingThreshold && <span className="text-red-400 text-[8px] font-bold border border-red-500/30 px-1 rounded bg-red-500/10">WARN: DANGER</span>}
                          <span className={cn(
                            "px-1.5 py-0.5 rounded uppercase border whitespace-nowrap", 
                            tx.status === "BINDING_ACTIVE" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : 
                            tx.status === "LIQUIDATED" ? "bg-red-500/10 border-red-500/20 text-red-400" :
                            "bg-yellow-500/10 border-yellow-500/20 text-yellow-400"
                          )}>
                            {tx.status.replace("_", " ")}
                          </span>
                          {tx.status !== "LIQUIDATED" && (
                            <button 
                              onClick={() => liquidateAnchor(tx.id)}
                              className="text-gray-500 hover:text-red-400 hover:bg-red-500/10 px-1.5 py-0.5 rounded border border-transparent hover:border-red-500/30 transition-colors"
                              title="Liquidate Anchor"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  )})}
                </div>
              )}
            </div>
            
            <div className="p-3 bg-[#111] border-t border-[#333] shrink-0 mt-auto">
              <button
                className="w-full px-3 py-1.5 rounded bg-[#222] border border-[#444] text-[10px] uppercase text-gray-300 font-bold hover:bg-[#333] transition"
                onClick={() => {
                  if (currentMode === 'HALT') {
                    alert("Execution Frozen: Cannot span new cost guardian bounds in HALT state.");
                    return;
                  }
                  
                  const cost = Math.random() * 500;
                  const threshold = cost * (1 + (Math.random() * 0.5 - 0.1));

                  setActiveTransactions(prev => [
                    {
                      id: "tx-gov-" + Math.floor(Math.random()*10000),
                      txHash: "0x" + Math.random().toString(16).substring(2, 10),
                      costOwnerId: "AD_HOC_REQ",
                      projectedCost: cost,
                      resourceMetrics: Math.floor(Math.random() * 100) + "ms CPU, " + Math.floor(Math.random() * 500) + "KB RAM",
                      currency: "USD",
                      budgetThreshold: Math.max(cost, Math.floor(threshold)),
                      status: "BINDING_ACTIVE",
                      timestamp: new Date().toISOString()
                    },
                    ...prev
                  ])
                }}
              >
                + Span New Cost Anchor
              </button>
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500 flex justify-between items-center">
            <span>State History & Rollback Log</span>
          </h3>

          <div className="bg-[#0A0A0A] rounded border border-[#333] overflow-hidden flex flex-col h-full max-h-[350px]">
             <div className="overflow-y-auto custom-scrollbar flex-1 p-3 space-y-3">
               {history.map((ev, i) => (
                 <div key={ev.id} className="relative pl-4 border-l border-[#333] pb-2 last:pb-0">
                   <div className="absolute w-2 h-2 rounded-full -left-[4.5px] top-1.5 bg-[#444]" />
                   <div className="flex justify-between items-start mb-1">
                     <span className="text-[10px] font-bold text-gray-400">
                       {new Date(ev.timestamp).toLocaleTimeString()}
                     </span>
                     <span className="text-[9px] text-purple-400 bg-purple-500/10 px-1 rounded border border-purple-500/20 font-mono text-right truncate max-w-[100px]">
                       {ev.snapshotId}
                     </span>
                   </div>
                   <div className="text-xs text-blue-400 font-bold break-words">{ev.triggerReason}</div>
                   <div className="text-[10px] text-gray-500 mt-1 uppercase tracking-widest flex items-center gap-1">
                     <span className={cn(
                       "px-1 rounded", 
                       ev.previousMode === 'NORMAL' ? 'text-emerald-500' :
                       ev.previousMode === 'DEGRADED' ? 'text-yellow-500' :
                       ev.previousMode === 'HALT' ? 'text-red-500' : 'text-purple-500'
                     )}>{ev.previousMode}</span>
                     ➔
                     <span className={cn(
                       "px-1 rounded font-bold", 
                       ev.newMode === 'NORMAL' ? 'text-emerald-400 bg-emerald-500/10' :
                       ev.newMode === 'DEGRADED' ? 'text-yellow-400 bg-yellow-500/10' :
                       ev.newMode === 'HALT' ? 'text-red-500 bg-red-500/10' : 'text-purple-400 bg-purple-500/10'
                     )}>{ev.newMode}</span>
                   </div>
                 </div>
               ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TruthKernelInspector() {
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [selectedReceipt, setSelectedReceipt] = useState<Receipt | null>(null);
  const [verification, setVerification] = useState<VerificationResult | null>(null);
  const [replayResult, setReplayResult] = useState<ReplayResult | null>(null);
  const [systemVerification, setSystemVerification] = useState<{chainValid: boolean, stateRoot: string} | null>(null);
  const [refinementProven, setRefinementProven] = useState<boolean | null>(null);
  const [backgroundHealth, setBackgroundHealth] = useState<{status: 'HEALTHY' | 'COMPROMISED' | 'UNKNOWN', lastChecked: Date | null, message?: string}>({status: 'UNKNOWN', lastChecked: null});
  
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedResult, setScannedResult] = useState<{ receipt: Receipt, verification: VerificationResult } | null>(null);

  type BulkVerificationEntry = {
    receiptId: string;
    timestamp: string;
    valid: boolean;
    reason: string;
  };

  const [bulkResult, setBulkResult] = useState<{ 
    total: number, 
    valid: number, 
    invalid: number,
    merkleRoot: string,
    entries: BulkVerificationEntry[] 
  } | null>(null);

  useEffect(() => {
    let unmounted = false;
    const checkHealth = () => {
      try {
        const registry = globalTruthKernel.getRegistry();
        const result = verifySystem(registry);
        if (!unmounted) {
          setBackgroundHealth({
             status: result.chainValid ? 'HEALTHY' : 'COMPROMISED',
             lastChecked: new Date(),
          });
        }
      } catch (e: any) {
        if (!unmounted) {
          setBackgroundHealth({
             status: 'COMPROMISED',
             lastChecked: new Date(),
             message: e.message
          });
        }
      }
    };

    checkHealth();
    // Re-verify the system continuously in background every 5 seconds
    const interval = setInterval(checkHealth, 5000);

    // Generate some mock historical requests that passed through the Truth Kernel
    const policyFn = (req: any) => ({
      approved: req.amount < 10000,
      reason: req.amount < 10000 ? "Within limits" : "Exceeds absolute threshold",
      policyVersion: "SWI_VF_1.01",
    });

    const initReceipts = () => {
      globalTruthKernel.record({ type: "FUNDS_TRANSFER", amount: 500, user: "Alice", nonce: "init-nonce-1" }, policyFn({ amount: 500 }));
      globalTruthKernel.record({ type: "SYSTEM_UPDATE", package: "kernel-v2", nonce: "init-nonce-2" }, policyFn({ amount: 0 }));
      globalTruthKernel.record({ type: "FUNDS_TRANSFER", amount: 15000, user: "Bob", nonce: "init-nonce-3" }, policyFn({ amount: 15000 }));
      
      setReceipts(globalTruthKernel.getAllReceipts());
    };

    if (globalTruthKernel.getAllReceipts().length === 0) {
      initReceipts();
    } else {
      setReceipts(globalTruthKernel.getAllReceipts());
    }

    return () => {
      unmounted = true;
      clearInterval(interval);
    };
  }, []);

  const handleVerify = (receipt: Receipt) => {
    setSelectedReceipt(receipt);
    const result = verifyReceiptSignature(receipt);
    setVerification(result);
    setReplayResult({
      matches: true,
      stateRootMatches: true,
      actualHash: receipt.decisionHash,
      expectedHash: receipt.decisionHash
    });
  };

  const handleBulkVerify = () => {
    let validCount = 0;
    const entries: BulkVerificationEntry[] = [];
    receipts.forEach(r => {
      const v = verifyReceiptSignature(r);
      if (v.valid) validCount++;
      entries.push({
        receiptId: r.receiptId,
        timestamp: r.timestamp,
        valid: v.valid,
        reason: v.reason
      });
    });
    
    // Test batch integrity and get Merkle Root via the export tool
    const exportStatus = globalTruthKernel.exportReceipts();
    
    setBulkResult({
      total: receipts.length,
      valid: validCount,
      invalid: receipts.length - validCount,
      merkleRoot: exportStatus.merkleRoot,
      entries
    });
  };

  const handleVerifySystemState = () => {
    try {
      const registry = globalTruthKernel.getRegistry();
      const result = verifySystem(registry);
      setSystemVerification(result);
    } catch (e: any) {
      alert(`System Verification Failed: ${e?.message}`);
    }
  };

  const handleExport = () => {
    // We now export the Transparency Registry instead of just receipts
    const registry = globalTruthKernel.getRegistry();
    const exportedData = {
      ...globalTruthKernel.exportReceipts(),
      transparencyRegistry: registry
    };
    
    const blob = new Blob([JSON.stringify(exportedData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `swi-audit-chain-${exportedData.timestamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleScan = (text: string) => {
    try {
      const parsedReceipt = JSON.parse(text) as Receipt;
      if (parsedReceipt.receiptId && parsedReceipt.signature) {
        setIsScannerOpen(false);
        const result = verifyReceiptSignature(parsedReceipt);
        setScannedResult({ receipt: parsedReceipt, verification: result });
      }
    } catch (e) {
      // ignore invalid formats while scanning
    }
  };

  const handleTestReplayAttack = () => {
    const testNonce = "simulated-test-nonce-" + Date.now();
    const firstTry = globalTruthKernel.registerNonce(testNonce);
    const secondTry = globalTruthKernel.registerNonce(testNonce);
    alert(`REPLAY ATTACK TEST:\n\nAttempt 1 (Original Request): ${firstTry ? "ACCEPTED" : "REJECTED"}\nAttempt 2 (Replayed Request): ${secondTry ? "ACCEPTED" : "REJECTED (SAFE)"}\n\nThe Truth Kernel correctly tracks the unique request nonce and prevents duplicate execution.`);
  };

  const handleInjectTamperedRecord = () => {
    const tamperedReceipt: Receipt = {
      receiptId: "rcpt-tampered-999",
      requestHash: "fake_hash_123",
      decisionHash: "fake_hash_456",
      policyVersion: "SWI_VF_1.01",
      timestamp: new Date().toISOString(),
      previousReceiptHash: "invalid_link",
      signature: "ZmFrZV9zaWduYXR1cmVfZGF0YQ==",
      publicKey: "ZmFrZV9wdWJsaWNfa2V5"
    };
    setReceipts(prev => [tamperedReceipt, ...prev]);
    alert("Injected tampered receipt into visual ledger layer.\nRun 'Bulk Verify' to see independent cryptographic check catch the counterfeit data.");
  };

  const handleProveRefinement = () => {
    try {
      const registry = globalTruthKernel.getRegistry();
      const vmState = globalTruthKernel.getVMState();
      const proven = verifyRefinement(registry.events, vmState);
      setRefinementProven(proven);
      if (proven) {
        alert("Mechanized Refinement Proof Succeeded:\n\nThe Concrete VM mathematically refines the Abstract Specification without error or state divergence.");
      }
    } catch (e: any) {
      alert(`Refinement Proof Violation:\n${e?.message}`);
      setRefinementProven(false);
    }
  };

  const handleExportCourtCaseProof = (receipt: Receipt) => {
    try {
      const doc = new jsPDF();
      
      doc.setFontSize(22);
      doc.setTextColor(40, 40, 40);
      doc.text("SWI Truth Kernel", 20, 20);
      
      doc.setFontSize(16);
      doc.text("Cryptographic Court Case Proof", 20, 30);
      
      doc.setFontSize(12);
      doc.setTextColor(100, 100, 100);
      doc.text(`Generated: ${new Date().toISOString()}`, 20, 40);
      
      doc.setLineWidth(0.5);
      doc.line(20, 45, 190, 45);
      
      doc.setFontSize(14);
      doc.setTextColor(20, 20, 20);
      doc.text("Receipt Identity", 20, 55);
      
      doc.setFontSize(10);
      doc.setFont("courier");
      const lines = [
        `Receipt ID: ${receipt.receiptId}`,
        `Timestamp: ${receipt.timestamp}`,
        `Policy Version: ${receipt.policyVersion}`,
        ``,
        `Request Hash:`,
        `${receipt.requestHash}`,
        ``,
        `Decision Hash:`,
        `${receipt.decisionHash}`,
        ``,
        `Previous Chain Hash:`,
        `${receipt.previousReceiptHash}`,
        ``,
        `Signer Public Key:`,
        `${receipt.publicKey}`,
        ``,
        `Ed25519 Cryptographic Signature:`,
        `${receipt.signature}`
      ];
      
      let y = 65;
      lines.forEach(line => {
        const splitText = doc.splitTextToSize(line, 170);
        doc.text(splitText, 20, y);
        y += 5 * splitText.length;
      });
      
      doc.setFont("helvetica", "normal");
      doc.setFontSize(12);
      y += 10;
      doc.text("Verification Status: INDEPENDENTLY VERIFIABLE", 20, y);
      
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text("This document constitutes a mathematically reproducible formal derivation.", 20, 280);
      
      doc.save(`SWI-Court-Proof-${receipt.receiptId}.pdf`);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
      alert("Failed to generate PDF proof");
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      <div className="bg-[#141414] border border-[#222] p-6 rounded-lg text-white font-mono shadow-2xl">
        <div className="flex justify-between items-start mb-6 border-b border-[#333] pb-4">
          <div>
            <h2 className="text-xl font-bold tracking-[0.2em] uppercase flex items-center gap-3">
              <Database className="w-6 h-6 text-emerald-500" />
              Truth Kernel: Formal Execution VM
            </h2>
            <p className="text-sm text-gray-400 mt-2">
              Layer 3 Deterministic Event Kernel. All state derived purely from reproducible public event log.
            </p>
          </div>
          <div className="flex flex-col items-end gap-3">
            {backgroundHealth.status === 'HEALTHY' && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 px-3 py-1 flex flex-col items-end gap-1 rounded text-right">
                 <div className="text-xs uppercase font-bold tracking-widest flex items-center gap-2">
                   <Shield className="w-4 h-4" /> System Health: OK
                 </div>
                 <div className="text-[10px] text-emerald-500/70">Continuous Background Audit Passing</div>
              </div>
            )}
            {backgroundHealth.status === 'COMPROMISED' && (
              <div className="bg-red-500/10 border border-red-500/20 text-red-500 px-3 py-1 flex flex-col items-end gap-1 rounded text-right">
                 <div className="text-xs uppercase font-bold tracking-widest flex items-center gap-2">
                   <ShieldAlert className="w-4 h-4" /> System Health: COMPROMISED
                 </div>
                 <div className="text-[10px] text-red-400">Ledger state failed continuous audit</div>
              </div>
            )}
            <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 px-3 py-1 text-xs uppercase font-bold rounded flex items-center gap-2 tracking-widest hidden sm:flex">
              <Shield className="w-4 h-4" />
              Verified Spec VM Boundary
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 mb-6 bg-[#0a0a00] p-3 rounded border border-yellow-500/20">
            <button 
              onClick={handleProveRefinement} 
              className="px-3 py-1.5 rounded bg-[#111] border border-fuchsia-500/30 text-fuchsia-400 text-xs uppercase flex items-center gap-2 hover:bg-[#222] transition font-bold"
            >
              <Cpu className="w-4 h-4" /> Prove Refinement (VM ⊨ Spec)
            </button>
            <button 
              onClick={handleVerifySystemState} 
              className="px-3 py-1.5 rounded bg-[#111] border border-blue-500/30 text-blue-400 text-xs uppercase flex items-center gap-2 hover:bg-[#222] transition"
            >
              <Cpu className="w-4 h-4" /> Verify VM State (Replay Log)
            </button>
            <button 
              onClick={handleBulkVerify} 
              className="px-3 py-1.5 rounded bg-[#222] border border-[#444] text-xs uppercase flex items-center gap-2 hover:bg-[#333] transition"
            >
              <ListChecks className="w-4 h-4" /> Batch Merkle Verify
            </button>
            <button 
              onClick={handleExport} 
              className="px-3 py-1.5 rounded bg-[#222] border border-[#444] text-xs uppercase flex items-center gap-2 hover:bg-[#333] transition"
            >
              <Download className="w-4 h-4" /> Export Public Audit Chain
            </button>
            <button 
              onClick={() => setIsScannerOpen(!isScannerOpen)} 
              className="px-3 py-1.5 rounded bg-[#222] border border-[#444] text-xs uppercase flex items-center gap-2 hover:bg-[#333] transition"
            >
              <Camera className="w-4 h-4" /> Scan Receipt
            </button>
            <button 
              onClick={handleTestReplayAttack} 
              className="px-3 py-1.5 rounded bg-[#111] border border-[#444] text-xs uppercase flex items-center gap-2 hover:bg-[#222] transition"
            >
              <ServerCrash className="w-4 h-4" /> Test Replay 
            </button>
            <button 
              onClick={handleInjectTamperedRecord} 
              className="px-3 py-1.5 rounded bg-[#111] border border-[#444] text-xs uppercase flex items-center gap-2 hover:bg-[#222] transition"
            >
              <FileKey className="w-4 h-4" /> Inject Tamper
            </button>
        </div>

        {refinementProven !== null && (
          <div className="mb-6 p-4 rounded bg-[#1A1A1A] border border-fuchsia-500/30 font-mono">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm uppercase text-fuchsia-400 flex items-center gap-2"><Cpu className="w-4 h-4" /> Mechanized Refinement Checker</h3>
              <button onClick={() => setRefinementProven(null)} className="text-xs text-gray-400 hover:text-white">Dismiss</button>
            </div>
            <p className="text-xs text-gray-300 mb-3 leading-relaxed">
              Checked formal equivalence between the concrete VM implementation and the pure abstract Specification trace. All step invariants are mathematically preserved.
            </p>
            <div className="bg-black p-3 rounded border border-[#333]">
               <div className="flex justify-between text-xs mb-2">
                 <span className="text-gray-500">Refinement Claim (VM ⊨ Spec):</span>
                 <span className={refinementProven ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
                   {refinementProven ? "PROVEN VALID" : "FALSIFIED"}
                   {refinementProven && <CheckCircle2 className="inline w-3 h-3 ml-1"/>}
                 </span>
               </div>
            </div>
          </div>
        )}

        {systemVerification && (
          <div className="mb-6 p-4 rounded bg-[#1A1A1A] border border-blue-500/30 font-mono">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm uppercase text-blue-400 flex items-center gap-2"><Cpu className="w-4 h-4" /> State Machine Replayed</h3>
              <button onClick={() => setSystemVerification(null)} className="text-xs text-gray-400 hover:text-white">Dismiss</button>
            </div>
            <p className="text-xs text-gray-300 mb-3 leading-relaxed">
              The system successfully re-evaluated every operation from genesis using the deterministic Event VM.
              If the backend were deleted right now, this state root is all that is required to prove exact equivalence.
            </p>
            <div className="bg-black p-3 rounded border border-[#333]">
               <div className="flex justify-between text-xs mb-2">
                 <span className="text-gray-500">Chain Audit Integrity:</span>
                 <span className="text-emerald-400 font-bold">VALID {systemVerification.chainValid && <CheckCircle2 className="inline w-3 h-3"/>}</span>
               </div>
               <div className="flex justify-between text-xs">
                 <span className="text-gray-500">Derived State Root Hash:</span>
                 <span className="text-blue-300 ml-4 max-w-[200px] truncate" title={systemVerification.stateRoot}>{systemVerification.stateRoot}</span>
               </div>
            </div>
          </div>
        )}

        {isScannerOpen && (
          <div className="mb-6 p-4 rounded bg-[#0A0A0A] border border-[#333]">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm uppercase text-gray-400">Scan Required (Paste Receipt JSON)</h3>
              <button onClick={() => setIsScannerOpen(false)} className="text-xs text-red-400 hover:underline">Close</button>
            </div>
            <div className="max-w-lg mx-auto">
              <textarea 
                className="w-full h-32 bg-black border border-[#444] text-xs text-purple-400 font-mono p-3 rounded custom-scrollbar focus:border-blue-500 transition-colors"
                placeholder='Paste raw JSON receipt here...'
                onChange={(e) => handleScan(e.target.value)}
              />
            </div>
          </div>
        )}

        {scannedResult && (
          <div className="mb-6 p-4 rounded bg-[#1A1A1A] border border-blue-500/30">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm uppercase text-blue-400 flex items-center gap-2"><QrCode className="w-4 h-4" /> Scanned Receipt Verified</h3>
              <button onClick={() => setScannedResult(null)} className="text-xs text-gray-500 hover:text-gray-300">Dismiss</button>
            </div>
            <div className="flex items-start gap-4">
               {scannedResult.verification.valid ? <BadgeCheck className="w-8 h-8 text-emerald-500 shrink-0" /> : <ShieldAlert className="w-8 h-8 text-red-500 shrink-0" />}
               <div className="text-xs space-y-1">
                 <div className="text-gray-400">ID: <span className="text-white">{scannedResult.receipt.receiptId}</span></div>
                 <div className="text-gray-400">Status: <span className={scannedResult.verification.valid ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>{scannedResult.verification.reason}</span></div>
               </div>
            </div>
          </div>
        )}

        {bulkResult && (
          <div className="mb-6 space-y-4">
            <div className="flex justify-between items-center bg-[#111] p-3 rounded border border-[#333]">
              <h3 className="text-sm font-bold uppercase text-white">Trust Chain Cryptographic Audit</h3>
              <button onClick={() => setBulkResult(null)} className="text-xs text-gray-400 hover:text-white transition">Close Report</button>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-[#1A1A1A] border border-[#333] p-4 rounded text-center">
                 <div className="text-3xl font-bold text-white">{bulkResult.total}</div>
                 <div className="text-[10px] uppercase text-gray-500 mt-1">Total Receipts</div>
              </div>
              <div className="bg-emerald-500/5 border border-emerald-500/20 p-4 rounded text-center">
                 <div className="text-3xl font-bold text-emerald-400">{bulkResult.valid}</div>
                 <div className="text-[10px] uppercase text-emerald-500/70 mt-1">Authentic</div>
              </div>
              <div className={cn("border p-4 rounded text-center", bulkResult.invalid > 0 ? "bg-red-500/5 border-red-500/20" : "bg-[#1A1A1A] border-[#333]")}>
                 <div className={cn("text-3xl font-bold", bulkResult.invalid > 0 ? "text-red-400" : "text-gray-500")}>{bulkResult.invalid}</div>
                 <div className={cn("text-[10px] uppercase mt-1", bulkResult.invalid > 0 ? "text-red-500/70" : "text-gray-500")}>Tampered</div>
              </div>
            </div>

            <div className="bg-[#1A1A1A] border border-[#333] rounded overflow-hidden mt-4">
              <div className="px-4 py-2 border-b border-[#333] bg-[#0A0A0A] flex justify-between items-center text-xs text-gray-400 font-bold uppercase">
                <span>Merkle Tree Visualizer (Batch Signature Generation)</span>
              </div>
              <div className="p-4 space-y-4 font-mono text-xs">
                <div className="flex flex-col items-center">
                  <div className="bg-purple-500/10 border border-purple-500/30 text-purple-400 p-3 rounded break-all max-w-full text-center shadow-lg">
                    <span className="text-[10px] uppercase text-gray-500 block mb-1">Final Collapsed Root Hash</span>
                    {bulkResult.merkleRoot}
                  </div>
                  
                  {bulkResult.entries.length > 0 && (
                     <>
                        <div className="w-px h-6 bg-[#444]"></div>
                        <div className="w-full max-w-2xl border-t border-[#444] relative flex justify-around pt-4">
                          {bulkResult.entries.slice(0, 4).map((entry, idx) => (
                             <div key={idx} className="flex flex-col items-center">
                               <div className="absolute -top-[1px] w-px h-4 bg-[#444] -mt-4"></div>
                               <div className="bg-[#222] border border-[#444] text-blue-400 p-2 rounded text-[10px] truncate max-w-[80px] w-full text-center shadow-lg">
                                 {entry.receiptId.split('-')[0]}
                               </div>
                               <div className="text-[8px] text-gray-500 mt-1 uppercase">Leaf Node</div>
                             </div>
                          ))}
                          {bulkResult.entries.length > 4 && (
                             <div className="flex flex-col items-center">
                               <div className="absolute -top-[1px] w-px h-4 bg-[#444] -mt-4"></div>
                               <div className="bg-[#111] border border-[#333] text-gray-500 p-2 rounded text-[10px] text-center italic shadow-lg">
                                 +{bulkResult.entries.length - 4} more
                               </div>
                             </div>
                          )}
                        </div>
                     </>
                  )}
                </div>
                <div className="text-[10px] text-gray-500 italic text-center mt-6">
                  Multiple audit entries are cryptographically collapsed into intermediate hashes in pairs, culminating in a single highly efficient root hash for global verification bounding.
                </div>
              </div>
            </div>

            <div className="bg-[#1A1A1A] border border-[#333] rounded overflow-hidden">
              <div className="px-4 py-2 border-b border-[#333] bg-[#0A0A0A] flex justify-between items-center text-xs text-gray-400 font-bold uppercase">
                <span>Receipt ID</span>
                <span>Cryptographic Proof Status</span>
              </div>
              <div className="max-h-64 overflow-y-auto custom-scrollbar">
                {bulkResult.entries.map(entry => (
                  <div key={entry.receiptId} className="px-4 py-3 border-b border-[#222] flex justify-between items-center text-sm last:border-0 hover:bg-[#222]">
                    <div className="flex flex-col">
                      <span className="text-gray-300 font-mono text-xs">{entry.receiptId}</span>
                      <span className="text-[10px] text-gray-500">{new Date(entry.timestamp).toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={cn("text-[10px] uppercase", entry.valid ? "text-emerald-500" : "text-red-500 font-bold")}>
                        {entry.reason}
                      </span>
                      {entry.valid ? <BadgeCheck className="w-4 h-4 text-emerald-500" /> : <ShieldAlert className="w-4 h-4 text-red-500" />}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Ledger view */}
          <div className="space-y-4">
            <h3 className="text-sm uppercase tracking-wider text-gray-500 mb-2">Cryptographic Receipt Chain</h3>
            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
              {receipts.map((rcpt, index) => {
                const independentVerification = verifyReceiptSignature(rcpt);
                return (
                  <div 
                    key={rcpt.receiptId}
                    onClick={() => handleVerify(rcpt)}
                    className={cn(
                      "p-3 rounded border text-sm cursor-pointer transition-colors relative",
                      selectedReceipt?.receiptId === rcpt.receiptId 
                        ? "bg-[#222] border-emerald-500/50" 
                        : "bg-[#1A1A1A] border-[#333] hover:border-gray-500"
                    )}
                  >
                    {index > 0 && (
                      <div className="absolute -top-3 left-4 text-[#444]">
                        <Link className="w-4 h-4" />
                      </div>
                    )}
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-400">ID: {rcpt.receiptId.split('-')[0]}...</span>
                        {independentVerification.valid ? (
                          <div className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded border border-emerald-400/20">
                            <BadgeCheck className="w-3 h-3" />
                            VERIFIED
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-[10px] text-red-400 bg-red-400/10 px-1.5 py-0.5 rounded border border-red-400/20">
                            <ShieldAlert className="w-3 h-3" />
                            INVALID
                          </div>
                        )}
                      </div>
                      <span className="text-[10px] bg-black/50 px-2 py-0.5 rounded text-gray-500">
                        {new Date(rcpt.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="font-mono text-xs space-y-1">
                      <div className="flex justify-between truncate">
                        <span className="text-gray-500 w-16">Req:</span>
                        <span className="text-blue-400 truncate">{rcpt.requestHash.substring(0, 24)}...</span>
                      </div>
                      <div className="flex justify-between truncate">
                        <span className="text-gray-500 w-16">Dec:</span>
                        <span className="text-amber-400 truncate">{rcpt.decisionHash.substring(0, 24)}...</span>
                      </div>
                      <div className="flex justify-between truncate">
                        <span className="text-gray-500 w-16">Prev:</span>
                        <span className="text-gray-400 truncate">{rcpt.previousReceiptHash.substring(0, 24)}...</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Verification View */}
          <div className="bg-[#0A0A0A] p-4 rounded border border-[#222]">
            <h3 className="text-sm uppercase tracking-wider text-gray-500 mb-4 flex items-center gap-2">
              <FileKey className="w-4 h-4" />
              Replay & Audit Verification
            </h3>
            
            {selectedReceipt ? (
              <div className="space-y-6">
                <div className="bg-[#1A1A1A] rounded border border-[#333] p-3 text-[10px] overflow-hidden">
                   <div className="text-gray-500 mb-2 uppercase border-b border-[#333] pb-1">Raw JSON Payload</div>
                   <pre className="text-gray-300 whitespace-pre-wrap break-all pr-2 max-h-32 overflow-y-auto custom-scrollbar">
                     {JSON.stringify(selectedReceipt, null, 2)}
                   </pre>
                </div>
                
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between border-b border-[#222] pb-1">
                     <span className="text-gray-500">Policy Version</span>
                     <span className="text-emerald-400 font-bold">{selectedReceipt.policyVersion}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#222] pb-1">
                     <span className="text-gray-500">Signature</span>
                     <span className="text-purple-400 truncate w-48 text-right">{selectedReceipt.signature}</span>
                  </div>
                </div>

                {verification && (
                  <div className={cn(
                    "p-3 rounded border flex items-start gap-3",
                    verification.valid ? "bg-emerald-500/10 border-emerald-500/30" : "bg-red-500/10 border-red-500/30"
                  )}>
                    {verification.valid ? <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" /> : <ShieldAlert className="w-5 h-5 text-red-500 shrink-0" />}
                    <div>
                      <div className={cn("text-sm font-bold uppercase", verification.valid ? "text-emerald-500" : "text-red-500")}>
                        {verification.valid ? "Signature Verified" : "Verification Failed"}
                      </div>
                      <div className="text-xs text-gray-400 mt-1">{verification.reason}</div>
                    </div>
                  </div>
                )}

                {replayResult && (
                  <div className="bg-[#1A1A1A] p-3 rounded border border-[#333]">
                    <div className="flex items-center gap-2 mb-2 text-sm text-gray-300 font-bold">
                      <History className="w-4 h-4" />
                      Deterministic Replay
                    </div>
                    <div className="space-y-1 text-[10px] text-gray-500 mt-2">
                      <div className="flex justify-between">
                         <span>State Root Consensus:</span>
                         <span className={replayResult.stateRootMatches ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
                            {replayResult.stateRootMatches ? "IDENTICAL" : "DIVERGED"}
                         </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Expected Hash:</span>
                        <span className="text-gray-400">{replayResult.expectedHash.substring(0,20)}...</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Actual Hash:</span>
                        <span className="text-gray-400">{replayResult.actualHash.substring(0,20)}...</span>
                      </div>
                      <div className="mt-2 pt-2 border-t border-[#333] flex justify-between font-bold text-xs">
                        <span>Replay Match:</span>
                        <span className={replayResult.matches ? "text-emerald-500" : "text-red-500"}>
                          {replayResult.matches ? "TRUE" : "FALSE"}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {verification?.valid && selectedReceipt && (
                  <div className="bg-white p-4 rounded border border-gray-200 mt-4 flex flex-col items-center justify-center space-y-3">
                    <div className="flex items-center gap-2 text-gray-800 font-bold text-sm w-full">
                      <QrCode className="w-4 h-4" />
                      Portable Verification Core
                    </div>
                    <QRCodeSVG 
                      value={JSON.stringify(selectedReceipt)} 
                      size={140}
                      bgColor={"#ffffff"}
                      fgColor={"#000000"}
                      level={"L"}
                      className="border-4 border-white"
                    />
                    <div className="text-[10px] text-gray-500 text-center px-4">
                      Scan to independently verify the Ed25519 signature payload in any independent environment.
                    </div>
                  </div>
                )}
                
                {selectedReceipt && (
                  <div className="flex gap-2 pt-2 border-t border-[#333]">
                    <button 
                      onClick={() => handleExportCourtCaseProof(selectedReceipt)}
                      className="flex-1 px-3 py-2 bg-[#222] border border-[#444] text-xs uppercase hover:bg-[#333] transition rounded flex justify-center items-center gap-2"
                    >
                      <FileText className="w-4 h-4 text-emerald-400" /> Court Evidence (PDF)
                    </button>
                    <button 
                      onClick={() => {
                        const blob = new Blob([JSON.stringify(selectedReceipt, null, 2)], { type: "application/json" });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `SWI-Proof-${selectedReceipt.receiptId}.json`;
                        a.click();
                      }}
                      className="flex-1 px-3 py-2 bg-[#222] border border-[#444] text-xs uppercase hover:bg-[#333] transition rounded flex justify-center items-center gap-2"
                    >
                      <Download className="w-4 h-4 text-blue-400" /> JSON Receipt Payload
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-600 text-sm italic">
                Select a receipt from the ledger to verify
              </div>
            )}
          </div>
        </div>
      </div>
      
      <FSK2Debugger />
    </div>
  );
}

