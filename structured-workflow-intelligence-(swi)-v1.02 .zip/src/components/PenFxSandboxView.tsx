import React, { useState, useEffect } from "react";
import {
  Skull,
  ShieldAlert,
  Terminal,
  Activity,
  AlertTriangle,
  ServerCrash,
  Fingerprint,
  Zap,
  Lock,
  Loader2,
  ShieldCheck,
  BugPlay,
  Server
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

type AttackVector = 
  | "GLYPH_POISONING"
  | "HASH_COLLISION"
  | "REPLAY_ATTACK"
  | "SIGNATURE_STRIP"
  | "L2_STATE_OVERFLOW";

interface AttackTarget {
  id: AttackVector;
  name: string;
  description: string;
  difficulty: "LOW" | "MED" | "HIGH";
  swiResponse: string;
}

const ATTACK_VECTORS: AttackTarget[] = [
  {
    id: "GLYPH_POISONING",
    name: "OCR Glyph Poisoning",
    description: "Inject invisible characters and swap kerning to spoof visually identical PDF text and bypass layout hashes.",
    difficulty: "MED",
    swiResponse: "Layout Fingerprinter detected micro-perturbation anomaly. Strict rejection."
  },
  {
    id: "SIGNATURE_STRIP",
    name: "Signature Stripping",
    description: "Remove the Ed25519 signature from the metadata and attempt to forward document as untrusted.",
    difficulty: "LOW",
    swiResponse: "Policy Engine Halt: Missing mandatory cryptographic provenance. Quarantined."
  },
  {
    id: "HASH_COLLISION",
    name: "Simulated Hash Collision",
    description: "Submit a modified document claiming the identical SHA-256 hash as a known-good ledger entry.",
    difficulty: "HIGH",
    swiResponse: "Cryptographic Verifier rejected payload. Byte-level mismatch against ledger canonical extract."
  },
  {
    id: "REPLAY_ATTACK",
    name: "Ledger Replay Attack",
    description: "Resubmit an old, valid provenance manifest attached to a newly generated rogue document.",
    difficulty: "HIGH",
    swiResponse: "Provenance Graph Engine detected orphaned lineage. Cross-node reconciliation failed."
  },
  {
    id: "L2_STATE_OVERFLOW",
    name: "Layer 2 State Overflow",
    description: "Spam the governance engine with high-volume garbage tx to overflow the L2 Beta weight buffers.",
    difficulty: "MED",
    swiResponse: "L2 Auto-Tuner engaged. Sandbox operations throttled. Persistence paused. Node isolated."
  }
];

export default function PenFxSandboxView() {
  const [selectedVector, setSelectedVector] = useState<AttackVector | null>(null);
  const [attackStatus, setAttackStatus] = useState<"IDLE" | "ARMING" | "LAUNCHED" | "DETECTED" | "DEFENDED">("IDLE");
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);

  const addLog = (msg: string) => {
    setTerminalLogs(prev => [...prev.slice(-15), `[${new Date().toISOString().split('T')[1].substring(0, 8)}] ${msg}`]);
  };

  useEffect(() => {
    if (attackStatus === "IDLE") {
      setTerminalLogs(["PEN_FX (v2.0) INITIALIZED.", "AWAITING ATTACK VECTOR SELECTION..."]);
    }
  }, [attackStatus]);

  const handleLaunch = () => {
    if (!selectedVector) return;
    
    setAttackStatus("ARMING");
    addLog(`ARMING VECTOR: ${selectedVector}`);
    
    setTimeout(() => {
      setAttackStatus("LAUNCHED");
      addLog(`PAYLOAD DEPLOYED. TARGETING SWI INGRESS PORT...`);
      
      setTimeout(() => {
        setAttackStatus("DETECTED");
        addLog(`WARNING: SWI ENGINE SENSOR TRIGGERED.`);
        
        setTimeout(() => {
          setAttackStatus("DEFENDED");
          const vectorDef = ATTACK_VECTORS.find(v => v.id === selectedVector);
          addLog(`SWI ACTION: ${vectorDef?.swiResponse}`);
          addLog(`ATTACK NEUTRALIZED. CONNECTION DROPPED.`);
        }, 2000);
      }, 1500);
    }, 1500);
  };

  const getDifficultyColor = (diff: string) => {
    if (diff === "LOW") return "text-emerald-400 border-emerald-400";
    if (diff === "MED") return "text-amber-400 border-amber-400";
    return "text-red-500 border-red-500";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#0a0a0a] text-red-500 p-6 border border-red-500/20 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/10 blur-[100px] pointer-events-none"></div>
         
         <div className="absolute inset-0 bg-[url('https://transparenttextures.com/patterns/cubes.png')] opacity-5"></div>

         <div className="space-y-3 relative z-10 w-full flex justify-between items-start">
            <div className="space-y-2">
               <div className="flex items-center gap-3">
                  <Skull className="w-5 h-5 text-red-500 animate-pulse" />
                  <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
                     PEN_FX / Adversarial Sandbox
                  </h2>
               </div>
               <p className="text-[10px] font-mono opacity-80 max-w-2xl text-red-200/70 border-l-2 border-red-500/50 pl-3">
                  Red Team testing environment. Launch simulated adversarial payloads against the SWI engine to verify cryptographic resilience, ledger reconciliation, and tamper-evident defenses.
               </p>
            </div>
            
            <div className="flex gap-2">
               <button
                  onClick={() => {
                    setSelectedVector(null);
                    setAttackStatus("IDLE");
                  }}
                  disabled={attackStatus === "IDLE"}
                  className="px-4 py-2 uppercase font-bold text-[9px] transition-all border bg-gray-900 border-gray-700 text-gray-500 hover:text-gray-300 disabled:opacity-50"
               >
                  Reset Framework
               </button>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
         {/* Vectors */}
         <div className="lg:col-span-4 space-y-4">
            <h3 className="text-[11px] font-bold text-red-500/80 uppercase tracking-widest flex items-center gap-2 border-b border-red-500/20 pb-2">
               <BugPlay className="w-4 h-4" /> Attack Vectors
            </h3>
            
            <div className="space-y-2">
              {ATTACK_VECTORS.map(vector => (
                 <div 
                   key={vector.id}
                   onClick={() => attackStatus === "IDLE" && setSelectedVector(vector.id)}
                   className={cn(
                     "p-3 border text-left transition-all cursor-pointer",
                     selectedVector === vector.id ? "bg-red-500/10 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]" : "bg-black border-white/5 hover:border-red-500/30",
                     attackStatus !== "IDLE" && selectedVector !== vector.id && "opacity-30 cursor-not-allowed",
                     attackStatus !== "IDLE" && selectedVector === vector.id && "animate-pulse"
                   )}
                 >
                    <div className="flex justify-between items-center mb-1">
                      <div className={cn("text-[10px] font-bold uppercase", selectedVector === vector.id ? "text-red-400" : "text-white/70")}>{vector.name}</div>
                      <div className={cn("text-[8px] font-mono px-1.5 py-0.5 border", getDifficultyColor(vector.difficulty))}>{vector.difficulty}</div>
                    </div>
                    <div className="text-[9px] font-mono text-white/40">{vector.description}</div>
                 </div>
              ))}
            </div>
            
            <button
               onClick={handleLaunch}
               disabled={!selectedVector || attackStatus !== "IDLE"}
               className="w-full mt-4 py-3 bg-red-600 hover:bg-red-500 text-white font-black uppercase text-[11px] tracking-widest disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
               Execute Payload
            </button>
         </div>

         {/* Visualizer & Terminal */}
         <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* Visualizer */}
            <div className="h-64 border border-white/10 bg-black p-4 relative overflow-hidden flex items-center justify-center">
               <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-red-500/5 via-black to-black"></div>
               
               {/* Attacker */}
               <div className="absolute left-8 flex flex-col items-center">
                 <div className={cn(
                   "w-16 h-16 flex items-center justify-center border", 
                   attackStatus === "IDLE" ? "border-gray-700 bg-gray-900" : "border-red-500 bg-red-500/20 shadow-[0_0_30px_rgba(239,68,68,0.5)]"
                 )}>
                    <Skull className={cn("w-8 h-8", attackStatus !== "IDLE" && "text-red-500")} />
                 </div>
                 <div className="text-[10px] font-mono mt-2 text-white/50">RED TEAM</div>
               </div>

               {/* Stream */}
               <div className="flex-1 max-w-[200px] h-2 bg-gray-900 mx-auto relative overflow-hidden border border-white/5">
                 {attackStatus === "LAUNCHED" && (
                   <div className="absolute inset-y-0 left-0 bg-red-500 w-1/3 animate-[slide_1s_linear_infinite]"></div>
                 )}
                 {attackStatus === "DEFENDED" && (
                   <div className="absolute inset-y-0 left-1/2 w-1 h-full bg-red-500 rotate-45 transform origin-center shadow-[0_0_10px_red]"></div>
                 )}
               </div>

               {/* Target SWI */}
               <div className="absolute right-8 flex flex-col items-center">
                 <div className={cn(
                   "w-16 h-16 flex items-center justify-center border transition-all duration-300", 
                   attackStatus === "DETECTED" ? "border-amber-500 bg-amber-500/20 scale-110" : 
                   attackStatus === "DEFENDED" ? "border-emerald-500 bg-emerald-500/20" : 
                   "border-indigo-500 bg-indigo-500/10"
                 )}>
                    {attackStatus === "DEFENDED" ? <ShieldCheck className="w-8 h-8 text-emerald-500" /> : <Server className="w-8 h-8 text-indigo-400" />}
                 </div>
                 <div className="text-[10px] font-mono mt-2 text-white/50">SWI KERNEL</div>
               </div>
               
            </div>

            {/* Terminal */}
            <div className="flex-1 bg-black border border-white/5 font-mono text-[10px] p-4 h-48 overflow-y-auto flex flex-col justify-end custom-scrollbar">
               <div className="space-y-1">
                 {terminalLogs.map((log, i) => (
                    <div key={i} className={cn(
                      "flex gap-3",
                      log.includes("SWI ACTION") || log.includes("DEFENDED") ? "text-emerald-400 font-bold" :
                      log.includes("DETECTED") || log.includes("WARNING") ? "text-amber-400" :
                      log.includes("PAYLOAD") || log.includes("ARMING") ? "text-red-400" :
                      "text-gray-500"
                    )}>
                      <span className="opacity-30">❯</span>
                      <span>{log}</span>
                    </div>
                 ))}
                 {attackStatus === "ARMING" && <Loader2 className="w-3 h-3 text-red-500 animate-spin mt-2" />}
                 {attackStatus === "LAUNCHED" && <Loader2 className="w-3 h-3 text-red-500 animate-spin mt-2" />}
               </div>
            </div>

         </div>
      </div>

     {attackStatus === "DEFENDED" && (
         <div className="bg-[#141414] p-6 border border-emerald-500/30 mt-6 flex justify-center animate-in slide-in-from-bottom-2 duration-500">
         <ProofArtifacts
            id="pen-fx-log"
            title="SWI Incident Repulsion Log"
            data={{
               incident_id: "SWI-SEC-" + Math.floor(Math.random() * 10000),
               vector: selectedVector || "UNKNOWN",
               engine_response: "THREAT_NEUTRALIZED",
               system_integrity: "100% SECURE"
            }}
            variant="always-dark"
         />
         </div>
      )}
    </div>
  );
}
