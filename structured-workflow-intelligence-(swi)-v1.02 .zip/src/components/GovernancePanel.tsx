// src/components/GovernancePanel.tsx
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Gavel, History, CheckCircle2, AlertTriangle, ArrowUpCircle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import TruthMatrixView from './TruthMatrixView';

interface ProtocolHistory {
  version: string;
  status: string;
  deployedAt: number;
}

export default function GovernancePanel() {
  const [history, setHistory] = useState<ProtocolHistory[]>([]);
  const [upgrading, setUpgrading] = useState(false);

  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/v3/protocol/history');
      const data = await res.json();
      setHistory(data);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const proposeUpgrade = async () => {
    setUpgrading(true);
    try {
      await fetch('/api/v3/protocol/upgrade', { method: 'POST' });
      await fetchHistory();
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setTimeout(() => setUpgrading(false), 1500);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white/5 border border-white/10 rounded-3xl p-8 flex justify-between items-center">
        <div className="flex items-center gap-6">
          <div className="w-16 h-16 rounded-2xl bg-purple-500/10 flex items-center justify-center border border-purple-500/20">
            <Gavel className="w-8 h-8 text-purple-500" />
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-black text-white uppercase tracking-tighter italic">Autonomous Protocol Governance</h2>
            <p className="text-xs text-white/40 max-w-md">
              The SWI kernel self-evolves through cryptographic governance votes. 
              Active protocol version: <span className="text-white font-mono">{history[0]?.version || 'v1.0'}</span>
            </p>
          </div>
        </div>
        <button 
          onClick={proposeUpgrade}
          disabled={upgrading}
          className="group px-6 py-4 bg-purple-600 hover:bg-purple-700 text-white rounded-2xl flex items-center gap-3 transition-all active:scale-95 disabled:opacity-50"
        >
          <ArrowUpCircle className={cn("w-5 h-5", upgrading && "animate-bounce")} />
          <div className="text-left">
            <span className="block text-[10px] font-black uppercase tracking-widest leading-none">Propose Evolution</span>
            <span className="text-[8px] opacity-60 uppercase font-mono">Bypass Quorum</span>
          </div>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <TruthMatrixView />
        <div className="bg-black/20 rounded-3xl p-6 border border-white/5 space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <History className="w-4 h-4 text-white/40" />
            <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Evolutionary Ledger</h3>
          </div>
          <div className="space-y-3">
             {history.map((p) => (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={p.version} 
                  className={cn(
                    "p-4 rounded-2xl border flex justify-between items-center",
                    p.status === 'ACTIVE' ? "bg-purple-500/10 border-purple-500/30" : "bg-white/5 border-white/5 opacity-60"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-8 h-8 rounded-lg flex items-center justify-center",
                      p.status === 'ACTIVE' ? "bg-purple-500/20" : "bg-white/10"
                    )}>
                      <span className="text-[10px] font-black text-white">{p.version}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] font-bold text-white uppercase">{p.status === 'ACTIVE' ? 'Primary Enclave Proto' : 'Legacy Branch'}</span>
                      <span className="text-[8px] text-white/40 font-mono italic">Deployed {new Date(p.deployedAt).toLocaleString()}</span>
                    </div>
                  </div>
                  {p.status === 'ACTIVE' ? (
                    <CheckCircle2 className="w-5 h-5 text-purple-500" />
                  ) : (
                    <div className="px-2 py-1 bg-white/5 rounded text-[8px] text-white/40 font-bold uppercase tracking-widest">Archived</div>
                  )}
                </motion.div>
             ))}
          </div>
        </div>

        <div className="bg-black/20 rounded-3xl p-6 border border-white/5 space-y-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-yellow-500/60" />
            <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Protocol Simulation Matrix</h3>
          </div>
          
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-white tracking-widest uppercase">Adversarial Resilience</span>
                <span className="text-[10px] font-mono text-purple-400">99.4% Sigma</span>
              </div>
              <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <div className="h-full w-[94%] bg-purple-500" />
              </div>
            </div>

            <div className="p-4 bg-yellow-500/5 border border-yellow-500/20 rounded-2xl flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5" />
              <div className="space-y-1">
                <span className="text-[9px] font-bold text-yellow-500 uppercase tracking-widest">Governor Note</span>
                <p className="text-[10px] text-yellow-500/60 leading-relaxed italic">
                  Protocols are currently operating in "Autonomous Override" mode. Manual verification requirement has been suspended for the duration of the stress test.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-4">
               <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-center">
                 <span className="block text-lg font-black text-white italic tracking-tighter">0.02ms</span>
                 <span className="text-[8px] text-white/40 uppercase tracking-widest">Contract Overhead</span>
               </div>
               <div className="p-3 bg-white/5 border border-white/5 rounded-xl text-center">
                 <span className="block text-lg font-black text-white italic tracking-tighter">100k+</span>
                 <span className="text-[8px] text-white/40 uppercase tracking-widest">Zod Val/Sec</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
