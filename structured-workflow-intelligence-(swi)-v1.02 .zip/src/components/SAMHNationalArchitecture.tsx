import React, { useState } from 'react';
import { cn } from '../lib/utils';
import { 
  Users, School, Activity, MessageSquare, Map, 
  LineChart, Database, AlertCircle, BookOpen, 
  Globe, Layers, Brain, LayoutTemplate, 
  ArrowRight, ShieldCheck, Server
} from 'lucide-react';
import { motion } from 'framer-motion';

interface Props {
  theme: 'light' | 'dark';
}

export function SAMHNationalArchitecture({ theme }: Props) {
  const [activeLayer, setActiveLayer] = useState<number | null>(null);

  const architectureLayers = [
    {
      group: "Service Delivery Layer",
      groupColor: "text-blue-400 font-bold uppercase tracking-widest text-xs",
      bgColor: "bg-blue-500/10 border-blue-500/20",
      description: "Direct interfaces with populations, schools, clinics, and crisis counselors.",
      items: [
        {
          id: 1,
          title: "1. Core Population & Identity Layer",
          icon: <Users className="w-5 h-5 text-blue-400" />,
          features: ["Participant Registration System", "National Beneficiary Database", "Digital identity linkage (where permitted)"]
        },
        {
          id: 2,
          title: "2. Education & Institutional Integration",
          icon: <School className="w-5 h-5 text-blue-400" />,
          features: ["School Integration APIs", "University & TVET onboarding", "Attendance + screening sync"]
        },
        {
          id: 3,
          title: "3. Health System Integration",
          icon: <Activity className="w-5 h-5 text-blue-400" />,
          features: ["Clinic / Health Integration APIs", "Referral exchange system", "Electronic case note interoperability"]
        },
        {
          id: 4,
          title: "4. Communication & Engagement",
          icon: <MessageSquare className="w-5 h-5 text-blue-400" />,
          features: ["SMS / WhatsApp gateway", "USSD support for remote users", "Automated nudging & follow-up"]
        },
        {
          id: 8,
          title: "8. Crisis & Emergency Response",
          icon: <AlertCircle className="w-5 h-5 text-red-400" />,
          features: ["Real-Time Crisis Response Center", "24/7 escalation routing", "Automated high-risk triggers", "Mobile rapid response tools"]
        }
      ]
    },
    {
      group: "Intelligence Layer",
      groupColor: "text-emerald-400 font-bold uppercase tracking-widest text-xs",
      bgColor: "bg-emerald-500/10 border-emerald-500/20",
      description: "Analytical engines, machine learning models, and real-time operational observatories.",
      items: [
        {
          id: 7,
          title: "7. Data & AI Infrastructure Layer",
          icon: <Database className="w-5 h-5 text-emerald-400" />,
          features: ["Data Warehouse / Analytics Lakehouse", "Unified cross-sector data model", "AI Risk Prediction Module", "Longitudinal data tracking"]
        },
        {
          id: 5,
          title: "5. Geo-Intelligence & Mapping",
          icon: <Map className="w-5 h-5 text-emerald-400" />,
          features: ["GIS District Heatmaps", "Community vulnerability indexing", "Service accessibility mapping"]
        },
        {
          id: 6,
          title: "6. National Intelligence & Monitoring",
          icon: <LineChart className="w-5 h-5 text-emerald-400" />,
          features: ["National Mental-Health Observatory", "Real-time population dashboards", "Policy insight engine", "Trend & early warning detection"]
        },
        {
          id: 9,
          title: "9. Research & Knowledge Generation",
          icon: <BookOpen className="w-5 h-5 text-emerald-400" />,
          features: ["Longitudinal Studies Module", "Ethical data access for NGOs", "Cohort tracking system", "Publication-ready analytics"]
        }
      ]
    },
    {
      group: "Governance Layer",
      groupColor: "text-purple-400 font-bold uppercase tracking-widest text-xs",
      bgColor: "bg-purple-500/10 border-purple-500/20",
      description: "Standardized protocols, DPI interoperability and cross-border API gateways.",
      items: [
        {
          id: 10,
          title: "10. National Interoperability Layer (DPI)",
          icon: <Globe className="w-5 h-5 text-purple-400" />,
          features: ["API gateway for all ministries", "Standards engine (data formats, consent)", "Cross-border NGO/UN compatibility", "Ledger verification nodes"]
        }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 font-mono pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-[#333] pb-6 gap-6">
        <div>
          <h2 className="text-3xl font-bold uppercase tracking-tighter flex items-center gap-2">
            <LayoutTemplate className="w-8 h-8 text-indigo-500" />
            SAMH National Architecture
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-widest mt-2 max-w-xl leading-relaxed">
            A Multi-sector Digital Public Health Operating System. Replacing legacy fragmented platforms with a comprehensive National Mental Health Intelligence & Response Infrastructure designed for the 2026+ ecosystem.
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs bg-[#111] p-3 rounded border border-[#333] shrink-0">
          <Brain className="w-5 h-5 text-emerald-500" />
          <div className="flex flex-col">
            <span className="font-bold uppercase tracking-widest text-gray-300">Target Scale: National</span>
            <span className="text-[10px] text-gray-500">Cross-Ministry Intelligence Engine</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {architectureLayers.map((layer, groupIdx) => (
          <div key={layer.group} className="flex flex-col space-y-4">
            <div className={cn("p-4 rounded-lg border", layer.bgColor)}>
              <h3 className={layer.groupColor}>{layer.group}</h3>
              <p className="text-[10px] text-gray-400 mt-2 min-h-[30px]">{layer.description}</p>
            </div>
            
            <div className="flex-1 space-y-4 relative">
              {layer.items.map((item, idx) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: (groupIdx * 0.1) + (idx * 0.1) }}
                  key={item.id}
                  onMouseEnter={() => setActiveLayer(item.id)}
                  onMouseLeave={() => setActiveLayer(null)}
                  className={cn(
                    "p-5 rounded-xl border transition-all duration-300 cursor-crosshair",
                    activeLayer === item.id 
                      ? "bg-[#1a1a1a] border-gray-500 shadow-[0_0_15px_rgba(255,255,255,0.05)] transform scale-[1.02]" 
                      : "bg-[#0A0A0A] border-[#222]"
                  )}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 bg-[#111] rounded border border-[#333]">
                      {item.icon}
                    </div>
                    <h4 className="text-xs font-bold text-gray-200 uppercase tracking-widest leading-snug">{item.title}</h4>
                  </div>
                  <ul className="space-y-2">
                    {item.features.map(f => (
                      <li key={f} className="flex items-start gap-2 text-[10px] text-gray-400 font-mono tracking-wide">
                        <ArrowRight className="w-3 h-3 shrink-0 text-gray-600 mt-0.5" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  {activeLayer === item.id && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 pt-3 border-t border-[#333] flex justify-between items-center text-[9px] uppercase font-bold text-emerald-500">
                      <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> System Live</span>
                      <span className="flex items-center gap-1"><Server className="w-3 h-3" /> Sync Active</span>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <div className="bg-[#111] border border-[#333] p-6 rounded-xl mt-8">
         <h4 className="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">
           <Layers className="w-5 h-5 text-indigo-400" /> Operational Context Check
         </h4>
         <p className="text-xs text-gray-300 leading-relaxed max-w-4xl">
           This represents the shift from isolated program logic (e.g., funding tracking, manual school lists) into a <strong>Digital Public Infrastructure (DPI)</strong> mindset. 
           The Truth Kernel (FSK-v2) now governs policy flows not just internally, but as boundaries spanning across the Health System Layer to the Intelligence Layer. Data from the Community Referral Network feeds the Lakehouse, while DPI protocols enforce the privacy boundaries.
         </p>
      </div>
    </div>
  );
}
