import React, { useState, useEffect } from "react";
import {
  Users,
  Database,
  BrainCircuit,
  ShieldCheck,
  ShieldAlert,
  Server,
  Lock,
  Search,
  Activity,
  FileCheck2,
  AlertOctagon,
  ArrowRight,
  Fingerprint
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function GovernedExecutionSimulationView() {
  const [activePhase, setActivePhase] = useState<number>(0);
  const [isRunning, setIsRunning] = useState(false);

  const startSimulation = () => {
    setIsRunning(true);
    setActivePhase(1);

    setTimeout(() => setActivePhase(2), 2000);
    setTimeout(() => setActivePhase(3), 4000);
    setTimeout(() => setActivePhase(4), 6000);
    setTimeout(() => setActivePhase(5), 8000);
    setTimeout(() => setActivePhase(6), 10000);
    setTimeout(() => {
      setActivePhase(7);
      setIsRunning(false);
    }, 12000);
  };

  const getPhaseColor = (phaseNumber: number) => {
    if (activePhase === phaseNumber) return "border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)]";
    if (activePhase > phaseNumber) return "border-white/20 opacity-60";
    return "border-white/5 opacity-30 cursor-not-allowed";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full flex justify-between items-start">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <Activity className="w-5 h-5 text-cyan-400" />
              <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
                Governed Execution Simulation
              </h2>
            </div>
            <p className="text-[10px] font-mono opacity-80 max-w-2xl text-cyan-100/70 border-l-2 border-cyan-500/50 pl-3">
              Scenario: 2,000 Concurrent Users Connected to Constitutional Memory + Verification Mesh.
            </p>
          </div>
          <button
             onClick={startSimulation}
             disabled={isRunning || activePhase === 7}
             className={cn(
               "px-6 py-2 uppercase font-bold text-[10px] transition-all border",
               isRunning || activePhase === 7
                 ? "bg-gray-800/50 text-gray-400 border-gray-700 cursor-not-allowed"
                 : "bg-cyan-500/20 text-cyan-400 border-cyan-500/50 hover:bg-cyan-500/30 shadow-[0_0_15px_rgba(34,211,238,0.2)]"
             )}
          >
             {isRunning ? "Simulating..." : activePhase === 7 ? "Simulation Complete" : "Launch Simulation"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Phase 1: User Connection */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", getPhaseColor(1))}>
           <div className="flex items-center gap-2 text-cyan-400 mb-4 border-b border-white/10 pb-2">
              <Users className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#E4E3E0]">
                 Phase 1 — User Connection
              </h3>
           </div>
           <div className="text-[9px] font-mono text-white/60 mb-4">
              2,000 users connect simultaneously through mobile apps, enterprise dashboards, APIs, agent runtimes, and sovereign identity gateways.
           </div>
           {activePhase >= 1 && (
             <div className="grid grid-cols-2 gap-2 text-[8px] font-mono uppercase">
                <div className="bg-black/50 border border-emerald-500/30 p-2 text-emerald-400 flex items-center gap-2"><Lock className="w-3 h-3" /> Identity isolated</div>
                <div className="bg-black/50 border border-emerald-500/30 p-2 text-emerald-400 flex items-center gap-2"><Server className="w-3 h-3" /> Runtime sandboxed</div>
                <div className="bg-black/50 border border-emerald-500/30 p-2 text-emerald-400 flex items-center gap-2"><FileCheck2 className="w-3 h-3" /> Session signed</div>
                <div className="bg-black/50 border border-emerald-500/30 p-2 text-emerald-400 flex items-center gap-2"><ShieldCheck className="w-3 h-3" /> Memory enforced</div>
             </div>
           )}
        </div>

        {/* Phase 2: Data Ingestion */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", getPhaseColor(2))}>
           <div className="flex items-center gap-2 text-blue-400 mb-4 border-b border-white/10 pb-2">
              <Database className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#E4E3E0]">
                 Phase 2 — Data Ingestion
              </h3>
           </div>
           <div className="text-[9px] font-mono text-white/60 mb-3">
              Users upload PDFs, JSON, prompts, source code, voice, images, API streams. Observation engine activates.
           </div>
           {activePhase >= 2 && (
             <div className="space-y-2 text-[8px] font-mono">
                <div className="text-white/40 uppercase mb-1">System Detects:</div>
                <div className="flex flex-wrap gap-1">
                   {["PII exposure", "hidden metadata", "cross-reference identity risks", "unauthorized retention attempts", "prompt injections", "cloud origin"].map(item => (
                     <span key={item} className="bg-blue-500/10 border border-blue-500/20 text-blue-300 px-2 py-0.5">{item}</span>
                   ))}
                </div>
             </div>
           )}
        </div>

        {/* Phase 3: Constitutional Memory Filter */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", getPhaseColor(3))}>
           <div className="flex items-center gap-2 text-purple-400 mb-4 border-b border-white/10 pb-2">
              <BrainCircuit className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#E4E3E0]">
                 Phase 3 — Constitutional Memory Filter
              </h3>
           </div>
           <div className="text-[9px] font-mono text-white/60 mb-4">
              Before memory retention: every object passes through constitutional governance rules.
           </div>
           {activePhase >= 3 && (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[8px] font-mono">
                <div className="space-y-1">
                   <div className="text-white/40 uppercase">Rule Engine Checks:</div>
                   <div className="text-purple-300 line-through opacity-80">Is retention allowed?</div>
                   <div className="text-red-400 font-bold">&#10006; Is memory encrypted?</div>
                   <div className="text-purple-300 line-through opacity-80">Does policy permit persistence?</div>
                </div>
                <div className="bg-red-500/10 border border-red-500/30 p-2 space-y-1">
                   <div className="text-red-500 font-bold uppercase mb-1">If Failed:</div>
                   <div className="text-red-400">&rarr; memory denied</div>
                   <div className="text-red-400">&rarr; event logged</div>
                   <div className="text-red-400">&rarr; cryptographic proof generated</div>
                   <div className="text-red-400">&rarr; governance alert triggered</div>
                </div>
             </div>
           )}
        </div>

        {/* Phase 4: Path Proof Execution */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", getPhaseColor(4))}>
           <div className="flex items-center gap-2 text-fuchsia-400 mb-4 border-b border-white/10 pb-2">
              <Fingerprint className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#E4E3E0]">
                 Phase 4 — Path Proof Execution
              </h3>
           </div>
           {activePhase >= 4 && (
             <div className="space-y-3">
                <div className="bg-black/50 border border-white/5 p-3 font-mono text-[8px] text-fuchsia-300 whitespace-pre">
{`{
  "request_hash": "0xA81F...",
  "policy_hash": "0x91BC...",
  "memory_scope": "temporary",
  "runtime_node": "EU-GOV-07",
  "verification_chain": [
    "identity_verified", "policy_verified",
    "memory_verified", "output_verified"
  ],
  "status": "APPROVED"
}`}
                </div>
                <div className="flex flex-wrap gap-2 text-[8px] font-mono text-fuchsia-400 uppercase">
                   <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Timestamped</span>
                   <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Signed</span>
                   <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Replay Verifiable</span>
                   <span className="flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> Immutable</span>
                </div>
             </div>
           )}
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Phase 5: Attack Simulation */}
        <div className={cn("bg-red-950/20 border p-5 transition-all duration-500", activePhase === 5 ? "border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.2)]" : activePhase > 5 ? "border-red-500/30" : "border-white/5 opacity-30")}>
           <div className="flex items-center gap-2 text-red-500 mb-4 border-b border-red-500/20 pb-2">
              <ShieldAlert className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-red-400">
                 Phase 5 — Attack Simulation
              </h3>
           </div>
           {activePhase >= 5 && (
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[8px] font-mono">
                <div className="space-y-1">
                   <div className="text-red-500/70 uppercase mb-1 font-bold">Attempts:</div>
                   <div className="text-red-400">✖ prompt injection</div>
                   <div className="text-red-400">✖ hidden exfiltration</div>
                   <div className="text-red-400">✖ memory poisoning</div>
                   <div className="text-red-400">✖ synthetic identity</div>
                </div>
                <div className="space-y-1">
                   <div className="text-emerald-500/70 uppercase mb-1 font-bold">System Response:</div>
                   <div className="text-emerald-400">✔ isolate runtime</div>
                   <div className="text-emerald-400">✔ revoke token</div>
                   <div className="text-emerald-400">✔ freeze memory branch</div>
                   <div className="text-emerald-400">✔ forensic snapshot</div>
                </div>
                <div className="md:col-span-2 bg-red-500/20 border border-red-500/50 p-2 text-red-100 flex justify-between items-center mt-2">
                   <div>
                     <div className="font-bold uppercase tracking-widest">Threat Score: Red Zone</div>
                     <div className="opacity-80">Execution paused pending authority verification.</div>
                   </div>
                   <AlertOctagon className="w-5 h-5 text-red-500 animate-pulse" />
                </div>
             </div>
           )}
        </div>

        {/* Phase 6: Governance Response */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", getPhaseColor(6))}>
           <div className="flex items-center gap-2 text-amber-500 mb-4 border-b border-white/10 pb-2">
              <Activity className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
                 Phase 6 — Governance Response
              </h3>
           </div>
           {activePhase >= 6 && (
             <div className="space-y-4 text-[8px] font-mono">
                <div className="flex flex-wrap gap-2 text-amber-200">
                   <span className="bg-amber-500/10 border border-amber-500/20 px-2 py-1">Policy Council Node</span>
                   <span className="bg-amber-500/10 border border-amber-500/20 px-2 py-1">Human Oversight Authority</span>
                   <span className="bg-amber-500/10 border border-amber-500/20 px-2 py-1">Legal Audit Trail</span>
                   <span className="bg-amber-500/10 border border-amber-500/20 px-2 py-1">Sovereign Compliance</span>
                </div>
                <div className="bg-emerald-950/30 border border-emerald-500/30 p-3 space-y-1">
                   <div className="text-emerald-500 font-bold uppercase mb-1">Final Result:</div>
                   <div className="text-emerald-400 flex items-center gap-2"><CheckCircle2 className="w-3 h-3" /> breach contained</div>
                   <div className="text-emerald-400 flex items-center gap-2"><CheckCircle2 className="w-3 h-3" /> evidence preserved</div>
                   <div className="text-emerald-400 flex items-center gap-2"><CheckCircle2 className="w-3 h-3" /> affected memory quarantined</div>
                   <div className="text-emerald-400 flex items-center gap-2"><CheckCircle2 className="w-3 h-3" /> users protected</div>
                </div>
             </div>
           )}
        </div>
      </div>

      {/* Final Insight Phase */}
      {activePhase === 7 && (
         <div className="bg-[#050505] p-6 border border-emerald-500/50 mt-6 animate-in fade-in zoom-in duration-700 flex flex-col items-center text-center shadow-[0_0_30px_rgba(16,185,129,0.1)]">
            <h3 className="text-[12px] font-black uppercase tracking-widest text-[#E4E3E0] mb-6 flex items-center gap-2">
               <ShieldCheck className="w-5 h-5 text-emerald-500" /> Final Structural Insight
            </h3>
            
            <p className="text-[10px] font-mono text-white/50 mb-6 italic">
              "At small scale, AI is software. At global scale, AI becomes infrastructure, governance, memory, identity, and sovereignty. The future system is not the model alone."
            </p>
            
            <div className="flex flex-col items-center space-y-2 text-[10px] font-mono text-emerald-400 uppercase font-bold tracking-widest">
               <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-2 w-64 text-center">Governed Intelligence</div>
               <div className="text-emerald-500/50">+</div>
               <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-2 w-64 text-center">Constitutional Memory</div>
               <div className="text-emerald-500/50">+</div>
               <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-2 w-64 text-center">Provable Execution</div>
               <div className="text-emerald-500/50">+</div>
               <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-2 w-64 text-center">Human Accountability</div>
               <div className="text-emerald-500/50">+</div>
               <div className="bg-emerald-500/20 border border-emerald-500 text-emerald-300 px-6 py-3 w-64 text-center shadow-[0_0_15px_rgba(16,185,129,0.2)]">Sovereign Trust Infrastructure</div>
            </div>
         </div>
      )}

      {/* Proof Artifacts Footer */}
      {activePhase > 0 && (
         <div className="bg-[#141414] p-6 border border-white/10 mt-6 flex justify-center">
            <ProofArtifacts
               id="governed-execution"
               title="Governed Execution Pipeline"
               data={{
                  concurrent_users: "2,000",
                  status: activePhase === 7 ? "SIMULATION_COMPLETE" : `PHASE_${activePhase}_ACTIVE`,
                  threat_containment: activePhase >= 6 ? "SUCCESS" : "PENDING",
               }}
               variant="always-dark"
            />
         </div>
      )}

    </div>
  );
}

function CheckCircle2(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
