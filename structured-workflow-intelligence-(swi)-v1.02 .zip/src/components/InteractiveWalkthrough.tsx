import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft, ShieldAlert, Cpu, Fingerprint, Lock } from 'lucide-react';

const TUTORIAL_STEPS = [
  {
    title: "Welcome to SWI",
    icon: <Cpu className="w-8 h-8 text-blue-400" />,
    content: "Structured Workflow Intelligence (SWI) is a research platform demonstrating governance validation, drift monitoring, and policy-aligned decision support. This tutorial will introduce you to its core concepts.",
    position: "center"
  },
  {
    title: "1. Cryptographic Signing",
    icon: <Fingerprint className="w-8 h-8 text-emerald-400" />,
    content: "Every transaction or operation must be cryptographically signed by an identifiable actor. This ensures non-repudiation and provides a traceable lineage for every mutation in the system state.",
    position: "center"
  },
  {
    title: "2. The Fail-Safe Kernel",
    icon: <Lock className="w-8 h-8 text-fuchsia-400" />,
    content: "The FSK (Fail-Safe Kernel) acts as the ultimate gatekeeper. It intercepts operations at runtime. If a transaction lacks a cost anchor or rollback plan, the FSK immediately throws a HALT and prevents the mutation.",
    position: "center"
  },
  {
    title: "3. CEK & Drift Detection",
    icon: <ShieldAlert className="w-8 h-8 text-yellow-500" />,
    content: "The Continuous Evaluation Kernel (CEK) constantly measures system risk. By observing User Behavior, Environment Stability, and Policy Mismatches, it calculates a Drift Score. If this score exceeds a safe threshold, the system restricts access.",
    position: "center"
  },
  {
    title: "Ready to Explore",
    icon: <Cpu className="w-8 h-8 text-blue-400" />,
    content: "You're now ready to use the Interactive Simulator, view Traces, and test the God's Eye Halt. Remember: Safety doesn't happen by accident; it requires mathematical bounds. Good luck.",
    position: "center"
  }
];

export default function InteractiveWalkthrough() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  // Auto-trigger on first visit (using local storage)
  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('swi_tutorial_seen');
    if (!hasSeenTutorial) {
      setIsOpen(true);
      localStorage.setItem('swi_tutorial_seen', 'true');
    }
  }, []);

  if (!isOpen) return null;

  const step = TUTORIAL_STEPS[currentStep];

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      >
        <motion.div 
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="bg-[#111] border border-[#333] rounded-xl max-w-lg w-full overflow-hidden shadow-2xl relative"
        >
          <button 
            onClick={() => setIsOpen(false)}
            className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="p-8 pb-4">
            <div className="flex justify-center mb-6">{step.icon}</div>
            <h2 className="text-xl font-bold font-serif italic text-white text-center mb-4">{step.title}</h2>
            <p className="text-sm font-mono text-gray-300 leading-relaxed text-center min-h-[80px]">
              {step.content}
            </p>
          </div>

          <div className="p-6 bg-[#0A0A0A] border-t border-[#333] flex justify-between items-center">
             <div className="flex gap-1.5">
               {TUTORIAL_STEPS.map((_, i) => (
                 <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${i === currentStep ? 'w-6 bg-blue-500' : 'w-2 bg-[#333]'}`} />
               ))}
             </div>
             
             <div className="flex gap-3">
               <button
                 onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
                 disabled={currentStep === 0}
                 className="p-2 rounded hover:bg-[#222] disabled:opacity-30 disabled:hover:bg-transparent text-gray-400 transition-colors"
               >
                 <ChevronLeft className="w-5 h-5" />
               </button>
               {currentStep < TUTORIAL_STEPS.length - 1 ? (
                 <button
                   onClick={() => setCurrentStep(prev => Math.min(TUTORIAL_STEPS.length - 1, prev + 1))}
                   className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold font-mono uppercase tracking-widest rounded flex items-center gap-2 transition-colors"
                 >
                   Next <ChevronRight className="w-4 h-4" />
                 </button>
               ) : (
                 <button
                   onClick={() => setIsOpen(false)}
                   className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono uppercase tracking-widest rounded transition-colors"
                 >
                   Complete
                 </button>
               )}
             </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
