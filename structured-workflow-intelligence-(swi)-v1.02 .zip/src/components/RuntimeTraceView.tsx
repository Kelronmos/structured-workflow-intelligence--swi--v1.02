import React, { useEffect, useState } from "react";
import { CanonicalTrace } from "../services/RuntimeTraceService";
import { Shield, Activity, Hash, AlertTriangle, ShieldCheck, FileKey, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import SWIStreamingDebugger from "./SWIStreamingDebugger";

export const RuntimeTraceView: React.FC = () => {
  const [events, setEvents] = useState<CanonicalTrace[]>([]);
  const [chainIntegrity, setChainIntegrity] = useState<boolean>(true);

  // Poll for UI updates using the server API instead of the local class singleton
  useEffect(() => {
    const fetchTrace = async () => {
      try {
        const res = await fetch("/api/execution-context");
        if (res.ok) {
          const data = await res.json();
          setEvents(data.events.slice(-15).reverse());
          setChainIntegrity(data.chainIntegrity);
        }
      } catch (e) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch runtime trace:", e);
      }
    };
    
    fetchTrace();
    const interval = setInterval(fetchTrace, 1000);
    return () => clearInterval(interval);
  }, []);

  const exportAdmissibility = async (traceId: string) => {
    try {
      const res = await fetch(`/api/execution-context/verification/${traceId}`);
      if (!res.ok) throw new Error("Export failed");
      const data = await res.json();
      
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `admissibility_evidence_${traceId.substring(0, 8)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to export admissibility:", e);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
    <SWIStreamingDebugger socketUrl="mock" />
    <div className="w-full rounded-lg overflow-hidden border border-slate-800 bg-slate-950 font-mono text-xs text-slate-300">
      <div className="flex items-center justify-between p-4 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-indigo-400" />
          <h2 className="text-sm font-semibold text-slate-200">Runtime Cryptographic Trace</h2>
        </div>
        <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${chainIntegrity ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"}`}>
          <Hash className="w-3 h-3" />
          <span className="font-bold">{chainIntegrity ? "CHAIN VERIFIED" : "INTEGRITY COMPROMISED"}</span>
        </div>
      </div>
      
      <div className="p-4 overflow-y-auto max-h-[600px] flex flex-col gap-2">
        <AnimatePresence>
          {events.length === 0 ? (
            <div className="text-center py-8 text-slate-500">No cryptographic events recorded yet.</div>
          ) : (
            events.map((event) => (
              <motion.div 
                key={event.event_id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`p-3 rounded-md border ${event.decision === "ACCEPT" ? "border-slate-800 bg-slate-900" : "border-red-900/50 bg-red-950/20"}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-400" />
                    <span className={`font-semibold ${event.decision === "ACCEPT" ? "text-slate-200" : "text-red-400"}`}>
                      {event.decision === "ACCEPT" ? "StateTransition" : "HALT"}
                    </span>
                    <span className="text-slate-500 text-[10px]">[SwIKernel]</span>
                  </div>
                  <span className="text-[10px] text-slate-500">{"N/A"}</span>
                </div>
                
                <div className="grid grid-cols-12 gap-2 text-[10px] mt-2 font-mono break-all">
                  <div className="col-span-2 text-slate-500 text-right">EVENT ID</div>
                  <div className="col-span-10 text-slate-400">{event.event_id}</div>
                  
                  <div className="col-span-2 text-slate-500 text-right">DECISION</div>
                  <div className="col-span-10 text-slate-500 truncate">{event.decision}</div>
                  
                  <>
                    <div className="col-span-2 text-emerald-500/70 text-right">PROOF REF</div>
                    <div className="col-span-10 text-emerald-400/80">{event.proof_ref}</div>
                  </>
                  <>
                    <div className="col-span-2 text-slate-500 text-right">STATE AFTER</div>
                    <div className="col-span-10 text-slate-400">{event.state_hash_after}</div>
                  </>
                </div>
                <div className="mt-3 flex justify-end">
                  <button 
                    onClick={() => exportAdmissibility(event.event_id)}
                    className="flex items-center gap-1.5 px-3 py-1 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 text-[10px] font-bold uppercase rounded border border-indigo-500/30 transition-colors"
                  >
                    <FileKey className="w-3 h-3" />
                    Export Evidence
                  </button>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
    </div>
  );
};
