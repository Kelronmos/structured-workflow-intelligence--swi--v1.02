import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { Shield, ShieldAlert, ShieldCheck, Zap } from 'lucide-react';

interface Node {
  id: string;
  status: 'VALID' | 'INVALID' | 'QUARANTINED';
  reputation: number;
}

interface LiveGovernanceGraphProps {
  nodes: Node[];
  decision: 'APPROVED' | 'REJECTED' | 'PENDING' | 'ESCALATE' | 'REFUSE';
  strength: 'STRONG' | 'WEAK' | 'DISPUTED';
}

export default function LiveGovernanceGraph({ nodes, decision, strength }: LiveGovernanceGraphProps) {
  return (
    <div className="relative w-full h-64 border border-[#141414]/10 dark:border-[#E4E3E0]/10 bg-black/5 dark:bg-white/5 overflow-hidden">
      <div className="absolute inset-0 flex items-center justify-center">
        {/* Central Decision Node */}
        <motion.div 
          animate={{
            scale: decision !== 'PENDING' ? [1, 1.1, 1] : 1,
            borderColor: decision === 'APPROVED' ? '#22c55e' : (decision === 'REJECTED' || decision === 'REFUSE') ? '#ef4444' : decision === 'ESCALATE' ? '#f97316' : '#141414',
          }}
          transition={{ repeat: Infinity, duration: 2 }}
          className={cn(
            "w-20 h-20 rounded-full border-2 flex flex-col items-center justify-center bg-white dark:bg-[#141414] z-20 shadow-2xl transition-colors",
            decision === 'APPROVED' ? "border-green-500 shadow-green-500/20" : 
            (decision === 'REJECTED' || decision === 'REFUSE') ? "border-red-500 shadow-red-500/20" : 
            decision === 'ESCALATE' ? "border-orange-500 shadow-orange-500/20" : "border-[#141414]/20"
          )}
        >
          {decision === 'APPROVED' ? <ShieldCheck className="w-8 h-8 text-green-500" /> : 
           (decision === 'REJECTED' || decision === 'REFUSE') ? <ShieldAlert className="w-8 h-8 text-red-500" /> : 
           decision === 'ESCALATE' ? <Shield className="w-8 h-8 text-orange-500" /> :
           <Shield className="w-8 h-8 opacity-20" />}
          <span className="text-[8px] font-bold uppercase mt-1 tracking-tighter">{decision}</span>
          {strength !== 'STRONG' && decision !== 'PENDING' && (
            <span className="text-[6px] text-yellow-600 font-bold uppercase">{strength}</span>
          )}
        </motion.div>

        {/* Distributed Nodes */}
        {nodes.map((node, i) => {
          const angle = (i / nodes.length) * Math.PI * 2;
          const radius = 100;
          const x = Math.cos(angle) * radius;
          const y = Math.sin(angle) * radius;

          return (
            <div key={node.id} className="absolute transition-all duration-1000" style={{ transform: `translate(${x}px, ${y}px)` }}>
              {/* Connection Line */}
              <svg className="absolute top-0 left-0 overflow-visible pointer-events-none" style={{ transform: 'translate(0, 0)' }}>
                <motion.line
                  x1="0" y1="0"
                  x2={-x} y2={-y}
                  stroke={node.status === 'VALID' ? '#22c55e' : node.status === 'INVALID' ? '#ef4444' : '#666'}
                  strokeWidth="1"
                  strokeDasharray="4 2"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ pathLength: 1, opacity: 0.2 }}
                />
                {node.status !== 'QUARANTINED' && (
                  <motion.circle
                    r="2"
                    fill={node.status === 'VALID' ? '#22c55e' : '#ef4444'}
                    animate={{
                      cx: [0, -x],
                      cy: [0, -y],
                    }}
                    transition={{
                      repeat: Infinity,
                      duration: 2,
                      delay: i * 0.5,
                      ease: "linear"
                    }}
                  />
                )}
              </svg>

              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className={cn(
                  "w-12 h-12 rounded-full border flex flex-col items-center justify-center bg-white dark:bg-[#141414] shadow-sm relative",
                  node.status === 'VALID' ? "border-green-500/30" : 
                  node.status === 'INVALID' ? "border-red-500/30" : "border-gray-500/30 opacity-40 grayscale"
                )}
              >
                <span className="text-[6px] font-bold uppercase opacity-60">{node.id}</span>
                <span className={cn(
                  "text-[8px] font-mono",
                  node.reputation > 0.8 ? "text-green-500" : node.reputation > 0.5 ? "text-yellow-500" : "text-red-500"
                )}>
                  {node.reputation.toFixed(2)}
                </span>
                {node.status === 'QUARANTINED' && <Zap className="w-2 h-2 text-red-500 absolute -top-1 -right-1 animate-pulse" />}
              </motion.div>
            </div>
          );
        })}
      </div>

      {/* Real-time Audit Feed Overlay */}
      <div className="absolute bottom-2 left-2 right-2 flex justify-between items-end pointer-events-none">
        <div className="space-y-1">
          <div className="flex items-center gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[7px] font-bold uppercase opacity-40">Live Governance Stream</span>
          </div>
          <div className="text-[6px] font-mono opacity-20 uppercase">
            Quorum Required: {Math.ceil(nodes.length * 0.66)} nodes
          </div>
        </div>
        <div className="text-[8px] font-bold uppercase tracking-widest opacity-30 italic">
          v1.0-DCG (Distributed Causal Governance)
        </div>
      </div>
    </div>
  );
}
