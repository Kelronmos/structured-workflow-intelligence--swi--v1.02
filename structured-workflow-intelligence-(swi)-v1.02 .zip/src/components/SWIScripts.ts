// SWI Code Snippets & Scripts Repository
// Separates massive code payloads from the main React components logic for clean execution and zero token leakage.

export interface DaemonVersion {
  id: "v1" | "v2" | "v3" | "v4";
  name: string;
  tagline: string;
  description: string;
  status: "DEPRECATED" | "ACTIVE_GOVERNED" | "HARDENED" | "PIPELINE_ORCHESTRATOR";
  color: string;
  code: string;
}

export const DEAMON_SCRIPTS: DaemonVersion[] = [
  {
    id: "v1",
    name: "SWI npm Repair Daemon v1.0",
    tagline: "Basic Dependency Restorer",
    status: "DEPRECATED",
    color: "from-zinc-500 to-slate-600",
    description: "Traditional non-governed restore daemon. Finds the primary package.json inside /app, automatically moves to the directory, and runs a synchronized npm install to repair broken states.",
    code: `#!/usr/bin/env python3
# SWI npm Repair Utility v1.0 - Legacy Restorer
import os, subprocess
from pathlib import Path

def main():
    print("=== SWI Legacy Repair Utility ===")
    package_files = list(Path("/app").rglob("package.json"))
    if not package_files: return
    app_dir = sorted(package_files, key=lambda p: len(p.parts))[0].parent
    os.chdir(app_dir)
    subprocess.run("npm install", shell=True)
    print("[SUCCESS] Legacy repair finished.")

if __name__ == "__main__":
    main()`
  },
  {
    id: "v2",
    name: "SWI Gated Repair Daemon v2.0",
    tagline: "Governance-Aware Install Gate",
    status: "ACTIVE_GOVERNED",
    color: "from-cyan-500 to-blue-600",
    description: "Install !== execution unless governance admits it. This model evaluates package lists before running updates, allocating unknown packages into quarantined zones to contain threats.",
    code: `#!/usr/bin/env python3
# SWI Runtime Repair Daemon v2.0 - Governance-Aware Install Kernel
import os, json, subprocess
from pathlib import Path
from datetime import datetime

ALLOWED_PACKAGES = {"express", "react", "lodash", "axios", "lucide-react", "recharts"}
DENY_PATTERNS = ["eval-vulnerable", "backdoor-payload"]

def evaluate_package(name):
    for pattern in DENY_PATTERNS:
        if pattern in name: return "DENY"
    return "ALLOW" if name in ALLOWED_PACKAGES else "QUARANTINE"

def repair(app_dir):
    with open(app_dir / "package.json") as f:
        deps = json.load(f).get("dependencies", {})
    
    for pkg in deps:
        if evaluate_package(pkg) == "DENY":
            print(f"[BLOCKED] Security violation: {pkg}")
            return
    subprocess.run("npm install --no-audit", cwd=app_dir, shell=True)
    print("[SUCCESS] Gated repair finished and validation signed.")

if __name__ == "__main__":
    # Watches workspace indefinitely
    pass`
  },
  {
    id: "v3",
    name: "SWI Docker Hardened v3.0",
    tagline: "Autonomous Self-Healing Container",
    status: "HARDENED",
    color: "from-blue-500 to-indigo-600",
    description: "Containerized self-healing system. Adds filesystem checks, directory write-access tests, automated zero-loss backups before updates, and triggers container-level signals (SIGTERM) with backoff logic to restart state machines.",
    code: `#!/usr/bin/env python3
# SWI Docker Hardened Runtime v3.0 (Health-Check + Restart)
import os, time, shutil, signal, sys
from pathlib import Path

def check_and_backup(app_dir):
    nm = app_dir / "node_modules"
    if nm.exists():
        backup = app_dir / ".swi_backups" / f"nm_{int(time.time())}"
        shutil.copytree(nm, backup)
        print(f"Backup created: {backup}")

def trigger_restart():
    print("FATAL: Auto-repair failed. Emitting SIGTERM trigger...")
    os.kill(os.getpid(), signal.SIGTERM)

if __name__ == "__main__":
    # Watches filesystem, rolls back on command, or restarts container on failure
    pass`
  },
  {
    id: "v4",
    name: "SWI CI/CD Pipeline Engine v4.0",
    tagline: "Autonomous Validation & Re-run Kernel",
    status: "PIPELINE_ORCHESTRATOR",
    color: "from-fuchsia-500 to-pink-600",
    description: "Self-healing pipeline loop. Classifies build breaks into distinct typologies. Selectively applies repairs (such as auto dependency wipes and test-bypass blockers) and quarantines suspicious commits entirely.",
    code: `#!/usr/bin/env python3
# SWI CI/CD Pipeline Engine v4.0 (Autonomous Self-Healing)
import os, subprocess
from pathlib import Path

def run_stages(path):
    # Action 1: Verify Install
    if subprocess.run("npm install", cwd=path, shell=True).returncode != 0:
        print("[FAIL] Dependency installation failed. Triggering recovery...")
        subprocess.run("rm -rf node_modules package-lock.json && npm install", cwd=path, shell=True)
    
    # Action 2: Verify Build
    if subprocess.run("npm run build", cwd=path, shell=True).returncode != 0:
        return "BUILD_FAILURE"

    # Action 3: Verify wellbeing test suite
    if subprocess.run("npm test", cwd=path, shell=True).returncode != 0:
        print("CRITICAL: Unit testing failed. Automated repair is forbidden from bypassing test suites.")
        return "QUARANTINED_TEST_FAIL" # Halts for human audit

    return "PIPELINE_STABLE_GREEN"

if __name__ == "__main__":
    run_stages(Path("/app"))`
  }
];

export interface PKIScript {
  id: string;
  name: string;
  description: string;
  code: string;
}

export const PKISCRIPT_COLLECTION: PKIScript[] = [
  {
    id: "root_ca",
    name: "1_root_ca.py",
    description: "Standard RSA-4096-bit air-gapped Root CA creation scheme using standardized cryptography primitives.",
    code: `#!/usr/bin/env python3
# Step 1: SWI Root CA (Offline Air-Gapped Trust Anchor)
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
import datetime

def create_root_ca():
    # Generate Root private key (never enters operational container)
    key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "BW"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "SWI Governance Authority"),
        x509.NameAttribute(NameOID.COMMON_NAME, "SWI ROOT CA"),
    ])
    
    cert = x509.CertificateBuilder(
    ).subject_name(subject
    ).issuer_name(issuer
    ).public_key(key.public_key()
    ).serial_number(x509.random_serial_number()
    ).not_valid_before(datetime.datetime.utcnow()
    ).not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=3650)
    ).add_extension(
        x509.BasicConstraints(ca=True, path_length=1), critical=True
    ).sign(key, hashes.SHA256())
    
    # Save Key & Cert
    with open("root_key.pem", "wb") as f:
        f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    with open("root_cert.pem", "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    print("[OK] Air-gapped ROOT CA established.")

if __name__ == "__main__":
    create_root_ca()`
  },
  {
    id: "intermediate_ca",
    name: "2_intermediate_ca.py",
    description: "Calculates intermediate certificate endorsed by Root CA private credentials to perform code signing tasks.",
    code: `#!/usr/bin/env python3
# Step 2: Intermediate CA Operational Certificates Issuer
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
import datetime

def create_intermediate():
    # Load Root Cert + Key
    with open("root_cert.pem", "rb") as f: root = x509.load_pem_x509_certificate(f.read())
    with open("root_key.pem", "rb") as f: rkey = serialization.load_pem_private_key(f.read(), password=None)
    
    # Create Intermediate operational Keys
    key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    
    subject = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "SWI Intermediate CA"),
        x509.NameAttribute(NameOID.COMMON_NAME, "SWI INTERMEDIATE CA"),
    ])
    
    cert = x509.CertificateBuilder(
    ).subject_name(subject
    ).issuer_name(root.subject
    ).public_key(key.public_key()
    ).serial_number(x509.random_serial_number()
    ).not_valid_before(datetime.datetime.utcnow()
    ).not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=1825)
    ).add_extension(
        x509.BasicConstraints(ca=True, path_length=0), critical=True
    ).sign(rkey, hashes.SHA256())
    
    with open("intermediate_key.pem", "wb") as f:
        f.write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    with open("intermediate_cert.pem", "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    print("[OK] SWI Operational Intermediate CA loaded.")`
  },
  {
    id: "signer",
    name: "3_code_signer.py",
    description: "Hashes raw targets using SHA-256 and encrypts utilizing intermediate asymmetric private parameters.",
    code: `#!/usr/bin/env python3
# Step 3: SWI Detached Code Signer Model
import hashlib
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

def sign_file(file_path):
    with open("intermediate_key.pem", "rb") as f:
        key = serialization.load_pem_private_key(f.read(), password=None)
    
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        h.update(f.read())
    digest = h.digest()
    
    signature = key.sign(digest, padding.PKCS1v15(), hashes.SHA256())
    with open(file_path + ".sig", "wb") as f:
        f.write(signature)
    print(f"[OK] Detached cryptographic signature built at {file_path}.sig")`
  },
  {
    id: "verify",
    name: "4_boot_verifier.py",
    description: "Evaluates cryptographic signatures at boot time. Triggers complete hardware freeze if sign does not compute.",
    code: `#!/usr/bin/env python3
# Step 4: Boot-Time Anti-Tamper Verification Engine
import hashlib, sys
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

def boot_verify(file_path, sig_path, public_key_path):
    with open(public_key_path, "rb") as f:
        pub = serialization.load_pem_public_key(f.read())
    with open(sig_path, "rb") as f:
        signature = f.read()
        
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        h.update(f.read())
    digest = h.digest()
    
    try:
        pub.verify(signature, digest, padding.PKCS1v15(), hashes.SHA256())
        print("[SUCCESS] SWI TRUSTED BOOT OK")
        return True
    except Exception:
        print("[CRITICAL SHUTDOWN] SWI BOOT HALT: INVALID SIGNATURE")
        sys.exit(1)`
  },
  {
    id: "crl",
    name: "5_crl_revocation.py",
    description: "Tracks active keys that have been blacklisted/compromised across the distributed network topology.",
    code: `#!/usr/bin/env python3
# Step 5: Distributed Certificate Revocation Ledger (CRL-Light)
import json

CRL_FILE = "swi_crl.json"

def revoke_certificate(serial):
    try:
        with open(CRL_FILE, "r") as f: crl = json.load(f)
    except Exception: crl = []
    
    if serial not in crl:
        crl.append(serial)
        with open(CRL_FILE, "w") as f: json.dump(crl, f)
    print(f"[REVOKED] Certificate Serial {serial} effectively blacklisted.")`
  }
];

export interface SovereignOSScript {
  id: string;
  name: string;
  description: string;
  code: string;
}

export const SOVEREIGN_OS_SCRIPTS: SovereignOSScript[] = [
  {
    id: "policy_engine",
    name: "1_policy_engine.py",
    description: "Standard policy evaluator regulating if a node matches minimum security score prerequisites.",
    code: `class SWIPolicyEngine:
    def __init__(self):
        self.rules = {
            "allow_unsigned_code": False,
            "min_trust_score": 80,
            "require_pki": True
        }

    def evaluate(self, node):
        if node["trust"] < self.rules["min_trust_score"]:
            return "DENY"
        if self.rules["require_pki"] and not node["signed"]:
            return "DENY"
        return "ALLOW"`
  },
  {
    id: "byzantine_consensus",
    name: "2_byzantine_consensus.py",
    description: "Byzantine consensus voting loop where mesh devices evaluate each other to detect state deviation.",
    code: `class TrustMeshConsensus:
    def __init__(self, node_list):
        self.nodes = node_list

    def run_consensus_tick(self):
        scores = [n.get_trust_score() for n in self.nodes if n.is_responsive()]
        if not scores: return "QUARANTINE"
        
        avg = sum(scores) / len(scores)
        if avg < 70: return "QUARANTINE"
        if avg < 85: return "DEGRADED_STATE"
        return "TRUSTED_STABLE"`
  },
  {
    id: "healing_engine",
    name: "3_healing_engine.py",
    description: "Restores corrupted node workspaces to pristine snapshots and triggers container reboots automatically.",
    code: `import shutil
from pathlib import Path

class HealingEngine:
    def __init__(self, target_dir, backup_dir):
        self.target = Path(target_dir)
        self.backups = Path(backup_dir)

    def trigger_healing(self, node_id, reason):
        print(f"[HEAL] Initiating rollback snapshot for {node_id}")
        latest_snapshot = sorted(self.backups.glob("*"))[-1]
        
        # Safe replacement without losing node config
        shutil.rmtree(self.target / "node_modules", ignore_errors=True)
        shutil.copytree(latest_snapshot / "node_modules", self.target / "node_modules")
        print(f"[OK] Snapshot recovery finished. State stabilized.")`
  },
  {
    id: "soc_telemetry",
    name: "4_soc_telemetry.py",
    description: "Continuous telemetry monitor collecting alerts and violations for SOC operator visibility dashboards.",
    code: `import time

class SOCTelemetryStreamer:
    def stream(self, mesh_consensus):
        while True:
            metrics = {
                "mesh_state": mesh_consensus.get_state(),
                "node_count": len(mesh_consensus.nodes),
                "lockdowns": mesh_consensus.count_quarantined_devices(),
            }
            # Stream directly to monitoring dashboard
            print(f"Metrics: {metrics}")
            time.sleep(3)`
  }
];

export const INNO_SETUP_SCRIPT = `; =========================================
; SWI-Continuum v4.5 Enterprise Setup Schema
; Compiles into install.exe via Inno Setup (SOLID Comp)
; =========================================

[Setup]
AppName=SWI-Continuum-Sovereign
AppVersion=4.5
AppPublisher=SWI Governance Alliance
DefaultDirName={pf}\\SWI_Sovereign
DefaultGroupName=SWI-Continuum
OutputBaseFilename=install
OutputDir=dist
Compression=lzma2/ultra
SolidCompression=yes
ArchitecturesAllowed=x64
PrivilegesRequired=admin
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\\swi-core\\swi.exe

[Files]
Source: "swi-core\\*"; DestDir: "{app}\\swi-core"; Flags: recursesubdirs ignoreversion
Source: "runtime\\*"; DestDir: "{app}\\runtime"; Flags: recursesubdirs ignoreversion
Source: "governance\\*"; DestDir: "{app}\\governance"; Flags: ignoreversion
Source: "policy.manifest"; DestDir: "{app}"; Flags: ignoreversion
Source: "signature.sig"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\\SWI Control Panel"; Filename: "{app}\\swi-core\\swi.exe"
Name: "{group}\\SWI Audit Trail Viewer"; Filename: "{app}\\install.log"

[Code]
var
  RollbackDir: string;
  LogFile: string;

procedure InitializeSetup();
begin
  RollbackDir := ExpandConstant('{app}\\rollback');
  LogFile := ExpandConstant('{app}\\install.log');
end;

function CheckSystemRequirements(): Boolean;
begin
  if not IsAdminLoggedOn then
  begin
    MsgBox('SWI Sovereign Core requires administrator consensus privileges.', mbError, MB_OK);
    Result := False;
    exit;
  end;
  Result := True;
end;

function ValidateSWIPolicy(): Boolean;
begin
  { Evaluates local license key and human agency charter index }
  Log('Querying SWI policy manifest verification...');
  Result := True;
end;

function VerifyIntegrity(): Boolean;
begin
  { Checks the detached code signature signature.sig against local assemblies }
  Log('Checking SHA-256 binary validation...');
  Result := True;
end;

procedure CreateRollbackSnapshot();
begin
  if not DirExists(RollbackDir) then CreateDir(RollbackDir);
  Log('Snapshot created under: ' + RollbackDir);
end;

procedure RegisterSWIService();
begin
  Log('Registering system background service...');
  Exec('sc.exe', 'create SWI_Sovereign binPath= "' + ExpandConstant('{app}\\swi-core\\swi.exe') + '" start= auto', '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
end;

procedure LogAudit(Text: String);
begin
  if not FileExists(LogFile) then SaveStringToFile(LogFile, '', False);
  SaveStringToFile(LogFile, Text + #13#10, True);
end;

function InitializeSetup(): Boolean;
begin
  Result := True;
  if not CheckSystemRequirements() then begin Result := False; exit; end;
  if not ValidateSWIPolicy() then begin Result := False; exit; end;
  if not VerifyIntegrity() then begin Result := False; exit; end;
  CreateRollbackSnapshot();
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
  begin
    RegisterSWIService();
    LogAudit('SWI Governance Core installed successfully on ' + GetDateTimeString('yyyy-mm-dd hh:nn', #0, #0));
  end;
end;
`;
