import React, { useState, useEffect } from "react";
import { cn } from "@/src/lib/utils";
import {
  Network,
  FileCheck2,
  KeyRound,
  DatabaseBackup,
  Skull,
  Gavel,
  TerminalSquare,
  Activity,
  ShieldAlert,
  ServerCrash,
  Play,
  Download,
} from "lucide-react";
import { ProofArtifacts } from "./common/ProofArtifacts";

type PhaseStatus = "PENDING" | "EXECUTING" | "VERIFIED" | "FAILED" | "PLANNED";

interface StructurePhase {
  id: string;
  index: number;
  title: string;
  icon: React.FC<any>;
  status: PhaseStatus;
  description: string;
  requirements: string[];
  purpose: string;
}

export default function StructuralRealityView() {
  const [activePhase, setActivePhase] = useState<string>("consensus");
  const [executionLog, setExecutionLog] = useState<string[]>([]);
  const [phases, setPhases] = useState<StructurePhase[]>([
    {
      id: "consensus",
      index: 1,
      title: "CONSENSUS REALITY LAYER",
      icon: Network,
      status: "PENDING",
      description:
        "Replace simulated coordination with verifiable distributed agreement.",
      requirements: [
        "Real CometBFT / HotStuff node execution",
        "Byzantine quorum validation",
        "Signed state propagation",
        "P2P synchronization",
        "Fault partition testing",
        "Leader rotation verification",
        "Replay protection",
      ],
      purpose: "Verifies continuity under distributed disagreement.",
    },
    {
      id: "verification",
      index: 2,
      title: "FORMAL VERIFICATION LAYER (PLANNED)",
      icon: FileCheck2,
      status: "PLANNED",
      description: "Ensure lawful continuity across all reachable states. Currently in theoretical modeling.",
      requirements: [
        "Real TLA+ specifications (pending fix of vars/scoping)",
        "TLC model-check CI pipeline (planned)",
        "Safety/liveness proofs (conceptual)",
        "Deadlock detection",
        "State invariant enforcement",
        "Rust FSM equivalence verification",
      ],
      purpose: "Verifies invariant preservation across all reachable states.",
    },
    {
      id: "cryptographic",
      index: 3,
      title: "CRYPTOGRAPHIC TRUTH LAYER",
      icon: KeyRound,
      status: "PENDING",
      description: "Remove symbolic trust assumptions.",
      requirements: [
        "Actual SNARK/STARK circuit compilation",
        "Halo2/Circom proving systems",
        "Witness generation",
        "Recursive proof validation",
        "Verifier contract execution",
        "Proof integrity benchmarking",
      ],
      purpose: "Verifies mathematical integrity independent of trust.",
    },
    {
      id: "persistence",
      index: 4,
      title: "PERSISTENT EVENT MEMORY LAYER",
      icon: DatabaseBackup,
      status: "PENDING",
      description: "Guarantee continuity after node death or disruption.",
      requirements: [
        "Kafka / Redpanda / MSK event sourcing",
        "Immutable append-only logs",
        "Replay reconstruction",
        "Node recovery restoration",
        "Distributed trace continuity",
        "Cross-region replication",
      ],
      purpose: "Verifies recovery capacity after partial failure.",
    },
    {
      id: "adversarial",
      index: 5,
      title: "ADVERSARIAL VALIDATION LAYER",
      icon: Skull,
      status: "PENDING",
      description: "Reveal hidden structural weakness before production.",
      requirements: [
        "Chaos engineering",
        "Byzantine attack injection",
        "Consensus poisoning tests",
        "Latency partition simulation",
        "Rollback resistance validation",
        "Resource exhaustion testing",
      ],
      purpose: "Verifies graceful degradation under hostile pressure.",
    },
    {
      id: "governance",
      index: 6,
      title: "GOVERNANCE ENFORCEMENT LAYER",
      icon: Gavel,
      status: "PENDING",
      description: "Prevent autonomous authority illusion.",
      requirements: [
        "Human authorization thresholds",
        "Multi-party approval enforcement",
        "Immutable audit signatures",
        "Policy execution constraints",
        "Non-bypassable escalation rules",
      ],
      purpose:
        "Prevents symbolic governance without operational accountability.",
    },
  ]);

  const [isExecuting, setIsExecuting] = useState(false);

  const triggerExecution = async (phaseId: string) => {
    setIsExecuting(true);
    setExecutionLog((prev) => [
      ...prev,
      `[${new Date().toISOString()}] INITIATING STRUCTURAL VERIFICATION: ${phaseId.toUpperCase()}`,
    ]);

    // Mark as executing
    setPhases((prev) =>
      prev.map((p) =>
        p.id === phaseId
          ? ({ ...p, status: "EXECUTING" } as StructurePhase)
          : p,
      ),
    );

    const phase = phases.find((p) => p.id === phaseId);
    if (!phase) return;

    // Simulate the execution steps
    for (let i = 0; i < phase.requirements.length; i++) {
      await new Promise((r) => setTimeout(r, 600)); // Delay between steps
      setExecutionLog((prev) => [
        `[${new Date().toISOString()}] EXECUTING: ${phase.requirements[i]}`,
        ...prev,
      ]);

      // Random chance of a simulated failure in adversarial mode to prove point
      if (phaseId === "adversarial" && i === 2 && Math.random() > 0.5) {
        setExecutionLog((prev) => [
          `[${new Date().toISOString()}] CRITICAL: ${phase.requirements[i]} FAILED. Basin integrity compromised.`,
          ...prev,
        ]);
        setPhases((prev) =>
          prev.map((p) =>
            p.id === phaseId
              ? ({ ...p, status: "FAILED" } as StructurePhase)
              : p,
          ),
        );
        setIsExecuting(false);
        return;
      }
    }

    await new Promise((r) => setTimeout(r, 800));
    setExecutionLog((prev) => [
      `[${new Date().toISOString()}] VERIFIED: ${phase.title} INVARIANTS HOLD.`,
      ...prev,
    ]);

    setPhases((prev) =>
      prev.map((p) =>
        p.id === phaseId ? ({ ...p, status: "VERIFIED" } as StructurePhase) : p,
      ),
    );
    setIsExecuting(false);
  };

  const getStatusColor = (status: PhaseStatus) => {
    switch (status) {
      case "PENDING":
        return "text-zinc-500 border-zinc-500/30 bg-zinc-500/5";
      case "PLANNED":
        return "text-yellow-500 border-yellow-500/30 bg-yellow-500/5";
      case "EXECUTING":
        return "text-blue-500 border-blue-500 bg-blue-500/10 animate-pulse";
      case "VERIFIED":
        return "text-green-500 border-green-500 bg-green-500/10";
      case "FAILED":
        return "text-red-500 border-red-500 bg-red-500/10";
    }
  };

  const activePhaseData = phases.find((p) => p.id === activePhase);

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-32">
      {/* Header */}
      <div className="border border-black dark:border-white p-8 relative overflow-hidden bg-[#141414] text-[#E4E3E0]">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_transparent_0%,_#E4E3E0_100%)] pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div className="space-y-4 max-w-2xl">
            <div className="flex items-center gap-3">
              <TerminalSquare className="w-8 h-8 text-blue-500" />
              <h1 className="text-3xl font-black tracking-tight uppercase">
                SWI // STRUCTURAL REALITY EXECUTION v1.0
              </h1>
            </div>
            <p className="text-sm font-mono opacity-80 leading-relaxed border-l-2 border-blue-500 pl-4">
              CURRENT STATE: UI-complete. Simulation-complete. Conceptually
              coherent. Operationally partial.
              <br />
              SYSTEM STATUS:{" "}
              <span className="text-red-500 font-bold bg-red-500/20 px-1">
                NOT YET STRUCTURALLY VERIFIED.
              </span>
            </p>
            <p className="text-xs uppercase tracking-widest opacity-60">
              MISSION: Convert symbolic architecture into measurable lawful
              continuity.
            </p>
          </div>
          <div className="text-right border-t md:border-t-0 md:border-l border-white/20 pt-4 md:pt-0 md:pl-6">
            <div className="text-[10px] font-bold uppercase tracking-widest opacity-50 mb-1">
              Core Law
            </div>
            <p className="text-xs max-w-xs opacity-80 leading-tight">
              No system is considered real because it appears operational.
              Reality is confirmed only when structure survives pressure,
              transfer, recovery, recursion, and adversarial disturbance without
              violating invariant law.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Phase Navigation */}
        <div className="lg:col-span-1 space-y-2">
          <h2 className="text-xs font-black uppercase tracking-[0.2em] mb-4 opacity-50">
            Validation Matrix
          </h2>
          {phases.map((phase) => (
            <button
              key={phase.id}
              onClick={() => setActivePhase(phase.id)}
              className={cn(
                "w-full text-left p-4 border transition-all relative flex flex-col gap-2 group",
                activePhase === phase.id
                  ? "bg-black text-white border-black dark:bg-white dark:text-black dark:border-white"
                  : "bg-white/5 border-black/10 hover:border-black/30 dark:border-white/10 dark:hover:border-white/30 text-black dark:text-white",
              )}
            >
              <div className="flex justify-between items-center w-full">
                <div className="flex items-center gap-3">
                  <phase.icon className="w-4 h-4 opacity-70" />
                  <span className="text-sm font-bold uppercase tracking-widest">
                    {phase.index}. {phase.title.split(" ")[0]}
                  </span>
                </div>
                <div
                  className={cn(
                    "text-[8px] font-black uppercase tracking-[0.2em] px-2 py-1 rounded-sm border",
                    getStatusColor(phase.status),
                    activePhase === phase.id &&
                      phase.status === "PENDING" &&
                      "bg-transparent border-current",
                  )}
                >
                  {phase.status}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Phase Execution Engine */}
        <div className="lg:col-span-2 space-y-6">
          {activePhaseData && (
            <div className="border border-black dark:border-white bg-[#141414] text-[#E4E3E0] p-6 flex flex-col min-h-[400px]">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-blue-500 mb-2">
                    Phase 0{activePhaseData.index}
                  </div>
                  <h2 className="text-2xl font-black uppercase tracking-tight">
                    {activePhaseData.title}
                  </h2>
                </div>
                <activePhaseData.icon className="w-8 h-8 opacity-20" />
              </div>

              <div className="space-y-6 flex-grow">
                <div className="p-4 bg-white/5 border-l-4 border-white/20">
                  <div className="text-[10px] uppercase font-bold tracking-widest opacity-50 mb-1">
                    Objective
                  </div>
                  <p className="text-sm font-mono">
                    {activePhaseData.description}
                  </p>
                </div>

                <div>
                  <div className="text-[10px] uppercase font-bold tracking-widest opacity-50 mb-3">
                    Execution Requirements
                  </div>
                  <ul className="space-y-2 font-mono text-xs">
                    {activePhaseData.requirements.map((req, i) => (
                      <li
                        key={i}
                        className="flex items-center gap-3 before:content-['>'] before:text-blue-500 border-b border-white/5 pb-2"
                      >
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 bg-blue-500/10 border border-blue-500/30">
                  <div className="text-[10px] uppercase font-bold tracking-widest text-blue-400 mb-1">
                    Structural Purpose
                  </div>
                  <p className="text-xs uppercase opacity-90">
                    {activePhaseData.purpose}
                  </p>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-white/10 flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => triggerExecution(activePhaseData.id)}
                    disabled={isExecuting}
                    className={cn(
                      "px-8 py-3 text-xs font-black uppercase tracking-widest border transition-all flex items-center gap-2",
                      isExecuting
                        ? "bg-blue-500/20 border-blue-500 text-blue-400 cursor-not-allowed"
                        : activePhaseData.status === "VERIFIED"
                          ? "bg-green-500/20 border-green-500 text-green-500 hover:bg-green-500 hover:text-black"
                          : "bg-white text-black hover:bg-black hover:text-white border-white",
                    )}
                  >
                    {isExecuting ? (
                      <>
                        <Activity className="w-4 h-4 animate-spin" /> Executing
                        Layer...
                      </>
                    ) : activePhaseData.status === "VERIFIED" ? (
                      <>
                        <Play className="w-4 h-4" /> Replay Trace
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" /> Execute Verification
                      </>
                    )}
                  </button>
                </div>

                <div className="text-[10px] font-mono opacity-40 uppercase">
                  Verify Status: {activePhaseData.status}
                </div>
              </div>

              {activePhaseData.status === "VERIFIED" && !isExecuting && (
                <ProofArtifacts
                  id={activePhaseData.id}
                  title={activePhaseData.title}
                  logs={executionLog}
                  data={{ requirements: activePhaseData.requirements }}
                  variant="always-dark"
                />
              )}
            </div>
          )}

          {/* Execution Logs */}
          <div className="border border-black dark:border-white bg-[#141414] text-[#E4E3E0] p-4 h-48 flex flex-col">
            <div className="text-[10px] font-black uppercase tracking-[0.2em] opacity-50 mb-4 flex items-center justify-between border-b border-white/10 pb-2">
              <span>Live Verification Trace</span>
              {isExecuting && (
                <span className="text-blue-500 animate-pulse">
                  STREAMING...
                </span>
              )}
            </div>
            <div className="overflow-y-auto flex-grow space-y-1 font-mono text-[10px]">
              {executionLog.length === 0 ? (
                <div className="opacity-30">
                  Waiting for execution trigger...
                </div>
              ) : (
                executionLog.map((log, i) => (
                  <div
                    key={i}
                    className={cn(
                      "break-all",
                      log.includes("FAILED") || log.includes("CRITICAL")
                        ? "text-red-500"
                        : log.includes("VERIFIED")
                          ? "text-green-500 font-bold"
                          : "opacity-80",
                    )}
                  >
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-4 bg-zinc-900 text-zinc-400 font-mono text-xs text-center border border-zinc-800">
            DISCOVERY BEGINS WHEN THE BASIN HOLDS.
          </div>
        </div>
      </div>
    </div>
  );
}
