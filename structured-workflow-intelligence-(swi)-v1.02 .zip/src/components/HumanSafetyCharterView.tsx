import React, { useState } from "react";
import {
  ShieldAlert,
  Heart,
  Users,
  Eye,
  FileCheck2,
  Terminal,
  FileSignature,
  Building2,
  Landmark,
  Scale,
  Key,
  Lock,
  Link2
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function HumanSafetyCharterView() {
  const [bindStatus, setBindStatus] = useState<"UNBOUND" | "BINDING" | "BOUND">("UNBOUND");
  const [policyHash, setPolicyHash] = useState("Awaiting binding...");

  const bindStructure = () => {
    setBindStatus("BINDING");
    setTimeout(() => {
      setPolicyHash("sha256:f7b3a19c8f2b1c4e9d0a7b5d" + Math.random().toString(16).substring(2, 10));
      setBindStatus("BOUND");
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-red-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 blur-[100px] pointer-events-none"></div>
        <div className="space-y-2 relative z-10">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-5 h-5 text-red-500" />
            <h2 className="text-sm font-black uppercase tracking-widest text-red-100">
              SWI Human Safety & Governance Charter
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-80 max-w-3xl text-red-200/70">
            "SWI/SSEP is a research-oriented secure verification and simulation platform focused on human safety, policy-constrained execution, hardware-backed attestation, and accountable governance."
          </p>
        </div>
      </div>

      {/* Binding Control */}
      <div className="bg-[#141414] border border-white/10 p-4 flex items-center justify-between">
         <div className="flex items-center gap-3">
            <Link2 className={cn("w-5 h-5 transition-colors", bindStatus === "BOUND" ? "text-emerald-500" : "text-white/40")} />
            <div className="text-[10px] font-mono uppercase font-bold text-white/70">
               Governance Structure Binding
            </div>
         </div>
         <div className="flex items-center gap-4">
            <div className="text-[9px] font-mono text-white/40">{policyHash}</div>
            <button
               onClick={bindStructure}
               disabled={bindStatus !== "UNBOUND"}
               className={cn(
                  "px-4 py-1.5 text-[9px] uppercase font-bold transition-all flex items-center gap-2",
                  bindStatus === "UNBOUND" ? "bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20" :
                  bindStatus === "BINDING" ? "bg-amber-500/10 text-amber-400 border border-amber-500/30" :
                  "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
               )}
            >
               {bindStatus === "UNBOUND" && <><Lock className="w-3 h-3" /> Bind Structure & Show Proof</>}
               {bindStatus === "BINDING" && <><Terminal className="w-3 h-3 animate-pulse" /> Generating Hash...</>}
               {bindStatus === "BOUND" && <><FileCheck2 className="w-3 h-3" /> Structurally Bound</>}
            </button>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core Principles & Pillars */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className={cn("bg-[#141414] border p-6 transition-all duration-500", bindStatus === "BOUND" ? "border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]" : "border-white/10")}>
            <div className="flex items-center gap-2 text-rose-400 mb-4 border-b border-white/10 pb-3">
              <Heart className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-widest">
                Core Principle & Non-Harm Requirement
              </h3>
            </div>
            <div className="font-mono text-[10px] text-white/70 space-y-4">
              <p className="text-rose-300 font-bold text-[11px] uppercase tracking-wide">
                Human life, dignity, and safety take priority over all runtime objectives.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                <div>
                  <div className="text-white/50 mb-2 uppercase tracking-widest font-bold text-[9px]">Never Intentionally Used For:</div>
                  <ul className="space-y-1.5 text-white/60">
                    <li className="flex items-start gap-2"><span className="text-rose-500 font-bold">×</span> Harming people</li>
                    <li className="flex items-start gap-2"><span className="text-rose-500 font-bold">×</span> Autonomous violence</li>
                    <li className="flex items-start gap-2"><span className="text-rose-500 font-bold">×</span> Unlawful surveillance</li>
                    <li className="flex items-start gap-2"><span className="text-rose-500 font-bold">×</span> Coercion or exploitation</li>
                    <li className="flex items-start gap-2"><span className="text-rose-500 font-bold">×</span> Critical life-risk decisions without oversight</li>
                  </ul>
                </div>
                
                <div className="bg-rose-950/20 border border-rose-500/20 p-3 rounded-sm">
                  <div className="text-rose-400 mb-2 uppercase tracking-widest font-bold text-[9px]">Especially Protected Categories:</div>
                  <ul className="space-y-1.5 text-rose-200/70">
                    <li className="flex items-center gap-2"><div className="w-1 h-1 bg-rose-400 rounded-full"></div> Children</li>
                    <li className="flex items-center gap-2"><div className="w-1 h-1 bg-rose-400 rounded-full"></div> Mothers</li>
                    <li className="flex items-center gap-2"><div className="w-1 h-1 bg-rose-400 rounded-full"></div> Vulnerable populations</li>
                    <li className="flex items-center gap-2"><div className="w-1 h-1 bg-rose-400 rounded-full"></div> Humanitarian environments</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className={cn("bg-[#141414] border p-5 transition-all duration-500", bindStatus === "BOUND" ? "border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]" : "border-white/10")}>
              <div className="flex items-center gap-2 text-amber-500 mb-3">
                <Users className="w-4 h-4" />
                <h3 className="text-xs font-bold uppercase tracking-widest">
                  Human Authorization Rule
                </h3>
              </div>
              <p className="font-mono text-[10px] text-amber-500/80 font-bold tracking-wide uppercase border-l-2 border-amber-500 pl-3 py-1 mb-3">
                No irreversible execution without verified human approval.
              </p>
              <div className="font-mono text-[9px] text-white/50 space-y-2">
                <p>Aligns with existing constraints:</p>
                <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 border border-amber-500/50"></div> WAITING_HUMAN manual gate</div>
                <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 border border-amber-500/50"></div> Quorum approval cryptographic thresholds</div>
                <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 border border-amber-500/50"></div> Simulation-first restricted execution</div>
              </div>
            </div>

            <div className={cn("bg-[#141414] border flex flex-col justify-between p-5 transition-all duration-500", bindStatus === "BOUND" ? "border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]" : "border-white/10")}>
              <div className="flex items-center gap-2 text-indigo-400 mb-3">
                <Landmark className="w-4 h-4" />
                <h3 className="text-[10px] font-bold uppercase tracking-widest leading-tight">
                  Governance & Allocation Model
                </h3>
              </div>
              <div className="font-mono text-[9px] text-white/60 space-y-3">
                 <p className="text-white/40 italic">Support responsible development, participate in verifiable execution testing, and apply for deployment partnerships.</p>
                 <div className="space-y-1 mt-auto">
                    <div className="flex justify-between items-center text-indigo-300 font-bold">
                       <span>SAMH Support Initiatives</span>
                       <span>40%</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                       <div className="h-full bg-indigo-500 w-[40%]"></div>
                    </div>
                 </div>
                 <div className="space-y-1">
                    <div className="flex justify-between items-center text-blue-300 font-bold">
                       <span>SWI Infra, Security & Research</span>
                       <span>60%</span>
                    </div>
                    <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                       <div className="h-full bg-blue-500 w-[60%]"></div>
                    </div>
                 </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar: SWI Safety Rules & Commercial API */}
        <div className="space-y-6">
          <div className={cn("bg-[#0A0A0A] border p-5 transition-all duration-500", bindStatus === "BOUND" ? "border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.1)]" : "border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]")}>
            <div className="flex items-center gap-2 text-emerald-400 mb-4 border-b border-emerald-500/20 pb-3">
              <Scale className="w-4 h-4" />
              <h3 className="text-[11px] font-bold uppercase tracking-widest text-emerald-300">
                SWI Safety Rules
              </h3>
            </div>
            <ul className="space-y-2.5 font-mono text-[9px] text-emerald-100/80">
              <li className="flex items-start gap-2 bg-emerald-500/5 p-2 border border-emerald-500/10">
                <span className="text-emerald-500 font-black">✓</span> <span>Human authorization required</span>
              </li>
              <li className="flex items-start gap-2 bg-emerald-500/5 p-2 border border-emerald-500/10">
                <span className="text-emerald-500 font-black">✓</span> <span>Simulation-first operation</span>
              </li>
              <li className="flex items-start gap-2 bg-emerald-500/5 p-2 border border-emerald-500/10">
                <span className="text-emerald-500 font-black">✓</span> <span>Child & civilian protection priority</span>
              </li>
              <li className="flex items-start gap-2 bg-emerald-500/5 p-2 border border-emerald-500/10">
                <span className="text-emerald-500 font-black">✓</span> <span>Auditability mandatory</span>
              </li>
              <li className="flex items-start gap-2 bg-emerald-500/5 p-2 border border-emerald-500/10">
                <span className="text-emerald-500 font-black">✓</span> <span>Commercial access requires verification</span>
              </li>
              <li className="flex items-start gap-2 bg-emerald-500/5 p-2 border border-emerald-500/10">
                <span className="text-emerald-500 font-black">✓</span> <span>Runtime policy enforcement active</span>
              </li>
            </ul>
          </div>

          <div className={cn("bg-[#141414] border p-5 transition-all duration-500", bindStatus === "BOUND" ? "border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.05)]" : "border-white/10")}>
            <div className="flex items-center gap-2 text-cyan-400 mb-3">
              <Building2 className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest">
                Commercial Use Policy
              </h3>
            </div>
            <div className="font-mono text-[9px] text-white/50 space-y-3">
               <div>Commercial deployments are heavily restricted and require the "Verified Commercial API Blueprint".</div>
               
               <div className="border border-white/5 bg-black/40 p-2 space-y-1.5 text-cyan-500/60 pl-3 border-l-2 border-l-cyan-500/40">
                  <div>↓ SWI Root CA</div>
                  <div>↓ Verified Organization</div>
                  <div>↓ Commercial API Certificate</div>
                  <div className="text-cyan-400 font-bold">→ Signed Runtime Access</div>
               </div>

               <div className="pt-2">
                 <div className="text-white/30 uppercase tracking-widest mb-1.5">Governance Rules</div>
                 <div className="grid grid-cols-[1fr_1fr] gap-x-2 gap-y-1">
                   <div className="flex items-center gap-1.5"><FileSignature className="w-3 h-3 text-cyan-500"/> Verified org</div>
                   <div className="flex items-center gap-1.5"><Key className="w-3 h-3 text-cyan-500"/> Signed keys</div>
                   <div className="flex items-center gap-1.5"><Eye className="w-3 h-3 text-cyan-500"/> Audit logs</div>
                   <div className="flex items-center gap-1.5"><ShieldAlert className="w-3 h-3 text-cyan-500"/> Rate limits</div>
                 </div>
               </div>
            </div>
          </div>
        </div>

      </div>

      {/* Proof Artifacts Footer */}
      {(bindStatus === "BOUND" || bindStatus === "BINDING") && (
         <div className="bg-[#141414] p-6 border border-emerald-500/30 mt-6 flex flex-col items-center text-center animate-in fade-in duration-500">
         <ProofArtifacts
            id="safety-charter"
            title="SWI Verified Governance & Safety Bounds"
            data={{
               charter: "Human Safety Boundary v1.0",
               status: bindStatus === "BOUND" ? "ENFORCED & BOUND" : "BINDING...",
               "policy.hash": policyHash,
               crypto_binding: bindStatus === "BOUND" ? "CONFIRMED" : "PENDING",
               attestation: bindStatus === "BOUND" ? "Structurally verified against hash." : ""
            }}
            variant="always-dark"
         />
         </div>
      )}
    </div>
  );
}
