import React, { useEffect, useState } from "react";
import { ZkOsKernel, KernelState, Process, Capability, KernelTrace } from "../core/zkos/ZkOsKernel";
import { Activity, Shield, Cpu, MemoryStick, Send } from "lucide-react";

const kernel = new ZkOsKernel();

export default function ZkOsDashboard() {
  const [state, setState] = useState<KernelState | null>(null);

  useEffect(() => {
    let active = true;
    const init = async () => {
      if (kernel.getSnapshot().processes.length === 0) {
        await kernel.initGenesisProcess();
      }
      if (active) setState(kernel.getSnapshot());
    };
    init();
    return () => { active = false; };
  }, []);

  const handleTick = async () => {
    await kernel.tick();
    setState(kernel.getSnapshot());
  };

  const handleFork = async () => {
    if (!state || state.processes.length === 0) return;
    const parent = state.processes[0];
    try {
      await kernel.fork(parent.pid, Math.floor(Math.random() * 1000) + 10);
      setState(kernel.getSnapshot());
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    }
  };

  if (!state) return <div className="p-4 text-white">Initializing zkOS...</div>;

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-[#E4E3E0] min-h-screen font-mono text-xs">
      <div className="flex items-center justify-between border-b border-[#333] pb-4">
        <div>
          <h1 className="text-xl font-bold uppercase tracking-widest text-[#00ffcc] flex items-center gap-2">
            <Cpu className="w-5 h-5" /> zkOS Kernel Sandbox
          </h1>
          <p className="text-[#888] mt-1">Multi-Process Deterministic zkVM Execution Environment</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-[#111] border border-[#333] px-4 py-2 rounded text-[#00ffcc]">
            CYCLE: {state.cycle}
          </div>
          <div className="bg-[#111] border border-[#333] px-4 py-2 rounded text-[#ffaa00]">
            STATE ROOT: {state.globalStateRoot.substring(0, 16)}...
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={handleTick}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#333] hover:border-[#00ffcc] text-[#00ffcc] transition-colors flex items-center gap-2"
        >
          <Activity className="w-4 h-4" /> Advance Tick (+1 Cycle)
        </button>
        <button
          onClick={handleFork}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#333] hover:border-[#ff00ff] text-[#ff00ff] transition-colors flex items-center gap-2"
        >
          <Cpu className="w-4 h-4" /> Fork Process
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase text-[#888] border-b border-[#333] pb-2">Active Processes</h2>
          <div className="space-y-3">
            {state.processes.map((p: Process) => (
              <div key={p.pid} className={`p-4 border ${p.status === 'Running' ? 'border-[#00ffcc] bg-[#00ffcc]/5' : 'border-[#333] bg-[#111]'} rounded`}>
                <div className="flex justify-between items-center mb-2">
                  <div className="font-bold text-lg">PID {p.pid}</div>
                  <div className={`px-2 py-1 text-[10px] rounded uppercase ${p.status === 'Running' ? 'bg-[#00ffcc] text-black' : 'bg-[#333] text-gray-400'}`}>
                    {p.status}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[#aaa]">
                  <div>PC: <span className="text-[#E4E3E0]">{p.pc}</span></div>
                  <div>Root: <span className="text-[#E4E3E0]">{p.memoryRoot.substring(0, 8)}...</span></div>
                </div>
                <div className="mt-3 text-[10px] flex gap-1 flex-wrap">
                  {p.capabilities.map((cap: Capability) => (
                    <span key={cap} className="px-2 py-0.5 border border-[#444] rounded bg-[#222]">
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase text-[#888] border-b border-[#333] pb-2 flex gap-2">
            <Shield className="w-4 h-4" /> Global Execution Trace
          </h2>
          <div className="h-[400px] overflow-y-auto space-y-2 pr-2">
            {state.traces.slice().reverse().map((t: KernelTrace, i: number) => (
              <div key={i} className="p-3 border border-[#222] bg-[#111] rounded grid grid-cols-12 gap-4 items-center">
                <div className="col-span-2 text-[#666]">CYC {t.cycle}</div>
                <div className="col-span-2 text-[#ffaa00]">PID {t.runningPid}</div>
                <div className="col-span-4 text-[#00ffcc]">{t.action}</div>
                <div className="col-span-4 text-[#444] text-[10px] text-right truncate">
                  {t.stateRootAfter}
                </div>
              </div>
            ))}
            {state.traces.length === 0 && <div className="text-[#444] p-4 text-center border dashed border-[#333]">No traces yet</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
