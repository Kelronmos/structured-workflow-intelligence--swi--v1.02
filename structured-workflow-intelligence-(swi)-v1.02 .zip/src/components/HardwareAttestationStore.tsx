import React, { useState, useEffect } from "react";
import { HardDrive, ShieldCheck, Lock, Fingerprint, Activity } from "lucide-react";
import { cn } from "../lib/utils";
import { MeasuredBootTPM } from "../boot/measured_boot";
import { BootChainGuard } from "../boot/boot_guard";
import { TrustAnchor } from "../crypto/trust_anchor";

interface PCRDisplay {
  index: number;
  name: string;
  hash: string;
  status: "valid" | "invalid" | "unmeasured";
  description: string;
}

const pcrDefinitions = [
  { index: 0, name: "CRTM, BIOS, Host Platform", description: "Core Root of Trust" },
  { index: 1, name: "Host Platform Configuration", description: "BIOS configuration" },
  { index: 2, name: "Option ROM Code", description: "Option ROMs" },
  { index: 3, name: "Option ROM Configuration", description: "Option ROM configuration" },
  { index: 4, name: "IPL Code (MBR)", description: "Bootloader code" },
  { index: 5, name: "IPL Config/Data", description: "Bootloader config" },
  { index: 6, name: "State Transitions / Wake Events", description: "State transitions" },
  { index: 7, name: "Secure Boot State", description: "Secure Boot variables" },
  { index: 8, name: "OS Kernel / Initial Ramdisk", description: "OS kernel image" },
  { index: 9, name: "OS Init State", description: "OS initial application payload" },
];

export default function HardwareAttestationStore() {
  const [pcrs, setPcrs] = useState<PCRDisplay[]>([]);
  const [attestationStatus, setAttestationStatus] = useState<"secure" | "compromised" | "verifying">("verifying");
  const [anchor, setAnchor] = useState<TrustAnchor | null>(null);
  const [guardResult, setGuardResult] = useState<{ valid: boolean; reason?: string } | null>(null);

  // We need a known good hash to verify against.
  // We'll calculate it once on initial pristine boot.
  const [knownGoodHash, setKnownGoodHash] = useState<string>("");

  const runBootSequence = React.useCallback((tampered: boolean) => {
    setAttestationStatus("verifying");
    setAnchor(null);
    setGuardResult(null);

    const tpm = new MeasuredBootTPM();

    // Step 1: Simulate measurements extending into PCRs
    setTimeout(() => {
      tpm.measure(0, "BIOS", "bios_v1.2.3");
      tpm.measure(1, "Config", "secure_boot_enabled");
      tpm.measure(2, "OptionROM", "gpu_rom_a");
      tpm.measure(3, "OptionROMConfig", "default");
      
      // Introduce tamper payload if requested
      if (tampered) {
        tpm.measure(4, "Bootloader", "grub_v2_TAMPERED_PAYLOAD");
      } else {
        tpm.measure(4, "Bootloader", "grub_v2_official");
      }
      
      tpm.measure(5, "BootloaderConfig", "menu_timeout_5");
      // PCR 6 left unmeasured
      tpm.measure(7, "SecureBoot", "db_dbx_kek_pk_valid");
      
      if (tampered) {
        tpm.measure(8, "Kernel", "linux_swi_V1.01_INJECTED_ROOTKIT");
      } else {
        tpm.measure(8, "Kernel", "linux_swi_V1.01_official");
      }

      tpm.measure(9, "Init", "systemd_default_target");

      const generatedAnchor = tpm.generateAnchor();
      
      // If this is the first boot (knownGoodHash not set), save it.
      // We rely on React state to persist the 'golden' hash.
      let goldenHash = knownGoodHash;
      if (!goldenHash && !tampered) {
        setKnownGoodHash(generatedAnchor.kernelHash);
        goldenHash = generatedAnchor.kernelHash;
      }

      // Format display
      const displayPcrs: PCRDisplay[] = pcrDefinitions.map(def => {
        const hash = generatedAnchor.pcrs.get(def.index) || "";
        const isUnmeasured = hash === "0000000000000000000000000000000000000000000000000000000000000000";
        // If tampered, flag specific pcrs artificially for UI
        let status: "valid" | "invalid" | "unmeasured" = isUnmeasured ? "unmeasured" : "valid";
        if (tampered && (def.index === 4 || def.index === 8)) {
            status = "invalid";
        }

        return {
          ...def,
          hash,
          status,
        };
      });

      setPcrs(displayPcrs);
      setAnchor(generatedAnchor);

      // Guard verification
      const guard = new BootChainGuard(goldenHash);
      const res = guard.verifyBoot(generatedAnchor);
      setGuardResult(res);
      setAttestationStatus(res.valid ? "secure" : "compromised");
      window.dispatchEvent(new CustomEvent('boot-status', { detail: res }));

    }, 800);
  }, [knownGoodHash]);

  useEffect(() => {
    runBootSequence(false);
  }, [runBootSequence]);

  useEffect(() => {
    const handleResetRequest = () => {
        runBootSequence(false);
    };
    window.addEventListener('request-hardware-reset', handleResetRequest);
    return () => window.removeEventListener('request-hardware-reset', handleResetRequest);
  }, [runBootSequence]);

  const triggerCompromise = () => {
    runBootSequence(true);
  };

  const triggerReset = () => {
    runBootSequence(false);
  };

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-[#E4E3E0] min-h-screen font-mono text-xs">
      <div className="flex items-center justify-between border-b border-[#333] pb-4">
        <div>
          <h1 className="text-xl font-bold uppercase tracking-widest text-[#00ffcc] flex items-center gap-2">
            <HardDrive className="w-5 h-5" /> Hardware Attestation
          </h1>
          <p className="text-[#888] mt-1">
            Platform Configuration Registers (PCRs) & Measured Boot Chain
          </p>
        </div>
        <div className="flex gap-4 items-center">
            {attestationStatus === "verifying" && (
                <div className="px-4 py-2 border rounded font-bold uppercase border-yellow-500 text-yellow-500 bg-yellow-500/10 animate-pulse flex items-center gap-2">
                    <Activity className="w-4 h-4" /> Validating Boot Chain...
                </div>
            )}
            {attestationStatus === "secure" && (
                <div className="px-4 py-2 border rounded font-bold uppercase border-[#00ffcc] text-[#00ffcc] bg-[#00ffcc]/10 flex items-center gap-2">
                   <ShieldCheck className="w-4 h-4" /> Secure Boot Anchor Confirmed
                </div>
            )}
            {attestationStatus === "compromised" && (
                <div className="px-4 py-2 border rounded font-bold uppercase border-red-500 text-red-500 bg-red-500/10 flex items-center gap-2">
                   <Lock className="w-4 h-4 text-red-500" /> ATTESTATION FAILED / TAMPER DETECTED
                </div>
            )}
        </div>
      </div>

       <div className="flex gap-4 items-center">
            <button
              onClick={triggerCompromise}
              disabled={attestationStatus === "verifying"}
              className="px-4 py-2 bg-[#330000] border border-[#333] hover:border-red-500 text-[#ffaaaa] transition-colors font-bold flex items-center gap-2 disabled:opacity-50"
            >
              Simulate Kernel Tampering
            </button>
            <button
              onClick={triggerReset}
              disabled={attestationStatus === "verifying"}
              className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#00ffcc] text-[#E4E3E0] transition-colors disabled:opacity-50"
            >
              Reset Hardware Enclave
            </button>
        </div>

      {anchor && (
          <div className="bg-[#111] border border-[#333] p-4 rounded grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                  <h3 className="font-bold text-[#bbbbbb] mb-2 uppercase border-b border-[#333] pb-1">Derived Kernel Hash Root</h3>
                  <div className={cn(
                      "font-mono text-sm break-all",
                      attestationStatus === "compromised" ? "text-red-400 font-bold" : "text-[#00ffcc]"
                  )}>{anchor.kernelHash}</div>
              </div>
              <div>
                  <h3 className="font-bold text-[#bbbbbb] mb-2 uppercase border-b border-[#333] pb-1">Guard Verification Log</h3>
                  {guardResult?.valid ? (
                       <span className="text-green-400">✅ Match with Known Golden Hash [{knownGoodHash.substring(0,8)}...]</span>
                  ) : (
                       <span className="text-red-400">❌ {guardResult?.reason}</span>
                  )}
                  <div className="mt-2 text-[#888] text-[10px]">Signature: {anchor.signature}</div>
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {pcrs.map((pcr) => (
          <div
            key={pcr.index}
            className={cn(
              "border p-4 rounded flex flex-col relative overflow-hidden",
              pcr.status === "valid" ? "border-[#333] bg-[#111]" : "",
              pcr.status === "invalid" ? "border-red-500 bg-red-500/10 shadow-[0_0_10px_rgba(255,0,0,0.2)]" : "",
              pcr.status === "unmeasured" ? "border-[#222] bg-[#0A0A0A] opacity-50" : ""
            )}
          >
             {pcr.status === "invalid" && <div className="absolute top-0 w-full h-1 bg-red-500 right-0 animate-pulse"></div>}
            
            <div className="flex justify-between items-center mb-2">
              <span className={cn(
                  "font-bold px-2 py-0.5 rounded text-[10px]",
                  pcr.status === "valid" ? "bg-[#333] text-[#00ffcc]" : "",
                  pcr.status === "invalid" ? "bg-red-500 text-white" : "",
                  pcr.status === "unmeasured" ? "bg-[#222] text-[#555]" : "",
              )}>
                PCR [{pcr.index}]
              </span>
              <Fingerprint className={cn(
                  "w-4 h-4",
                  pcr.status === "valid" ? "text-[#00ffcc]" : "",
                  pcr.status === "invalid" ? "text-red-500" : "",
                  pcr.status === "unmeasured" ? "text-[#555]" : "",
              )} />
            </div>
            <div className={cn(
                "font-bold uppercase mb-1 tracking-tight truncate",
                 pcr.status === "invalid" ? "text-red-400" : "text-[#E4E3E0]"
            )} title={pcr.name}>{pcr.name}</div>
            <div className="text-[#888] text-[9px] mb-4 truncate" title={pcr.description}>{pcr.description}</div>
            
            <div className="mt-auto">
               <div className="text-[8px] text-[#555] uppercase mb-1 drop-shadow-sm">Current Hash Measurement</div>
               <div className={cn(
                   "font-mono text-[9px] break-all p-1 rounded",
                   pcr.status === "valid" ? "bg-[#1A1A1A] text-[#00ffcc]/80" : "",
                   pcr.status === "invalid" ? "bg-red-500/20 text-red-300 font-bold" : "",
                   pcr.status === "unmeasured" ? "bg-[#111] text-[#444]" : "",
               )}>
                   {pcr.hash}
               </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
