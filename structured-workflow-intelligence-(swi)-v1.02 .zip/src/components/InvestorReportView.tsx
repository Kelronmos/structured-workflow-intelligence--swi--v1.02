// src/components/InvestorReportView.tsx
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, BarChart3, Fingerprint, FileSearch, Globe, ChevronRight, Download } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { SovereignAuditReport } from '@/swi-core/kernel/UniverseTypes';

export default function InvestorReportView() {
    const [report, setReport] = useState<SovereignAuditReport | null>(null);
    const [loading, setLoading] = useState(true);

    const fetchReport = async () => {
        try {
            const res = await fetch('/api/v4/sovereign-audit');
            const data = await res.json();
            setReport(data);
        } catch (e) {
            console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchReport();
        const interval = setInterval(fetchReport, 5000);
        return () => clearInterval(interval);
    }, []);

    if (!report && loading) return <div className="p-12 text-center text-white/20 animate-pulse font-black uppercase tracking-[0.3em]">Building 6D+ Sovereign Audit...</div>;
    if (!report) return null;

    const dimensionIcons = {
        ethics: ShieldCheck,
        law: Globe,
        safety: FileSearch,
        authority: Fingerprint,
        coherence: BarChart3,
        determinism: ChevronRight,
        transparency: FileSearch,
        traceability: Fingerprint
    };

    return (
        <div className="bg-black/90 border border-white/10 rounded-[2.5rem] p-8 shadow-2xl overflow-hidden relative group">
            {/* Background Texture/Accent */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 blur-[80px] -mr-32 -mt-32 rounded-full" />
            
            <div className="flex flex-col lg:flex-row justify-between items-start gap-8 relative z-10">
                <div className="space-y-4 max-w-xl">
                    <div className="flex items-center gap-3">
                        <div className="px-3 py-1 bg-blue-500/10 border border-blue-500/30 rounded-full">
                            <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest italic flex items-center gap-2">
                                <ShieldCheck className="w-3 h-3" /> Proof of SWI Core v6 (Proxima)
                            </span>
                        </div>
                        <span className="text-[10px] font-mono text-white/30 uppercase tracking-widest">{report.auditId}</span>
                    </div>
                    
                    <h2 className="text-4xl font-black text-white leading-none tracking-tighter">
                        Dimensional <span className="text-blue-500">Integrity</span> Report
                    </h2>
                    
                    <p className="text-sm font-serif italic text-white/60 leading-relaxed">
                        "{report.summary}"
                    </p>

                    <div className="flex gap-4 pt-4">
                        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex-1">
                            <p className="text-[8px] font-bold text-white/30 uppercase tracking-widest mb-1">Integrity Score</p>
                            <div className="flex items-baseline gap-2">
                                <span className={cn(
                                    "text-3xl font-black",
                                    report.integrityScore > 90 ? "text-green-500" : "text-yellow-500"
                                )}>
                                    {report.integrityScore.toFixed(2)}%
                                </span>
                            </div>
                        </div>
                        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex-1">
                            <p className="text-[8px] font-bold text-white/30 uppercase tracking-widest mb-1">Investor Confidence</p>
                            <div className="flex items-baseline gap-2">
                                <span className="text-3xl font-black text-blue-400">
                                    {(report.investorConfidence).toFixed(2)}%
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="w-full lg:w-80 space-y-2">
                    <div className="flex items-center justify-between px-2 mb-2">
                         <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">8D Alignment Matrix (v6.0)</span>
                         <BarChart3 className="w-3 h-3 text-white/20" />
                    </div>
                    {Object.entries(report.dimensions).map(([key, val]) => {
                        const Icon = (dimensionIcons as Record<string, React.ElementType>)[key] || BarChart3;
                        return (
                            <div key={key} className="bg-white/5 border border-white/5 rounded-xl p-2 hover:bg-white/10 transition-all">
                                <div className="flex justify-between items-center mb-1">
                                    <div className="flex items-center gap-2">
                                        <Icon className="w-3 h-3 text-white/40" />
                                        <span className="text-[8px] font-black uppercase tracking-widest text-white/80">{key}</span>
                                    </div>
                                    <span className="text-[8px] font-mono text-blue-400">{(val * 100).toFixed(1)}%</span>
                                </div>
                                <div className="h-0.5 bg-white/5 rounded-full overflow-hidden">
                                    <motion.div 
                                        initial={{ width: 0 }}
                                        animate={{ width: `${val * 100}%` }}
                                        className={cn("h-full", val > 0.95 ? "bg-blue-500" : "bg-blue-500/40")}
                                    />
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>

            {report.executionProof && (
                <div className="mt-8 pt-4 border-t border-white/5">
                    <div className="flex items-center gap-2 mb-3">
                         <ShieldCheck className="w-3 h-3 text-blue-500" />
                         <span className="text-[9px] font-black uppercase tracking-[0.2em] text-white/40">v6.0 Execution Trace Proofs</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <span className="text-[7px] font-black text-white/20 uppercase tracking-widest">TRACE_HASH</span>
                            <div className="bg-white/5 p-2 rounded-lg border border-white/5 font-mono text-[7px] text-white/40 truncate">
                                {report.executionProof.traceHash}
                            </div>
                        </div>
                        <div className="space-y-1">
                            <span className="text-[7px] font-black text-white/20 uppercase tracking-widest">MERKLE_ROOT</span>
                            <div className="bg-white/5 p-2 rounded-lg border border-white/5 font-mono text-[7px] text-white/40 truncate">
                                {report.executionProof.merkleRoot}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-end gap-6 relative z-10">
                <div className="space-y-4 w-full md:w-auto">
                    <div className="flex items-center gap-2 mb-4">
                        <Fingerprint className="w-4 h-4 text-white/20" />
                        <h4 className="text-[10px] font-black uppercase tracking-widest text-white/40">Cryptographic Proof Chain</h4>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {report.proofs.map((proof, i) => (
                            <span key={i} className="text-[8px] font-mono px-3 py-1 bg-black/40 border border-white/5 rounded-md text-white/40 group-hover:border-blue-500/20 transition-all">
                                {proof}
                            </span>
                        ))}
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className={cn(
                        "px-6 py-3 rounded-2xl border flex flex-col items-center justify-center",
                        report.verdict === 'SOVEREIGN_PASSED' ? "bg-green-500/10 border-green-500/30 text-green-500" : "bg-red-500/10 border-red-500/30 text-red-500"
                    )}>
                        <span className="text-[8px] font-black uppercase tracking-[0.2em] opacity-60 mb-1">System Verdict</span>
                        <span className="text-xs font-black uppercase tracking-widest">{report.verdict}</span>
                    </div>
                    <button className="h-12 w-12 bg-white flex items-center justify-center rounded-2xl hover:bg-blue-400 transition-all group/btn">
                        <Download className="w-5 h-5 text-black group-hover/btn:scale-110 transition-transform" />
                    </button>
                </div>
            </div>
        </div>
    );
}
