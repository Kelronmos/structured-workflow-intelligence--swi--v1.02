// src/components/common/StateGuard.tsx
import React, { ReactNode } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Loader2, ShieldAlert } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface StateGuardProps {
  status: 'loading' | 'warm' | 'live' | 'degraded' | 'error';
  children: ReactNode;
  errorLabel?: string;
  className?: string;
  onRetry?: () => void;
}

export function StateGuard({ status, children, errorLabel, className, onRetry }: StateGuardProps) {
  return (
    <div className={cn("relative min-h-[100px]", className)}>
      <AnimatePresence mode="wait">
        {status === 'loading' && (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-md rounded-3xl z-10 space-y-3 border border-white/5"
          >
            <div className="relative">
              <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
              <div className="absolute inset-0 blur-lg bg-blue-500/20 animate-pulse" />
            </div>
            <span className="text-[10px] font-bold text-white uppercase tracking-widest bg-blue-500/10 px-3 py-1 rounded-full border border-blue-500/20">Initializing Enclave...</span>
          </motion.div>
        )}

        {status === 'error' && (
          <motion.div
            key="error"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-xl rounded-3xl z-20 p-8 text-center space-y-6 border border-red-500/30"
          >
            <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center border border-red-500/20">
              <ShieldAlert className="w-8 h-8 text-red-500" />
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-black text-white uppercase tracking-[0.2em]">Kernel Panic Engaged</h3>
              <p className="text-[10px] text-white/50 font-mono max-w-[280px] leading-relaxed">
                {errorLabel || "Critical drift threshold exceeded. Execution halted to prevent state corruption."}
              </p>
            </div>
            {onRetry && (
               <button 
                onClick={onRetry}
                className="group flex items-center gap-3 px-6 py-3 bg-red-500 text-white rounded-full text-xs font-black uppercase tracking-widest hover:bg-red-600 transition-all active:scale-95 shadow-[0_0_20px_rgba(239,68,68,0.3)]"
               >
                 Force Reset Sequence
                 <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center group-hover:rotate-180 transition-transform">
                    <Loader2 className="w-2 h-2 animate-spin-slow" />
                 </div>
               </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <div className={cn(
        "transition-all duration-500",
        status === 'loading' || status === 'error' ? "blur-md pointer-events-none opacity-40" : "blur-0 opacity-100",
        status === 'degraded' ? "grayscale opacity-80" : ""
      )}>
        {children}
      </div>
      
      {status === 'degraded' && (
        <div className="absolute top-4 right-4 pointer-events-none">
          <div className="flex items-center gap-2 px-2 py-1 bg-orange-500/20 border border-orange-500/20 rounded-md">
            <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
            <span className="text-[8px] font-bold text-orange-500 uppercase">Degraded State</span>
          </div>
        </div>
      )}
    </div>
  );
}
