import React from "react";
import { cn } from "../../lib/utils";
import { Shield, ShieldAlert, Cpu } from "lucide-react";

export type TrustLevel = "SIMULATED" | "PARTIAL" | "VERIFIED";

interface TrustBadgeProps {
  level: TrustLevel;
  className?: string;
  tooltip?: string;
}

export function TrustBadge({ level, className, tooltip }: TrustBadgeProps) {
  const styles = {
    SIMULATED: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    PARTIAL: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    VERIFIED: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  };

  return (
    <div
      title={tooltip || `${level} Component`}
      className={cn(
        "inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] uppercase font-mono font-bold tracking-wider border",
        styles[level],
        className
      )}
    >
      {level === "SIMULATED" && <Cpu className="w-3 h-3" />}
      {level === "PARTIAL" && <ShieldAlert className="w-3 h-3" />}
      {level === "VERIFIED" && <Shield className="w-3 h-3" />}
      {level}
    </div>
  );
}
