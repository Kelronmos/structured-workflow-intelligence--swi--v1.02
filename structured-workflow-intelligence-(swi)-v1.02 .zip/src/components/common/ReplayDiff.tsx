import React, { useState } from 'react';
import { TraceStep, TraceDiff } from '../../../swi-core/kernel/ReplayEngine';
import { AlertTriangle, CheckCircle, FileDiff } from 'lucide-react';

interface ReplayDiffProps {
  originalTrace: TraceStep[];
  replayedTrace: TraceStep[];
  diffs: TraceDiff[];
  match: boolean;
}

export function ReplayDiff({ originalTrace, replayedTrace, diffs, match }: ReplayDiffProps) {
  return (
    <div className="mt-4 p-4 border border-gray-700 bg-gray-900 rounded-md text-white font-mono text-xs">
      <div className="flex items-center gap-2 mb-4 pb-2 border-b border-gray-700">
        <FileDiff className="w-5 h-5 text-blue-400" />
        <h3 className="font-bold uppercase tracking-widest text-sm">Replay Trace Diff</h3>
        {match ? (
          <span className="ml-auto flex items-center gap-1 text-green-400 bg-green-900/30 px-2 py-1 rounded">
            <CheckCircle className="w-3 h-3" /> PERFECT MATCH
          </span>
        ) : (
          <span className="ml-auto flex items-center gap-1 text-red-400 bg-red-900/30 px-2 py-1 rounded">
            <AlertTriangle className="w-3 h-3" /> DIVERGENCE DETECTED
          </span>
        )}
      </div>

      <div className="space-y-6">
        {originalTrace.map((orig, i) => {
          const rep = replayedTrace[i];
          const stepDiff = diffs.find(d => d.stepIndex === i);
          const hasDiff = !!stepDiff && stepDiff.divergenceDetected;

          return (
            <div key={i} className={`p-3 rounded border ${hasDiff ? 'border-red-500/50 bg-red-900/10' : 'border-gray-800 bg-black/20'}`}>
              <div className="flex justify-between text-gray-400 mb-2 border-b border-gray-800 pb-1">
                <span>Step {i} [ID: {orig?.entryId || rep?.entryId}]</span>
                <span>{hasDiff ? '❌ Mismatch' : '✅ Verified'}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {/* Original */}
                <div>
                  <h4 className="text-gray-500 mb-1 border-b border-gray-800 pb-1">Original Execution</h4>
                  {orig ? (
                    <div className="space-y-1">
                      <div><span className="text-gray-600">Hash:</span> {orig.hash.substring(0,16)}...</div>
                      <div><span className="text-gray-600">State:</span> {JSON.stringify(orig.stateAfter)}</div>
                      <div><span className="text-gray-600">Policy:</span> {orig.policyEvaluation || 'N/A'}</div>
                    </div>
                  ) : (
                    <div className="text-gray-600 italic">Missing in original</div>
                  )}
                </div>

                {/* Replay */}
                <div>
                  <h4 className="text-gray-500 mb-1 border-b border-gray-800 pb-1">Replayed Execution</h4>
                  {rep ? (
                    <div className="space-y-1">
                      <div><span className="text-gray-600">Hash:</span> {rep.hash.substring(0,16)}...</div>
                      <div><span className="text-gray-600">State:</span> {JSON.stringify(rep.stateAfter)}</div>
                      <div><span className="text-gray-600">Policy:</span> {rep.policyEvaluation || 'N/A'}</div>
                    </div>
                  ) : (
                    <div className="text-gray-600 italic">Missing in replay</div>
                  )}
                </div>
              </div>

              {hasDiff && (
                <div className="mt-3 pt-2 border-t border-red-900/30">
                  <span className="text-red-400 font-bold mb-1 block">Divergence Details:</span>
                  <ul className="list-disc list-inside text-red-300 pl-2">
                    {stepDiff.differences.map((d, idx) => (
                      <li key={idx}>
                        <span className="font-bold">{d.field}:</span> {JSON.stringify(d.liveValue)} ≠ {JSON.stringify(d.replayValue)}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
