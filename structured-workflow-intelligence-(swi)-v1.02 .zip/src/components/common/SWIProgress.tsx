import React from 'react';
import { cn } from '@/src/lib/utils';

interface SWIProgressProps {
  percent: number;
  className?: string;
  indicatorClassName?: string;
}

export const SWIProgress: React.FC<SWIProgressProps> = ({ percent, className, indicatorClassName }) => {
  return (
    <div className={cn("relative w-full h-2 overflow-hidden bg-white/10 rounded-full", className)}>
      <div
        className={cn(
          "absolute left-0 top-0 bottom-0 rounded-full bg-gradient-to-r from-[#00D4FF] via-[#2563EB] to-[#00FF88] transition-all duration-300 ease-out",
          indicatorClassName
        )}
        style={{ width: `${Math.min(100, Math.max(0, percent))}%` }}
      />
    </div>
  );
};
