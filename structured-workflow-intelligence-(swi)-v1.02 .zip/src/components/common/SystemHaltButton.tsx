import React, { useState } from "react";
import { useExecutionGate } from "../../hooks/useExecutionGate";
import { useSystemStore, SystemState } from "../../lib/systemStore";
import { ShieldAlert, Fingerprint, Loader2 } from "lucide-react";

export const SystemHaltButton: React.FC<{ className?: string }> = ({ className }) => {
  const { system, setSystem } = useSystemStore();
  const { isHalted } = useExecutionGate();
  const [loading, setLoading] = useState(false);

  const updateState = async (newState: SystemState, reason: string) => {
    setLoading(true);
    try {
      const response = await fetch("/api/system/control", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ state: newState, reason, user: "UI_ADMIN_OVERRIDE" }),
      });
      if (response.ok) {
        setSystem({
          state: newState,
          timestamp: Date.now(),
          reason,
          triggeredBy: "UI_ADMIN_OVERRIDE",
        });
      }
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to update system state", e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`flex flex-col gap-2 ${className}`}>
      {isHalted ? (
        <button
          onClick={() => {
            if (confirm("Confirm system resume? Requires high clearance.")) {
                updateState("LIVE", "Manual clear");
            }
          }}
          disabled={loading}
          className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/40 text-emerald-500 hover:bg-emerald-500/20 px-4 py-2 rounded-lg font-mono text-sm tracking-widest transition-all disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Fingerprint className="w-4 h-4" />}
          RESUME EXECUTION
        </button>
      ) : (
        <button
          onClick={() => {
            if (confirm("DANGER: Confirm system halt? This freezes the entire runtime pipeline end-to-end.")) {
                updateState("HALTED", "Emergency manual trigger");
            }
          }}
          disabled={loading}
          className="flex items-center gap-2 bg-rose-500/20 border-2 border-rose-500 text-rose-500 hover:bg-rose-500 hover:text-black px-4 py-3 rounded-lg font-mono font-bold tracking-widest transition-all shadow-[0_0_15px_rgba(244,63,94,0.5)] disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ShieldAlert className="w-5 h-5 animate-pulse" />}
          SYSTEM HALT
        </button>
      )}
      
      {isHalted && (
        <span className="text-xs font-mono text-rose-400 opacity-80 mt-1">
          EXECUTION BLOCKED. ALL APIS DISABLED.
        </span>
      )}
    </div>
  );
};
