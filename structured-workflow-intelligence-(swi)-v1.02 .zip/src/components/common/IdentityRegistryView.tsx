import React from 'react';
import { Fingerprint, Globe, Building2, MapPin, Mail } from 'lucide-react';
import { SWI_IDENTITY, TRUSTS_MOTION_IDENTITY, generateSystemIdentifier } from '../../registry/IdentityRegistry';

export function IdentityRegistryView() {
  return (
    <div className="bg-[#111] border border-[#333] rounded-xl p-6 font-mono text-gray-300">
      <div className="flex justify-between items-center mb-6 border-b border-[#333] pb-4">
        <div>
          <h3 className="text-lg font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
            <Fingerprint className="w-5 h-5" /> Master Registry Snapshot
          </h3>
          <p className="text-xs text-gray-500 mt-1">SWI Identity & Naming Standard Version Enforcement.</p>
        </div>
        <div className="bg-blue-500/10 border border-blue-500/30 text-blue-400 px-3 py-1 rounded text-xs font-bold shadow-lg">
          v{SWI_IDENTITY.version} BASELINE
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Core System Def */}
        <div className="space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-widest text-emerald-400 mb-3 flex items-center gap-2 border-b border-emerald-500/20 pb-2">
            <Globe className="w-4 h-4" /> System Definition
          </h4>
          
          <div className="bg-black border border-[#222] p-4 rounded space-y-3">
            <div className="flex justify-between items-center pb-2 border-b border-[#1A1A1A]">
               <span className="text-[10px] text-gray-500 uppercase font-bold">Canonical ID</span>
               <span className="text-xs text-blue-400 font-bold">{generateSystemIdentifier('TrustsMotion', 'SWI', 'Core')}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b border-[#1A1A1A]">
               <span className="text-[10px] text-gray-500 uppercase font-bold">System Name</span>
               <span className="text-xs text-gray-300">{SWI_IDENTITY.name}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b border-[#1A1A1A]">
               <span className="text-[10px] text-gray-500 uppercase font-bold">Version</span>
               <span className="text-xs text-emerald-400 font-bold">v{SWI_IDENTITY.version}</span>
            </div>
            <div className="flex justify-between items-center">
               <span className="text-[10px] text-gray-500 uppercase font-bold">Architecture</span>
               <span className="text-[10px] text-purple-400 uppercase text-right max-w-[150px]">{SWI_IDENTITY.architecture}</span>
            </div>
          </div>
        </div>

        {/* Canonical Organization */}
        <div className="space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-widest text-purple-400 mb-3 flex items-center gap-2 border-b border-purple-500/20 pb-2">
            <Building2 className="w-4 h-4" /> Canonical Identity
          </h4>

          <div className="bg-black border border-[#222] p-4 rounded space-y-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Building2 className="w-4 h-4 text-purple-500 opacity-70" />
                <div>
                   <div className="text-[10px] text-gray-500 uppercase font-bold">Legal / Trading Name</div>
                   <div className="text-xs text-gray-300">{TRUSTS_MOTION_IDENTITY.legal_name} (Trading as {TRUSTS_MOTION_IDENTITY.trading_name})</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-purple-500 opacity-70" />
                <div>
                   <div className="text-[10px] text-gray-500 uppercase font-bold">Official Contact</div>
                   <div className="text-xs text-gray-300">{TRUSTS_MOTION_IDENTITY.email}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-purple-500 opacity-70" />
                <div>
                   <div className="text-[10px] text-gray-500 uppercase font-bold">Physical Registry</div>
                   <div className="text-xs text-gray-300">{TRUSTS_MOTION_IDENTITY.address}</div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-[#1A1A1A]">
              <div className="text-[10px] text-gray-500 uppercase font-bold mb-2">Canonical Domains</div>
              <div className="flex flex-col gap-2">
                 <div className="flex justify-between items-center text-[10px] bg-[#111] border border-[#222] p-1.5 rounded">
                   <span className="text-gray-400 uppercase">Public Org Layer</span>
                   <span className="text-blue-400">{TRUSTS_MOTION_IDENTITY.domains.official}</span>
                 </div>
                 <div className="flex justify-between items-center text-[10px] bg-[#111] border border-[#222] p-1.5 rounded">
                   <span className="text-gray-400 uppercase">Intelligence Layer</span>
                   <span className="text-emerald-400">{TRUSTS_MOTION_IDENTITY.domains.swi}</span>
                 </div>
                 <div className="flex justify-between items-center text-[10px] bg-[#111] border border-[#222] p-1.5 rounded">
                   <span className="text-gray-400 uppercase">SAMH Ecosystem</span>
                   <span className="text-purple-400">{TRUSTS_MOTION_IDENTITY.domains.samh}</span>
                 </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
