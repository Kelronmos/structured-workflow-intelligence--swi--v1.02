import React, { useState } from "react";
import { 
  FileJson, 
  ShieldCheck, 
  History, 
  Users, 
  AlertOctagon,
  Download,
  CheckCircle2,
  Lock
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function CryptographicProofsView() {
  const [activeTab, setActiveTab] = useState<"ATTESTATION" | "REPLAY" | "GOVERNANCE" | "ISOLATION">("ATTESTATION");

  const proofs = {
    ATTESTATION: {
      title: "Attestation Artifact",
      icon: <ShieldCheck className="w-5 h-5" />,
      color: "emerald",
      desc: "Baseline invariant proof that a runtime executed nominally.",
      code: `{
  "runtime_id": "SWI-Node-01",
  "state_hash": "sha256:8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4",
  "timestamp": "2026-05-13T22:10:00Z",
  "validator_signature": "ed25519:7b6f...c3a9",
  "drift_score": 12,
  "status": "NOMINAL"
}`
    },
    REPLAY: {
      title: "Replay Snapshot",
      icon: <History className="w-5 h-5" />,
      color: "blue",
      desc: "Deterministic event history for provenance verification and state continuity.",
      code: `{
  "snapshot_id": "REP-2026-05-14A",
  "genesis_hash": "sha256:d04b98f48e8f81a5fc0d...0192e",
  "terminal_hash": "sha256:a8f5f167f44f4964e6c9...f9a45",
  "events_count": 450,
  "replay_verification": {
    "computed_hash": "sha256:a8f5f167f44f4964e6c9...f9a45",
    "match": true
  },
  "signature": "rsa-4096:b93c...01af"
}`
    },
    GOVERNANCE: {
      title: "Governance Proof",
      icon: <Users className="w-5 h-5" />,
      color: "purple",
      desc: "Authority chain, approval signatures, and escalation traces.",
      code: `{
  "intervention_id": "GOV-INT-992",
  "reason": "Ethical constraint violation prediction",
  "authority_chain": [
    {"node": "Automated Reflex Engine", "action": "HALT"},
    {"node": "Human Oversight Node-AB", "action": "REVIEW"},
    {"node": "Governance Committee", "action": "OVERRIDE"}
  ],
  "quorum_reached": true,
  "approved_by": ["ed25519:11a...", "ed25519:b23..."],
  "escalation_trace": "ref://audit/trace/GOV-INT-992",
  "new_policy_hash": "sha256:f12a...77b1"
}`
    },
    ISOLATION: {
      title: "Isolation Proof",
      icon: <AlertOctagon className="w-5 h-5" />,
      color: "red",
      desc: "Immutable record of a drift threshold breach and subsequent containment.",
      code: `{
  "alert_id": "ISO-REFLEX-001",
  "trigger_source": "SWI Monitor Engine",
  "drift_threshold_exceeded": {
    "allowed_max": 50,
    "actual": 82
  },
  "affected_dependencies": [
    "module.decision_tree.v4",
    "module.policy_evaluator.v2"
  ],
  "preserved_evidence_hashes": [
    "sha256:ee89...9912",
    "sha256:ba12...8834"
  ],
  "containment_status": "LOCKED",
  "timestamp": "2026-05-14T13:45:00Z"
}`
    }
  };

  const activeData = proofs[activeTab];

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="bg-[#050510] border border-emerald-500/20 p-6 md:p-8 flex items-center justify-between overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 blur-[120px] pointer-events-none"></div>
        <div className="relative z-10 w-full">
           <h2 className="text-xl md:text-2xl font-black uppercase tracking-widest text-[#E4E3E0] flex items-center gap-3">
              <FileJson className="w-6 h-6 text-emerald-500" /> Cryptographic Artifacts & Proofs
           </h2>
           <p className="text-xs font-mono text-emerald-300/60 mt-2 max-w-3xl leading-relaxed">
              SWI v3.5 validates governance continuity through deterministic, auditable JSON objects. 
              The architecture becomes defensible when every action is observable, attributable, and independently verifiable.
           </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {Object.entries(proofs).map(([key, data]) => {
          const isActive = activeTab === key;
          const bgColors = {
             emerald: "bg-emerald-500/10 border-emerald-500/30 text-emerald-400",
             blue: "bg-blue-500/10 border-blue-500/30 text-blue-400",
             purple: "bg-purple-500/10 border-purple-500/30 text-purple-400",
             red: "bg-red-500/10 border-red-500/30 text-red-400"
          };
          
          return (
            <button
              key={key}
              onClick={() => setActiveTab(key as any)}
              className={cn(
                "p-4 border rounded-xl flex items-center justify-center gap-3 transition-all font-bold text-[10px] uppercase tracking-wider relative overflow-hidden",
                isActive ? bgColors[data.color as keyof typeof bgColors] : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10"
              )}
            >
               {isActive && (
                 <div className={cn("absolute inset-0 opacity-20 blur-xl", bgColors[data.color as keyof typeof bgColors].split(" ")[0])}></div>
               )}
               <span className="relative z-10">{data.icon}</span>
               <span className="relative z-10">{data.title}</span>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative">
         <div className="bg-[#141414] border border-white/10 p-6 rounded-xl animate-in slide-in-from-left-4">
            <h3 className={cn(
               "text-xl font-black uppercase tracking-widest mb-2 flex items-center gap-2",
               activeTab === "ATTESTATION" ? "text-emerald-400" :
               activeTab === "REPLAY" ? "text-blue-400" :
               activeTab === "GOVERNANCE" ? "text-purple-400" :
               "text-red-400"
            )}>
               {activeData.icon} {activeData.title}
            </h3>
            <p className="text-[11px] font-mono text-white/60 mb-6 pb-4 border-b border-white/10">
               {activeData.desc}
            </p>
            
            <div className="bg-black/80 p-4 rounded-lg font-mono text-[10px] text-white/80 overflow-x-auto border border-white/5 relative group">
               <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="bg-white/10 hover:bg-white/20 p-2 rounded text-white transition-colors">
                     <Download className="w-3 h-3" />
                  </button>
               </div>
               <pre className="leading-relaxed">
                  <code dangerouslySetInnerHTML={{
                     __html: activeData.code.replace(/"(.*?)":/g, '<span class="text-blue-400">"$1"</span>:').replace(/: "(.*?)"/g, ': <span class="text-emerald-400">"$1"</span>').replace(/: ([0-9]+)/g, ': <span class="text-amber-400">$1</span>').replace(/: (true|false)/g, ': <span class="text-fuchsia-400">$1</span>')
                  }}></code>
               </pre>
            </div>
         </div>

         <div className="bg-[#050505] border border-white/10 p-6 rounded-xl flex flex-col justify-center animate-in slide-in-from-right-4">
            <div className="text-center mb-8">
               <Lock className="w-12 h-12 text-white/10 mx-auto mb-4" />
               <h4 className="text-xs font-bold uppercase tracking-widest text-[#E4E3E0] mb-2">Formal Semantics Grounding</h4>
               <p className="text-[10px] font-mono text-white/50 max-w-sm mx-auto leading-relaxed">
                  Without formal semantics, operators may interpret state differently. Once interpretation diverges, governance continuity weakens.
               </p>
            </div>
            
            <div className="space-y-3 px-8">
               <div className="flex gap-3 items-center text-[10px] font-mono border-b border-white/10 pb-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span className="text-white/70">Every governance action is observable.</span>
               </div>
               <div className="flex gap-3 items-center text-[10px] font-mono border-b border-white/10 pb-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span className="text-white/70">Every escalation is attributable.</span>
               </div>
               <div className="flex gap-3 items-center text-[10px] font-mono border-b border-white/10 pb-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span className="text-white/70">Every transition is replayable.</span>
               </div>
               <div className="flex gap-3 items-center text-[10px] font-mono">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span className="text-emerald-400 font-bold">Every proof is independently verifiable.</span>
               </div>
            </div>
         </div>
      </div>
      
      <div className="flex justify-center mt-6">
         <ProofArtifacts
            id="artifacts-proofs"
            title="SWI Formal Artifacts Demo"
            data={{
               artifact_type: activeTab,
               status: "MATURING",
               formal_semantics: "DEFINED"
            }}
            variant="default"
         />
      </div>
    </div>
  );
}
