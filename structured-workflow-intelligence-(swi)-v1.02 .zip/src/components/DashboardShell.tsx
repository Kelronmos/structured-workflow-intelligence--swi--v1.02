import React, { useState } from 'react';
import { 
  Database, 
  ShieldCheck, 
  Lock, 
  Cpu, 
  FileSearch, 
  TestTube,
  Bell,
  Settings,
  Search,
  User,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

const navItems = [
  { id: 'truth-kernel', label: 'Truth Kernel', icon: Database },
  { id: 'governance', label: 'Governance', icon: ShieldCheck },
  { id: 'security', label: 'Security', icon: Lock },
  { id: 'firefly', label: 'Firefly', icon: Cpu },
  { id: 'audit', label: 'Audit', icon: FileSearch },
  { id: 'research', label: 'Research', icon: TestTube },
];

export function DashboardShell({ children }: { children?: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [activeItem, setActiveItem] = useState('truth-kernel');

  return (
    <div className="flex h-screen bg-swi-bg text-swi-text font-sans selection:bg-swi-accent/30 overflow-hidden">
      {/* Sidebar */}
      <aside 
        className={`flex flex-col bg-swi-surface border-r border-swi-border transition-all duration-300 ${
          collapsed ? 'w-16' : 'w-64'
        }`}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b border-swi-border shrink-0">
          {!collapsed && (
            <div className="flex items-center gap-2 font-mono font-medium text-swi-text tracking-wider text-sm">
              <ShieldCheck className="w-5 h-5 text-swi-accent" />
              <span>SWI_GOV_DASH</span>
            </div>
          )}
          {collapsed && (
             <ShieldCheck className="w-5 h-5 mx-auto text-swi-accent" />
          )}
          <button 
            onClick={() => setCollapsed(!collapsed)}
            className="p-1 hover:bg-swi-surface-hover rounded text-swi-text-muted hidden md:block"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        <nav className="flex-1 py-4 flex flex-col gap-1 px-2 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeItem === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveItem(item.id)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded transition-colors group ${
                  isActive 
                    ? 'bg-swi-accent/10 text-swi-accent' 
                    : 'text-swi-text-muted hover:bg-swi-surface-hover hover:text-swi-text'
                } ${collapsed ? 'justify-center' : ''}`}
                title={collapsed ? item.label : undefined}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-swi-accent' : 'text-swi-text-muted group-hover:text-swi-text'}`} />
                {!collapsed && <span className="text-sm font-medium tracking-wide">{item.label}</span>}
              </button>
            )
          })}
        </nav>

        <div className="p-4 border-t border-swi-border shrink-0">
          <div className={`flex items-center gap-3 ${collapsed ? 'justify-center' : ''}`}>
            <div className="w-8 h-8 rounded bg-swi-surface-hover flex items-center justify-center shrink-0 border border-swi-border">
              <User className="w-4 h-4 text-swi-text-muted" />
            </div>
            {!collapsed && (
              <div className="flex flex-col text-left flex-1 min-w-0">
                <span className="text-xs font-medium truncate">Admin User</span>
                <span className="text-[10px] text-swi-text-muted font-mono truncate">SYS_AUTH_OK</span>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 bg-swi-bg">
        <header className="h-16 flex items-center justify-between px-6 bg-swi-surface/50 border-b border-swi-border backdrop-blur-sm shrink-0">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-medium text-swi-text">
              {navItems.find(i => i.id === activeItem)?.label || 'Dashboard'}
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative hidden sm:block">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-swi-text-muted" />
              <input 
                type="text" 
                placeholder="Search resources..." 
                className="bg-swi-surface border border-swi-border rounded pl-9 pr-4 py-1.5 text-sm focus:outline-none focus:border-swi-accent/50 w-64 text-swi-text placeholder-swi-text-muted font-mono"
              />
            </div>
            <button className="p-2 hover:bg-swi-surface rounded relative text-swi-text-muted hover:text-swi-text transition-colors">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-swi-accent rounded-full"></span>
            </button>
            <button className="p-2 hover:bg-swi-surface rounded text-swi-text-muted hover:text-swi-text transition-colors">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </header>
        
        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto h-full">
            {children || (
              <div className="flex items-center justify-center h-full border border-dashed border-swi-border rounded-lg bg-swi-surface/30">
                <div className="text-center space-y-2">
                  <Cpu className="w-8 h-8 text-swi-text-muted mx-auto" />
                  <p className="text-swi-text-muted font-mono text-sm">Waiting for {navItems.find(i => i.id === activeItem)?.label} module...</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
