import React from "react";
import {
  FolderTree,
  ShieldCheck,
  Brain,
  Scale,
  AlertOctagon,
  Eye,
  CheckCircle2,
  FileCode2,
  Activity,
  PackageCheck
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function RepositoryBlueprintView() {
  const repoStructure = `swi-core/
│
├── README.md
├── LICENSE
├── SECURITY.md
├── GOVERNANCE.md
├── CONTRIBUTING.md
├── SWI_MANIFEST.json
│
├── docs/               # Architecture, Safety, Threat Models
├── kernel/             # Integrity, Governance, Reflection
├── modules/            # P/, S/, G/, L/, H/, O/
├── policies/           # Human-Safety, Escalation, Halt
├── validators/         # Quorum, Signatures, Replay
├── audit/              # Immutable-Logs, State-Proofs
├── simulations/        # Adversarial, Recovery
├── runtime/            # Manifests, Measurements
├── dashboards/         # Governance, Observability
├── crypto/             # Merkle, Attestations
├── tests/              # Integrity, Replay, Adversarial
└── deployment/         # Docker, Secure-Boot
`;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full">
          <div className="flex items-center gap-3">
            <FolderTree className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              SWI Foundation Repository Blueprint
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-80 max-w-3xl text-emerald-100/70 border-l-2 border-emerald-500/50 pl-3">
            A human-centered governance, observability, safety, and integrity framework structured for accountability, verification, reflection, continuity, and safe bounded execution.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Repository Structure */}
        <div className="lg:col-span-1 bg-[#141414] border border-white/10 p-5 flex flex-col h-full">
           <div className="flex items-center gap-2 text-blue-400 border-b border-white/10 pb-3 mb-4">
              <FileCode2 className="w-4 h-4" />
              <h3 className="text-[11px] font-bold uppercase tracking-widest">
                Production-Oriented Layout
              </h3>
           </div>
           <div className="flex-1 bg-black/50 border border-white/5 p-4 rounded-sm overflow-x-auto text-[9px] font-mono text-emerald-400/80 leading-relaxed whitespace-pre">
             {repoStructure}
           </div>
        </div>

        {/* Core Philosophy & Phases */}
        <div className="lg:col-span-2 space-y-6">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-[#141414] border border-white/10 p-5">
                 <h4 className="text-[10px] font-bold text-amber-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <Brain className="w-3 h-3" /> Core Philosophy
                 </h4>
                 <ul className="space-y-3 text-[9px] font-mono text-white/60">
                    <li><span className="font-bold text-white">1. Humans Remain Central: </span><br/>HumanDignity &gt; AutonomousEfficiency</li>
                    <li><span className="font-bold text-white">2. Reflection Before Escalation: </span><br/>The SWI "3-Minute Reflection Gate."</li>
                    <li><span className="font-bold text-white">3. Integrity Before Capability: </span><br/>Prove what executed, who approved, replay integrity.</li>
                    <li><span className="font-bold text-white">4. Structure Over Chaos: </span><br/>Organized relationships, bounded interaction.</li>
                 </ul>
              </div>

              <div className="bg-[#141414] border border-white/10 p-5">
                 <h4 className="text-[10px] font-bold text-fuchsia-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                    <Activity className="w-3 h-3" /> Observability Model
                 </h4>
                 <p className="text-[9px] font-mono text-white/60 leading-relaxed mb-3">
                   Treated as continuity evidence, operational memory, replay capability, and integrity visibility.
                 </p>
                 <div className="bg-black/40 border border-white/5 p-3 text-[8px] font-mono text-fuchsia-200/70 space-y-1">
                    <div>MUST EXPOSE:</div>
                    <div>• Degraded states</div>
                    <div>• Failed checks</div>
                    <div>• Missing attestations</div>
                    <div>• Uncertainty</div>
                    <div>• Policy conflicts</div>
                 </div>
              </div>
           </div>

           {/* Phases Overview */}
           <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
              <h4 className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                 <ShieldCheck className="w-3 h-3" /> Phase Foundation Model
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                 <div className="bg-cyan-950/20 border border-cyan-500/20 p-3">
                    <div className="text-[9px] font-bold text-cyan-400 uppercase mb-1">Phase 1: Integrity</div>
                    <div className="text-[8px] font-mono text-white/50 mb-2">Deterministic execution, immutable trace.</div>
                    <div className="text-[8px] font-mono bg-black/50 p-1 text-cyan-200/50">State_t = H(State_t-1 || Event_t || Policy_t)</div>
                 </div>
                 <div className="bg-cyan-950/20 border border-cyan-500/20 p-3">
                    <div className="text-[9px] font-bold text-cyan-400 uppercase mb-1">Phase 2: Verification</div>
                    <div className="text-[8px] font-mono text-white/50 mb-2">Independent trust validation.</div>
                    <div className="text-[8px] font-mono bg-black/50 p-1 text-cyan-200/50">Σ ValidatorSigs &gt;= QuorumThreshold</div>
                 </div>
                 <div className="bg-cyan-950/20 border border-cyan-500/20 p-3">
                    <div className="text-[9px] font-bold text-cyan-400 uppercase mb-1">Phase 3: Reflection</div>
                    <div className="text-[8px] font-mono text-white/50 mb-2">Prevent reactive escalation.</div>
                    <div className="text-[8px] font-mono bg-black/50 p-1 text-cyan-200/50">REQUEST &rarr; HOLD &rarr; REVIEW &rarr; EXECUTE</div>
                 </div>
              </div>
           </div>
        </div>

      </div>

      {/* Safety & Halt Principles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         <div className="bg-[#141414] border border-white/10 p-5">
            <h4 className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-3 flex items-center gap-2">
               <CheckCircle2 className="w-3 h-3" /> Safety Principles (Allowed)
            </h4>
            <div className="flex flex-wrap gap-2 text-[9px] font-mono text-emerald-200/80">
               <span className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-1">Halt</span>
               <span className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-1">Isolate</span>
               <span className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-1">Degrade Safely</span>
               <span className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-1">Request Review</span>
               <span className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-1">Rollback</span>
               <span className="bg-emerald-500/10 border border-emerald-500/20 px-2 py-1">Refuse Unsafe Execution</span>
            </div>
         </div>
         
         <div className="bg-[#141414] border border-white/10 p-5">
            <h4 className="text-[10px] font-bold text-red-500 uppercase tracking-widest mb-3 flex items-center gap-2">
               <AlertOctagon className="w-3 h-3" /> Disallowed Behaviors
            </h4>
            <div className="flex flex-wrap gap-2 text-[9px] font-mono text-red-300/80">
               <span className="bg-red-500/10 border border-red-500/20 px-2 py-1">Silent Escalation</span>
               <span className="bg-red-500/10 border border-red-500/20 px-2 py-1">Hidden Authority</span>
               <span className="bg-red-500/10 border border-red-500/20 px-2 py-1">Unverifiable Execution</span>
               <span className="bg-red-500/10 border border-red-500/20 px-2 py-1">False Certainty</span>
               <span className="bg-red-500/10 border border-red-500/20 px-2 py-1">Coercive Governance</span>
            </div>
         </div>
      </div>

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-emerald-500/30 mt-6 flex flex-col items-center text-center">
         <p className="text-[10px] font-mono text-white/50 max-w-4xl italic leading-relaxed mb-4">
            "Technology reflects human structure. If systems are built too fast, without reflection, without accountability, or without human grounding, then automation amplifies instability."
         </p>
         <ProofArtifacts
            id="repository-blueprint"
            title="SWI Architecture Blueprint Verification"
            data={{
               type: "Foundation Layout",
               priorities: "Continuity, Reflection, Observability, Governance, Human-Centered Restraint",
               status: "ACTIVE_SPEC"
            }}
            variant="always-dark"
         />
      </div>

    </div>
  );
}
