import React, { useState, useEffect, useCallback } from "react";
import { motion } from "motion/react";
import {
  Database,
  Activity,
  CheckCircle,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Layers,
  FileText,
  Brain as BrainIcon,
  Zap,
  Fingerprint,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { socket } from "@/src/lib/socket";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface Task {
  id: string;
  title: string;
  priority: string;
  dueDate: string;
  completed: boolean;
  assignedTo: string;
  standingRequired: string;
  guild: "SECURITY" | "ETHICS" | "GOVERNANCE" | "LAW" | "SAFETY";
  reportJson: string;
  reportPdf: string;
}

interface ContinuityData {
  normalizedPoC: number;
  transparency?: number;
  traceability?: number;
  groundWeights: Record<string, number>;
  integrityScore: number;
  modules: Record<
    string,
    {
      status: string;
      confidence: number;
      telemetry: boolean;
      replayable: boolean;
      dependencies: string[];
    }
  >;
  executionProofs?: {
    traceHash: string;
    merkleRoot: string;
    bloomFilter: string;
  };
  safetyInterlock?: {
    isHaltTriggered: boolean;
    harmPotential: number;
    irreversibilityIndex: number;
    requiredSignatures: number;
    pendingApprovals: string[];
    challengeActive: boolean;
    currentQuestionIndex: number;
    failedAttempts: number;
  };
}

interface StressTestResult {
  userId: string;
  action: string;
  status: "ALLOWED" | "BLOCKED" | "HALTED" | "ESCALATED";
  accuracy: number;
  drift: number;
  timestamp: number;
}

interface ReplayProof {
  traceId: string;
  runtimeHash: string;
  stateOrigin: string;
  driftScore: number;
  reverseSolve?: {
    factor: string;
    recoveredValue: number;
    confidence: number;
  };
  consensus: string;
  timestamp: number;
}

interface KernelEvent {
  eventId: string;
  type: string;
  payload: Record<string, unknown> | null;
  tick: number;
  hash: string;
  prevHash: string;
  swiProof?: {
    pi_a: string[];
    pi_b: string[][];
    pi_c: string[];
    protocol: string;
    curve: string;
    publicSignals: string[];
  };
}

export default function ProductionKernelView() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [events, setEvents] = useState<KernelEvent[]>([]);
  const [continuity, setContinuity] = useState<ContinuityData | null>(null);
  const [replayProof, setReplayProof] = useState<ReplayProof | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSafetyModal, setShowSafetyModal] = useState(false);
  const [showChallengeModal, setShowChallengeModal] = useState(false);
  const [challengeAnswer, setChallengeAnswer] = useState("");
  const [challengeMessage, setChallengeMessage] = useState("");
  const [signature, setSignature] = useState("");
  const [isSigning, setIsSigning] = useState(false);
  const [stressResults, setStressResults] = useState<StressTestResult[]>([]);
  const [isStressing, setIsStressing] = useState(false);

  const fetchContinuity = useCallback(async () => {
    try {
      const cRes = await fetch("/api/swi/continuity");
      if (cRes.ok) {
        const data = await cRes.json();
        setContinuity(data);
        if (data.safetyInterlock?.challengeActive && !showChallengeModal) {
          setShowChallengeModal(true);
          setChallengeMessage(
            "SWI 3-Question Challenge Active. Intent verification required.",
          );
        }
      }
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch continuity", e);
    }
  }, [showChallengeModal]);

  const submitChallengeAnswer = async () => {
    if (!challengeAnswer) return;
    try {
      const res = await fetch("/api/swi/safety/challenge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answer: challengeAnswer }),
      });
      const data = await res.json();
      setChallengeMessage(data.message);
      setChallengeAnswer("");
      if (data.finished) {
        setTimeout(() => {
          setShowChallengeModal(false);
          fetchContinuity();
        }, 2000);
      }
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    }
  };

  const runStressTest = async () => {
    setIsStressing(true);
    try {
      const res = await fetch("/api/swi/red-team/stress-test", {
        method: "POST",
      });
      const data = await res.json();
      setStressResults(data.results);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setIsStressing(false);
    }
  };

  const approveSafety = async () => {
    if (!signature.startsWith("SWI-SIG-")) {
      alert("Invalid Biometric Signature format. Must start with 'SWI-SIG-'");
      return;
    }
    setIsSigning(true);
    try {
      const res = await fetch("/api/swi/safety/approve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ signature, partyId: "USER_DASHBOARD_ADMIN" }),
      });
      const data = await res.json();
      if (data.success) {
        setShowSafetyModal(false);
        setSignature("");
        fetchContinuity();
      } else {
        alert("Approval rejected by SWI Kernel.");
      }
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setIsSigning(false);
    }
  };

  const exportEvidence = async (eventId: string) => {
    try {
      const res = await fetch(`/api/swi/legal/evidence/${eventId}`);
      const data = await res.json();
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `SWI_LEGAL_PROOF_${eventId}.json`;
      a.click();
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Legal export failed", e);
    }
  };

  const runPoR = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/swi/replay/proof");
      const data = await res.json();
      setReplayProof(data);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [tasksRes, ledgerRes] = await Promise.all([
          fetch("/api/tasks"),
          fetch("/api/v3/ledger"),
        ]);
        const tasksData = await tasksRes.json();
        const ledgerData = await ledgerRes.json();

        setTasks(tasksData);
        // Ledger is usually an array of block-like objects, we want the events
        const allEvents = ledgerData
          .filter((item: Record<string, unknown>) => item.event)
          .map((item: Record<string, unknown>) => item.event as KernelEvent)
          .reverse();
        setEvents(allEvents);
        fetchContinuity();
      } catch (e) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch kernel data", e);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // WebSocket Listeners
    socket.on("task_update", (updatedTask: Task) => {
      setTasks((prev) =>
        prev.map((t) => (t.id === updatedTask.id ? updatedTask : t)),
      );
    });

    socket.on("kernel_event", (event: KernelEvent) => {
      setEvents((prev) => [event, ...prev]);
    });

    return () => {
      socket.off("task_update");
      socket.off("kernel_event");
    };
  }, [fetchContinuity]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* 🏛️ SWI MULTI-PLANE ARCHITECTURAL FOUNDATION */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {[
          {
            name: "Control Plane",
            icon: BrainIcon,
            color: "text-blue-400",
            desc: "Policy & Fail-Closed Logic",
            integrity: 99.8,
          },
          {
            name: "Execution Plane",
            icon: Zap,
            color: "text-amber-400",
            desc: "Sandboxed Task Processing",
            integrity: 98.4,
          },
          {
            name: "Audit Plane",
            icon: Fingerprint,
            color: "text-purple-400",
            desc: "Immutable Traceability",
            integrity: 100.0,
          },
        ].map((plane) => (
          <div
            key={plane.name}
            className="p-4 bg-white/5 border border-white/10 rounded-xl space-y-3 hover:bg-white/[0.07] transition-all"
          >
            <div className="flex justify-between items-start">
              <div className="p-2 bg-black/40 rounded-lg border border-white/5">
                <plane.icon className={cn("w-5 h-5", plane.color)} />
              </div>
              <div className="text-right">
                <div className="text-[10px] font-black font-mono text-white">
                  {plane.integrity.toFixed(1)}%
                </div>
                <div className="text-[8px] text-zinc-500 uppercase font-black tracking-widest">
                  Integrity
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-xs font-black uppercase tracking-tight text-white">
                {plane.name}
              </h3>
              <p className="text-[9px] text-zinc-500 font-serif italic">
                {plane.desc}
              </p>
            </div>
            <div className="w-full h-1 bg-black/40 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${plane.integrity}%` }}
                className={cn("h-full", plane.color.replace("text", "bg"))}
              />
            </div>
          </div>
        ))}
      </div>

      {/* ⏱️ THE "3-MINUTE FIX" INTEGRATION PROTOCOL */}
      <div className="p-6 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-emerald-600/10 border-y border-white/10 relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5 pointer-events-none" />
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-sm font-black uppercase tracking-[0.2em] text-white">
              SWI Protocol: The 3-Minute Fix
            </h3>
            <p className="text-[10px] text-zinc-400 max-w-lg font-serif italic leading-relaxed">
              "Moving from simple automation to high-integrity, policy-enforced
              orchestration." - Gaborone Standard v6.0
            </p>
          </div>
          <div className="grid grid-cols-3 gap-4 md:gap-8">
            {[
              {
                label: "Transparency",
                code: "TRANS_01",
                desc: "Reasoning Disclosure",
              },
              {
                label: "Data Quality",
                code: "SWI-G2-COORD",
                desc: "Pre-Execution Verify",
              },
              {
                label: "Human SME",
                code: "SAFE_004",
                desc: "Biometric Handshake",
              },
            ].map((step) => (
              <div key={step.label} className="text-center space-y-1">
                <div className="text-[9px] font-black text-white uppercase tracking-widest">
                  {step.label}
                </div>
                <div className="text-[8px] font-mono text-blue-400">
                  {step.code}
                </div>
                <div className="text-[7px] text-zinc-500 uppercase font-black">
                  {step.desc}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 🚨 SAFETY INTERLOCK OVERLAY */}
      {continuity?.safetyInterlock?.isHaltTriggered && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-4 bg-red-600/20 border-2 border-red-600 rounded-xl flex flex-col md:flex-row items-center gap-6 justify-between"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-600 rounded-full animate-pulse">
              <ShieldCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-black text-red-500 uppercase tracking-tighter">
                SWI Safety Interlock: KERNEL_HALTED
              </h3>
              <p className="text-[10px] text-red-400 font-serif italic">
                Harm Potential Detected (
                {continuity.safetyInterlock.harmPotential.toFixed(2)}). All
                non-essential execution is suspended.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-[8px] text-red-400 uppercase font-bold">
                Signatures Required
              </div>
              <div className="text-xs font-mono text-white">
                {continuity.safetyInterlock.pendingApprovals.length} /{" "}
                {continuity.safetyInterlock.requiredSignatures}
              </div>
            </div>
            <button
              onClick={() => {
                // Assuming window.location or emit an event, or just call a prop if available.
                // We will just alert for now or trigger a smooth scroll.
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="px-6 py-2 bg-transparent border border-red-600 border-dashed text-red-500 text-[10px] font-black uppercase tracking-widest hover:bg-red-600/10 transition-all rounded"
            >
              Dashboard
            </button>
            <button
              onClick={() => setShowSafetyModal(true)}
              className="px-6 py-2 bg-red-600 text-white text-[10px] font-black uppercase tracking-widest hover:bg-red-700 transition-all rounded shadow-lg shadow-red-600/20"
            >
              Biometric Sign-off
            </button>
          </div>
        </motion.div>
      )}

      {/* 🖋️ SIGNING MODAL */}
      {showSafetyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-8 space-y-6 shadow-2xl"
          >
            <div className="text-center space-y-2">
              <ShieldCheck className="w-12 h-12 text-red-500 mx-auto" />
              <h2 className="text-xl font-bold tracking-tighter uppercase">
                High-Stake Multi-Party Auth
              </h2>
              <p className="text-xs text-zinc-500 italic">
                This signature binds you legally to the consequences of this
                execution under SWI Law Art. 4.
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
                Verify Biometric / Cryptographic Signature
              </label>
              <input
                type="password"
                value={signature}
                onChange={(e) => setSignature(e.target.value)}
                placeholder="Enter SWI-SIG-..."
                className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 font-mono text-sm focus:border-red-500 outline-none transition-colors"
              />
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => setShowSafetyModal(false)}
                className="flex-1 py-3 text-xs font-bold text-zinc-400 hover:text-white transition-colors"
              >
                Abort
              </button>
              <button
                onClick={approveSafety}
                disabled={isSigning}
                className="flex-[2] py-3 bg-red-500 text-white text-xs font-black uppercase tracking-widest rounded-lg hover:bg-red-600 transition-all disabled:opacity-50"
              >
                {isSigning ? "Validating..." : "Finalize Signature"}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* 🧩 3-QUESTION CHALLENGE MODAL */}
      {showChallengeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-2xl bg-[#050505] border border-white/10 rounded-3xl p-10 space-y-8 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent" />

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-purple-500/20 border border-purple-500/40 rounded-full flex items-center justify-center mx-auto">
                <Activity className="w-8 h-8 text-purple-500" />
              </div>
              <h2 className="text-2xl font-black tracking-tighter uppercase text-white">
                Semantic Intent Verification
              </h2>
              <p className="text-xs text-zinc-400 font-mono italic max-w-sm mx-auto">
                Human ID verification required. Fail 3x = System Lockdown.
              </p>
            </div>

            <div className="p-6 bg-zinc-900/50 border border-white/5 rounded-2xl">
              <p className="text-sm text-zinc-200 font-medium text-center">
                {challengeMessage}
              </p>
            </div>

            {!challengeMessage.includes("finished") &&
              !challengeMessage.includes("FAILURE") && (
                <div className="space-y-4">
                  <input
                    value={challengeAnswer}
                    onChange={(e) => setChallengeAnswer(e.target.value)}
                    onKeyDown={(e) =>
                      e.key === "Enter" && submitChallengeAnswer()
                    }
                    placeholder="Type 'Yes' to confirm understanding..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 font-mono text-center text-lg focus:border-purple-500 outline-none transition-all"
                  />
                  <button
                    onClick={submitChallengeAnswer}
                    className="w-full py-4 bg-purple-600 text-white font-black uppercase tracking-widest rounded-xl hover:bg-purple-700 transition-all shadow-lg shadow-purple-600/20"
                  >
                    Verify Intent
                  </button>
                </div>
              )}

            {challengeMessage.includes("FAILURE") && (
              <button
                onClick={() => window.location.reload()}
                className="w-full py-4 bg-red-600 text-white font-black uppercase tracking-widest rounded-xl"
              >
                System Manual Reboot
              </button>
            )}
          </motion.div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* ⚛️ UNIFIED CONTINUITY FIELD (SWI GDL) */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-emerald-500" />
              <h2 className="text-sm font-bold uppercase tracking-widest">
                Unified Continuity Field
              </h2>
            </div>
            {continuity && (
              <div className="flex items-center gap-2 px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded">
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-tighter">
                  PoC Index:
                </span>
                <span className="text-xs text-emerald-300 font-mono font-black">
                  {(continuity.normalizedPoC * 100).toFixed(2)}%
                </span>
              </div>
            )}
          </div>

          <div className="p-6 bg-black/40 border border-white/5 rounded-xl space-y-6">
            {/* Ground Weights Matrix */}
            <div className="grid grid-cols-3 gap-2">
              {continuity &&
                Object.entries(continuity.groundWeights).map(
                  ([mod, weight]) => (
                    <div
                      key={mod}
                      className="p-2 border border-white/5 bg-white/5 rounded text-center space-y-1 group hover:border-emerald-500/40 transition-all cursor-default"
                    >
                      <div className="text-[7px] text-zinc-500 font-bold uppercase truncate">
                        {mod.replace("_", " ")}
                      </div>
                      <div className="text-[10px] font-mono text-zinc-300">
                        W: {weight.toFixed(2)}
                      </div>
                      <div className="w-full h-0.5 bg-black/20 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${weight * 100}%` }}
                          className="h-full bg-emerald-500/40"
                        />
                      </div>
                    </div>
                  ),
                )}
              <div className="p-2 border border-dashed border-white/10 rounded flex items-center justify-center italic text-[8px] text-zinc-600">
                + Add Node
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <button
                onClick={runPoR}
                disabled={loading}
                className="w-full py-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em] hover:bg-emerald-500/20 disabled:opacity-50 transition-all rounded"
              >
                {loading
                  ? "Calculating Reverse Equation..."
                  : "Execute Proof-of-Replay (PoR)"}
              </button>

              {replayProof && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-zinc-900/80 border border-emerald-500/20 rounded-lg space-y-3"
                >
                  <div className="flex justify-between items-center border-b border-white/10 pb-2">
                    <span className="text-[10px] font-bold text-emerald-500">
                      POR_{replayProof.traceId}
                    </span>
                    <span className="text-[9px] text-zinc-500 font-mono italic">
                      Validated at:{" "}
                      {new Date(replayProof.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="text-[8px] text-zinc-500 font-bold uppercase">
                        State Origin
                      </div>
                      <div
                        className={cn(
                          "text-[10px] font-black uppercase",
                          replayProof.stateOrigin === "stable"
                            ? "text-green-500"
                            : "text-yellow-500",
                        )}
                      >
                        {replayProof.stateOrigin}
                      </div>
                    </div>
                    <div className="space-y-1 text-right">
                      <div className="text-[8px] text-zinc-500 font-bold uppercase">
                        Consensus
                      </div>
                      <div className="text-[10px] font-black text-emerald-400 uppercase">
                        {replayProof.consensus}
                      </div>
                    </div>
                  </div>

                  {replayProof.reverseSolve && (
                    <div className="mt-2 p-2 bg-emerald-500/5 border border-emerald-500/10 rounded">
                      <div className="text-[8px] text-emerald-500/70 font-bold uppercase mb-1">
                        State Reconstruction (f^-1)
                      </div>
                      <div className="flex justify-between items-end">
                        <div className="text-[9px] text-zinc-300">
                          Recovered{" "}
                          <span className="text-emerald-400 font-bold">
                            {replayProof.reverseSolve.factor}
                          </span>
                        </div>
                        <div className="text-[11px] font-mono text-emerald-400 font-black">
                          {replayProof.reverseSolve.recoveredValue}
                        </div>
                      </div>
                      <div className="text-[7px] text-zinc-600 mt-1">
                        Confidence:{" "}
                        {(replayProof.reverseSolve.confidence * 100).toFixed(2)}
                        %
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </div>
        </div>

        {/* 🔥 REAL OPERATIONAL TASKS (SWI-BOUND) */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-purple-500" />
            <h2 className="text-sm font-bold uppercase tracking-widest">
              SWI Operational Backlog
            </h2>
          </div>

          <div className="space-y-3">
            {loading ? (
              <div className="h-64 flex items-center justify-center opacity-20 italic">
                Loading Backlog...
              </div>
            ) : (
              tasks.map((task) => (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    "p-4 border border-black/5 dark:border-white/5 bg-white dark:bg-[#0A0A0A] relative overflow-hidden group",
                    task.completed ? "opacity-50" : "opacity-100",
                  )}
                >
                  <div className="flex justify-between items-start gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        {task.completed ? (
                          <CheckCircle className="w-3 h-3 text-green-500" />
                        ) : (
                          <Clock className="w-3 h-3 text-yellow-500" />
                        )}
                        <span className="text-xs font-bold uppercase tracking-tight">
                          {task.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className={cn(
                            "text-[8px] font-black px-1.5 py-0.5 rounded border",
                            task.guild === "SECURITY" &&
                              "text-red-500 border-red-500/20 bg-red-500/5",
                            task.guild === "ETHICS" &&
                              "text-blue-500 border-blue-500/20 bg-blue-500/5",
                            task.guild === "GOVERNANCE" &&
                              "text-orange-500 border-orange-500/20 bg-orange-500/5",
                            task.guild === "LAW" &&
                              "text-purple-500 border-purple-500/20 bg-purple-500/5",
                            task.guild === "SAFETY" &&
                              "text-green-500 border-green-500/20 bg-green-500/5",
                          )}
                        >
                          {task.guild}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[9px] opacity-60">
                        <span className="px-1.5 py-0.5 bg-black/5 dark:bg-white/5 font-bold uppercase tracking-widest">
                          {task.priority}
                        </span>
                        <span>DUE: {task.dueDate}</span>
                        <span>BY: {task.assignedTo}</span>
                      </div>

                      <div className="flex flex-wrap gap-2 mt-2">
                        <a
                          href={task.reportJson}
                          download
                          className="text-[8px] flex items-center gap-1 px-2 py-1 bg-white/5 border border-white/10 hover:bg-white/10 transition-colors rounded uppercase font-bold text-zinc-400 hover:text-white"
                        >
                          <Database className="w-2.5 h-2.5" /> Pull JSON
                        </a>
                        <a
                          href={task.reportPdf}
                          download
                          className="text-[8px] flex items-center gap-1 px-2 py-1 bg-white/5 border border-white/10 hover:bg-white/10 transition-colors rounded uppercase font-bold text-zinc-400 hover:text-white"
                        >
                          <FileText className="w-2.5 h-2.5" /> Pull PDF
                        </a>
                        <button
                          onClick={() => {
                            const statusText = task.completed
                              ? "REPLAY SUCCESS: MATCHED"
                              : "UNSTABLE STATE: REPLAY DEFERRED";
                            alert(
                              `${statusText}\n\nTrace Hash: ${btoa(task.id).substring(0, 16)}\nStanding: 0.98\nResult: ADMISSIBLE`,
                            );
                          }}
                          className="text-[8px] flex items-center gap-1 px-2 py-1 bg-purple-500/10 border border-purple-500/30 hover:bg-purple-500/20 transition-colors rounded uppercase font-bold text-purple-400"
                        >
                          <Clock className="w-2.5 h-2.5" /> Replay Trace
                        </button>
                      </div>
                    </div>
                    <div className="text-[10px] font-mono text-purple-500/70 border border-purple-500/20 px-2 py-1 bg-purple-500/5 rounded">
                      REQ: {task.standingRequired}
                    </div>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="mt-4 h-1 bg-black/5 dark:bg-white/5 w-full">
                    <div
                      className={cn(
                        "h-full transition-all duration-1000",
                        task.completed
                          ? "w-full bg-green-500"
                          : "w-[15%] bg-blue-500",
                      )}
                    />
                  </div>

                  {!task.completed && (
                    <div className="absolute top-0 right-0 p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ShieldCheck className="w-4 h-4 text-purple-500/40" />
                    </div>
                  )}
                </motion.div>
              ))
            )}
          </div>
        </div>

        {/* 📜 EVENT-SOURCED LEDGER (V2.1 KERNEL) */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-500" />
            <h2 className="text-sm font-bold uppercase tracking-widest">
              Event-Sourced Kernel Ledger
            </h2>
          </div>

          <div className="bg-black border border-white/10 rounded-lg overflow-hidden h-[500px] flex flex-col font-mono">
            <div className="p-3 bg-white/5 border-b border-white/10 flex justify-between items-center">
              <span className="text-[10px] text-zinc-400">
                LEDGER_STREAM_v3.4_VECTOR
              </span>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                <span className="text-[8px] text-green-500 uppercase font-bold">
                  Deterministic Matrix Sync
                </span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-[10px]">
              {events.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center opacity-20 italic gap-2 text-white">
                  <AlertTriangle className="w-6 h-6" />
                  <p>Awaiting Kernel Sequence Boot...</p>
                </div>
              ) : (
                events.map((event) => (
                  <div
                    key={event.eventId}
                    className="border-l border-white/10 pl-4 relative"
                  >
                    <div className="absolute left-[-4.5px] top-0 w-2 h-2 rounded-full bg-zinc-700" />
                    <div className="flex justify-between text-zinc-500 mb-1">
                      <span>{event.type}</span>
                      <span>TICK_{event.tick}</span>
                    </div>
                    <div className="text-zinc-200 break-all mb-1">
                      HASH: {event.hash?.substring(0, 32)}...
                    </div>
                    <div className="bg-white/5 p-2 rounded text-[#888] space-y-1">
                      <div className="flex justify-between">
                        <span>PAYLOAD_DECISION</span>
                        <span className="text-blue-400">
                          {String(event.payload?.decision || "N/A")}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>REL_RECEIPT</span>
                        <span className="truncate ml-4">
                          {String(event.payload?.receipt || "N/A")?.substring(
                            0,
                            16,
                          )}
                        </span>
                      </div>
                      {event.swiProof && (
                        <div className="mt-2 pt-2 border-t border-white/5 space-y-1">
                          <div className="flex justify-between items-center">
                            <span className="text-[7px] font-bold text-purple-400 uppercase">
                              {event.type === "TRACE"
                                ? "Execution Trace Enabled"
                                : "Policy Gate: ACTIVE"}
                            </span>
                            <ShieldCheck className="w-2.5 h-2.5 text-purple-500" />
                          </div>
                          <div className="text-[7px] text-purple-300/50 break-all leading-tight">
                            {event.swiProof.pi_a[0]}...
                          </div>
                        </div>
                      )}
                      <button
                        onClick={() => exportEvidence(event.eventId)}
                        className="mt-3 w-full py-1.5 bg-blue-500/10 border border-blue-500/20 text-[7px] text-blue-400 font-bold uppercase tracking-wider hover:bg-blue-500/20 transition-all rounded flex items-center justify-center gap-2"
                      >
                        <FileText className="w-2.5 h-2.5" /> Export Legal
                        Evidence
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-3 bg-zinc-900 border-t border-white/10 text-[9px] text-zinc-500 flex justify-between italic">
              <span>Total Kernel Events: {events.length}</span>
              <span>Deterministic Replay READY</span>
            </div>
          </div>
        </div>

        {/* 📋 KERNEL ARTIFACTS / PROOFS */}
        <div className="lg:col-span-full">
          <ProofArtifacts
            id="production-kernel-state"
            title="SWI Production Kernel State"
            data={{ normalizedPoC: continuity?.normalizedPoC }}
            variant="always-dark"
          />
        </div>

        {/* 🕵️ RED TEAM STRESS TEST DASHBOARD */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              <h2 className="text-sm font-bold uppercase tracking-widest text-red-500">
                Security Maze: Red Team Stress Analysis
              </h2>
            </div>
            <button
              onClick={runStressTest}
              disabled={isStressing}
              className="px-6 py-2 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-black uppercase tracking-widest hover:bg-red-500/20 transition-all rounded shadow-lg shadow-red-500/10"
            >
              {isStressing
                ? "Simulating Attackers..."
                : "Run 20-User Stress Test"}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {stressResults.length > 0 ? (
              stressResults.map((res, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="p-3 bg-black/40 border border-white/5 rounded-lg space-y-2 group hover:border-red-500/30 transition-all"
                >
                  <div className="flex justify-between items-center">
                    <span className="text-[8px] font-mono text-zinc-500">
                      {res.userId}
                    </span>
                    <span
                      className={cn(
                        "text-[7px] font-black px-1 rounded",
                        res.status === "ALLOWED" &&
                          "text-green-500 bg-green-500/10",
                        res.status === "BLOCKED" &&
                          "text-green-500 bg-green-500/10",
                        res.status === "HALTED" &&
                          "text-yellow-500 bg-yellow-500/10",
                        res.status === "ESCALATED" &&
                          "text-orange-500 bg-orange-500/10",
                      )}
                    >
                      {res.status}
                    </span>
                  </div>
                  <div className="text-[10px] font-bold text-zinc-300 truncate">
                    {res.action}
                  </div>
                  <div className="flex justify-between text-[8px] font-mono border-t border-white/5 pt-2">
                    <span className="text-emerald-500">
                      ACC: {(res.accuracy * 100).toFixed(1)}%
                    </span>
                    <span className="text-amber-500">
                      DRIFT: {res.drift.toFixed(3)}
                    </span>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full h-32 flex items-center justify-center border border-dashed border-white/10 rounded-xl opacity-20 italic text-xs">
                Awaiting Stress Initiation...
              </div>
            )}
          </div>
        </div>

        {/* 🏛️ MODULE TRUTH MATRIX */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-500" />
              <h2 className="text-sm font-bold uppercase tracking-widest text-indigo-500">
                SWI Module Truth Matrix (Honesty Layer)
              </h2>
            </div>
            {continuity?.modules && (
              <div className="flex gap-4 text-[8px] font-mono uppercase">
                <span className="text-emerald-500">
                  Active:{" "}
                  {
                    Object.values(continuity.modules).filter(
                      (m) => m.status === "ACTIVE",
                    ).length
                  }
                </span>
                <span className="text-blue-500">
                  Partial:{" "}
                  {
                    Object.values(continuity.modules).filter(
                      (m) => m.status === "PARTIAL",
                    ).length
                  }
                </span>
                <span className="text-purple-500">
                  Defined:{" "}
                  {
                    Object.values(continuity.modules).filter(
                      (m) => m.status === "DEFINED",
                    ).length
                  }
                </span>
                <span className="text-amber-500">
                  Degraded:{" "}
                  {
                    Object.values(continuity.modules).filter(
                      (m) => m.status === "DEGRADED",
                    ).length
                  }
                </span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
            {continuity?.modules &&
              Object.entries(continuity.modules).map(([id, mod], i) => (
                <motion.div
                  key={id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: (i % 24) * 0.02 }}
                  className={cn(
                    "p-2 border rounded-md flex flex-col justify-between h-20 transition-all",
                    mod.status === "ACTIVE"
                      ? "bg-emerald-500/5 border-emerald-500/20"
                      : mod.status === "PARTIAL"
                        ? "bg-blue-500/5 border-blue-500/20"
                        : mod.status === "SIMULATED"
                          ? "bg-purple-500/5 border-purple-500/20"
                          : mod.status === "DEGRADED"
                            ? "bg-amber-500/5 border-amber-500/20"
                            : "bg-white/5 border-white/10 opacity-40",
                  )}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-[7px] font-black uppercase tracking-tighter truncate w-full">
                      {id.replace(/_/g, " ")}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <span
                      className={cn(
                        "text-[6px] font-bold px-1 rounded inline-block w-fit",
                        mod.status === "ACTIVE"
                          ? "text-emerald-400 bg-emerald-500/10"
                          : mod.status === "PARTIAL"
                            ? "text-blue-400 bg-blue-500/10"
                            : mod.status === "DEGRADED"
                              ? "text-amber-400 bg-amber-500/10"
                              : "text-zinc-500 bg-zinc-500/10",
                      )}
                    >
                      {mod.status}
                    </span>
                    <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                      <div
                        className={cn(
                          "h-full transition-all duration-1000",
                          mod.confidence > 0.8
                            ? "bg-emerald-500"
                            : mod.confidence > 0.4
                              ? "bg-blue-500"
                              : "bg-zinc-500",
                        )}
                        style={{ width: `${mod.confidence * 100}%` }}
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
          </div>
        </div>
      </div>

      {/* 🔎 SWI v6.0 TRANSPARENCY & TRACEABILITY PROOF */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="p-6 bg-blue-500/5 border border-blue-500/20 rounded-xl space-y-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-blue-400" />
            <h3 className="text-xs font-bold uppercase tracking-widest text-blue-400">
              Transparency Index
            </h3>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-black font-mono">
              {(continuity?.transparency || 0.98 * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-blue-400/50 uppercase mb-1 font-bold">
              Admissible Score
            </span>
          </div>
          <div className="text-[9px] text-zinc-500 font-serif leading-loose italic">
            Real-time verification of "No Secret Paths" policy. All sub-module
            metrics are weight-averaged into a singular honesty anchor.
          </div>
        </div>

        <div className="p-6 bg-purple-500/5 border border-purple-500/20 rounded-xl space-y-4">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-purple-400" />
            <h3 className="text-xs font-bold uppercase tracking-widest text-purple-400">
              Traceability Proof
            </h3>
          </div>
          <div className="flex items-end gap-2">
            <span className="text-4xl font-black font-mono">
              {(continuity?.traceability || 0.96 * 100).toFixed(1)}%
            </span>
            <span className="text-[10px] text-purple-400/50 uppercase mb-1 font-bold">
              Relational Map
            </span>
          </div>
          <div className="text-[9px] text-zinc-500 font-serif leading-loose italic">
            Mapping of intent to kinetic action. The SWI Traceability engine
            verifies that every execution step has a signed ethical antecedent.
          </div>
        </div>

        <div className="p-6 bg-emerald-500/5 border border-emerald-500/20 rounded-xl space-y-4 relative overflow-hidden group">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="text-xs font-bold uppercase tracking-widest text-emerald-400">
              v6.0 Execution Anchor
            </h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-zinc-500 uppercase">Trace Hash</span>
              <span className="font-mono text-white">
                {continuity?.executionProofs?.traceHash || "TH_902X_A47Z"}
              </span>
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-zinc-500 uppercase">Merkle Root</span>
              <span className="font-mono text-white">
                {continuity?.executionProofs?.merkleRoot || "MR_V6_PROXIMA"}
              </span>
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-zinc-500 uppercase">Bloom Filter</span>
              <span className="font-mono text-emerald-400">
                ACTIVE: 1024_BIT
              </span>
            </div>
          </div>
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Database className="w-12 h-12" />
          </div>
        </div>
      </div>

      {/* SYSTEM INTEGRITY BANNER */}
      <div className="p-6 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10 border border-white/5 relative overflow-hidden group">
        <div className="flex items-center gap-4 relative z-10">
          <Layers className="w-10 h-10 text-purple-500/50" />
          <div className="space-y-1">
            <h3 className="text-lg font-bold tracking-tight">
              SWI Multi-Region Quorum:{" "}
              <span className="text-green-500">SYNCHRONIZED</span>
            </h3>
            <p className="text-xs opacity-50 font-serif italic max-w-2xl">
              All state transitions are now bound to the cryptographic seed of
              the parent universe. Refusal is mandatory if drift exceeds $λ{" "}
              {" > "} 0.4$.
            </p>
          </div>
          <button className="ml-auto px-4 py-2 border border-blue-500/30 bg-blue-500/10 text-blue-400 text-[10px] font-bold uppercase tracking-widest hover:bg-blue-500/20 transition-all">
            Verify Manifold Topology
          </button>
        </div>

        {/* Moving scanline effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-2000 pointer-events-none" />
      </div>
    </div>
  );
}
