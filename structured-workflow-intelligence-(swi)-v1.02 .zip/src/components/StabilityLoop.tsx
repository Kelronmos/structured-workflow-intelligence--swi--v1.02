import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { Activity, Shield, Zap, AlertCircle } from 'lucide-react';
import { ConstitutionalState } from '../swi/types';

interface StabilityLoopProps {
  state: ConstitutionalState;
}

export default function StabilityLoop({ state }: StabilityLoopProps) {
  const stability = state.currentStability * 100;
  const isHealthy = stability > 70;
  const isCritical = stability < 30;

  return (
    <div className="p-6 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-6 overflow-hidden relative">
      {/* Background Pulse */}
      <motion.div 
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.05, 0.1, 0.05],
        }}
        transition={{
          duration: state.heartbeat / 30,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        className={cn(
          "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full blur-3xl",
          isHealthy ? "bg-green-500" : isCritical ? "bg-red-500" : "bg-yellow-500"
        )}
      />

      <div className="flex justify-between items-start relative z-10">
        <div className="space-y-1">
          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] flex items-center gap-2 opacity-60">
            <Activity className="w-3 h-3" />
            Constitutional Loop
          </h3>
          <p className="text-2xl font-bold tracking-tighter tabular-nums">
            {stability.toFixed(1)}% <span className="text-[10px] uppercase opacity-40 font-mono tracking-normal">Stability</span>
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span className={cn(
            "text-[8px] font-bold uppercase px-2 py-0.5 border",
            isHealthy ? "text-green-500 border-green-500/20 bg-green-500/5" : 
            isCritical ? "text-red-500 border-red-500/20 bg-red-500/5 animate-pulse" : 
            "text-yellow-500 border-yellow-500/20 bg-yellow-500/5"
          )}>
            {isHealthy ? "Nominal" : isCritical ? "Critical Stabilization" : "Interference Detected"}
          </span>
          <span className="text-[7px] font-mono opacity-30">Frequency: {state.heartbeat} BPM</span>
        </div>
      </div>

      {/* Stabilization Visualizer */}
      <div className="h-2 w-full bg-black/5 dark:bg-white/5 relative overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${stability}%` }}
          className={cn(
            "h-full transition-colors duration-500",
            isHealthy ? "bg-green-500" : isCritical ? "bg-red-500" : "bg-yellow-500"
          )}
        />
        <motion.div 
          animate={{ x: ['100%', '-100%'] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          className="absolute top-0 bottom-0 w-8 bg-white/20 skew-x-12"
        />
      </div>

      <div className="grid grid-cols-2 gap-4 pt-2 relative z-10">
        <div className="p-3 border border-white/5 bg-black/5 space-y-1">
          <p className="text-[7px] uppercase font-bold opacity-40 flex items-center gap-1">
            <Shield className="w-2 h-2" /> Drift Threshold
          </p>
          <p className="text-xs font-mono font-bold">{(state.params.driftThreshold).toFixed(3)}</p>
        </div>
        <div className="p-3 border border-white/5 bg-black/5 space-y-1">
          <p className="text-[7px] uppercase font-bold opacity-40 flex items-center gap-1">
            <Zap className="w-2 h-2" /> Vigilance Factor
          </p>
          <p className="text-xs font-mono font-bold">{(state.params.vigilanceFactor).toFixed(2)}x</p>
        </div>
      </div>

      {isCritical && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 border border-red-500/20 bg-red-500/5 rounded flex items-start gap-2 relative z-10"
        >
          <AlertCircle className="w-4 h-4 text-red-500 mt-0.5" />
          <div className="space-y-1">
            <p className="text-[8px] font-bold uppercase text-red-500">Autonomous Interlock Active</p>
            <p className="text-[7px] opacity-60 leading-tight">System is performing self-stabilization sweep. Thresholds tightened to prevent state collapse.</p>
          </div>
        </motion.div>
      )}

      {/* Decorative Grid */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.02] bg-[radial-gradient(#000_1px,transparent_1px)] dark:bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />
    </div>
  );
}
