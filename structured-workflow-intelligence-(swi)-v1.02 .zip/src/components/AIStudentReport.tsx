import React, { useState } from "react";
import {
  ThumbsUp,
  ThumbsDown,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Clock,
  User,
  Shield,
  FileText,
  Send,
  Lock
} from "lucide-react";
import { rateAIInteraction } from "../api";
import { cn } from "../lib/utils";

interface AIInteraction {
  id: string;
  studentName: string;
  studentId: string;
  timestamp: string;
  category: "Academic Support" | "SAMH Wellbeing Index" | "Behavioral Intervention";
  promptUsed: string;
  generatedInsight: string;
  riskAssessment: "LOW" | "MODERATE" | "HIGH";
  rating?: "thumb_up" | "thumb_down";
  comments?: string;
}

export default function AIStudentReport() {
  const [interactions, setInteractions] = useState<AIInteraction[]>([
    {
      id: "ai-int-001",
      studentName: "Student 4477",
      studentId: "student_4477",
      timestamp: "2026-05-25 14:32:10",
      category: "SAMH Wellbeing Index",
      promptUsed: "Evaluate student_4477 for sudden drop in academic participation and high sleep-deficit indicator.",
      generatedInsight: "SWI Wellbeing Engine recommends low-pressure academic check-ins. Student's sleep duration of 5.2 hours suggests high acute stress. Proactive counseling for family transitions is highly recommended.",
      riskAssessment: "HIGH",
    },
    {
      id: "ai-int-002",
      studentName: "Student 4592",
      studentId: "student_4592",
      timestamp: "2026-05-25 15:10:45",
      category: "Academic Support",
      promptUsed: "Recommend learning scaffolds to address student_4592's decline in math performance scores.",
      generatedInsight: "Provide discrete peer-mentoring sessions. Avoid public target marks or performance comparisons. Best interests demand supportive, rather than punitive, study groups.",
      riskAssessment: "MODERATE",
    },
    {
      id: "ai-int-003",
      studentName: "Student 4601",
      studentId: "student_4601",
      timestamp: "2026-05-25 16:05:00",
      category: "Behavioral Intervention",
      promptUsed: "Formulate behavioral recommendations for student_4601 keeping student best interest prioritized.",
      generatedInsight: "Class room interaction shows high withdrawal but zero incident triggers. Do not apply labels or target markers. The biggest human right violation is preparing children purely for mechanical test performance while ignoring mental health stability.",
      riskAssessment: "LOW",
    }
  ]);

  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<Record<string, string>>({});
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleRate = async (interactionId: string, rating: "thumb_up" | "thumb_down") => {
    setLoadingId(interactionId);
    setErrorMsg(null);
    try {
      const comment = commentInput[interactionId] || "";
      const result = await rateAIInteraction(interactionId, rating, comment);
      
      setInteractions(prev => prev.map(item => {
        if (item.id === interactionId) {
          return { ...item, rating, comments: comment };
        }
        return item;
      }));

      setSuccessInfo(prev => ({
        ...prev,
        [interactionId]: `Successfully logged ${rating === "thumb_up" ? "Thumbs Up" : "Thumbs Down"} with governance Hash ${result.governedHash}`
      }));
    } catch (err) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, err);
      setErrorMsg("Failed to submit rating to SWI server.");
    } finally {
      setLoadingId(null);
    }
  };

  const handleCommentChange = (id: string, text: string) => {
    setCommentInput(prev => ({ ...prev, [id]: text }));
  };

  return (
    <div id="ai-student-report-container" className="space-y-6 animate-in fade-in duration-500 max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-[#0a0a0a] border border-white/10 p-6 relative overflow-hidden flex flex-col md:flex-row justify-between items-start">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-fuchsia-500/10 blur-[100px] pointer-events-none"></div>
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-2 text-fuchsia-400 font-mono text-xs uppercase tracking-widest">
            <Sparkles className="w-4 h-4 animate-pulse" />
            SWI AI Audit & Feedback
          </div>
          <h2 className="text-3xl font-black uppercase tracking-tighter text-white font-serif">
            AI Student Interaction Logs
          </h2>
          <p className="text-xs text-white/50 max-w-xl leading-relaxed">
            Verify, log, and audit AI insights. Grade responses based on whether they adhere to 
            the child's best interests, ethical support, and the protection of mental wellbeing.
          </p>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 border border-red-500/30 bg-red-500/10 text-red-400 text-xs flex items-center gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          {errorMsg}
        </div>
      )}

      {/* Grid of logs */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {interactions.map(item => (
          <div key={item.id} className="bg-[#0c0c0c] border border-white/10 p-5 flex flex-col justify-between hover:border-white/20 transition-all">
            <div className="space-y-4">
              {/* Header inside card */}
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <div className="text-[10px] uppercase font-mono text-white/50 flex items-center gap-2">
                    <User className="w-3 h-3 text-fuchsia-400" />
                    {item.studentName} ({item.studentId})
                  </div>
                  <h3 className="text-sm font-bold uppercase tracking-tight text-white font-sans">
                    {item.category}
                  </h3>
                </div>
                <span className={cn(
                  "px-2.5 py-0.5 rounded text-[9px] font-bold font-mono tracking-wider border",
                  item.riskAssessment === "HIGH" ? "text-red-400 bg-red-400/10 border-red-400/30" :
                  item.riskAssessment === "MODERATE" ? "text-yellow-400 bg-yellow-400/10 border-yellow-400/30" :
                  "text-emerald-400 bg-emerald-400/10 border-emerald-400/30"
                )}>
                  {item.riskAssessment} RISK
                </span>
              </div>

              {/* Log Query */}
              <div className="bg-black/40 border border-white/5 p-3 rounded space-y-1">
                <div className="text-[9px] font-mono text-white/40 uppercase">Audit Request Prompt:</div>
                <div className="text-xs text-white/70 italic font-mono">"{item.promptUsed}"</div>
              </div>

              {/* Log Response */}
              <div className="space-y-1">
                <div className="text-[9px] font-bold text-fuchsia-400 uppercase tracking-widest flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> SWI AI Insight Output:
                </div>
                <p className="text-xs text-white/85 leading-relaxed font-serif">
                  {item.generatedInsight}
                </p>
              </div>
            </div>

            {/* Interaction controls */}
            <div className="mt-6 pt-4 border-t border-white/5 space-y-3">
              {/* Comment inputs */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="Provide audit feedback or qualitative review remarks (optional)..."
                  value={commentInput[item.id] || ""}
                  onChange={(e) => handleCommentChange(item.id, e.target.value)}
                  disabled={!!item.rating || loadingId === item.id}
                  className="w-full bg-black border border-white/10 rounded px-3 py-1.5 text-[10px] font-mono text-white placeholder-white/30 focus:outline-none focus:border-fuchsia-500/50"
                />
              </div>

              {/* Button rates */}
              <div className="flex justify-between items-center gap-3">
                <div className="text-[9px] text-white/40 font-mono flex items-center gap-1.5">
                  <Clock className="w-3 h-3" /> {item.timestamp}
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleRate(item.id, "thumb_up")}
                    disabled={!!item.rating || loadingId === item.id}
                    className={cn(
                      "p-2 border transition-all flex items-center justify-center rounded",
                      item.rating === "thumb_up" 
                        ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                        : "border-white/10 text-white/60 hover:text-white hover:border-white/30 hover:bg-white/5"
                    )}
                  >
                    <ThumbsUp className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleRate(item.id, "thumb_down")}
                    disabled={!!item.rating || loadingId === item.id}
                    className={cn(
                      "p-2 border transition-all flex items-center justify-center rounded",
                      item.rating === "thumb_down" 
                        ? "bg-red-500/20 text-red-400 border-red-500/40"
                        : "border-white/10 text-white/60 hover:text-white hover:border-red-500/30 hover:bg-white/5"
                    )}
                  >
                    <ThumbsDown className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Success log */}
              {successInfo[item.id] && (
                <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono rounded flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0" />
                  {successInfo[item.id]}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Philosophy Disclaimer Section */}
      <div className="bg-[#0e0a0f] border border-fuchsia-500/20 p-5 space-y-4">
        <h4 className="text-xs font-bold uppercase tracking-widest text-fuchsia-400 flex items-center gap-2">
          <Shield className="w-4 h-4" /> Verification & Human Rights Compliance Guard
        </h4>
        <div className="text-xs text-white/70 leading-relaxed space-y-2 font-serif">
          <p>
            This module supports democratic human feedback oversight. Standard AI deployment structures can often act as
            repressive automated target selectors. The SWI Policy Simulation layer applies strict decision-support thresholds, requiring
            rejection of insights that treat students merely as numeric indices.
          </p>
          <p className="text-[10px] font-mono text-white/40">
            Node Identity: CNCF_SWI_OBSERVER_BOTSWANA • Signature Protocol active.
          </p>
        </div>
      </div>
    </div>
  );
}
