import React, { useState } from 'react';
import { cn } from '../lib/utils';
import { 
  Users, Activity, FolderKanban, ClipboardCheck, 
  BarChart3, PiggyBank, Eye, AlertCircle, 
  CheckCircle2, ShieldCheck, ChevronRight,
  UserPlus, FileOutput, Gavel, 
  LineChart, Coins, Building2, BrainCircuit
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  theme: 'light' | 'dark';
}

export function SAMHSuperModule({ theme }: Props) {
  const [activeTab, setActiveTab] = useState<'registry' | 'assessment' | 'cases' | 'attendance' | 'financial' | 'impact' | 'scenarios'>('impact');

  const tabs = [
    { id: 'impact', label: 'Impact Dashboard', icon: <BarChart3 className="w-4 h-4"/> },
    { id: 'registry', label: 'Participant Registry', icon: <Users className="w-4 h-4"/> },
    { id: 'assessment', label: 'Mental Health Engine', icon: <Activity className="w-4 h-4"/> },
    { id: 'cases', label: 'Case Management', icon: <FolderKanban className="w-4 h-4"/> },
    { id: 'attendance', label: 'Attendance Ledger', icon: <ClipboardCheck className="w-4 h-4"/> },
    { id: 'financial', label: 'Financial System', icon: <PiggyBank className="w-4 h-4"/> },
    { id: 'scenarios', label: 'Demo Scenarios', icon: <Eye className="w-4 h-4"/> },
  ] as const;

  return (
    <div className="max-w-7xl mx-auto space-y-6 font-mono pb-20">
      <div className="flex items-center justify-between border-b border-[#333] pb-6">
        <div>
          <h2 className="text-3xl font-bold uppercase tracking-tighter flex items-center gap-2">
            <BrainCircuit className="w-8 h-8 text-indigo-500" />
            SAMH Super Module
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-widest mt-1">Holistic Adolescent Mental Health & Governance Subsystem</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-[10px] uppercase font-bold tracking-widest whitespace-nowrap transition-colors",
              activeTab === t.id 
                ? "bg-indigo-600 text-white" 
                : "bg-[#111] text-gray-500 hover:text-gray-300 border border-[#333]"
            )}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      <div className="bg-[#111] border border-[#333] rounded-xl p-6 min-h-[500px]">
        {activeTab === 'impact' && <ImpactDashboard />}
        {activeTab === 'registry' && <ParticipantRegistry />}
        {activeTab === 'assessment' && <MentalHealthEngine />}
        {activeTab === 'cases' && <CaseManagement />}
        {activeTab === 'attendance' && <AttendanceLedger />}
        {activeTab === 'financial' && <FinancialSystem />}
        {activeTab === 'scenarios' && <DemoScenarios />}
      </div>
    </div>
  );
}

// Sub-components

function ImpactDashboard() {
  const stats = [
    { label: "Participants Registered", value: "10,000", color: "text-blue-400" },
    { label: "Girls Supported", value: "6,500", color: "text-pink-400" },
    { label: "Counselling Sessions", value: "3,200", color: "text-emerald-400" },
    { label: "Schools Covered", value: "150", color: "text-purple-400" },
    { label: "Districts Covered", value: "16", color: "text-amber-400" },
    { label: "Cases Resolved", value: "89%", color: "text-indigo-400" },
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
        <LineChart className="w-5 h-5" /> Global Impact Measurement
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {stats.map(s => (
          <div key={s.label} className="bg-[#0A0A0A] p-6 rounded-lg border border-[#222]">
            <div className="text-[10px] uppercase text-gray-500 tracking-widest mb-2">{s.label}</div>
            <div className={cn("text-4xl font-bold tracking-tighter", s.color)}>{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ParticipantRegistry() {
  const codeString = `{
  "participant_id": "SAMH-2026-0001",
  "name": "Jane Doe",
  "district": "Gaborone",
  "gender": "Female",
  "age": 15,
  "risk_level": "Moderate",
  "consent": "Approved"
}`;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
          <Users className="w-5 h-5" /> Participant Registry
        </h3>
        <button className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 rounded text-[10px] uppercase font-bold text-white transition-colors flex items-center gap-2">
          <UserPlus className="w-3 h-3" /> Enroll New
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#0A0A0A] p-4 rounded border border-[#222] overflow-x-auto">
          <div className="text-[10px] text-gray-500 mb-2 uppercase tracking-widest border-b border-[#333] pb-2">Active Entity Payload Example</div>
          <pre className="text-xs text-emerald-400">
            {codeString}
          </pre>
        </div>
        <div className="space-y-4">
           <div className="text-[10px] text-gray-500 uppercase tracking-widest border-b border-[#333] pb-2">Privacy & Consents</div>
           <ul className="space-y-3">
             <li className="flex items-center gap-2 text-xs text-gray-300">
               <ShieldCheck className="w-4 h-4 text-emerald-500" /> End-to-end encrypted identity bounds
             </li>
             <li className="flex items-center gap-2 text-xs text-gray-300">
               <ShieldCheck className="w-4 h-4 text-emerald-500" /> Guardian zero-knowledge consent verification
             </li>
             <li className="flex items-center gap-2 text-xs text-gray-300">
               <ShieldCheck className="w-4 h-4 text-emerald-500" /> Role-based obfuscation applied
             </li>
           </ul>
        </div>
      </div>
    </div>
  );
}

function MentalHealthEngine() {
  const codeString = `{
  "assessment_id": "MH-1001",
  "participant": "SAMH-2026-0001",
  "score": 74,
  "risk": "Moderate",
  "recommendation": "Counselling"
}`;

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
        <Activity className="w-5 h-5" /> Continuous Assessment Engine
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-4">Tracking Variables</div>
          <div className="flex flex-wrap gap-2">
            {['Depression Index', 'Anxiety Index', 'Self-esteem Matrix', 'School Attendance', 'Abuse Indicators'].map(t => (
              <span key={t} className="px-2 py-1 bg-[#222] border border-[#333] rounded text-xs text-gray-300 font-bold">{t}</span>
            ))}
          </div>
        </div>

        <div className="bg-[#0A0A0A] p-4 rounded border border-[#222] overflow-x-auto">
          <div className="text-[10px] text-gray-500 mb-2 uppercase tracking-widest border-b border-[#333] pb-2">Analysis Output Payload</div>
          <pre className="text-xs text-yellow-400">
            {codeString}
          </pre>
        </div>
      </div>
    </div>
  );
}

function CaseManagement() {
  const bullyingFlow = ["Report Created", "Case Assigned", "Counsellor Review", "Intervention", "Follow Up", "Case Closed"];
  const gbvFlow = ["Alert", "Social Worker", "Police Referral", "Medical Referral", "Legal Tracking", "Closure"];

  return (
    <div className="space-y-8">
      <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
        <FolderKanban className="w-5 h-5" /> Escalated Case Workflows
      </h3>

      <div className="space-y-6">
        <div className="bg-[#0A0A0A] border border-[#222] rounded p-6">
           <div className="flex justify-between items-center mb-4">
             <h4 className="text-sm font-bold text-gray-300 uppercase tracking-widest">Scenario A: Bullying Report</h4>
             <span className="text-[10px] px-2 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded uppercase font-bold tracking-widest">Signed & Verified</span>
           </div>
           <div className="flex flex-wrap items-center gap-2 text-xs text-indigo-300">
             {bullyingFlow.map((step, i) => (
               <React.Fragment key={step}>
                 <span className="px-3 py-1.5 bg-[#111] border border-indigo-500/30 rounded font-bold">{step}</span>
                 {i < bullyingFlow.length - 1 && <ChevronRight className="w-4 h-4 text-gray-600" />}
               </React.Fragment>
             ))}
           </div>
        </div>

        <div className="bg-[#0A0A0A] border border-[#222] rounded p-6">
           <div className="flex justify-between items-center mb-4">
             <h4 className="text-sm font-bold text-gray-300 uppercase tracking-widest">Scenario B: Gender Based Violence</h4>
             <span className="text-[10px] px-2 py-1 bg-red-500/10 text-red-500 border border-red-500/30 rounded uppercase font-bold tracking-widest">Multi-Agency Protocol Active</span>
           </div>
           <div className="flex flex-wrap items-center gap-2 text-xs text-red-400">
             {gbvFlow.map((step, i) => (
               <React.Fragment key={step}>
                 <span className="px-3 py-1.5 bg-[#111] border border-red-500/30 rounded font-bold">{step}</span>
                 {i < gbvFlow.length - 1 && <ChevronRight className="w-4 h-4 text-gray-600" />}
               </React.Fragment>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
}

function AttendanceLedger() {
  const codeString = `{
  "event": "SAMH Session",
  "location": "Gaborone",
  "participants": 150,
  "timestamp": "2026-06-21T10:00:00Z",
  "proof_hash": "0xabc12345efgh..."
}`;

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
        <ClipboardCheck className="w-5 h-5" /> Cryptographic Attendance Ledger
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#0A0A0A] p-4 rounded border border-[#222] overflow-x-auto">
          <div className="text-[10px] text-gray-500 mb-2 uppercase tracking-widest border-b border-[#333] pb-2">Session Block Output</div>
          <pre className="text-xs text-blue-400">
            {codeString}
          </pre>
        </div>
        <div className="space-y-4">
           <div className="p-4 border border-emerald-500/30 bg-emerald-500/5 rounded">
             <div className="flex items-center gap-2 text-emerald-400 text-xs uppercase font-bold tracking-widest mb-1">
               <ShieldCheck className="w-4 h-4" /> Integrity Guaranteed
             </div>
             <p className="text-[10px] text-gray-400 leading-relaxed">
               Each attendance block is batched and hashed into the immutable provenance registry. Ensures zero phantom participants and binds physical presence to cryptographic identity.
             </p>
           </div>
        </div>
      </div>
    </div>
  );
}

function FinancialSystem() {
  const [activeFinTab, setActiveFinTab] = useState<'budget' | 'donors' | 'fraud'>('budget');

  const budgetItems = [
    { item: 'Training', budget: 500000, spent: 250000, committed: 100000 },
    { item: 'Counselling', budget: 300000, spent: 150000, committed: 50000 },
    { item: 'Outreach', budget: 250000, spent: 200000, committed: 0 },
    { item: 'Technology', budget: 450000, spent: 400000, committed: 20000 },
    { item: 'Monitoring', budget: 150000, spent: 50000, committed: 50000 },
  ];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
        <PiggyBank className="w-5 h-5" /> Core Financial Engine
      </h3>

      <div className="flex gap-4 border-b border-[#333] pb-2">
        {['budget', 'donors', 'fraud'].map(t => (
          <button 
            key={t}
            onClick={() => setActiveFinTab(t as any)}
            className={cn("text-xs font-bold uppercase tracking-widest pb-2 -mb-[9px] border-b-2 transition-colors", activeFinTab === t ? "text-indigo-400 border-indigo-500" : "text-gray-500 border-transparent hover:text-gray-300")}
          >
            {t.toUpperCase()}
          </button>
        ))}
      </div>

      {activeFinTab === 'budget' && (
        <div className="space-y-4 animate-in fade-in">
           <div className="bg-[#0A0A0A] border border-[#222] rounded p-4 overflow-hidden">
              <table className="w-full text-xs text-left">
                <thead className="text-[10px] uppercase tracking-widest text-gray-500 border-b border-[#333]">
                  <tr>
                    <th className="pb-2">Line Item</th>
                    <th className="pb-2 text-right">Total Budget</th>
                    <th className="pb-2 text-right">Spent</th>
                    <th className="pb-2 text-right">Committed</th>
                    <th className="pb-2 text-right">Variance</th>
                  </tr>
                </thead>
                <tbody className="text-gray-300">
                  {budgetItems.map(b => (
                    <tr key={b.item} className="border-b border-[#222] last:border-0 hover:bg-[#111]">
                      <td className="py-3 font-bold">{b.item}</td>
                      <td className="py-3 text-right">${b.budget.toLocaleString()}</td>
                      <td className="py-3 text-right text-emerald-400">${b.spent.toLocaleString()}</td>
                      <td className="py-3 text-right text-yellow-400">${b.committed.toLocaleString()}</td>
                      <td className="py-3 text-right text-blue-400">${(b.budget - b.spent - b.committed).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
           </div>
        </div>
      )}

      {activeFinTab === 'donors' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-in fade-in">
          <div className="bg-[#0A0A0A] border border-[#222] rounded p-4 space-y-4">
             <h4 className="text-xs font-bold uppercase tracking-widest text-blue-400 flex items-center gap-2"><GlobeIcon className="w-4 h-4"/> UNICEF Dashboard</h4>
             <div className="space-y-2">
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">Funds Received</span><span className="font-bold text-gray-300">$1,200,000</span></div>
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">Funds Spent</span><span className="font-bold text-emerald-400">$850,000</span></div>
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">Beneficiaries</span><span className="font-bold text-indigo-400">8,420</span></div>
             </div>
          </div>
          <div className="bg-[#0A0A0A] border border-[#222] rounded p-4 space-y-4">
             <h4 className="text-xs font-bold uppercase tracking-widest text-pink-400 flex items-center gap-2"><HeartIcon className="w-4 h-4"/> UN Women View</h4>
             <div className="space-y-2">
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">Girls Reached</span><span className="font-bold text-gray-300">6,500</span></div>
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">Protection Outcomes</span><span className="font-bold text-emerald-400">4,200 Validated</span></div>
               <div className="w-full h-1 mt-2 bg-[#222] rounded overflow-hidden"><div className="w-[64%] h-full bg-pink-500"></div></div>
             </div>
          </div>
          <div className="bg-[#0A0A0A] border border-[#222] rounded p-4 space-y-4">
             <h4 className="text-xs font-bold uppercase tracking-widest text-amber-400 flex items-center gap-2"><Building2 className="w-4 h-4"/> Gov Dashboard</h4>
             <div className="space-y-2">
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">District Perf.</span><span className="font-bold text-gray-300">Gaborone (A+)</span></div>
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">School Partic.</span><span className="font-bold text-emerald-400">150 Sites</span></div>
               <div className="flex justify-between items-center text-xs"><span className="text-gray-500">Audit Status</span><span className="font-bold text-emerald-500 text-[10px] uppercase border p-0.5 rounded border-emerald-500/30">Verified</span></div>
             </div>
          </div>
        </div>
      )}

      {activeFinTab === 'fraud' && (
        <div className="space-y-4 animate-in fade-in">
           <div className="grid grid-cols-2 lg:grid-cols-5 gap-2">
             {[
               { id: 'dup', label: 'Duplicate Payments', status: 'clean' },
               { id: 'ghost', label: 'Ghost Participant', status: 'flag' },
               { id: 'att', label: 'Attendance Fraud', status: 'clean' },
               { id: 'over', label: 'Budget Overrun', status: 'clean' },
               { id: 'unauth', label: 'Unauthorized Tx', status: 'clean' },
             ].map(f => (
                <div key={f.id} className={cn("p-3 border rounded text-center flex flex-col items-center gap-2", f.status === 'clean' ? 'border-[#222] bg-[#0A0A0A]' : 'border-red-500/30 bg-red-500/10')}>
                  {f.status === 'clean' ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <AlertCircle className="w-5 h-5 text-red-500" />}
                  <span className={cn("text-[9px] uppercase font-bold tracking-widest", f.status === 'clean' ? 'text-gray-400' : 'text-red-400')}>{f.label}</span>
                </div>
             ))}
           </div>
           
           <div className="p-4 border border-red-500/30 bg-red-500/5 rounded mt-4 flex items-start gap-4">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div>
                <h5 className="text-xs font-bold text-red-400 uppercase tracking-widest mb-1">Active Fraud Flag: Ghost Participant</h5>
                <p className="text-[10px] text-gray-400">Entity ID SAMH-2026-X81 attempted to claim daily stipend without valid cryptographic attendance hash for session GBE-40. Transaction frozen by Fail-Safe Kernel.</p>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}

function DemoScenarios() {
  const journeys = [
    { 
      title: "1. Participant Journey", 
      icon: <Users className="w-5 h-5 text-pink-400" />,
      steps: ["Registration", "Assessment", "Training", "Counselling", "Graduation"]
    },
    { 
       title: "2. Donor Journey", 
       icon: <Coins className="w-5 h-5 text-amber-400" />,
       steps: ["Grant Approved", "Funds Released", "Activities Executed", "Proof Submitted", "Verification", "Next Tranche Released"]
    },
    { 
       title: "3. Government Audit", 
       icon: <Gavel className="w-5 h-5 text-indigo-400" />,
       steps: ["Auditor Login", "Select Program", "Verify Ledger", "Verify Signatures", "Download Report"]
    },
    { 
       title: "4. UN Reporting", 
       icon: <FileOutput className="w-5 h-5 text-blue-400" />,
       steps: ["Generate SDG Report", "SDG 3, 4, 5, 10, 16", "Export PDF"]
    }
  ];

  const flagshipSteps = [
    { num: 1, title: "Participant registers", detail: "Jane Doe, Age 16, Gaborone" },
    { num: 2, title: "AI screening", detail: "Risk: HIGH" },
    { num: 3, title: "Counselling assigned", detail: "Social Worker: SW-042" },
    { num: 4, title: "Attends training", detail: "Module: Mental Health Literacy" },
    { num: 5, title: "Attendance recorded", detail: "Cryptographic hash: 0xA123..." },
    { num: 6, title: "Case opened", detail: "Referral to medical professional" },
    { num: 7, title: "Community referral", detail: "Gaborone Local Clinic" },
    { num: 8, title: "Outcome improved", detail: "Depression Index dropped by 40%" },
    { num: 9, title: "Impact dashboard updated", detail: "Global metrics synced" },
    { num: 10, title: "Funding linked", detail: "Tranche 2 condition tracking" },
    { num: 11, title: "Audit generated", detail: "Zero-knowledge proofs compiled" },
    { num: 12, title: "Donor report generated", detail: "UNICEF impact statement PDF" },
    { num: 13, title: "UN SDG report generated", detail: "SDG 3 & 5 matrices updated" },
    { num: 14, title: "Verification certificate issued", detail: "Immutable registry commit" }
  ];

  const [activeStep, setActiveStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  React.useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        setActiveStep(prev => {
          if (prev >= flagshipSteps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, 1500);
    }
    return () => clearInterval(interval);
  }, [isPlaying, flagshipSteps.length]);

  React.useEffect(() => {
    const el = document.getElementById('demo-scroll-container');
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [activeStep]);

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
        <Eye className="w-5 h-5" /> End-to-End Demonstration Journeys
      </h3>

      <div className="bg-[#0A0A0A] border border-emerald-500/30 rounded p-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <BrainCircuit className="w-48 h-48 text-emerald-500" />
        </div>
        <div className="relative z-10 flex flex-col lg:flex-row gap-8">
          <div className="flex-1 space-y-4">
            <h4 className="text-sm font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-2 border-b border-[#333] pb-2">
              💎 Flagship SWI v5 Demo: Full SAMH Ecosystem Lifecycle
            </h4>
            <p className="text-[10px] text-gray-400 leading-relaxed max-w-md">
              Demonstrates a complete socio-technical workflow traversing from the field (participant registration) through risk screening, programmatic interventions (counselling/training), data impact synchronization, financial auditing, and international reporting. All driven by the cryptographic truth kernel.
            </p>
            <div className="flex gap-4 pt-2">
               <button 
                 onClick={() => {
                   if (activeStep === flagshipSteps.length - 1) setActiveStep(0);
                   setIsPlaying(!isPlaying);
                 }}
                 className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold uppercase tracking-widest transition-colors flex items-center gap-2"
               >
                 {isPlaying ? 'Pause Simulation' : activeStep === flagshipSteps.length - 1 ? 'Restart Simulation' : 'Start End-to-End Run'}
               </button>
               <button 
                 onClick={() => {
                   setActiveStep(0);
                   setIsPlaying(false);
                 }}
                 className="px-4 py-2 border border-[#333] text-gray-400 hover:text-white rounded text-xs font-bold uppercase tracking-widest transition-colors"
               >
                 Reset
               </button>
            </div>
          </div>

          <div className="flex-1 relative min-h-[300px]">
            <div className="absolute inset-0 bg-[#111] border border-[#222] rounded p-4 overflow-hidden">
               <div className="h-full overflow-y-auto custom-scrollbar space-y-2 pr-2" id="demo-scroll-container">
                 {flagshipSteps.map((s, i) => (
                   <motion.div 
                     key={s.num}
                     initial={{ opacity: 0.3, x: -10 }}
                     animate={{ 
                       opacity: i <= activeStep ? 1 : 0.3, 
                       x: i <= activeStep ? 0 : -10,
                       backgroundColor: i === activeStep ? 'rgba(16, 185, 129, 0.1)' : 'transparent',
                       borderColor: i === activeStep ? 'rgba(16, 185, 129, 0.3)' : 'transparent'
                     }}
                     className="p-3 border rounded transition-all duration-500 flex gap-4 items-center"
                   >
                      <div className={cn(
                        "w-6 h-6 shrink-0 rounded-full flex items-center justify-center text-[10px] font-bold border",
                        i <= activeStep ? "bg-emerald-500 text-black border-emerald-500" : "bg-transparent text-gray-500 border-[#444]"
                      )}>
                        {s.num}
                      </div>
                      <div>
                        <div className={cn("text-xs font-bold uppercase tracking-wide", i <= activeStep ? "text-gray-200" : "text-gray-500")}>
                          {s.title}
                        </div>
                        <div className={cn("text-[10px]", i <= activeStep ? "text-emerald-400" : "text-gray-600")}>
                          {s.detail}
                        </div>
                      </div>
                      {i <= activeStep && (
                        <div className="ml-auto">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        </div>
                      )}
                   </motion.div>
                 ))}
               </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {journeys.map(j => (
           <div key={j.title} className="bg-[#0A0A0A] border border-[#222] rounded p-5 space-y-4 opacity-70 hover:opacity-100 transition-opacity">
             <h4 className="text-sm font-bold text-gray-300 uppercase tracking-widest flex items-center gap-2 border-b border-[#333] pb-2">
               {j.icon} {j.title}
             </h4>
             <div className="space-y-2">
               {j.steps.map((step, i) => (
                 <div key={step} className="flex flex-col gap-2 relative">
                   <div className="flex bg-[#111] border border-[#333] rounded px-3 py-2 text-[10px] font-bold uppercase tracking-wide text-gray-400 z-10">
                     {step}
                   </div>
                   {i < j.steps.length - 1 && <div className="absolute top-7 left-1/2 -ml-px w-px h-5 bg-[#333] z-0"></div>}
                 </div>
               ))}
               <div className="h-4"></div>
             </div>
           </div>
        ))}
      </div>
    </div>
  );
}

function GlobeIcon(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" x2="22" y1="12" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
}

function HeartIcon(props: any) {
  return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
}
