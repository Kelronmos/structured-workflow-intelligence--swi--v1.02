import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { KnowledgeObject, RustState } from '../swi/rustGovernance';

interface RustScatterPlotProps {
  objects: KnowledgeObject[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

const StateColors: Record<RustState, string> = {
  Active: '#22c55e',       // green-500
  Stable: '#eab308',       // yellow-500
  Dormant: '#f97316',      // orange-500
  Rusting: '#b45309',      // amber-700
  Rust: '#4b5563',         // gray-600
  Reactivated: '#3b82f6',  // blue-500
  Archived: '#9ca3af'      // gray-400
};

export const RustScatterPlot: React.FC<RustScatterPlotProps> = ({ objects, selectedId, onSelect }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const historyRef = useRef<Record<string, { rust: number, patina: number }[]>>({});
  
  // Track initialization
  const initialized = useRef(false);

  useEffect(() => {
    // Update history
    const history = historyRef.current;
    objects.forEach(obj => {
      if (!history[obj.id]) {
        history[obj.id] = [];
      }
      const lastPoint = history[obj.id][history[obj.id].length - 1];
      if (!lastPoint || lastPoint.rust !== obj.rust_factor || lastPoint.patina !== obj.patina_factor) {
        history[obj.id].push({ rust: obj.rust_factor, patina: obj.patina_factor });
        // Keep only last 10 points for trajectory
        if (history[obj.id].length > 10) {
          history[obj.id].shift();
        }
      }
    });

    if (!svgRef.current || !containerRef.current) return;

    const margin = { top: 20, right: 20, bottom: 40, left: 50 };
    const width = containerRef.current.clientWidth || 600;
    const height = 300;
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current);
    svg.attr('width', width).attr('height', height);

    if (!initialized.current) {
      svg.selectAll('*').remove();
      
      const g = svg.append('g')
        .attr('class', 'main-group')
        .attr('transform', `translate(${margin.left},${margin.top})`);
        
      g.append('g').attr('class', 'heatmap-group');
      g.append('g').attr('class', 'axes-group');
      g.append('g').attr('class', 'trajectories-group');
      g.append('g').attr('class', 'points-group');
      
      const tooltipDiv = d3.select('body').append('div')
        .attr('id', 'rust-tooltip')
        .attr('class', 'absolute hidden bg-gray-900 text-white text-xs px-2 py-1 rounded shadow-lg pointer-events-none z-50')
        .style('opacity', 0);

      initialized.current = true;
    }

    const g = svg.select('.main-group');
    
    // Scales
    const xScale = d3.scaleLinear()
      .domain([0, 1]) // Rust factor is 0 to 1
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, 1]) // Patina factor is 0 to 1
      .range([innerHeight, 0]);

    // Update axes if needed (we can redraw them)
    const axesGroup = g.select('.axes-group');
    axesGroup.selectAll('*').remove();
    
    const xAxis = d3.axisBottom(xScale).ticks(5).tickFormat(d => `${(Number(d) * 100).toFixed(0)}%`);
    const yAxis = d3.axisLeft(yScale).ticks(5).tickFormat(d => `${(Number(d) * 100).toFixed(0)}%`);

    axesGroup.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .attr('color', '#9ca3af') // gray-400
      .append('text')
      .attr('x', innerWidth / 2)
      .attr('y', 35)
      .attr('fill', '#6b7280') // gray-500
      .style('text-anchor', 'middle')
      .text('Rust Factor');

    axesGroup.append('g')
      .call(yAxis)
      .attr('color', '#9ca3af')
      .append('text')
      .attr('transform', 'rotate(-90)')
      .attr('x', -innerHeight / 2)
      .attr('y', -40)
      .attr('fill', '#6b7280')
      .style('text-anchor', 'middle')
      .text('Patina (Trust)');

    // Heatmap calculation
    const bins = 10;
    const heatmapData = Array.from({ length: bins * bins }, () => 0);
    
    objects.forEach(obj => {
      const xBin = Math.min(Math.floor(obj.rust_factor * bins), bins - 1);
      const yBin = Math.min(Math.floor(obj.patina_factor * bins), bins - 1);
      heatmapData[yBin * bins + xBin]++;
    });

    const maxDensity = Math.max(...heatmapData, 1);
    const cellWidth = innerWidth / bins;
    const cellHeight = innerHeight / bins;

    // Draw Heatmap
    const heatmapGroup = g.select('.heatmap-group');
    
    heatmapGroup.selectAll('rect')
      .data(heatmapData)
      .join('rect')
      .attr('x', (d, i) => (i % bins) * cellWidth)
      .attr('y', (d, i) => innerHeight - (Math.floor(i / bins) + 1) * cellHeight)
      .attr('width', cellWidth)
      .attr('height', cellHeight)
      .attr('fill', '#3b82f6')
      .attr('stroke', 'rgba(255,255,255,0.05)')
      .transition()
      .duration(750)
      .attr('opacity', d => (d / maxDensity) * 0.3);

    // Draw trajectories
    const lineGenerator = d3.line<{rust: number, patina: number}>()
      .x(d => xScale(d.rust))
      .y(d => yScale(d.patina))
      .curve(d3.curveMonotoneX);

    const activeObjects = objects.filter(o => o.state !== 'Archived');

    const trajectoriesGroup = g.select('.trajectories-group');
    trajectoriesGroup.selectAll('path')
      .data(activeObjects, (d: any) => d.id)
      .join(
        enter => enter.append('path')
          .attr('fill', 'none')
          .attr('stroke-width', 2)
          .attr('opacity', 0.4)
          .attr('stroke', d => StateColors[d.state])
          .attr('d', d => {
            const pts = history[d.id] || [];
            return pts.length > 1 ? lineGenerator(pts) : null;
          }),
        update => update
          .transition()
          .duration(750)
          .attr('stroke', d => StateColors[d.state])
          .attr('d', d => {
            const pts = history[d.id] || [];
            return pts.length > 1 ? lineGenerator(pts) : null;
          }),
        exit => exit.remove()
      );

    // Draw points (Scatter)
    const pointsGroup = g.select('.points-group');
    const tooltip = d3.select('#rust-tooltip');
    
    // Create an object map for easy access in events without stale closure issues
    const objMap = new Map(objects.map(o => [o.id, o]));

    pointsGroup.selectAll('circle')
      .data(activeObjects, (d: any) => d.id)
      .join(
        enter => enter.append('circle')
          .attr('cx', d => xScale(d.rust_factor))
          .attr('cy', d => yScale(d.patina_factor))
          .attr('r', d => d.id === selectedId ? 8 : 6)
          .attr('fill', d => StateColors[d.state])
          .attr('stroke', d => d.id === selectedId ? '#fff' : 'none')
          .attr('stroke-width', 2)
          .style('cursor', 'pointer')
          .style('opacity', 1)
          .on('mouseover', function(event, d: any) {
            const currentObj = objMap.get(d.id) || d;
            d3.select(this).style('opacity', 1).attr('r', 8);
            tooltip.transition().duration(200).style('opacity', 1).style('display', 'block');
            tooltip.html(`
              <div class="font-medium truncate max-w-[150px]">${currentObj.content}</div>
              <div class="text-gray-300 mt-1">Rust: ${(currentObj.rust_factor * 100).toFixed(1)}%</div>
              <div class="text-gray-300">Patina: ${(currentObj.patina_factor * 100).toFixed(1)}%</div>
              <div class="text-[10px] mt-1 px-1.5 py-0.5 rounded border border-gray-700 w-fit">${currentObj.state}</div>
            `)
              .style('left', (event.pageX + 10) + 'px')
              .style('top', (event.pageY - 10) + 'px');
          })
          .on('mouseout', function(event, d: any) {
            d3.select(this).attr('r', d.id === selectedId ? 8 : 6);
            tooltip.transition().duration(500).style('opacity', 0).on('end', () => tooltip.style('display', 'none'));
          })
          .on('click', (event, d: any) => {
            onSelect(d.id);
          }),
        update => update
          .on('click', (event, d: any) => {
            onSelect(d.id);
          })
          .transition()
          .duration(750)
          .attr('cx', d => xScale(d.rust_factor))
          .attr('cy', d => yScale(d.patina_factor))
          .attr('fill', d => StateColors[d.state])
          .attr('stroke', d => d.id === selectedId ? '#fff' : 'none')
          .attr('r', d => d.id === selectedId ? 8 : 6),
        exit => exit.transition().duration(500).style('opacity', 0).remove()
      );

    // Make sure we unbind and rebind tooltip events properly to get the latest state
    pointsGroup.selectAll('circle').on('click', (event, d: any) => {
      onSelect(d.id);
    });

  }, [objects, selectedId, onSelect]);

  useEffect(() => {
    return () => {
      d3.select('#rust-tooltip').remove();
    };
  }, []);

  return (
    <div ref={containerRef} className="w-full h-[300px] overflow-hidden">
      <svg ref={svgRef} className="w-full h-full overflow-visible"></svg>
    </div>
  );
};
