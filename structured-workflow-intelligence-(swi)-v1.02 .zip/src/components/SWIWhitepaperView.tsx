// src/components/SWIWhitepaperView.tsx
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Download, ShieldCheck, Bookmark, ChevronRight, Share2 } from 'lucide-react';

interface SWIWhitepaper {
    title: string;
    version: string;
    author: string;
    classification: string;
    sections: {
        id: string;
        title: string;
        content?: string;
        steps?: string[];
        subsections?: {
            title: string;
            items: string[];
        }[];
    }[];
}

export default function SWIWhitepaperView() {
    const [paper, setPaper] = useState<SWIWhitepaper | null>(null);
    const [downloading, setDownloading] = useState(false);

    useEffect(() => {
        fetch('/api/v4/documentation/whitepaper')
            .then(res => res.json())
            .then(setPaper)
            .catch(e => console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e));
    }, []);

    const handleDownload = async () => {
        setDownloading(true);
        try {
            const res = await fetch('/api/v4/documentation/whitepaper/download');
            const data = await res.json();
            if (data.url) {
                window.open(data.url, '_blank');
            }
        } catch (error) {
            console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Download failed:", error);
        } finally {
            setDownloading(false);
        }
    };

    if (!paper) return null;

    return (
        <div className="bg-white rounded-[3rem] p-12 text-black shadow-2xl relative overflow-hidden">
            {/* Header / Meta */}
            <div className="flex flex-col md:flex-row justify-between items-start gap-8 mb-16 relative z-10">
                <div className="space-y-4">
                    <div className="flex items-center gap-3">
                        <div className="px-3 py-1 bg-black text-white rounded-full">
                            <span className="text-[10px] font-black uppercase tracking-widest">{paper.classification}</span>
                        </div>
                        <span className="text-[10px] font-mono text-black/40 uppercase tracking-widest">v{paper.version}</span>
                    </div>
                    <h1 className="text-5xl font-black tracking-tighter leading-none max-w-2xl">
                        {paper.title}
                    </h1>
                    <p className="text-xs font-bold text-black/40 uppercase tracking-[0.3em] flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4" /> Official System Specification
                    </p>
                </div>
                <div className="flex flex-col items-end gap-2">
                     <button 
                         onClick={handleDownload}
                         disabled={downloading}
                         className="flex items-center gap-2 px-6 py-3 bg-black text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl shadow-black/20 disabled:opacity-50"
                     >
                        {downloading ? <span className="animate-pulse">Building...</span> : <><Download className="w-4 h-4" /> Download PDF</>}
                     </button>
                     <p className="text-[10px] font-bold text-black/20 uppercase tracking-widest italic">{paper.author}</p>
                </div>
            </div>

            {/* Document Content Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-16 relative z-10">
                {/* Table of Contents */}
                <div className="md:col-span-3 space-y-4 border-r border-black/5 pr-8 hidden md:block">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-black/30 mb-6">Contents</h4>
                    {paper.sections.map(section => (
                        <a key={section.id} href={`#${section.id}`} className="block text-[10px] font-bold uppercase tracking-widest text-black/40 hover:text-black transition-colors">
                            {section.title.split('. ')[1] || section.title}
                        </a>
                    ))}
                </div>

                {/* Main Body */}
                <div className="md:col-span-9 space-y-16">
                    {paper.sections.map((section) => (
                        <motion.section 
                            key={section.id} 
                            id={section.id}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            className="space-y-6"
                        >
                            <h3 className="text-xl font-black uppercase tracking-tighter border-b-2 border-black pb-2 inline-block">
                                {section.title}
                            </h3>
                            
                            {section.content && (
                                <p className="text-base font-serif leading-relaxed text-black/80">
                                    {section.content}
                                </p>
                            )}

                            {section.subsections && (
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
                                    {section.subsections.map((sub, i) => (
                                        <div key={i} className="space-y-3">
                                            <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-black/40">{sub.title}</h4>
                                            <ul className="space-y-2">
                                                {sub.items.map((item, j) => (
                                                    <li key={j} className="flex items-start gap-2 text-xs font-bold text-black/70">
                                                        <ChevronRight className="w-3 h-3 mt-0.5 text-black/20" />
                                                        {item}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {section.steps && (
                                <div className="space-y-4 pt-4">
                                    {section.steps.map((step, idx) => (
                                        <div key={idx} className="flex gap-4 p-4 bg-black/5 rounded-2xl border border-black/5">
                                            <span className="text-xs font-black font-mono text-black/30 bg-white w-6 h-6 flex items-center justify-center rounded-lg shadow-sm">{idx + 1}</span>
                                            <p className="text-xs font-bold leading-normal text-black/70">
                                                {step}
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </motion.section>
                    ))}
                </div>
            </div>

            {/* Footer / Authentication */}
            <div className="mt-24 pt-12 border-t border-black/10 flex flex-col items-center justify-center gap-4 text-center">
                 <Bookmark className="w-8 h-8 text-black/10" />
                 <p className="text-[10px] font-bold text-black/20 uppercase tracking-[0.5em] max-w-lg">
                    This document is cryptographically linked to the SWI kernel and serves as the legal gold-standard for deterministic governance.
                 </p>
                 <div className="flex gap-4 mt-4">
                    <button className="p-4 bg-black/5 rounded-full hover:bg-black/10 transition-colors">
                        <Share2 className="w-5 h-5 opacity-40" />
                    </button>
                    <div className="px-6 py-4 bg-black/5 rounded-3xl border border-black/5 flex items-center gap-3">
                         <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                         <span className="text-[9px] font-black uppercase tracking-[0.2em] text-black/40">Continuity Verifiable</span>
                    </div>
                 </div>
            </div>

            {/* Watermark */}
            <div className="absolute bottom-10 left-10 pointer-events-none opacity-[0.03]">
                 <h2 className="text-[15vw] font-black leading-none -rotate-12 select-none">SOVEREIGN</h2>
            </div>
        </div>
    );
}
