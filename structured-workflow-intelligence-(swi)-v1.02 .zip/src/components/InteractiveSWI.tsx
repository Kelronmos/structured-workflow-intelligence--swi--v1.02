import { useState } from 'react';

export default function InteractiveSWI() {
  const [environment, setEnvironment] = useState('stable');
  const [userBehavior, setUserBehavior] = useState('normal');
  const [output, setOutput] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);

  const runTest = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          event_id: "E-001",
          action: "TRANSFER",
          userBehavior,
          environment,
          details: {
            cost_owner: null,
            rollback_owner: null,
            rollback_plan: null
          },
          signatures: [],
          authority_token: "invalid",
          ahmr: {
            attestation_token: "AHMR_LEGAL_TEST",
            legal_signer_id: "SIGNER_001",
            dual_signoff: true
          }
        })
      });

      const data = await res.json();
      setOutput(data);
    } catch (err) {
      setOutput({ error: String(err) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 border border-[#141414] bg-white dark:bg-[#141414] dark:border-[#E4E3E0]/20 space-y-6">
      <h2 className="text-xl font-bold uppercase tracking-tighter">Interactive SWI</h2>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-[10px] uppercase font-bold opacity-40">Environment</label>
          <select 
            value={environment} 
            onChange={(e) => setEnvironment(e.target.value)}
            className="w-full p-2 border border-[#141414] dark:border-[#E4E3E0]/20 bg-transparent text-sm"
          >
            <option value="stable">Stable</option>
            <option value="unstable">Unstable</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[10px] uppercase font-bold opacity-40">User Behavior</label>
          <select 
            value={userBehavior} 
            onChange={(e) => setUserBehavior(e.target.value)}
            className="w-full p-2 border border-[#141414] dark:border-[#E4E3E0]/20 bg-transparent text-sm"
          >
            <option value="normal">Normal</option>
            <option value="anomalous">Anomalous</option>
          </select>
        </div>
      </div>

      <div className="flex gap-4">
        <button 
          onClick={runTest}
          disabled={loading}
          className="px-6 py-3 bg-[#141414] text-white dark:bg-[#E4E3E0] dark:text-[#141414] font-bold uppercase text-sm"
        >
          {loading ? "Executing..." : "Execute"}
        </button>
      </div>

      <pre className="p-4 bg-black/5 dark:bg-white/5 font-mono text-xs overflow-x-auto">
        {output ? JSON.stringify(output, null, 2) : "No output yet."}
      </pre>
    </div>
  );
}
