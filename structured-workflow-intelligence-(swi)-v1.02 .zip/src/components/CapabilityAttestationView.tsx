import React, { useState, useEffect } from "react";
import {
  Cpu,
  ShieldCheck,
  Lock,
  Smartphone,
  Monitor,
  Apple,
  Terminal,
  FileCheck2,
  ScanLine,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface PlatformCapability {
  id: string;
  name: string;
  icon: React.ElementType;
  supportLevel: "Strongest" | "Strong" | "Moderate" | "Restricted";
  checks: string[];
}

export default function CapabilityAttestationView() {
  const [scanStatus, setScanStatus] = useState<
    "IDLE" | "SCANNING" | "VERIFIED" | "FAILED"
  >("IDLE");
  const [scanProgress, setScanProgress] = useState(0);

  const platforms: PlatformCapability[] = [
    {
      id: "linux",
      name: "Linux",
      icon: Terminal,
      supportLevel: "Strongest",
      checks: [
        "TPM2 presence",
        "Secure Boot",
        "dm-verity",
        "Kernel hash",
        "Disk encryption",
        "Container integrity",
      ],
    },
    {
      id: "windows",
      name: "Windows",
      icon: Monitor,
      supportLevel: "Strong",
      checks: [
        "TPM 2.0",
        "Secure Boot",
        "BitLocker",
        "Device Guard",
        "WinVerifyTrust",
        "Windows Defender",
      ],
    },
    {
      id: "macos",
      name: "macOS",
      icon: Apple,
      supportLevel: "Moderate",
      checks: [
        "Secure Enclave",
        "SIP status",
        "FileVault",
        "Notarization validation",
        "Signed binaries",
      ],
    },
    {
      id: "android",
      name: "Android",
      icon: Smartphone,
      supportLevel: "Moderate",
      checks: [
        "Verified Boot",
        "Hardware-backed keystore",
        "Play Integrity",
        "Bootloader lock",
        "SELinux enforcing",
      ],
    },
  ];

  useEffect(() => {
    if (scanStatus === "SCANNING") {
      const interval = setInterval(() => {
        setScanProgress((p) => {
          if (p >= 100) {
            clearInterval(interval);
            setScanStatus("VERIFIED");
            return 100;
          }
          return p + 2;
        });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [scanStatus]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Cpu className="w-5 h-5 text-fuchsia-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Hardware Capability & Attestation Layer (HCAL)
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            Inspect device properties, verify minimum trust requirements, bond
            execution to approved hardware states, and generate signed
            capability proofs. NO TRUST BY DEFAULT.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live Device Scanner */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4 lg:col-span-1 flex flex-col">
          <div className="flex items-center gap-2 text-fuchsia-400 mb-2">
            <ScanLine className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              Live Device Scanner
            </h3>
          </div>

          <div className="bg-black/40 border border-white/5 p-4 flex-1 flex flex-col">
            <button
              onClick={() => {
                setScanStatus("SCANNING");
                setScanProgress(0);
              }}
              disabled={scanStatus === "SCANNING"}
              className="w-full bg-fuchsia-500/10 hover:bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/30 text-[10px] uppercase font-bold py-2 mb-4 transition-all disabled:opacity-50"
            >
              Run Attestation Scan
            </button>

            {scanStatus !== "IDLE" && (
              <div className="space-y-3 font-mono text-[9px] text-white/60">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Scanning hardware...</span>
                    <span>{scanProgress}%</span>
                  </div>
                  <div className="h-1 bg-white/10 w-full overflow-hidden">
                    <div
                      className="h-full bg-fuchsia-500 transition-all duration-75"
                      style={{ width: `${scanProgress}%` }}
                    ></div>
                  </div>
                </div>

                {scanProgress > 20 && (
                  <div className="text-green-400">
                    <CheckCircle2 className="w-3 h-3 inline mr-1" /> CPU / RAM /
                    Secure Boot ... OK
                  </div>
                )}
                {scanProgress > 50 && (
                  <div className="text-green-400">
                    <CheckCircle2 className="w-3 h-3 inline mr-1" /> TPM 2.0 /
                    Secure Enclave ... OK
                  </div>
                )}
                {scanProgress > 80 && (
                  <div className="text-green-400">
                    <CheckCircle2 className="w-3 h-3 inline mr-1" /> Disk
                    Encryption / Integrity ... OK
                  </div>
                )}

                {scanStatus === "VERIFIED" && (
                  <div className="mt-4 p-3 border border-fuchsia-500/30 bg-fuchsia-500/5 text-fuchsia-300">
                    <div className="font-bold mb-1">
                      CAPABILITY PROOF SIGNED
                    </div>
                    <div className="opacity-70">
                      Binding execution to verified session. Minimum spec policy
                      check passed.
                    </div>
                  </div>
                )}
              </div>
            )}

            {scanStatus === "IDLE" && (
              <div className="text-center text-white/30 font-mono text-[9px] py-10 my-auto">
                AWAITING SCAN TRIGGGER
              </div>
            )}
          </div>
        </div>

        {/* Minimum Spec & Policy */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center gap-2 text-blue-400 mb-2">
            <FileCheck2 className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              Minimum Spec Engine
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#0A0A0A] border border-blue-500/20 p-3 font-mono text-[10px] text-blue-300">
              <div className="text-blue-500/60 mb-2"># Policy Evaluation</div>
              <div>minimum_requirements:</div>
              <div className="pl-4">ram_gb: 8</div>
              <div className="pl-4">cpu_cores: 4</div>
              <div className="pl-4">secure_boot: true</div>
              <div className="pl-4">disk_encryption: true</div>
              <br />
              <div>required_security:</div>
              <div className="pl-4">tpm_or_secure_enclave: true</div>
              <div className="pl-4">signed_runtime: true</div>
              <br />
              <div>disallowed:</div>
              <div className="pl-4 text-red-400">rooted_devices: true</div>
              <div className="pl-4 text-red-400">jailbroken_devices: true</div>
            </div>

            <div className="space-y-3">
              <div className="border border-white/10 p-3">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-white/60 mb-2">
                  Capability Score Model
                </h4>
                <div className="space-y-1 text-[9px] font-mono text-white/50">
                  <div className="flex justify-between">
                    <span>BOOT TRUST</span> <span>20</span>
                  </div>
                  <div className="flex justify-between">
                    <span>HARDWARE SECURITY</span> <span>20</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RUNTIME INTEGRITY</span> <span>20</span>
                  </div>
                  <div className="flex justify-between">
                    <span>POLICY COMPLIANCE</span> <span>20</span>
                  </div>
                  <div className="flex justify-between">
                    <span>HUMAN AUTH</span> <span>20</span>
                  </div>
                </div>
              </div>

              <div className="border border-white/10 p-3 bg-red-950/20">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-red-400 mb-2">
                  Important Safety Boundary
                </h4>
                <div className="text-[9px] font-mono text-red-300/80 leading-relaxed">
                  SWI should NEVER bypass OS security, secretly persist, or
                  override device ownership. Instead it must be USER-CONSENTED,
                  VISIBLE, ATTESTED, and POLICY-CONSTRAINED.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Cross-Platform Architecture */}
      <h3 className="text-xs font-bold uppercase tracking-widest text-[#E4E3E0] pt-4 border-t border-white/10">
        Cross-Platform Attestation Support
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {platforms.map((platform) => (
          <div
            key={platform.id}
            className="bg-[#141414] border border-white/10 p-4"
          >
            <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
              <div className="flex items-center gap-2 text-white">
                <platform.icon className="w-4 h-4" />
                <span className="text-[11px] font-bold uppercase tracking-widest">
                  {platform.name}
                </span>
              </div>
              <span
                className={cn(
                  "text-[8px] uppercase font-bold px-2 py-0.5 rounded-full border",
                  platform.supportLevel === "Strongest"
                    ? "border-green-500 text-green-500 bg-green-500/10"
                    : platform.supportLevel === "Strong"
                      ? "border-emerald-500 text-emerald-500 bg-emerald-500/10"
                      : "border-yellow-500 text-yellow-500 bg-yellow-500/10",
                )}
              >
                {platform.supportLevel}
              </span>
            </div>

            <ul className="space-y-1.5 text-[9px] font-mono text-white/50">
              {platform.checks.map((check) => (
                <li key={check} className="flex items-start gap-1.5">
                  <ShieldCheck className="w-3 h-3 text-white/20 mt-0.5 shrink-0" />
                  <span>{check}</span>
                </li>
              ))}
            </ul>
            {platform.id === "android" && (
              <div className="mt-3 pt-2 border-t border-white/5 text-[8px] text-yellow-500 font-mono">
                iPhone/iOS restricted by sandboxing (App Attest only).
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Binding Model */}
      <div className="bg-[#141414] border border-white/10 p-5 mt-4">
        <h3 className="text-xs font-bold uppercase tracking-widest text-[#E4E3E0] mb-3">
          Session Binding Model
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 font-mono text-[9px]">
          <div className="space-y-2">
            <div className="text-emerald-400 font-bold mb-1">
              ✅ SAFEST INTERPRETATION: SESSION BINDING
            </div>
            <div className="text-white/60">
              Runtime token tied to device identity.
            </div>
            <div className="text-white/60">
              Execution only valid on verified hardware.
            </div>
            <div className="text-white/60">Tokens expire quickly.</div>
            <div className="text-white/60">Proof tied to attested state.</div>
          </div>
          <div className="space-y-2">
            <div className="text-red-400 font-bold mb-1">
              ❌ DANGEROUS/NOT ALLOWED
            </div>
            <div className="text-white/60">Permanent device ownership.</div>
            <div className="text-white/60">Hidden persistence.</div>
            <div className="text-white/60">Bypassing OS permissions.</div>
            <div className="text-white/60">Remote unrestricted control.</div>
          </div>
        </div>
      </div>

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-white/10 mt-6 text-center">
        <ProofArtifacts
          id="hcal"
          title="Attestation Validation & Capability Proof"
          data={{
            scanStatus,
            progress: scanProgress,
            capabilities: platforms.map((p) => p.name),
          }}
          variant="always-dark"
        />
      </div>
    </div>
  );
}
