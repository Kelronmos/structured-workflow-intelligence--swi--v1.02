import React from "react";

export const SkeletonLoader = () => (
  <div className="animate-pulse flex flex-col gap-6">
    <div className="h-8 bg-gray-800/50 rounded w-1/4 mb-4"></div>
    <div className="grid grid-cols-4 gap-4">
      <div className="col-span-2 row-span-2 bg-gray-900/50 border border-gray-800 rounded-lg p-6 h-full flex flex-col gap-4">
        <div className="h-4 bg-gray-800 rounded w-1/3"></div>
        <div className="flex items-end gap-4 mt-auto">
          <div className="h-16 bg-gray-800 rounded w-1/4"></div>
          <div className="h-8 bg-gray-800 rounded w-1/4"></div>
        </div>
      </div>
      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 h-32 flex flex-col justify-between">
         <div className="h-3 bg-gray-800 rounded w-1/2"></div>
         <div className="h-8 bg-gray-800 rounded w-1/3"></div>
      </div>
      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 h-32 flex flex-col justify-between">
         <div className="h-3 bg-gray-800 rounded w-1/2"></div>
         <div className="h-8 bg-gray-800 rounded w-1/3"></div>
      </div>
      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 h-32 flex flex-col justify-between">
         <div className="h-3 bg-gray-800 rounded w-1/2"></div>
         <div className="h-8 bg-gray-800 rounded w-1/3"></div>
      </div>
      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 h-32 flex flex-col justify-between">
         <div className="h-3 bg-gray-800 rounded w-1/2"></div>
         <div className="h-8 bg-gray-800 rounded w-1/3"></div>
      </div>
    </div>
    <div className="h-64 bg-gray-900/30 rounded border border-gray-800 mt-4"></div>
  </div>
);
