
import { motion } from 'motion/react';
import { Cpu, Shield, Database, Layout, Lock, Globe, FileCheck2 } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export default function ArchitectureDiagram({ theme }: { theme: 'light' | 'dark' }) {
  const layers = [
    { id: 'client', name: 'Client Layer', icon: Layout, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { id: 'api', name: 'API Gateway', icon: Globe, color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { id: 's9', name: 'S9 Kernel (Orchestrator)', icon: Cpu, color: 'text-orange-500', bg: 'bg-orange-500/10' },
    { id: 'rust', name: 'Rust Authority Engine', icon: Shield, color: 'text-red-500', bg: 'bg-red-500/10' },
    { id: 'provenance', name: 'Document Provenance & Replay', icon: FileCheck2, color: 'text-fuchsia-500', bg: 'bg-fuchsia-500/10' },
    { id: 'crypto', name: 'Cryptographic Proofs (Ed25519)', icon: Lock, color: 'text-green-500', bg: 'bg-green-500/10' },
    { id: 'logs', name: 'Kafka Audit Ledger', icon: Database, color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
  ];

  return (
    <div className="p-8 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-8">
      <div className="space-y-1">
        <h3 className="text-sm font-bold uppercase tracking-widest">SWI System Architecture</h3>
        <p className="text-[10px] opacity-40 uppercase">Deterministic Execution Boundary Topology</p>
      </div>

      <div className="flex flex-col items-center gap-4 relative">
        {layers.map((layer, index) => (
          <motion.div
            key={layer.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={cn(
              "w-full max-w-md p-4 border border-dashed flex items-center justify-between z-10",
              layer.bg,
              theme === 'light' ? "border-[#141414]/20" : "border-[#E4E3E0]/20"
            )}
          >
            <div className="flex items-center gap-4">
              <layer.icon className={cn("w-5 h-5", layer.color)} />
              <div>
                <p className="text-[10px] font-bold uppercase">{layer.name}</p>
                <p className="text-[8px] opacity-60 uppercase">Layer {index + 1}</p>
              </div>
            </div>
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
          </motion.div>
        ))}

        {/* Connecting Lines */}
        <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[2px] bg-gradient-to-b from-transparent via-[#141414]/10 dark:via-[#E4E3E0]/10 to-transparent z-0" />
      </div>

      <div className="pt-4 border-t border-[#141414]/10 dark:border-[#E4E3E0]/10 grid grid-cols-2 gap-4">
         <div className="space-y-1">
            <p className="text-[8px] font-bold uppercase opacity-40">Isolation Model</p>
            <p className="text-[10px] font-mono">NON_BYPASSABLE_KERNEL</p>
         </div>
         <div className="space-y-1 text-right">
            <p className="text-[8px] font-bold uppercase opacity-40">Proof Standard</p>
            <p className="text-[10px] font-mono">MERKLE_CHAIN_V4</p>
         </div>
      </div>
    </div>
  );
}
