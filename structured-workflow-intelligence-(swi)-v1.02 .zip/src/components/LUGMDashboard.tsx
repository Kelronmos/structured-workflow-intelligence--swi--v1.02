import React, { useState, useEffect } from "react";
import { globalLugmEngine } from "../swi/lugm/engine";
import { AuditOutput } from "../swi/lugm/types";
import { ShieldAlert, BookLock, Database, CheckCircle, FileWarning } from "lucide-react";

export default function LUGMDashboard() {
  const [report, setReport] = useState<AuditOutput | null>(null);

  const refreshReport = () => {
    setReport(globalLugmEngine.generateAuditReport());
  };

  useEffect(() => {
    refreshReport();
  }, []);

  const handleAddClaim = () => {
    globalLugmEngine.registerClaim(
      `claim-${Math.random().toString(36).substring(7, 12)}`,
      "prototype-level execution boundary behavior exists",
      ["evidence-test-001"]
    );
    refreshReport();
  };

  const handleAddUnverifiedClaim = () => {
    globalLugmEngine.registerClaim(
      `claim-${Math.random().toString(36).substring(7, 12)}`,
      "production-level execution behavior exists (unsupported)",
      [] // No evidence provided
    );
    refreshReport();
  };

  const handleAddUpdate = async () => {
    await globalLugmEngine.registerUpdate("v0.1-proto", "v0.2-proto", ["test_log_01", "trace_005"]);
    refreshReport();
  };

  if (!report) return null;

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-[#E4E3E0] min-h-screen font-mono text-xs">
      <div className="flex items-center justify-between border-b border-[#333] pb-4">
        <div>
          <h1 className="text-xl font-bold uppercase tracking-widest text-[#00ffcc] flex items-center gap-2">
            <BookLock className="w-5 h-5" /> Lifecycle & Update Governance Module (LUGM)
          </h1>
          <p className="text-[#888] mt-1">Prototype Status Only - No Production Claims</p>
        </div>
        <div className="flex gap-4">
          <div className={`px-4 py-2 border rounded font-bold uppercase ${report.verification_level === 'prototype_level_2' ? 'border-[#00ffcc] text-[#00ffcc] bg-[#00ffcc]/10' : 'border-[#ffaa00] text-[#ffaa00] bg-[#ffaa00]/10'}`}>
            Classification: {report.verification_level}
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={handleAddClaim}
          className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#00ffcc] text-[#00ffcc] transition-colors"
        >
          Inject Verified Prototype Claim
        </button>
        <button
          onClick={handleAddUnverifiedClaim}
          className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#ffaa00] text-[#ffaa00] transition-colors"
        >
          Inject Missing-Evidence Claim
        </button>
        <button
          onClick={handleAddUpdate}
          className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#ff00ff] text-[#ff00ff] transition-colors"
        >
          Publish Prototype Update
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase text-[#888] border-b border-[#333] pb-2 flex gap-2">
            <Database className="w-4 h-4" /> Claims Registry (Evidence Linked)
          </h2>
          <div className="space-y-3">
            {report.claims.map((c, i) => (
              <div key={i} className={`p-4 border ${c.status === 'prototype_verified' ? 'border-[#00ffcc]/30 bg-[#00ffcc]/5' : 'border-[#ffaa00]/30 bg-[#ffaa00]/5'} rounded`}>
                <div className="flex justify-between items-center mb-2">
                  <div className="font-bold text-[#E4E3E0]">{c.id}</div>
                  <div className={`px-2 py-1 text-[10px] uppercase rounded flex items-center gap-1 ${c.status === 'prototype_verified' ? 'text-[#00ffcc] border border-[#00ffcc]' : 'text-[#ffaa00] border border-[#ffaa00]'}`}>
                    {c.status === 'prototype_verified' ? <CheckCircle className="w-3 h-3" /> : <FileWarning className="w-3 h-3" />}
                    {c.status}
                  </div>
                </div>
                <div className="text-[#888] mb-2">{c.statement}</div>
                <div className="text-[10px] text-[#555]">
                  Evidence Links: {c.evidence.length > 0 ? c.evidence.join(", ") : "NONE PROVIDED"}
                </div>
              </div>
            ))}
            {report.claims.length === 0 && <div className="text-center p-6 text-[#555] dashed border border-[#222]">No Claims Registered</div>}
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase text-[#888] border-b border-[#333] pb-2 flex gap-2">
            <ShieldAlert className="w-4 h-4" /> Update Ledger
          </h2>
          <div className="space-y-3">
            {report.updates.map((u, i) => (
              <div key={i} className="p-4 border border-[#333] bg-[#111] rounded">
                <div className="flex justify-between items-center mb-2">
                  <div className="text-[#ff00ff] font-bold">Update: {u.previousVersion} → {u.newVersion}</div>
                  <div className="px-2 py-1 text-[10px] border border-[#333] text-[#888] rounded">{u.deploymentScope}</div>
                </div>
                <div className="text-[#555] mb-2">ID: {u.updateId}</div>
                <div className="flex flex-wrap gap-2 text-[10px]">
                  <span className="px-2 py-1 bg-[#222] text-[#888] rounded">Valid: {u.validationStatus}</span>
                  <span className="px-2 py-1 bg-[#222] text-[#888] rounded">Evidence: {u.evidenceLinks.length}</span>
                </div>
                <div className="mt-3 text-[10px] text-[#444] truncate border-t border-[#222] pt-2">
                  SIG: {u.auditSignature}
                </div>
              </div>
            ))}
            {report.updates.length === 0 && <div className="text-center p-6 text-[#555] dashed border border-[#222]">No Updates Published</div>}
          </div>
        </div>
      </div>

      <div className="p-4 border border-[#333] bg-[#111] rounded mt-6 print:border-none print:shadow-none">
        <h2 className="text-sm font-bold uppercase text-[#888] mb-3">Audit Output (JSON Report)</h2>
        <pre className="text-[10px] text-[#00ffcc] overflow-x-auto">
          {JSON.stringify(report, null, 2)}
        </pre>
      </div>
    </div>
  );
}
