import React, { useState } from "react";
import { 
  Milestone, 
  BookOpen, 
  Terminal, 
  ShieldCheck, 
  Network, 
  AlertTriangle, 
  Target 
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function DeploymentStrategyView() {
  const [activePhase, setActivePhase] = useState<number | null>(null);

  const phases = [
    {
      num: 1,
      title: "Public Research Repo",
      status: "Realistic & Credible",
      icon: <BookOpen className="w-5 h-5" />,
      items: [
        "Architecture & Ontology",
        "Reaction Matrix & Diagram concepts",
        "Isolation flow & Simulations",
        "Governance models & Pseudocode",
      ],
      desc: "Safe and realistic starting point to establish the foundation of SWI.",
      color: "blue"
    },
    {
      num: 2,
      title: "Simulation Runtime",
      status: "Prototype Status",
      icon: <Terminal className="w-5 h-5" />,
      items: [
        "Local runtime execution",
        "Event engine & Replay system",
        "Drift engine (computing entropy)",
        "Observability dashboard telemetry",
      ],
      desc: "Creating executable representations of the governance physics matrix.",
      color: "emerald"
    },
    {
      num: 3,
      title: "Cryptographic Trust Layer",
      status: "Maturation Phase",
      icon: <ShieldCheck className="w-5 h-5" />,
      items: [
        "Signatures & Validator proofs",
        "Attestation & Hardware trust",
        "Rollback protection guarantees",
        "Deterministic origin anchors",
      ],
      desc: "Grounding the simulation in verifiable cryptographic roots.",
      color: "purple"
    },
    {
      num: 4,
      title: "Distributed Governance Network",
      status: "Target State",
      icon: <Network className="w-5 h-5" />,
      items: [
        "Deterministic verification",
        "Adversarial testing environments",
        "Governance stability metrics",
        "Reproducible node audits",
      ],
      desc: "Only deploying after robust stability and adversarial resilience are proven.",
      color: "fuchsia"
    }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="bg-[#050510] border border-cyan-500/20 p-6 md:p-8 flex items-center justify-between overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 blur-[120px] pointer-events-none"></div>
        <div className="relative z-10 w-full">
           <h2 className="text-xl md:text-2xl font-black uppercase tracking-widest text-[#E4E3E0] flex items-center gap-3">
              <Milestone className="w-6 h-6 text-cyan-500" /> Best Deployment Strategy Right Now
           </h2>
           <p className="text-xs font-mono text-cyan-300/60 mt-2 max-w-3xl leading-relaxed">
              Incremental capability deployment. Treating governance continuity as a runtime engineering problem instead of a policy document.
           </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {phases.map((phase) => {
          const isActive = activePhase === phase.num;
          const mapColors = {
            blue: "border-blue-500/30 bg-blue-500/5 text-blue-400 group-hover:border-blue-500/60",
            emerald: "border-emerald-500/30 bg-emerald-500/5 text-emerald-400 group-hover:border-emerald-500/60",
            purple: "border-purple-500/30 bg-purple-500/5 text-purple-400 group-hover:border-purple-500/60",
            fuchsia: "border-fuchsia-500/30 bg-fuchsia-500/5 text-fuchsia-400 group-hover:border-fuchsia-500/60",
          };
          const activeColor = mapColors[phase.color as keyof typeof mapColors];
          
          return (
            <button 
               key={phase.num}
               onClick={() => setActivePhase(isActive ? null : phase.num)}
               className={cn(
                 "text-left p-4 rounded-xl border transition-all duration-500 group relative overflow-hidden",
                 isActive ? "bg-white/10 border-white/30 scale-[1.02] shadow-xl" : "bg-[#141414] border-white/5 hover:bg-white/5 hover:border-white/10 opacity-70 hover:opacity-100"
               )}
            >
               <div className={cn("absolute -top-10 -right-10 w-32 h-32 blur-[40px] opacity-20 transition-opacity", isActive ? "opacity-40" : "group-hover:opacity-30", activeColor.split(" ")[1])}></div>
               
               <div className={cn("inline-flex p-2 rounded-lg mb-4 border transition-colors", activeColor)}>
                  {phase.icon}
               </div>
               
               <div className="text-[10px] font-bold text-white/50 uppercase tracking-widest mb-1">
                  Phase {phase.num}
               </div>
               <h3 className="text-sm font-bold text-white mb-2 leading-tight">
                  {phase.title}
               </h3>
               
               <div className="text-[9px] font-mono uppercase px-2 py-1 bg-white/5 inline-block text-white/60 mb-4 rounded border border-white/10">
                  {phase.status}
               </div>

               <div className={cn("overflow-hidden transition-all duration-500", isActive ? "max-h-96 opacity-100" : "max-h-0 opacity-0")}>
                  <p className="text-[10px] text-white/70 mb-3 leading-relaxed border-b border-white/10 pb-3">
                     {phase.desc}
                  </p>
                  <ul className="space-y-2">
                     {phase.items.map((item, idx) => (
                        <li key={idx} className="text-[10px] font-mono text-white/50 flex gap-2">
                           <span className="text-white/20">-</span> {item}
                        </li>
                     ))}
                  </ul>
               </div>
            </button>
          )
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 animate-in slide-in-from-bottom-6 duration-700 delay-200">
         <div className="bg-[#1a0f0f] border border-red-500/20 p-6 rounded-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 blur-[50px]"></div>
            <h3 className="text-xs font-bold text-red-400 uppercase tracking-widest mb-4 flex items-center gap-2">
               <AlertTriangle className="w-4 h-4" /> Important Warning
            </h3>
            <p className="text-[11px] font-mono text-rose-200/70 leading-relaxed mb-4">
               Do not overclaim. A strong architecture loses credibility when claims exceed operational proof.
            </p>
            <div className="bg-black/40 border border-red-500/20 rounded p-4">
               <span className="text-[10px] font-bold text-white/40 uppercase mb-2 block">Avoid statements like:</span>
               <ul className="text-[11px] font-mono text-red-300/80 space-y-1">
                 <li className="line-through opacity-70">"unbreakable"</li>
                 <li className="line-through opacity-70">"fully sovereign"</li>
                 <li className="line-through opacity-70">"court-certified"</li>
                 <li className="line-through opacity-70">"military-grade"</li>
                 <li className="line-through opacity-70">"verified AI governance"</li>
               </ul>
               <div className="text-[9px] text-red-500/80 uppercase mt-4 font-bold tracking-widest">
                  *unless independently validated.
               </div>
            </div>
         </div>

         <div className="bg-[#0f1a15] border border-emerald-500/20 p-6 rounded-xl relative overflow-hidden flex flex-col">
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 blur-[50px]"></div>
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-4 flex items-center gap-2">
               <Target className="w-4 h-4" /> Most Realistic Positioning
            </h3>
            
            <div className="flex-1 flex flex-col justify-center text-center px-4 bg-black/40 border border-emerald-500/20 rounded-[1rem] p-6 shadow-inner relative z-10">
               <p className="text-sm font-serif italic text-emerald-100/90 leading-relaxed mb-6">
                  "A governance-oriented runtime architecture and simulation framework for trust continuity, observability, reflex isolation, and cryptographic governance research."
               </p>

               <div className="text-[11px] font-mono text-emerald-400/80 border-t border-emerald-500/20 pt-4">
                  <strong>The strongest innovation is not the cryptography itself.</strong><br/>
                  It is treating governance continuity as a <span className="underline decoration-emerald-500/50 underline-offset-4 font-bold text-white">runtime engineering problem</span> instead of a policy document.
               </div>
            </div>
         </div>
      </div>

      <div className="flex justify-center mt-8">
         <ProofArtifacts
            id="deployment-strategy"
            title="Strategic Credibility Grounding"
            data={{
               posture: "REALISTIC",
               primary_innovation: "RUNTIME_ENGINEERING_VS_POLICY",
               roadmap_phases: 4
            }}
            variant="default"
         />
      </div>
    </div>
  );
}
