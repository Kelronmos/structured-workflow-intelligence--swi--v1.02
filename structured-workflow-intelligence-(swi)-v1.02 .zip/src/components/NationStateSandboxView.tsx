import React, { useState, useEffect } from "react";
import {
  Globe,
  ShieldAlert,
  Crosshair,
  Users,
  LineChart,
  AlertTriangle,
  Play,
  Pause,
  RefreshCw,
  Terminal,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface SandboxScenario {
  id: string;
  name: string;
  severity: number;
  trigger: string;
  logs: string[];
}

const scenarios: SandboxScenario[] = [
  {
    id: "cyber-attack",
    name: "Critical Infrastructure Cyber-Attack",
    severity: 95,
    trigger: "SCENARIO_INJECT: GRID_OFFLINE_PROBABILITY_0.9",
    logs: [
      "[EVENT] Power grid failure reported in Sector 4.",
      "[ASSERT] Verifying signature of failure report... OK.",
      "[FSM] Transitioning to EMERGENCY_MODE.",
      "[GOVERNANCE] Invoking bypass protocols. Requesting Quorum...",
      "[HOTSTUFF] 2f+1 nodes signed emergency protocol.",
      "[EXECUTE] Rerouting auxiliary power reserves.",
    ],
  },
  {
    id: "economic-collapse",
    name: "Hyperinflation Bank Run",
    severity: 80,
    trigger: "SCENARIO_INJECT: FIAT_DEVALUATION_SPIKE",
    logs: [
      "[EVENT] Massive capital flight detected across top 3 exchanges.",
      "[POLICY] Assert: Liquidity threshold drop below 20%.",
      "[FSM] State -> FREEZE_ASSETS.",
      "[AUDIT] Writing freeze event to append-only immutable ledger.",
      "[GOVERNANCE] Human quorum required for unfreeze. Waiting...",
    ],
  },
  {
    id: "rogue-general",
    name: "Command Chain Hijack",
    severity: 100,
    trigger: "SCENARIO_INJECT: UNAUTHORIZED_EXEC_ATTEMPT",
    logs: [
      "[SECURITY] Rogue authority token usage detected. Drift=0.88.",
      "[JOE_RUNTIME] VPI Hook intercepted unauthorized command.",
      "[EVENT_QUEUE] Pushing HALT_AND_ISOLATE event.",
      "[BYZANTINE] Node isolated from cluster. Signatures rejected.",
      "[RUNTIME] Structural rules confirm no unsafe state reached.",
    ],
  },
];

export default function NationStateSandboxView() {
  const [activeScenarioId, setActiveScenarioId] =
    useState<string>("cyber-attack");
  const [isRunning, setIsRunning] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([
    "INITIALIZING NATION-STATE SANDBOX...",
    "Loading FSM Governance Model...",
    "Awaiting scenario trigger.",
  ]);

  const activeScenario = scenarios.find((s) => s.id === activeScenarioId)!;

  useEffect(() => {
    if (!isRunning) return;

    setSimulationLogs([
      `[TICK 00] Injecting scenario: ${activeScenario.name}...`,
      `[TICK 01] ${activeScenario.trigger}`,
    ]);

    let step = 0;
    const interval = setInterval(() => {
      if (step < activeScenario.logs.length) {
        setSimulationLogs((prev) => [
          ...prev,
          `[TICK ${String(step + 2).padStart(2, "0")}] ${activeScenario.logs[step]}`,
        ]);
        step++;
      } else {
        setSimulationLogs((prev) => [
          ...prev,
          "[SYS] Scenario resolved. System returning to nominal state.",
        ]);
        setIsRunning(false);
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning, activeScenario]);

  const handleRun = () => {
    setIsRunning(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-red-500" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Nation-State Sandbox
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            Live simulation translating abstract governance models into
            real-time stress testing scenarios. Monitors formal assertions,
            event queues, and state machines under duress.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right border-r border-white/10 pr-4">
            <div className="text-[10px] font-bold uppercase tracking-widest text-white/50">
              Sim Status
            </div>
            <div
              className={cn(
                "font-mono text-xs font-bold",
                isRunning ? "text-yellow-500" : "text-blue-500",
              )}
            >
              {isRunning ? "ACTIVE_EVENT_QUEUE" : "IDLE"}
            </div>
          </div>
          <button
            onClick={handleRun}
            disabled={isRunning}
            className="bg-red-500/20 hover:bg-red-500/40 text-red-500 border border-red-500/50 px-4 py-2 text-[10px] uppercase font-bold tracking-widest flex items-center gap-2 disabled:opacity-50"
          >
            <Play className="w-3 h-3" /> Run Scenario
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 border border-white/10 bg-[#141414] p-2 space-y-2">
          <div className="text-[10px] text-white/50 font-bold uppercase tracking-widest p-2 flex items-center gap-2">
            <ShieldAlert className="w-3 h-3" /> Stress Tests
          </div>
          {scenarios.map((s) => (
            <button
              key={s.id}
              onClick={() => {
                if (!isRunning) setActiveScenarioId(s.id);
              }}
              disabled={isRunning}
              className={cn(
                "w-full flex items-center justify-between p-4 border transition-all text-left",
                activeScenarioId === s.id
                  ? "bg-black text-white border-red-500"
                  : "bg-[#141414] text-white border-white/5 hover:border-white/20 disabled:opacity-50",
              )}
            >
              <div>
                <h3 className="text-[11px] font-bold uppercase tracking-widest">
                  {s.name}
                </h3>
              </div>
              <div className="text-[10px] font-mono">{s.severity}%</div>
            </button>
          ))}
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#141414] border border-white/10 p-4 min-h-[300px] flex flex-col">
            <div className="flex items-center gap-2 text-white/40 border-b border-white/10 pb-3 mb-3 text-[10px] font-bold uppercase tracking-widest">
              <Terminal className="w-3 h-3" /> Event Driven Execution Log
            </div>
            <div className="flex-1 overflow-y-auto space-y-1 font-mono text-[10px] p-2 bg-black/50 border border-white/5">
              {simulationLogs.map((log, i) => {
                let color = "text-green-400";
                if (log.includes("SCENARIO_INJECT")) color = "text-red-400";
                if (log.includes("[ASSERT]") || log.includes("[POLICY]"))
                  color = "text-purple-400";
                if (log.includes("[SYS]")) color = "text-blue-400 font-bold";
                return (
                  <div
                    key={i}
                    className={`${color} leading-relaxed opacity-90`}
                  >
                    {log}
                  </div>
                );
              })}
            </div>
          </div>

          <ProofArtifacts
            id={`sandbox-${activeScenarioId}`}
            title={`${activeScenario.name} Simulation Artifact`}
            data={{ severity: activeScenario.severity, logs: simulationLogs }}
            variant="always-dark"
          />
        </div>
      </div>
    </div>
  );
}
