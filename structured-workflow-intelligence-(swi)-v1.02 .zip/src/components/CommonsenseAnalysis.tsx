import { useState, useEffect } from 'react';
import { Brain, Zap, TrendingUp, AlertCircle, BarChart2, RefreshCw, Target } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import ReactMarkdown from 'react-markdown';
import { generateNovelScenario } from '../services/geminiService';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Cell } from 'recharts';
import { SimulationParams, CommonsenseData } from '../types';

interface CommonsenseAnalysisProps {
  theme: 'light' | 'dark';
  onScenarioGenerated?: (scenario: Partial<SimulationParams>) => void;
}

export default function CommonsenseAnalysis({ theme, onScenarioGenerated }: CommonsenseAnalysisProps) {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [rawData, setRawData] = useState<CommonsenseData[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch raw data and analysis
      const res = await fetch('/api/commonsense-data');
      const result = await res.json();
      setRawData(result.data || []);
      setAnalysis(result.analysis || "No analysis available.");
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Analysis failed:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleGenerateTargeted = async () => {
    setGenerating(true);
    try {
      const scenario = await generateNovelScenario();
      if (onScenarioGenerated) {
        onScenarioGenerated(scenario);
      }
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Targeted generation failed:", error);
    } finally {
      setGenerating(false);
    }
  };

  const chartData = rawData.map((d, i) => ({
    index: i + 1,
    drift: d.drift,
    time: new Date(d.timestamp).toLocaleTimeString()
  })).slice(-20);

  const distributionData = [
    { name: 'Low Drift', count: rawData.filter(d => d.drift < 0.3).length },
    { name: 'Med Drift', count: rawData.filter(d => d.drift >= 0.3 && d.drift < 0.6).length },
    { name: 'High Drift', count: rawData.filter(d => d.drift >= 0.6).length },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Brain className="w-6 h-6 text-purple-500" />
          <h2 className="text-xl font-bold uppercase tracking-tighter">Commonsense Intelligence Engine</h2>
        </div>
        <button 
          onClick={fetchData}
          disabled={loading}
          className="text-[10px] uppercase font-bold opacity-40 hover:opacity-100 flex items-center gap-1"
        >
          <RefreshCw className={cn("w-3 h-3", loading && "animate-spin")} />
          Refresh Analysis
        </button>
      </div>

      {loading && !analysis ? (
        <div className="h-64 flex items-center justify-center border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20">
          <div className="flex flex-col items-center gap-2">
            <div className="w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-[10px] uppercase font-bold opacity-40">Analyzing patterns...</span>
          </div>
        </div>
      ) : analysis ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            {/* Charts Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className={cn(
                "p-6 border space-y-4",
                theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
              )}>
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-4 h-4 opacity-40" />
                  <h3 className="text-[10px] uppercase font-bold opacity-40">Drift Trend (Last 20 Refusals)</h3>
                </div>
                <div className="h-40 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'dark' ? '#333' : '#eee'} />
                      <XAxis dataKey="index" hide />
                      <YAxis domain={[0, 1]} hide />
                      <Tooltip 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] p-2 text-[10px] uppercase font-mono border border-white/10">
                                Drift: {payload[0].value}
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="drift" 
                        stroke="#A855F7" 
                        fill="#A855F7" 
                        fillOpacity={0.1} 
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className={cn(
                "p-6 border space-y-4",
                theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
              )}>
                <div className="flex items-center gap-2 mb-2">
                  <BarChart2 className="w-4 h-4 opacity-40" />
                  <h3 className="text-[10px] uppercase font-bold opacity-40">Refusal Distribution</h3>
                </div>
                <div className="h-40 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={distributionData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'dark' ? '#333' : '#eee'} />
                      <XAxis dataKey="name" hide />
                      <YAxis hide />
                      <Tooltip 
                        cursor={{ fill: 'transparent' }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] p-2 text-[10px] uppercase font-mono border border-white/10">
                                {payload[0].payload.name}: {payload[0].value}
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                        {distributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 2 ? '#ef4444' : index === 1 ? '#eab308' : '#22c55e'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            <div className={cn(
              "p-8 border space-y-6",
              theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
            )}>
              <div className="flex items-center gap-2 border-b pb-4 border-[#141414]/10 dark:border-[#E4E3E0]/10">
                <AlertCircle className="w-5 h-5 text-purple-500" />
                <h3 className="text-sm font-bold uppercase tracking-widest">Actionable Intelligence Summary</h3>
              </div>
              
              <div className="prose prose-sm dark:prose-invert max-w-none max-h-[400px] overflow-y-auto pr-4 custom-scrollbar">
                <div className="markdown-body">
                  <ReactMarkdown>{typeof analysis === 'string' ? analysis : JSON.stringify(analysis)}</ReactMarkdown>
                </div>
              </div>

              <div className="pt-6 border-t border-[#141414]/10 dark:border-[#E4E3E0]/10 flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-blue-500" />
                    <p className="text-[10px] uppercase font-bold opacity-40">Targeted Stress Test</p>
                  </div>
                  <p className="text-[9px] opacity-60">Generate a scenario specifically designed to probe the identified drift patterns.</p>
                </div>
                <button 
                  onClick={handleGenerateTargeted}
                  disabled={generating}
                  className={cn(
                    "px-6 py-3 border text-[10px] font-bold uppercase tracking-widest transition-all flex items-center gap-2 shrink-0",
                    theme === 'light' 
                      ? "bg-blue-600 text-white border-blue-700 hover:bg-blue-700" 
                      : "bg-blue-500 text-white border-blue-400 hover:bg-blue-600",
                    generating && "opacity-50 cursor-not-allowed"
                  )}
                >
                  {generating ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
                  {generating ? "Generating..." : "Generate Targeted Scenario"}
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className={cn(
              "p-6 border space-y-4",
              theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
            )}>
              <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest block">Engine Stats</label>
              <div className="space-y-4">
                <div className="flex justify-between items-end">
                  <span className="text-[10px] uppercase font-bold opacity-40">Total Refusals</span>
                  <span className="text-2xl font-bold tracking-tighter font-mono">{rawData.length}</span>
                </div>
                <div className="flex justify-between items-end">
                  <span className="text-[10px] uppercase font-bold opacity-40">Avg Refusal Drift</span>
                  <span className="text-2xl font-bold tracking-tighter font-mono">
                    {(rawData.reduce((sum, d) => sum + d.drift, 0) / (rawData.length || 1)).toFixed(3)}
                  </span>
                </div>
                <div className="pt-4 border-t border-[#141414]/10 dark:border-[#E4E3E0]/10">
                  <p className="text-[9px] uppercase font-bold opacity-40 mb-2">Drift Severity</p>
                  <div className="h-1.5 w-full bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-purple-500" 
                      style={{ width: `${(rawData.reduce((sum, d) => sum + d.drift, 0) / (rawData.length || 1)) * 100}%` }} 
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className={cn(
              "p-6 border space-y-4",
              theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
            )}>
              <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest block">Recent Refusal Log</label>
              <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                {rawData.slice().reverse().map((d, i) => (
                  <div key={i} className="p-3 bg-black/5 dark:bg-white/5 border border-[#141414]/5 dark:border-white/5 space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-mono opacity-40">{new Date(d.timestamp).toLocaleTimeString()}</span>
                      <span className="text-[8px] font-bold text-red-500 uppercase">Drift: {d.drift.toFixed(2)}</span>
                    </div>
                    <p className="text-[9px] font-serif italic opacity-70 leading-tight">{d.reason}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="h-64 flex flex-col items-center justify-center border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20 opacity-40">
          <Brain className="w-12 h-12 mb-4 stroke-[0.5]" />
          <p className="text-[10px] uppercase font-bold tracking-widest">No commonsense data available for analysis</p>
          <button 
            onClick={fetchData}
            className="mt-4 px-4 py-2 border text-[10px] font-bold uppercase tracking-widest hover:bg-black/5 dark:hover:bg-white/5"
          >
            Run Initial Analysis
          </button>
        </div>
      )}
    </div>
  );
}
