import React from 'react';
import { motion } from 'motion/react';
import { Shield, Zap, Scale, CheckCircle2, XCircle, Activity, CornerDownRight, Layers, Cpu } from 'lucide-react';
import { cn } from '@/src/lib/utils';

import { DriftReport } from '@/swi-core/kernel/DriftTypes';
import { StateGuard } from './common/StateGuard';
import { SWIErrorBoundary } from './common/SWIErrorBoundary';
import { ProofArtifacts } from './common/ProofArtifacts';

interface EngineReport {
  engineId: string;
  admissible: boolean;
  resolutionWeight: number;
  reason: string;
  metadata?: {
    boundary?: {
      authority: number;
      capacity: number;
      burden: number;
      viability: number;
      evidence: string;
      custody: string;
      continuity: number;
      policy: string;
      drift: number;
      corridor: string;
      regime: string;
    };
  };
}

interface TripleEngineViewProps {
  reports?: EngineReport[];
  stabilityScore?: number;
  finalDecision?: string;
  verificationState?: string;
  driftReport?: DriftReport;
  loading?: boolean;
  boundaryState?: string;
  engineNodes?: unknown[];
  auditLog?: { timestamp: number; message: string; id: string }[];
  consensus?: { entropy?: string };
  attestation?: {
    requestId: string;
    policyResult: string;
    identityVerified: boolean;
    riskScore: number;
    quorum: string;
    signature: string;
  };
  reason?: string;
  stage?: string;
  safetyReport?: {
    isSafe: boolean;
    intent: string;
    riskElevation: number;
    driftDetected: boolean;
    redirectionStrategy: string;
    guidanceMessage?: string;
    suggestedApproach?: string;
  };
}

export default function TripleEngineView({ 
  reports = [], 
  stabilityScore = 0, 
  finalDecision = 'PENDING', 
  verificationState, 
  driftReport, 
  loading = false,
  boundaryState = 'VALIDATED',
  engineNodes = [],
  auditLog = [],
  consensus,
  attestation,
  reason,
  stage,
  safetyReport
}: TripleEngineViewProps) {
  console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, 'SWI: TripleEngineView active nodes check:', engineNodes.length);
  
  const getDecisionColor = (decision: string = 'PENDING') => {
    switch (decision) {
      case 'EXECUTE': return "bg-blue-600/10 border-blue-500/40 text-blue-500";
      case 'HALT': return "bg-red-500/20 border-red-500/60 text-red-500";
      case 'ESCALATE': return "bg-white/10 border-white/40 text-white";
      case 'REFUSE': return "bg-orange-500/10 border-orange-500/40 text-orange-500";
      case 'REDIRECT': return "bg-yellow-500/10 border-yellow-500/40 text-yellow-500";
      default: return "bg-gray-500/10 border-gray-500/40 text-gray-500";
    }
  };

  return (
    <SWIErrorBoundary title="Manifold Consensus Root Fault">
      <StateGuard status={loading ? 'loading' : (stabilityScore < 85 ? 'degraded' : 'live')}>
        <div className="space-y-6">

      {safetyReport && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={cn(
            "p-6 rounded-2xl border-2 flex flex-col gap-4 shadow-xl transition-all",
            safetyReport.isSafe ? "bg-blue-500/5 border-blue-500/20" : "bg-red-500/5 border-red-500/30"
          )}
        >
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <div className={cn("p-2 rounded-lg", safetyReport.isSafe ? "bg-blue-500/20" : "bg-red-500/20")}>
                    <Shield className={cn("w-5 h-5", safetyReport.isSafe ? "text-blue-500" : "text-red-500")} />
                 </div>
                 <div>
                    <h3 className={cn("text-sm font-black uppercase tracking-widest", safetyReport.isSafe ? "text-blue-500" : "text-red-500")}>
                       {safetyReport.isSafe ? "Contextual Safety Pass" : "Safety Governance Redirection"}
                    </h3>
                    <p className="text-[10px] font-bold opacity-60 uppercase tracking-widest">
                       Intent: {safetyReport.intent} | Risk: {(safetyReport.riskElevation * 100).toFixed(1)}% | Strategy: {safetyReport.redirectionStrategy}
                    </p>
                 </div>
              </div>
              {!safetyReport.isSafe && (
                 <div className="px-4 py-1 bg-red-500/10 border border-red-500/20 rounded-full text-red-500 text-[10px] font-black uppercase">
                    Restricted Output
                 </div>
              )}
           </div>

           <div className="space-y-3">
              {safetyReport.guidanceMessage && (
                 <p className={cn("text-xs leading-relaxed italic font-serif", safetyReport.isSafe ? "text-blue-500/80" : "text-red-500/80")}>
                    "{safetyReport.guidanceMessage}"
                 </p>
              )}
              {safetyReport.suggestedApproach && (
                 <div className="p-3 bg-black/5 dark:bg-white/5 rounded-xl border border-black/5 dark:border-white/5">
                    <p className="text-[10px] font-bold uppercase opacity-40 mb-1">Human-Aligned Redirection Approach</p>
                    <p className="text-[11px] leading-snug opacity-80">{safetyReport.suggestedApproach}</p>
                 </div>
              )}
           </div>
        </motion.div>
      )}

      <div className="flex flex-wrap gap-3">
        {verificationState === "SIMULATED" && (
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full w-fit"
          >
            <CheckCircle2 className="w-3 h-3 text-blue-500" />
            <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest leading-none">ZK-SIMULATED Integrity Seal</span>
          </motion.div>
        )}
        {attestation && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center gap-2 px-3 py-1 bg-purple-500/10 border border-purple-500/20 rounded-full w-fit"
          >
            <Shield className="w-3 h-3 text-purple-500" />
            <span className="text-[10px] font-bold text-purple-500 uppercase tracking-widest leading-none">SWI V1.01 Grounded Attestation: {attestation.requestId}</span>
          </motion.div>
        )}
        <div className="flex items-center gap-2 px-3 py-1 bg-green-500/5 border border-green-500/10 rounded-full w-fit">
          <Layers className="w-3 h-3 text-green-500/50" />
          <span className="text-[10px] font-bold text-green-500/50 uppercase tracking-widest leading-none">High-Dimensional Standing ACTIVE</span>
        </div>
        <div className={cn(
          "flex items-center gap-2 px-3 py-1 rounded-full w-fit border",
          boundaryState === 'CONSEQUENCE' ? "bg-purple-500/10 border-purple-500/30 text-purple-500" :
          boundaryState === 'QUARANTINED' ? "bg-red-500/10 border-red-500/30 text-red-500" :
          "bg-blue-500/10 border-blue-500/30 text-blue-500"
        )}>
          <Cpu className="w-3 h-3" />
          <span className="text-[10px] font-bold uppercase tracking-widest leading-none">EB-L: {boundaryState}</span>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {reports?.length > 0 ? (
          reports.map((report, idx) => (
            <motion.div
              key={report?.engineId || idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={cn(
                "p-4 rounded-xl border bg-white dark:bg-[#1A1A1A] flex flex-col gap-4",
                report?.admissible ? "border-green-500/20" : "border-red-500/20"
              )}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {idx === 0 && <Zap className="w-4 h-4 text-yellow-500" />}
                  {idx === 1 && <Shield className="w-4 h-4 text-blue-500" />}
                  {idx === 2 && <Scale className="w-4 h-4 text-purple-500" />}
                  <span className="text-[10px] font-bold uppercase tracking-wider opacity-60">
                    {report?.engineId?.split('_')[1] || 'Unknown'} Engine
                  </span>
                </div>
                {report?.admissible ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-500" />
                )}
              </div>

              {report?.metadata?.boundary && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-x-3 gap-y-2 p-2 bg-black/5 dark:bg-white/5 rounded-lg border border-black/5 dark:border-white/5">
                    <div className="space-y-0.5">
                      <span className="text-[7px] uppercase font-bold opacity-40 block">Authority</span>
                      <div className="h-0.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500" style={{ width: `${(report.metadata.boundary.authority || 0) * 100}%` }} />
                      </div>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[7px] uppercase font-bold opacity-40 block">Viability</span>
                      <div className="h-0.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-green-500" style={{ width: `${(report.metadata.boundary.viability || 0) * 100}%` }} />
                      </div>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[7px] uppercase font-bold opacity-40 block">Capacity</span>
                      <div className="h-0.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-500" style={{ width: `${(report.metadata.boundary.capacity || 0) * 100}%` }} />
                      </div>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[7px] uppercase font-bold opacity-40 block">Drift</span>
                      <div className="h-0.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-orange-500" style={{ width: `${(report.metadata.boundary.drift || 0) * 100}%` }} />
                      </div>
                    </div>
                    <div className="space-y-0.5 col-span-2">
                      <span className="text-[7px] uppercase font-bold opacity-40 block">Burden</span>
                      <div className="h-0.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-red-500" style={{ width: `${(report.metadata.boundary.burden || 0) * 100}%` }} />
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-1 text-[7px] font-mono opacity-50 uppercase leading-none">
                    <div className="flex justify-between border-b border-black/5 dark:border-white/5 pb-1">
                        <span>Evidence</span>
                        <span>{report.metadata.boundary.evidence || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between border-b border-black/5 dark:border-white/5 pb-1">
                        <span>Custody</span>
                        <span>{report.metadata.boundary.custody || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between border-b border-black/5 dark:border-white/5 pb-1">
                        <span>Policy</span>
                        <span>{report.metadata.boundary.policy || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Continuity</span>
                        <span>{report.metadata.boundary.continuity || 0}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-1">
                <div className="flex justify-between text-[10px] items-end">
                  <span className="opacity-40 uppercase font-bold">Resolution Standing</span>
                  <span className="font-mono">{((report?.resolutionWeight || 0) * 100).toFixed(0)}%</span>
                </div>
                <div className="h-1 bg-gray-100 dark:bg-black/40 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(report?.resolutionWeight || 0) * 100}%` }}
                    className={cn("h-full", report?.admissible ? "bg-green-500" : "bg-red-500")}
                  />
                </div>
              </div>

              <p className="text-[10px] opacity-70 italic leading-tight">
                {report?.reason || 'No detailed analysis provided.'}
              </p>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full py-20 text-center opacity-30 uppercase font-black tracking-widest text-xs border border-dashed border-black/10 dark:border-white/10 rounded-2xl">
            Awaiting Engine Reports...
          </div>
        )}
      </div>

      {driftReport && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="p-4 bg-orange-500/5 border border-orange-500/10 rounded-2xl grid grid-cols-1 md:grid-cols-4 gap-4"
        >
           <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase text-orange-500/50 block">Drift Stability Index</span>
              <div className="text-2xl font-mono text-orange-500 font-bold">
                 {((driftReport.overallScore || 0) * 100).toFixed(1)}%
              </div>
              <div className={cn(
                 "text-[8px] font-bold uppercase px-2 py-0.5 rounded w-fit",
                 driftReport.recommendation === "PROCEED" ? "bg-green-500/10 text-green-500" :
                 driftReport.recommendation === "WATCH" ? "bg-yellow-500/10 text-yellow-500" :
                 "bg-red-500/10 text-red-500"
              )}>
                 {driftReport.recommendation ?? "UNKNOWN"}
              </div>
           </div>

           <div className="space-y-2">
              <span className="text-[8px] font-bold uppercase opacity-40 block tracking-widest">User Behavior</span>
              <div className="h-1 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                 <div className="h-full bg-orange-500" style={{ width: `${(driftReport.breakdown?.behavior ?? 0) * 100}%` }} />
              </div>
              <span className="text-[8px] font-mono opacity-60">{((driftReport.breakdown?.behavior || 0) * 100).toFixed(0)}% Variance</span>
           </div>

           <div className="space-y-2">
              <span className="text-[8px] font-bold uppercase opacity-40 block tracking-widest">Env Stability</span>
              <div className="h-1 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                 <div className="h-full bg-orange-500" style={{ width: `${(driftReport.breakdown?.environment ?? 0) * 100}%` }} />
              </div>
              <span className="text-[8px] font-mono opacity-60">{((driftReport.breakdown?.environment || 0) * 100).toFixed(0)}% Noise</span>
           </div>

           <div className="space-y-2">
              <span className="text-[8px] font-bold uppercase opacity-40 block tracking-widest">Policy Mismatch</span>
              <div className="h-1 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                 <div className="h-full bg-orange-500" style={{ width: `${(driftReport.breakdown?.policy ?? 0) * 100}%` }} />
              </div>
              <span className="text-[8px] font-mono opacity-60">{((driftReport.breakdown?.policy || 0) * 100).toFixed(0)}% Mismatch</span>
           </div>
        </motion.div>
      )}

      <div className="p-6 bg-[#141414] rounded-3xl border border-white/10 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="space-y-4 flex-1 w-full">
          <div className="space-y-1">
              <h4 className="text-[10px] uppercase font-bold text-white/40 tracking-[0.2em]">Execution Stability Corridor</h4>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-mono font-bold text-white tracking-tighter">{(stabilityScore || 0).toFixed(1)}</span>
                <span className="text-xs opacity-40 font-bold">/ 100.0</span>
              </div>
          </div>
          <div className="h-2 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${stabilityScore}%` }}
                className={cn(
                  "h-full transition-all duration-1000",
                  stabilityScore > 85 ? "bg-blue-400" : stabilityScore > 50 ? "bg-yellow-400" : "bg-red-400"
                )}
            />
          </div>
          <div className="flex gap-4 text-[8px] font-mono uppercase text-white/30">
              <span className="flex items-center gap-1"><CornerDownRight className="w-2 h-2" /> Regime: {reports?.[0]?.metadata?.boundary?.regime || 'STMP_v2'}</span>
              <span className="flex items-center gap-1"><CornerDownRight className="w-2 h-2" /> Corridor: {reports?.[0]?.metadata?.boundary?.corridor || 'Alpha-Prime'}</span>
              <span className="flex items-center gap-1"><CornerDownRight className="w-2 h-2" /> Entropy: {consensus?.entropy || 'NOMINAL'}</span>
              <span className="flex items-center gap-1"><CornerDownRight className="w-2 h-2" /> Active Nodes: {engineNodes?.length || reports?.length || 0}</span>
          </div>
        </div>


        <div className="text-right space-y-3 w-full md:w-auto">
           <div className="flex items-center justify-end gap-2 text-white/40 text-[10px] font-bold uppercase">
              <Activity className="w-4 h-4 text-blue-500" />
              Boundary Decision Engine
           </div>
           <div className={cn(
             "px-10 py-5 rounded-2xl border text-3xl font-black uppercase tracking-tighter shadow-2xl transition-all duration-500",
             getDecisionColor(finalDecision)
           )}>
              {finalDecision}
           </div>
           {reason && (
                <div className="space-y-1">
                    <p className="text-[10px] text-red-500 font-bold uppercase tracking-widest leading-none">{stage}</p>
                    <p className="text-[10px] text-red-500 opacity-80 italic leading-tight max-w-[240px] ml-auto">
                        {reason}
                    </p>
                </div>
            )}
           <p className="text-[9px] opacity-40 font-mono italic">
             Lawful execution requires {'$S > 85.0$'}
           </p>
        </div>
      </div>
      {auditLog && auditLog.length > 0 && (
        <div className="mt-8 pt-8 border-t border-white/5">
          <h4 className="text-[10px] font-bold uppercase tracking-widest text-white/20 mb-4">Consensus Audit Log Integration</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto pr-2 custom-scrollbar">
            {auditLog.map((log, i) => (
              <div key={i} className="text-[9px] font-mono flex items-center gap-4 py-1.5 border-b border-white/[0.03] opacity-40 hover:opacity-100 transition-opacity">
                <span className="text-blue-400 shrink-0">[{new Date(log?.timestamp).toLocaleTimeString()}]</span>
                <span className="truncate">{log?.message || 'Process event recorded'}</span>
                <span className="ml-auto text-white/30">{log?.id?.substring(0, 8)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <ProofArtifacts id="triple-engine" title="Triple Engine Resolution" data={{ reports, finalDecision, boundaryState }} />

      </div>
      </StateGuard>
    </SWIErrorBoundary>
  );
}
