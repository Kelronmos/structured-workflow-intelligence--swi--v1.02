import React, { useState, useEffect } from "react";
import {
  Activity,
  ShieldAlert,
  SlidersHorizontal,
  ServerCrash,
  AlertTriangle,
  Brain,
  ShieldCheck,
  Lock,
  PauseCircle,
  Network
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function Layer2AutoTuningView() {
  const [simulationState, setSimulationState] = useState<"STABLE" | "ANOMALY_DETECTED" | "TUNING" | "PROTECTED">("STABLE");
  const [anomalyLevel, setAnomalyLevel] = useState(0);
  const [layer2Weight, setLayer2Weight] = useState(0.2); // beta weight
  const [sandboxLimit, setSandboxLimit] = useState(100);
  const [persistencePaused, setPersistencePaused] = useState(false);

  const injectAnomaly = () => {
    setSimulationState("ANOMALY_DETECTED");
    setAnomalyLevel(85);
    
    setTimeout(() => {
      setSimulationState("TUNING");
      setLayer2Weight(0.85); // Shift beta weight
      setSandboxLimit(20); // Limit sandbox
      setPersistencePaused(true); // Pause persistence
    }, 2000);

    setTimeout(() => {
      setSimulationState("PROTECTED");
      setAnomalyLevel(45); // stabilized under protection
    }, 5000);
  };

  const resetSimulation = () => {
    setSimulationState("STABLE");
    setAnomalyLevel(0);
    setLayer2Weight(0.2);
    setSandboxLimit(100);
    setPersistencePaused(false);
  };

  const getStatusColor = () => {
    switch (simulationState) {
      case "STABLE": return "text-emerald-400 border-emerald-500/50 bg-emerald-500/10";
      case "ANOMALY_DETECTED": return "text-red-500 border-red-500/50 bg-red-500/10 shadow-[0_0_20px_rgba(239,68,68,0.2)]";
      case "TUNING": return "text-amber-400 border-amber-500/50 bg-amber-500/10";
      case "PROTECTED": return "text-cyan-400 border-cyan-500/50 bg-cyan-500/10 shadow-[0_0_20px_rgba(34,211,238,0.2)]";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full flex justify-between items-start">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <SlidersHorizontal className="w-5 h-5 text-amber-400" />
              <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
                Layer 2 Auto-Tuning Simulation
              </h2>
            </div>
            <p className="text-[10px] font-mono opacity-80 max-w-2xl text-amber-100/70 border-l-2 border-amber-500/50 pl-3">
              Observe the ACE engine automatically detect environmental instability and shift beta (Environment) constitutional weights to protect the governance layer.
            </p>
          </div>
          <div className="flex gap-2">
            <button
               onClick={resetSimulation}
               disabled={simulationState === "STABLE"}
               className="px-4 py-2 uppercase font-bold text-[9px] transition-all border bg-gray-800/50 text-white/50 border-white/10 hover:bg-white/5 disabled:opacity-50"
            >
               Reset
            </button>
            <button
               onClick={injectAnomaly}
               disabled={simulationState !== "STABLE"}
               className={cn(
                 "px-6 py-2 uppercase font-bold text-[10px] transition-all border shrink-0",
                 simulationState !== "STABLE"
                   ? "bg-gray-800/50 text-gray-500 border-gray-700 cursor-not-allowed"
                   : "bg-red-500/20 text-red-400 border-red-500/50 hover:bg-red-500/30"
               )}
            >
               Inject Drift Anomaly
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         {/* Live Metrics */}
         <div className="lg:col-span-1 space-y-4">
            <div className="bg-[#141414] p-5 border border-white/10 h-full">
               <h3 className="text-[11px] font-bold text-white/40 uppercase tracking-widest mb-4 flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Telemetry
               </h3>
               
               <div className="space-y-6">
                  <div>
                     <div className="flex justify-between text-[9px] font-mono mb-2 uppercase">
                        <span className="text-white/50">Anomaly Density</span>
                        <span className={anomalyLevel > 50 ? "text-red-400 font-bold" : "text-emerald-400"}>{anomalyLevel}%</span>
                     </div>
                     <div className="h-1.5 w-full bg-white/5 overflow-hidden">
                        <div className={cn("h-full transition-all duration-1000", anomalyLevel > 50 ? "bg-red-500" : "bg-emerald-500")} style={{ width: `${anomalyLevel}%` }}></div>
                     </div>
                  </div>

                  <div>
                     <div className="flex justify-between text-[9px] font-mono mb-2 uppercase">
                        <span className="text-white/50">Layer 2 Shield Weight (β)</span>
                        <span className="text-amber-400">{layer2Weight.toFixed(2)}</span>
                     </div>
                     <div className="h-1.5 w-full bg-white/5 overflow-hidden relative">
                        <div className="h-full bg-amber-500 transition-all duration-1000" style={{ width: `${layer2Weight * 100}%` }}></div>
                     </div>
                  </div>

                  <div>
                     <div className="flex justify-between text-[9px] font-mono mb-2 uppercase">
                        <span className="text-white/50">Sandbox Tx Limit</span>
                        <span className="text-cyan-400">{sandboxLimit}%</span>
                     </div>
                     <div className="h-1.5 w-full bg-white/5 overflow-hidden">
                        <div className="h-full bg-cyan-500 transition-all duration-1000" style={{ width: `${sandboxLimit}%` }}></div>
                     </div>
                  </div>

                  <div className="pt-4 border-t border-white/10">
                     <div className="text-[9px] font-mono uppercase text-white/50 mb-2">Memory Persistence</div>
                     <div className={cn("p-2 border text-[10px] font-bold text-center", persistencePaused ? "bg-amber-500/10 border-amber-500/50 text-amber-400" : "bg-emerald-500/10 border-emerald-500/50 text-emerald-400")}>
                        {persistencePaused ? "PAUSED (SAFE MODE)" : "ACTIVE_WRITE"}
                     </div>
                  </div>
               </div>
            </div>
         </div>

         {/* Reactor Visualization */}
         <div className="lg:col-span-2">
            <div className={cn("border p-8 h-full flex flex-col items-center justify-center relative overflow-hidden transition-all duration-1000", getStatusColor())}>
               
               <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
                  <Network className="w-96 h-96" />
               </div>

               <div className="z-10 flex items-center justify-center mb-6 relative">
                  {simulationState === "STABLE" && <Brain className="w-16 h-16 animate-pulse" />}
                  {simulationState === "ANOMALY_DETECTED" && <ServerCrash className="w-16 h-16 animate-bounce" />}
                  {simulationState === "TUNING" && <SlidersHorizontal className="w-16 h-16 animate-spin-slow" />}
                  {simulationState === "PROTECTED" && <ShieldCheck className="w-16 h-16" />}
               </div>

               <div className="z-10 text-center space-y-2">
                  <h2 className="text-lg font-black uppercase tracking-widest bg-black/50 px-4 py-1 inline-block">
                     {simulationState === "STABLE" && "ENVIRONMENT STABLE"}
                     {simulationState === "ANOMALY_DETECTED" && "INSTABILITY DETECTED"}
                     {simulationState === "TUNING" && "ADAPTING LAYER 2 WEIGHTS"}
                     {simulationState === "PROTECTED" && "PROTECTION INVARIANTS ACTIVE"}
                  </h2>
                  <p className="text-[11px] font-mono opacity-80 max-w-lg mx-auto bg-black/50 p-2">
                     {simulationState === "STABLE" && "Network operating within nominal parameters. Governance weights balanced."}
                     {simulationState === "ANOMALY_DETECTED" && "System detects external drift event. Escalation rules evaluating response."}
                     {simulationState === "TUNING" && "Engine logic shifting beta values to shield the constitutional layer from malicious propagation."}
                     {simulationState === "PROTECTED" && "Sandbox limited. Core state isolated. Persistence paused pending review."}
                  </p>
               </div>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
         <div className={cn("p-4 border transition-all duration-500", layer2Weight > 0.5 ? "bg-amber-500/10 border-amber-500/50" : "bg-[#141414] border-white/10")}>
            <SlidersHorizontal className={cn("w-5 h-5 mb-2", layer2Weight > 0.5 ? "text-amber-400" : "text-white/30")} />
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-white mb-2">Weight Shift</h4>
            <p className="text-[9px] font-mono text-white/50">Beta weight scales dynamically in response to threat density, reducing fast-path autonomy.</p>
         </div>

         <div className={cn("p-4 border transition-all duration-500", sandboxLimit < 50 ? "bg-cyan-500/10 border-cyan-500/50" : "bg-[#141414] border-white/10")}>
            <Lock className={cn("w-5 h-5 mb-2", sandboxLimit < 50 ? "text-cyan-400" : "text-white/30")} />
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-white mb-2">Sandbox Throttling</h4>
            <p className="text-[9px] font-mono text-white/50">Execution throughput is limited to prevent widespread state propagation during tuning.</p>
         </div>

         <div className={cn("p-4 border transition-all duration-500", persistencePaused ? "bg-emerald-500/10 border-emerald-500/50" : "bg-[#141414] border-white/10")}>
            <PauseCircle className={cn("w-5 h-5 mb-2", persistencePaused ? "text-emerald-400" : "text-white/30")} />
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-white mb-2">Persistence Freeze</h4>
            <p className="text-[9px] font-mono text-white/50">Memory and audit trails are buffered. No new state is permanently committed while anomaly persists.</p>
         </div>
      </div>

      {simulationState === "PROTECTED" && (
         <div className="flex justify-center bg-[#141414] border border-white/10 p-6 animate-in fade-in zoom-in duration-500">
            <ProofArtifacts
               id="layer-2-tuning"
               title="Layer 2 Engine Response"
               data={{
                  event_type: "ENVIRONMENT_INSTABILITY",
                  beta_weight_shift: "+0.65",
                  sandbox_operations: "THROTTLED",
                  memory_state: "FROZEN_PENDING_REVIEW"
               }}
               variant="always-dark"
            />
         </div>
      )}
    </div>
  );
}
