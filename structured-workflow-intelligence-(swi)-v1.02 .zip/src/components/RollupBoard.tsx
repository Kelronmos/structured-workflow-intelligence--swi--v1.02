import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Layers, CheckCircle2, Cpu, Activity, Thermometer, Database, Zap } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface Batch {
  id: string;
  txCount: number;
  root: string;
  proof: string;
  timestamp: string;
  verificationState: string;
}

interface GPUMetrics {
  utilization: number;
  temp: number;
  vram: string;
  activeKernels: string[];
}

export default function RollupBoard() {
  const [batches, setBatches] = useState<Batch[]>([]);
  const [metrics, setMetrics] = useState<GPUMetrics>({
    utilization: 0,
    temp: 0,
    vram: "0/0",
    activeKernels: []
  });
  const [history, setHistory] = useState<number[]>(Array(40).fill(0));
  const [isMinting, setIsMinting] = useState(false);
  const [benchmarking, setBenchmarking] = useState(false);
  const [benchResult, setBenchResult] = useState<{
    cpu: { timeMs: number; opsPerSec: number };
    gpu: { timeMs: number; opsPerSec: number };
    speedup: string;
  } | null>(null);

  // Poll metrics
  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch('/api/system/gpu-metrics');
        const data = await res.json();
        setMetrics(data);
        setHistory(prev => [...prev.slice(1), data.utilization]);
      } catch (e) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Metrics offline", e);
      }
    };

    const interval = setInterval(fetchMetrics, 1000);
    return () => clearInterval(interval);
  }, []);

  const runBenchmark = async () => {
    setBenchmarking(true);
    try {
      const res = await fetch('/api/system/benchmark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ constraints: 1000000 }) // 1M constraints
      });
      const data = await res.json();
      setBenchResult(data);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setBenchmarking(false);
    }
  };

  const mintBatch = async () => {
    setIsMinting(true);
    try {
      const res = await fetch('/api/rollup/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactions: Array(Math.floor(Math.random() * 20) + 5).fill({
            sender: "0xAlice",
            receiver: "0xBob",
            amount: 10
          })
        })
      });
      const data = await res.json();
      
      const newBatch: Batch = {
        id: data.batchId.substring(0, 8),
        txCount: data.txCount,
        root: data.stateRoot.substring(0, 16),
        proof: data.proof.substring(0, 20) + "...",
        timestamp: new Date(data.timestamp).toLocaleTimeString(),
        verificationState: data.verificationState || "SIMULATED"
      };
      
      setBatches(prev => [newBatch, ...prev].slice(0, 10));
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Minting failed", e);
    } finally {
      setIsMinting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="space-y-1">
          <h3 className="text-xl font-bold font-serif italic text-blue-600 flex items-center gap-2">
            <Layers className="w-5 h-5 transition-transform hover:rotate-12" />
            STMP Rollup Mainnet
          </h3>
          <p className="text-[10px] uppercase font-bold opacity-40 tracking-widest text-[#141414] dark:text-[#E4E3E0]">Recursive ZK Proof-of-Continuation Pipeline</p>
        </div>
        <button 
          onClick={mintBatch}
          disabled={isMinting}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2 shadow-lg shadow-blue-500/20"
        >
          {isMinting ? <Activity className="w-4 h-4 animate-spin" /> : <Layers className="w-4 h-4" />}
          Mint State Batch
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* GPU Performance Monitor */}
        <div className="lg:col-span-2 p-6 bg-white dark:bg-[#1A1A1A] border border-black/5 dark:border-white/5 rounded-3xl space-y-6">
           <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                  <Cpu className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase opacity-40">Prover Load (GPU 0)</p>
                  <p className="text-sm font-mono font-bold">{metrics.utilization.toFixed(1)}% Utilized</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="text-right">
                  <p className="text-[10px] font-bold uppercase opacity-40 flex items-center justify-end gap-1">
                    <Thermometer className="w-3 h-3" /> Core Temp
                  </p>
                  <p className="text-sm font-mono">{metrics.temp.toFixed(1)}°C</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-bold uppercase opacity-40 flex items-center justify-end gap-1">
                    <Database className="w-3 h-3" /> VRAM
                  </p>
                  <p className="text-sm font-mono">{metrics.vram}</p>
                </div>
              </div>
           </div>

           <div className="h-48 flex items-end gap-1 bg-black/5 dark:bg-white/5 rounded-2xl p-4 overflow-hidden relative">
              {history.map((val, i) => (
                <motion.div 
                  key={i}
                  animate={{ height: `${val}%`, backgroundColor: val > 80 ? '#ef4444' : '#3b82f6' }}
                  className="flex-1 rounded-t-sm opacity-40"
                  transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                />
              ))}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <div className="text-[8px] uppercase font-bold opacity-10 tracking-[0.4em]">CUDA MSM PIPELINE</div>
              </div>
           </div>

           <div className="flex gap-2">
              {metrics.activeKernels.map((k, i) => (
                <span key={i} className="px-2 py-1 bg-black/5 dark:bg-white/5 border border-black/5 rounded text-[8px] font-mono opacity-60">
                  {k}
                </span>
              ))}
           </div>
        </div>

        {/* Acceleration Lab */}
        <div className="p-6 bg-white dark:bg-[#1A1A1A] border border-black/5 dark:border-white/5 rounded-3xl space-y-4">
           <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-bold uppercase tracking-widest opacity-40">Acceleration Lab</h4>
              <button 
                onClick={runBenchmark}
                disabled={benchmarking}
                className="p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                title="Run Benchmark"
              >
                <Zap className={cn("w-4 h-4 text-yellow-500", benchmarking && "animate-pulse")} />
              </button>
           </div>
           
           <div className="space-y-4">
              <div className="p-4 border border-black/5 dark:border-white/5 rounded-2xl bg-black/5 dark:bg-black/20 space-y-3">
                 <div className="flex justify-between text-[10px] uppercase font-bold opacity-40">
                    <span>Engine</span>
                    <span>1M Constraints</span>
                 </div>
                 <div className="space-y-2">
                    <div className="flex items-center gap-3">
                       <span className="text-[10px] font-mono w-8">CPU</span>
                       <div className="flex-1 h-1.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: benchResult ? "100%" : "30%" }}
                            className="h-full bg-red-500/50"
                          />
                       </div>
                       <span className="text-[10px] font-mono w-12 text-right">
                         {benchResult ? `${benchResult.cpu.timeMs}ms` : '---'}
                       </span>
                    </div>
                    <div className="flex items-center gap-3">
                       <span className="text-[10px] font-mono w-8">GPU</span>
                       <div className="flex-1 h-1.5 bg-black/10 dark:bg-white/10 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: benchResult ? `${(benchResult.gpu.timeMs / benchResult.cpu.timeMs) * 100}%` : "5%" }}
                            className="h-full bg-blue-500"
                          />
                       </div>
                       <span className="text-[10px] font-mono w-12 text-right">
                         {benchResult ? `${benchResult.gpu.timeMs}ms` : '---'}
                       </span>
                    </div>
                 </div>
              </div>

              {benchResult && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center justify-center gap-2 p-3 bg-green-500/10 rounded-xl text-green-500"
                >
                   <Zap className="w-3 h-3" />
                   <span className="text-[10px] font-bold uppercase tracking-widest">{benchResult.speedup} Faster</span>
                </motion.div>
              )}
           </div>
        </div>

        {/* Batch Feed */}
        <div className="space-y-3">
           <AnimatePresence initial={false}>
             {batches.length === 0 && !isMinting && (
               <div className="h-full flex items-center justify-center border border-dashed border-black/10 rounded-3xl p-12 text-center">
                  <p className="text-[10px] uppercase font-bold opacity-30 leading-relaxed">No batches committed.<br/>Dispatch state proof to mesh.</p>
               </div>
             )}
             {batches.map((batch) => (
               <motion.div
                 key={batch.id}
                 initial={{ opacity: 0, y: 20 }}
                 animate={{ opacity: 1, y: 0 }}
                 className="p-4 bg-white dark:bg-[#1A1A1A] border border-black/5 dark:border-white/5 rounded-2xl flex flex-col gap-3 group hover:border-blue-500/30 transition-all cursor-default"
               >
                 <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                       <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                       </div>
                       <div>
                          <p className="text-[10px] font-bold font-mono tracking-tighter uppercase">STMP-{batch.id}</p>
                          <p className="text-[8px] opacity-40 uppercase">{batch.timestamp}</p>
                       </div>
                    </div>
                    <span className={cn(
                      "text-[10px] font-bold px-2 py-0.5 rounded",
                      batch.verificationState === "SIMULATED" ? "text-blue-500 bg-blue-500/10" : "text-yellow-500 bg-yellow-500/10"
                    )}>
                      {batch.verificationState === "SIMULATED" ? 'ZK-SIMULATED' : 'PENDING'}
                    </span>
                 </div>
                 
                 <div className="grid grid-cols-2 gap-2 text-[9px] uppercase font-bold opacity-60">
                    <div className="space-y-1">
                       <p className="opacity-40">TX COUNT</p>
                       <p>{batch.txCount}</p>
                    </div>
                    <div className="space-y-1">
                       <p className="opacity-40">STATE ROOT</p>
                       <p className="font-mono text-[8px]">{batch.root}...</p>
                    </div>
                 </div>

                 <div className="pt-2 border-t border-black/5 dark:border-white/5">
                    <div className="flex items-center gap-2 text-[8px] font-mono opacity-30 truncate">
                       <Cpu className="w-2.5 h-2.5" />
                       {batch.proof}
                    </div>
                 </div>
               </motion.div>
             ))}
           </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
