import React, { useEffect, useState } from 'react';
import { Database, Link, ShieldCheck, Fingerprint, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LedgerEntry {
  hash: string;
  timestamp: number;
  data: Record<string, unknown>;
  prevHash: string;
}

export default function ImmutableAuditLog() {
  const [history, setHistory] = useState<LedgerEntry[]>([]);
  const [integrity, setIntegrity] = useState<boolean>(true);
  const [root, setRoot] = useState<string>("");

  const fetchLedger = async () => {
    try {
      const res = await fetch('/api/v2/audit-ledger');
      const data = await res.json();
      setHistory(data.history || []);
      setIntegrity(data.integrity ?? true);
      setRoot(data.root || "");
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch audit ledger:", error);
    }
  };

  useEffect(() => {
    const init = async () => {
      await fetchLedger();
    };
    init();
    const interval = setInterval(fetchLedger, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div className="space-y-1">
          <h2 className="text-xl font-bold uppercase tracking-widest flex items-center gap-2">
            <Database className="w-5 h-5 text-blue-500" />
            Immutable Audit Ledger
          </h2>
          <p className="text-[10px] uppercase opacity-50 tracking-[0.2em]">Blockchain-Linked Governance Receipts</p>
        </div>
        
        <div className="flex gap-4">
           <div className="p-2 bg-gray-100 dark:bg-black/20 border border-black/5 dark:border-white/5 rounded-lg">
             <p className="text-[8px] uppercase opacity-40 font-bold">Consensus Root</p>
             <p className="text-[10px] font-mono truncate w-32">{root}</p>
           </div>
           <div className={`p-2 rounded-lg flex items-center gap-2 border ${integrity ? 'bg-green-500/10 border-green-500/20 text-green-500' : 'bg-red-500/10 border-red-500/20 text-red-500'}`}>
              <ShieldCheck className="w-4 h-4" />
              <span className="text-[10px] font-bold uppercase">{integrity ? 'Verified' : 'Tampered'}</span>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-2">
        <AnimatePresence mode="popLayout">
          {history && history.length > 0 ? (
            history.map((entry, idx) => (
              <motion.div
                layout
                key={entry.hash}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="group relative bg-white dark:bg-[#1A1A1A] border border-black/5 dark:border-white/5 rounded-xl p-4 transition-all hover:border-blue-500/30"
              >
                {/* Connection Line */}
                {idx < history.length - 1 && (
                  <div className="absolute left-6 bottom-[-16px] w-[2px] h-4 bg-gradient-to-b from-blue-500/20 to-transparent z-0" />
                )}
                
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center shrink-0">
                    <Fingerprint className="w-4 h-4 text-blue-500" />
                  </div>
                  
                  <div className="flex-1 space-y-2 min-w-0">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase text-blue-500">{String(entry.data.action || 'INTERNAL')}</span>
                      <span className="text-[10px] opacity-40 font-mono">{new Date(entry.timestamp).toLocaleTimeString()}</span>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-black/20 p-2 rounded-md text-[10px] font-mono break-all opacity-80">
                      <pre className="whitespace-pre-wrap">{JSON.stringify(entry.data, null, 2)}</pre>
                    </div>

                    <div className="flex gap-4 pt-1">
                       <div className="flex items-center gap-1">
                          <Link className="w-3 h-3 opacity-30" />
                          <span className="text-[8px] font-mono opacity-40 truncate max-w-[100px]">Prev: {entry.prevHash}</span>
                       </div>
                       <div className="flex items-center gap-1">
                          <Lock className="w-3 h-3 opacity-30" />
                          <span className="text-[8px] font-mono opacity-40 truncate max-w-[100px]">Hash: {entry.hash}</span>
                       </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="p-12 text-center border border-dashed border-black/10 rounded-2xl opacity-30 uppercase font-black tracking-widest text-xs">
              No Audit History Found
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
