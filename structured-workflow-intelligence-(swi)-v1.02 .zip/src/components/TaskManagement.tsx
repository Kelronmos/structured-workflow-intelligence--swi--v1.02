import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  CheckCircle2,
  Circle,
  Clock,
  AlertCircle,
  User,
  ArrowUp,
  ArrowDown,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface Task {
  id: string;
  title: string;
  priority: "low" | "medium" | "high";
  dueDate: string;
  createdAt: string;
  completed: boolean;
  assignedTo: string;
}

interface User {
  id: string;
  name: string;
  role: string;
}

export default function TaskManagement() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<"priority" | "dueDate" | "createdAt">(
    "createdAt",
  );
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [filterUser, setFilterUser] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<
    "all" | "active" | "completed"
  >("all");
  const [showConfirm, setShowConfirm] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTask, setNewTask] = useState({
    title: "",
    priority: "medium" as "low" | "medium" | "high",
    dueDate: new Date().toISOString().split("T")[0],
    assignedTo: "",
  });

  useEffect(() => {
    Promise.all([
      fetch("/api/tasks").then((res) => res.json()),
      fetch("/api/users").then((res) => res.json()),
    ]).then(([tasksData, usersData]) => {
      setTasks(tasksData);
      setUsers(usersData);
      if (usersData.length > 0) {
        setNewTask((prev) => ({ ...prev, assignedTo: usersData[0].id }));
      }
      setLoading(false);
    });
  }, []);

  const createTask = async () => {
    if (!newTask.title) return;
    const res = await fetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newTask),
    });
    const created = await res.json();
    setTasks([...tasks, created]);
    setShowCreateModal(false);
    setNewTask({
      title: "",
      priority: "medium",
      dueDate: new Date().toISOString().split("T")[0],
      assignedTo: users[0]?.id || "",
    });
  };

  const toggleComplete = async (id: string) => {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;

    const res = await fetch(`/api/tasks/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completed: !task.completed }),
    });
    const updatedTask = (await res.json()) as Task;
    setTasks(tasks.map((t) => (t.id === id ? updatedTask : t)));
    setShowConfirm(null);
    setConfirmType(null);
  };

  const deleteTask = async (id: string) => {
    await fetch(`/api/tasks/${id}`, {
      method: "DELETE",
    });
    setTasks(tasks.filter((t) => t.id !== id));
    setShowConfirm(null);
    setConfirmType(null);
  };

  const [confirmType, setConfirmType] = useState<"complete" | "delete" | null>(
    null,
  );

  const sortedTasks = [...tasks]
    .sort((a, b) => {
      let comparison: number;
      if (sortBy === "priority") {
        const pMap = { high: 3, medium: 2, low: 1 };
        comparison = pMap[a.priority] - pMap[b.priority];
      } else if (sortBy === "dueDate") {
        comparison =
          new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      } else {
        comparison =
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      }
      return sortOrder === "asc" ? comparison : -comparison;
    })
    .filter((t) => filterUser === "all" || t.assignedTo === filterUser)
    .filter((t) => {
      if (filterStatus === "all") return true;
      if (filterStatus === "active") return !t.completed;
      if (filterStatus === "completed") return t.completed;
      return true;
    });

  if (loading)
    return (
      <div className="p-8 text-center animate-pulse">
        Loading Governance Spine...
      </div>
    );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold uppercase tracking-tighter">
            Task Governance
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-widest">
            Immutability Anchor for SWI Spine
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-600 text-white px-4 py-2 text-[10px] uppercase font-bold hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            Create Task
          </button>
          <div className="flex flex-col gap-1">
            <label className="text-[8px] font-bold uppercase opacity-40">
              Status
            </label>
            <select
              value={filterStatus}
              onChange={(e) =>
                setFilterStatus(
                  e.target.value as "all" | "active" | "completed",
                )
              }
              className="bg-white dark:bg-black border border-[#141414]/10 dark:border-[#E4E3E0]/10 text-[10px] p-1 uppercase font-bold"
            >
              <option value="all">All</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[8px] font-bold uppercase opacity-40">
              Assignee
            </label>
            <select
              value={filterUser}
              onChange={(e) => setFilterUser(e.target.value)}
              className="bg-white dark:bg-black border border-[#141414]/10 dark:border-[#E4E3E0]/10 text-[10px] p-1 uppercase font-bold"
            >
              <option value="all">All Users</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[8px] font-bold uppercase opacity-40">
              Sort By
            </label>
            <select
              value={sortBy}
              onChange={(e) =>
                setSortBy(
                  e.target.value as "priority" | "dueDate" | "createdAt",
                )
              }
              className="bg-white dark:bg-black border border-[#141414]/10 dark:border-[#E4E3E0]/10 text-[10px] p-1 uppercase font-bold"
            >
              <option value="createdAt">Creation</option>
              <option value="dueDate">Due Date</option>
              <option value="priority">Priority</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[8px] font-bold uppercase opacity-40">
              Order
            </label>
            <button
              onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
              className="bg-white dark:bg-black border border-[#141414]/10 dark:border-[#E4E3E0]/10 text-[10px] p-1 px-2 uppercase font-bold flex items-center h-[21px] gap-1"
            >
              {sortOrder === "asc" ? (
                <ArrowUp className="w-3 h-3" />
              ) : (
                <ArrowDown className="w-3 h-3" />
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="grid gap-2">
        <AnimatePresence>
          {sortedTasks.map((task) => (
            <motion.div
              key={task.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: task.completed ? 0.4 : 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={cn(
                "p-4 border transition-all flex items-center justify-between group",
                task.completed
                  ? "bg-black/5 dark:bg-white/5 border-transparent"
                  : "bg-white dark:bg-[#1A1A1A] border-[#141414]/10 dark:border-[#E4E3E0]/10 hover:border-[#141414]/30 dark:hover:border-[#E4E3E0]/30 shadow-sm",
              )}
            >
              <div className="flex items-center gap-4">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    if (!task.completed) {
                      setShowConfirm(task.id);
                      setConfirmType("complete");
                    } else {
                      toggleComplete(task.id);
                    }
                  }}
                  className="text-blue-500 transition-colors"
                >
                  <AnimatePresence mode="wait">
                    {task.completed ? (
                      <motion.div
                        key="completed"
                        initial={{ scale: 0.8, opacity: 0, rotate: -45 }}
                        animate={{ scale: 1, opacity: 1, rotate: 0 }}
                        exit={{ scale: 0.8, opacity: 0, rotate: 45 }}
                        transition={{
                          type: "spring",
                          stiffness: 300,
                          damping: 20,
                        }}
                      >
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      </motion.div>
                    ) : (
                      <motion.div
                        key="pending"
                        initial={{ scale: 0.8, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0.8, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <Circle className="w-5 h-5 opacity-30 group-hover:opacity-100 group-hover:text-blue-500 transition-all" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.button>
                <div>
                  <div className="flex items-center gap-3">
                    <h3
                      className={cn(
                        "text-sm font-bold uppercase tracking-tight",
                        task.completed && "line-through opacity-40",
                      )}
                    >
                      {task.title}
                    </h3>
                    <span
                      className={cn(
                        "text-[8px] font-bold uppercase px-1.5 py-0.5 border rounded-full",
                        task.priority === "high"
                          ? "border-red-500 text-red-500 bg-red-500/5"
                          : task.priority === "medium"
                            ? "border-yellow-500 text-yellow-500 bg-yellow-500/5"
                            : "border-blue-500 text-blue-500 bg-blue-500/5",
                      )}
                    >
                      {task.priority}
                    </span>
                  </div>
                  <div className="flex gap-3 mt-1 items-center">
                    <span className="text-[8px] font-mono opacity-40 flex items-center gap-1">
                      <Clock className="w-2 h-2" /> DUE: {task.dueDate}
                    </span>
                    <span className="text-[8px] font-mono opacity-40 flex items-center gap-1">
                      <User className="w-2 h-2" />{" "}
                      {users.find((u) => u.id === task.assignedTo)?.name ||
                        "Unassigned"}
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowConfirm(task.id);
                  setConfirmType("delete");
                }}
                className="p-2 opacity-0 group-hover:opacity-100 text-red-500 hover:bg-red-500/10 transition-all rounded"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <ProofArtifacts
        id="task-governance"
        title="Task Governance Ledger"
        data={{ tasks: sortedTasks }}
      />

      {showCreateModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-[#141414] border border-[#E4E3E0]/20 p-8 max-w-md w-full space-y-6"
          >
            <div className="flex justify-between items-center border-b border-black/10 dark:border-white/10 pb-4">
              <h3 className="text-xl font-bold uppercase tracking-tighter">
                Initiate Governance Task
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="opacity-40 hover:opacity-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[8px] font-bold uppercase opacity-40">
                  Task Title
                </label>
                <input
                  type="text"
                  value={newTask.title}
                  onChange={(e) =>
                    setNewTask({ ...newTask, title: e.target.value })
                  }
                  placeholder="E.g. Verify Merkle Proofs"
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-2 text-xs font-bold uppercase focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[8px] font-bold uppercase opacity-40">
                    Priority
                  </label>
                  <select
                    value={newTask.priority}
                    onChange={(e) =>
                      setNewTask({
                        ...newTask,
                        priority: e.target.value as "low" | "medium" | "high",
                      })
                    }
                    className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-2 text-xs font-bold uppercase focus:outline-none focus:border-blue-500 transition-colors"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-bold uppercase opacity-40">
                    Due Date
                  </label>
                  <input
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) =>
                      setNewTask({ ...newTask, dueDate: e.target.value })
                    }
                    className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-2 text-xs font-bold uppercase focus:outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[8px] font-bold uppercase opacity-40">
                  Assign To
                </label>
                <select
                  value={newTask.assignedTo}
                  onChange={(e) =>
                    setNewTask({ ...newTask, assignedTo: e.target.value })
                  }
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 p-2 text-xs font-bold uppercase focus:outline-none focus:border-blue-500 transition-colors"
                >
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.role})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button
              onClick={createTask}
              className="w-full bg-blue-600 text-white py-3 text-xs font-bold uppercase tracking-widest hover:bg-blue-700 transition-colors"
            >
              Commit Task to Spine
            </button>
          </motion.div>
        </div>
      )}

      {showConfirm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#141414] border border-[#E4E3E0]/20 p-8 max-w-md w-full space-y-6">
            <div
              className={cn(
                "flex items-center gap-4",
                confirmType === "delete" ? "text-red-500" : "text-yellow-500",
              )}
            >
              <AlertCircle className="w-12 h-12" />
              <h3 className="text-xl font-bold uppercase tracking-tighter">
                {confirmType === "delete"
                  ? "Confirm Deletion"
                  : "Confirm Completion"}
              </h3>
            </div>
            <p className="text-sm opacity-60">
              {confirmType === "delete"
                ? "WARNING: You are about to PERMANENTLY DELETE this task. This action is irreversible and will be logged as a destructive mutation in the SWI Governance Spine."
                : "ADVISORY: You are about to mark this task as COMPLETED. This signature will be recorded in the SWI Governance Spine and cannot be silently reverted."}
            </p>
            <div className="flex gap-4">
              <button
                onClick={() =>
                  confirmType === "delete"
                    ? deleteTask(showConfirm)
                    : toggleComplete(showConfirm)
                }
                className={cn(
                  "flex-1 text-white py-3 text-xs font-bold uppercase tracking-widest transition-colors",
                  confirmType === "delete"
                    ? "bg-red-600 hover:bg-red-700"
                    : "bg-blue-600 hover:bg-blue-700",
                )}
              >
                {confirmType === "delete"
                  ? "Confirm & Delete"
                  : "Confirm & Sign"}
              </button>
              <button
                onClick={() => {
                  setShowConfirm(null);
                  setConfirmType(null);
                }}
                className="flex-1 border border-[#141414]/20 dark:border-[#E4E3E0]/20 py-3 text-xs font-bold uppercase tracking-widest hover:bg-white/10 transition-colors text-[#141414] dark:text-[#E4E3E0]"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
