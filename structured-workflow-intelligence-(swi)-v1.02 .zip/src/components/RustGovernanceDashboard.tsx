import React, { useState, useEffect } from 'react';
import { rustGovernanceEngine, KnowledgeObject, RustState } from '../swi/rustGovernance';
import { RefreshCw, Archive, Play, Activity, AlertTriangle, ShieldCheck, Clock } from 'lucide-react';

import { RustScatterPlot } from './RustScatterPlot';

const cn = (...classes: (string | undefined | null | false)[]) => classes.filter(Boolean).join(' ');

// Simple UI Components
const Card = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn("bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-sm", className)}>
    {children}
  </div>
);
const CardHeader = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn("p-6 pb-4 border-b border-gray-100 dark:border-gray-800", className)}>{children}</div>
);
const CardTitle = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <h3 className={cn("text-lg font-semibold text-gray-900 dark:text-white", className)}>{children}</h3>
);
const CardContent = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn("p-6", className)}>{children}</div>
);
const Badge = ({ children, className, variant = 'default' }: { children: React.ReactNode, className?: string, variant?: 'default' | 'outline' }) => (
  <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border", className)}>
    {children}
  </span>
);
const Button = ({ children, onClick, disabled, className, variant = 'default' }: { children: React.ReactNode, onClick?: () => void, disabled?: boolean, className?: string, variant?: 'default' | 'outline' | 'destructive' }) => {
  const baseStyle = "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 disabled:pointer-events-none ring-offset-background h-10 py-2 px-4";
  const variants = {
    default: "bg-gray-900 text-white hover:bg-gray-800 dark:bg-gray-50 dark:text-gray-900 dark:hover:bg-gray-200",
    outline: "border border-gray-200 hover:bg-gray-100 dark:border-gray-800 dark:hover:bg-gray-800 dark:text-gray-100",
    destructive: "bg-red-500 text-white hover:bg-red-600 dark:bg-red-900 dark:hover:bg-red-800"
  };
  return (
    <button onClick={onClick} disabled={disabled} className={cn(baseStyle, variants[variant], className)}>
      {children}
    </button>
  );
};
const Progress = ({ value, className, indicatorColor = "bg-blue-600" }: { value: number, className?: string, indicatorColor?: string }) => (
  <div className={cn("relative w-full overflow-hidden rounded-full bg-gray-100 dark:bg-gray-800", className)}>
    <div className={cn("h-full w-full flex-1 transition-all", indicatorColor)} style={{ transform: `translateX(-${100 - (value || 0)}%)` }} />
  </div>
);

const StateColors: Record<RustState, string> = {
  Active: 'bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20',
  Stable: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20',
  Dormant: 'bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/20',
  Rusting: 'bg-amber-700/10 text-amber-700 dark:text-amber-500 border-amber-700/20',
  Rust: 'bg-gray-800 text-gray-400 border-gray-700',
  Reactivated: 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20',
  Archived: 'bg-gray-100 text-gray-500 border-gray-200 dark:bg-gray-900 dark:border-gray-800'
};

const StateIcons: Record<RustState, React.ElementType> = {
  Active: Activity,
  Stable: ShieldCheck,
  Dormant: Clock,
  Rusting: AlertTriangle,
  Rust: AlertTriangle,
  Reactivated: RefreshCw,
  Archived: Archive
};

export const RustGovernanceDashboard: React.FC = () => {
  const [objects, setObjects] = useState<KnowledgeObject[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [alerts, setAlerts] = useState<{id: string, content: string, timestamp: Date}[]>([]);
  
  const [transitionState, setTransitionState] = useState<RustState | ''>('');
  const [transitionReason, setTransitionReason] = useState('');

  const loadObjects = () => {
    setObjects(rustGovernanceEngine.getAllObjects());
  };

  useEffect(() => {
    loadObjects();
    const interval = setInterval(() => {
      rustGovernanceEngine.tickGovernanceCycle();
      const currentObjects = rustGovernanceEngine.getAllObjects();
      setObjects(currentObjects);

      // Simulate incoming high-evidence alerts for rusting/dormant objects
      const rusting = currentObjects.filter(o => o.state === 'Rusting' || o.state === 'Dormant');
      if (rusting.length > 0 && Math.random() > 0.4) {
          const randomObj = rusting[Math.floor(Math.random() * rusting.length)];
          setAlerts(prev => {
             if (prev.find(a => a.id === randomObj.id)) return prev;
             return [{ id: randomObj.id, content: randomObj.content, timestamp: new Date() }, ...prev].slice(0, 5);
          });
      }
    }, 5000); // Tick every 5 seconds for demonstration
    return () => clearInterval(interval);
  }, []);

  const handleReactivate = (id: string) => {
    rustGovernanceEngine.reactivate(id, 0.8);
    setAlerts(prev => prev.filter(a => a.id !== id));
    loadObjects();
  };

  const handleValidate = (id: string) => {
    rustGovernanceEngine.validate(id, 0.1);
    loadObjects();
  };

  const handleArchive = (id: string) => {
    rustGovernanceEngine.archive(id);
    loadObjects();
  };

  const handleManualTick = () => {
    rustGovernanceEngine.tickGovernanceCycle();
    loadObjects();
  };

  const handleForceTransition = (id: string) => {
    if (!transitionState || !transitionReason) return;
    rustGovernanceEngine.forceState(id, transitionState as RustState, transitionReason);
    setTransitionState('');
    setTransitionReason('');
    loadObjects();
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white">
            Rust Governance
          </h1>
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            Knowledge is never governed by age alone. Its influence is continuously recalculated.
          </p>
        </div>
        <Button onClick={handleManualTick} variant="outline" className="flex items-center gap-2">
          <Play className="w-4 h-4" />
          Tick Governance Cycle
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Influence Trajectory</CardTitle>
            </CardHeader>
            <CardContent>
              <RustScatterPlot objects={objects} selectedId={selectedId} onSelect={setSelectedId} />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Knowledge Objects</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {objects.map((obj) => {
                  const Icon = StateIcons[obj.state];
                  return (
                    <div 
                      key={obj.id} 
                      className={cn(
                        "p-4 rounded-lg border cursor-pointer transition-colors",
                        selectedId === obj.id 
                          ? "border-blue-500 bg-blue-50/50 dark:bg-blue-900/20" 
                          : "border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700"
                      )}
                      onClick={() => setSelectedId(obj.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <h3 className="font-medium text-gray-900 dark:text-white truncate max-w-[400px]">
                            {obj.content}
                          </h3>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span>ID: {obj.id.substring(0, 8)}</span>
                            <span>Last Validated: {obj.last_validated.toLocaleDateString()}</span>
                          </div>
                        </div>
                        <Badge variant="outline" className={cn("flex items-center gap-1", StateColors[obj.state])}>
                          <Icon className="w-3 h-3" />
                          {obj.state}
                        </Badge>
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-4">
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-amber-700 dark:text-amber-500">Rust Factor</span>
                            <span>{(obj.rust_factor * 100).toFixed(1)}%</span>
                          </div>
                          <Progress value={obj.rust_factor * 100} className="h-1.5" indicatorColor="bg-amber-500" />
                        </div>
                        <div>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-emerald-700 dark:text-emerald-500">Patina (Trust)</span>
                            <span>{(obj.patina_factor * 100).toFixed(1)}%</span>
                          </div>
                          <Progress value={obj.patina_factor * 100} className="h-1.5" indicatorColor="bg-emerald-500" />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="mb-6 border-red-200 dark:border-red-900/30">
            <CardHeader className="bg-red-50 dark:bg-red-900/10 border-b border-red-100 dark:border-red-900/20 pb-4">
              <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-400 text-sm">
                <AlertTriangle className="w-4 h-4" />
                Evidence Alerts
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
               {alerts.length === 0 ? (
                  <div className="p-6 text-center text-sm text-gray-500">No new evidence alerts.</div>
               ) : (
                  <div className="divide-y divide-gray-100 dark:divide-gray-800">
                    {alerts.map(alert => (
                       <div key={alert.id} className="p-4 flex flex-col gap-3">
                          <p className="text-sm font-medium text-gray-900 dark:text-gray-100 line-clamp-2" title={alert.content}>{alert.content}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] uppercase font-bold text-red-600 dark:text-red-400 tracking-widest">High-Evidence Detected</span>
                            <Button onClick={() => handleReactivate(alert.id)} className="h-7 text-xs px-3 bg-red-600 hover:bg-red-700 text-white">
                                Reactivate
                            </Button>
                          </div>
                       </div>
                    ))}
                  </div>
               )}
            </CardContent>
          </Card>

          {selectedId ? (
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle>Object Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {objects.find(o => o.id === selectedId) && (
                  <>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-gray-500">Content</p>
                      <p className="text-sm text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-900 p-3 rounded-md">
                        {objects.find(o => o.id === selectedId)?.content}
                      </p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Evidence Score</span>
                          <span className="text-gray-900 dark:text-white font-medium">{(objects.find(o => o.id === selectedId)!.evidence_score * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={objects.find(o => o.id === selectedId)!.evidence_score * 100} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Governance Score</span>
                          <span className="text-gray-900 dark:text-white font-medium">{(objects.find(o => o.id === selectedId)!.governance_score * 100).toFixed(1)}%</span>
                        </div>
                        <Progress value={objects.find(o => o.id === selectedId)!.governance_score * 100} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-700 dark:text-gray-300">Usage Frequency</span>
                          <span className="text-gray-900 dark:text-white font-medium">{objects.find(o => o.id === selectedId)!.usage_frequency}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 pt-4 border-t border-gray-200 dark:border-gray-800">
                      <Button 
                        onClick={() => handleValidate(selectedId)} 
                        variant="outline" 
                        className="w-full justify-start text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-900/20"
                      >
                        <ShieldCheck className="w-4 h-4 mr-2" />
                        Validate (Add Evidence)
                      </Button>
                      <Button 
                        onClick={() => handleReactivate(selectedId)} 
                        variant="outline" 
                        className="w-full justify-start text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20"
                        disabled={!['Rust', 'Archived', 'Rusting', 'Dormant'].includes(objects.find(o => o.id === selectedId)!.state)}
                      >
                        <RefreshCw className="w-4 h-4 mr-2" />
                        Reactivate Knowledge
                      </Button>
                      <Button 
                        onClick={() => handleArchive(selectedId)} 
                        variant="destructive" 
                        className="w-full justify-start"
                        disabled={objects.find(o => o.id === selectedId)!.state === 'Archived'}
                      >
                        <Archive className="w-4 h-4 mr-2" />
                        Archive Knowledge
                      </Button>
                    </div>
                    <div className="pt-4 border-t border-gray-200 dark:border-gray-800 space-y-3">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Force State Transition</p>
                      <div className="flex gap-2">
                        <select 
                          className="flex-1 rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          value={transitionState}
                          onChange={(e) => setTransitionState(e.target.value as RustState)}
                        >
                          <option value="" disabled>Select state...</option>
                          {Object.keys(StateIcons).map(state => (
                             <option key={state} value={state}>{state}</option>
                          ))}
                        </select>
                      </div>
                      <input 
                        type="text" 
                        placeholder="Audit justification note..."
                        className="w-full rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value={transitionReason}
                        onChange={(e) => setTransitionReason(e.target.value)}
                      />
                      <Button 
                        onClick={() => handleForceTransition(selectedId)}
                        disabled={!transitionState || !transitionReason}
                        className="w-full"
                      >
                        Force Transition
                      </Button>
                    </div>

                    <div className="pt-4 border-t border-gray-200 dark:border-gray-800 space-y-3">
                      <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Governance History</p>
                      <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
                        {objects.find(o => o.id === selectedId)?.history?.map((entry, idx) => (
                          <div key={idx} className="bg-gray-50 dark:bg-gray-900/50 p-3 rounded border border-gray-100 dark:border-gray-800 text-sm">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-xs text-gray-500">{new Date(entry.timestamp).toLocaleString()}</span>
                              <div className="flex items-center gap-2 text-xs font-medium">
                                <span className={cn("px-1.5 py-0.5 rounded", StateColors[entry.previousState])}>{entry.previousState}</span>
                                <span className="text-gray-400">→</span>
                                <span className={cn("px-1.5 py-0.5 rounded", StateColors[entry.newState])}>{entry.newState}</span>
                              </div>
                            </div>
                            <p className="text-gray-600 dark:text-gray-400 text-xs italic">
                              "{entry.reason}"
                            </p>
                          </div>
                        ))}
                        {(!objects.find(o => o.id === selectedId)?.history || objects.find(o => o.id === selectedId)!.history.length === 0) && (
                          <p className="text-xs text-gray-500 text-center py-4">No history recorded yet.</p>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="sticky top-6">
              <CardContent className="flex flex-col items-center justify-center text-center p-12 text-gray-500 h-64">
                <Activity className="w-8 h-8 mb-4 text-gray-400" />
                <p>Select a knowledge object to view governance details.</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default RustGovernanceDashboard;
