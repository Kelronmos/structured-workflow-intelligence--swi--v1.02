import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface DriftHeatmapProps {
  data: { x: number; y: number; drift: number }[];
  width?: number;
  height?: number;
}

export default function DriftHeatmap({ data, width = 600, height = 400 }: DriftHeatmapProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !data.length) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const margin = { top: 20, right: 20, bottom: 30, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`);

    const xScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.x) || 100])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.y) || 100])
      .range([innerHeight, 0]);

    const colorScale = d3.scaleSequential(d3.interpolateYlOrRd)
      .domain([0, 1]); // Drift is 0 to 1

    // Add cells
    g.selectAll('rect')
      .data(data)
      .enter()
      .append('rect')
      .attr('x', d => xScale(d.x))
      .attr('y', d => yScale(d.y))
      .attr('width', innerWidth / 20) // approx
      .attr('height', innerHeight / 20)
      .attr('fill', d => colorScale(d.drift))
      .attr('stroke', 'rgba(0,0,0,0.1)')
      .style('opacity', 0.8)
      .on('mouseover', function() {
        d3.select(this).style('opacity', 1).attr('stroke', '#000');
        // Simple tooltip could be here
      })
      .on('mouseout', function() {
        d3.select(this).style('opacity', 0.8).attr('stroke', 'rgba(0,0,0,0.1)');
      });

    // Add Axes
    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale).ticks(5));

    g.append('g')
      .call(d3.axisLeft(yScale).ticks(5));

    // Label
    g.append('text')
      .attr('x', innerWidth / 2)
      .attr('y', -5)
      .attr('text-anchor', 'middle')
      .attr('font-size', '12px')
      .attr('font-weight', 'bold')
      .text('SWI Governance Drift Heatmap');

  }, [data, width, height]);

  return (
    <div className="bg-white p-4 rounded-xl shadow-lg border border-gray-100">
      <svg ref={svgRef} width={width} height={height}></svg>
    </div>
  );
}
