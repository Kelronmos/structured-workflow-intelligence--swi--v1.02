import { useEffect, useState, useCallback, useRef } from 'react';
import { Shield, AlertTriangle, CheckCircle, Info, TrendingUp, Edit3, Save, RotateCcw, Trash2, History as HistoryIcon } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine } from 'recharts';
import { socket } from '@/src/lib/socket';

interface PolicyConstraints {
  maxRiskValue: number;
  minCountdownForReboot: number;
  allowedActions: string[];
  restrictedContexts: string[];
}

interface Policy {
  id: string;
  name: string;
  version: string | number;
  description: string;
  constraints: PolicyConstraints;
  updatedAt: string;
}

interface StableState {
  value: number;
  timestamp: string;
}

interface PolicyHistoryEntry {
  version: number;
  updatedAt: string;
  changes: string;
}

interface PolicyDashboardProps {
  theme: 'light' | 'dark';
}

interface HistoryEntry {
  time: string;
  value: number;
  limit: number;
}

export default function PolicyDashboard({ theme }: PolicyDashboardProps) {
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [stableState, setStableState] = useState<StableState | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editPolicy, setEditPolicy] = useState<Policy | null>(null);
  const [policyHistory, setPolicyHistory] = useState<PolicyHistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [changeLog, setChangeLog] = useState("");
  const policyRef = useRef<Policy | null>(null);

  useEffect(() => {
    policyRef.current = policy;
  }, [policy]);

  const fetchData = useCallback(async () => {
    try {
      const [pRes, sRes, hRes] = await Promise.all([
        fetch('/api/policy'),
        fetch('/api/stable-state'),
        fetch('/api/policy/history')
      ]);
      if (pRes.ok) {
        const pData = await pRes.json();
        setPolicy(pData);
        if (!isEditing) setEditPolicy(pData);
      }
      if (sRes.ok) {
        const state = await sRes.json();
        setStableState(state);
        setHistory(prev => {
          const val = typeof state.value === 'number' ? state.value : 0;
          const newEntry: HistoryEntry = { 
            time: new Date().toLocaleTimeString(), 
            value: val,
            limit: policyRef.current?.constraints?.maxRiskValue || 30
          };
          return [...prev, newEntry].slice(-20);
        });
      }
      if (hRes.ok) setPolicyHistory(await hRes.json());
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch policy data:", error);
    }
  }, [isEditing]);

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      if (isMounted) await fetchData();
    };
    load();

    // WebSocket Listeners
    socket.on('stable_state', (state: StableState) => {
      if (state) {
        setStableState(state as StableState);
        setHistory(prev => {
          const val = typeof state.value === 'number' ? state.value : 0;
          const newEntry: HistoryEntry = { 
            time: new Date().toLocaleTimeString(), 
            value: val,
            limit: policyRef.current?.constraints?.maxRiskValue || 30
          };
          return [...prev, newEntry].slice(-20);
        });
      }
    });

    return () => {
      isMounted = false;
      socket.off('stable_state');
    };
  }, [fetchData]);

  const handleSave = async () => {
    try {
      const res = await fetch('/api/policy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ policy: editPolicy, changeLog })
      });
      if (res.ok) {
        setIsEditing(false);
        setChangeLog("");
        fetchData();
      }
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to save policy:", error);
    }
  };

  if (!policy) return null;

  const isAdherent = stableState ? Math.abs(stableState.value ?? 0) <= policy.constraints.maxRiskValue : true;

  return (
    <div className={cn(
      "border p-6 space-y-8 font-mono",
      theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
    )}>
      <div className="flex items-center justify-between border-b pb-4">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          <h2 className="text-sm uppercase font-bold tracking-tighter">External Policy Dashboard</h2>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className="text-[10px] uppercase font-bold flex items-center gap-1 opacity-60 hover:opacity-100"
          >
            <HistoryIcon className="w-3 h-3" />
            History
          </button>
          <button 
            onClick={() => {
              setIsEditing(!isEditing);
              if (!isEditing) setEditPolicy(policy);
            }}
            className="text-[10px] uppercase font-bold flex items-center gap-1 opacity-60 hover:opacity-100"
          >
            {isEditing ? <RotateCcw className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}
            {isEditing ? "Cancel" : "Manage Policy"}
          </button>
          <div className={cn(
            "px-3 py-1 rounded-full text-[10px] font-bold uppercase flex items-center gap-1",
            isAdherent ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
          )}>
            {isAdherent ? <CheckCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
            {isAdherent ? "Adherent" : "Violation Detected"}
          </div>
        </div>
      </div>

      {showHistory && (
        <div className={cn(
          "p-4 border space-y-4",
          theme === 'light' ? "bg-gray-50 border-[#141414]/10" : "bg-black border-[#E4E3E0]/10"
        )}>
          <p className="text-[10px] uppercase font-bold opacity-40">Policy Version History</p>
          <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
            {policyHistory.slice().reverse().map((entry, i) => (
              <div key={i} className="text-[10px] border-b border-white/5 pb-2">
                <div className="flex justify-between font-bold">
                  <span>v{entry.version}</span>
                  <span className="opacity-40">{new Date(entry.updatedAt).toLocaleString()}</span>
                </div>
                <p className="opacity-60 italic mt-1">{entry.changes}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {isEditing ? (
        <div className={cn(
          "p-6 border space-y-6",
          theme === 'light' ? "bg-gray-50 border-[#141414]/10" : "bg-black/40 border-white/5"
        )}>
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-4">
              <p className="text-[10px] uppercase font-bold opacity-40">Identity & Metadata</p>
              <div className="space-y-2">
                <input 
                  className="w-full bg-transparent border border-white/10 p-2 text-xs"
                  value={editPolicy?.name || ''}
                  onChange={e => setEditPolicy(prev => prev ? {...prev, name: e.target.value} : null)}
                  placeholder="Policy Name"
                />
                <textarea 
                  className="w-full bg-transparent border border-white/10 p-2 text-xs h-20"
                  value={editPolicy?.description || ''}
                  onChange={e => setEditPolicy(prev => prev ? {...prev, description: e.target.value} : null)}
                  placeholder="Description"
                />
              </div>
            </div>
            <div className="space-y-4">
              <p className="text-[10px] uppercase font-bold opacity-40">Numeric Constraints</p>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[10px]">
                  <span>Max Risk Value</span>
                  <input 
                    type="number"
                    className="w-20 bg-transparent border border-white/10 p-1 text-right"
                    value={editPolicy?.constraints.maxRiskValue || 0}
                    onChange={e => setEditPolicy(prev => prev ? {...prev, constraints: {...prev.constraints, maxRiskValue: Number(e.target.value)}} : null)}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px]">
                  <span>Min Countdown</span>
                  <input 
                    type="number"
                    className="w-20 bg-transparent border border-white/10 p-1 text-right"
                    value={editPolicy?.constraints.minCountdownForReboot || 0}
                    onChange={e => setEditPolicy(prev => prev ? {...prev, constraints: {...prev.constraints, minCountdownForReboot: Number(e.target.value)}} : null)}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <p className="text-[10px] uppercase font-bold opacity-40">Allowed Actions (Allowlist)</p>
              <div className="flex flex-wrap gap-2 p-2 border border-white/10 bg-white/5 min-h-[44px] rounded-sm focus-within:border-blue-500/50 transition-colors">
                {editPolicy?.constraints.allowedActions?.map((action: string, i: number) => (
                  <div key={i} className="flex items-center gap-1 bg-blue-500/20 px-2 py-1 text-[10px] border border-blue-500/30 text-blue-400 rounded-sm">
                    {action}
                    <button 
                      onClick={() => setEditPolicy(prev => prev ? {
                        ...prev, 
                        constraints: {
                          ...prev.constraints, 
                          allowedActions: prev.constraints.allowedActions.filter((_: string, idx: number) => idx !== i)
                        }
                      } : null)}
                      className="hover:text-blue-300 transition-colors"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
                <input 
                  className="flex-1 bg-transparent border-none outline-none text-[10px] min-w-[120px] py-1"
                  placeholder="Add action..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ',') {
                      e.preventDefault();
                      const val = e.currentTarget.value.trim();
                      if (val && editPolicy && !editPolicy.constraints.allowedActions?.includes(val)) {
                        setEditPolicy(prev => prev ? {
                          ...prev,
                          constraints: {
                            ...prev.constraints,
                            allowedActions: [...(prev.constraints.allowedActions || []), val]
                          }
                        } : null);
                        e.currentTarget.value = '';
                      }
                    } else if (e.key === 'Backspace' && !e.currentTarget.value && editPolicy?.constraints.allowedActions?.length) {
                      setEditPolicy(prev => prev ? {
                        ...prev,
                        constraints: {
                          ...prev.constraints,
                          allowedActions: prev.constraints.allowedActions.slice(0, -1)
                        }
                      } : null);
                    }
                  }}
                />
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] uppercase font-bold opacity-40">Restricted Contexts (Blocklist)</p>
              <div className="flex flex-wrap gap-2 p-2 border border-white/10 bg-white/5 min-h-[44px] rounded-sm focus-within:border-red-500/50 transition-colors">
                {editPolicy?.constraints.restrictedContexts?.map((ctx: string, i: number) => (
                  <div key={i} className="flex items-center gap-1 bg-red-500/20 px-2 py-1 text-[10px] border border-red-500/30 text-red-400 rounded-sm">
                    {ctx}
                    <button 
                      onClick={() => setEditPolicy(prev => prev ? {
                        ...prev, 
                        constraints: {
                          ...prev.constraints, 
                          restrictedContexts: prev.constraints.restrictedContexts.filter((_: string, idx: number) => idx !== i)
                        }
                      } : null)}
                      className="hover:text-red-300 transition-colors"
                    >
                      <Trash2 className="w-2.5 h-2.5" />
                    </button>
                  </div>
                ))}
                <input 
                  className="flex-1 bg-transparent border-none outline-none text-[10px] min-w-[120px] py-1"
                  placeholder="Add context..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ',') {
                      e.preventDefault();
                      const val = e.currentTarget.value.trim();
                      if (val && editPolicy && !editPolicy.constraints.restrictedContexts?.includes(val)) {
                        setEditPolicy(prev => prev ? {
                          ...prev,
                          constraints: {
                            ...prev.constraints,
                            restrictedContexts: [...(prev.constraints.restrictedContexts || []), val]
                          }
                        } : null);
                        e.currentTarget.value = '';
                      }
                    } else if (e.key === 'Backspace' && !e.currentTarget.value && editPolicy?.constraints.restrictedContexts?.length) {
                      setEditPolicy(prev => prev ? {
                        ...prev,
                        constraints: {
                          ...prev.constraints,
                          restrictedContexts: prev.constraints.restrictedContexts.slice(0, -1)
                        }
                      } : null);
                    }
                  }}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] uppercase font-bold opacity-40">Change Log (Required)</p>
            <input 
              className="w-full bg-transparent border border-white/10 p-2 text-xs"
              value={changeLog}
              onChange={e => setChangeLog(e.target.value)}
              placeholder="Describe what changed in this version..."
            />
          </div>

          <button 
            disabled={!changeLog}
            onClick={handleSave}
            className={cn(
              "w-full py-3 text-xs uppercase font-bold flex items-center justify-center gap-2 transition-all",
              changeLog ? "bg-blue-600 text-white hover:bg-blue-500" : "bg-gray-500/20 text-gray-500 cursor-not-allowed"
            )}
          >
            <Save className="w-4 h-4" />
            Commit Policy Update
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <div className="space-y-4">
              <div>
                <p className="text-[10px] uppercase font-bold opacity-40 mb-1">Policy Identity</p>
                <p className="text-xs font-bold">{policy.name}</p>
                <p className="text-[10px] opacity-60">{policy.id} v{policy.version}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase font-bold opacity-40 mb-1">Description</p>
                <p className="text-[10px] leading-relaxed">{policy.description}</p>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-[10px] uppercase font-bold opacity-40 mb-1">Active Constraints</p>
              <div className="space-y-2">
                {Object.entries(policy.constraints).map(([key, value]) => (
                  <div key={key} className={cn(
                    "p-2 border flex flex-col gap-1 text-[10px]",
                    theme === 'light' ? "bg-gray-50 border-[#141414]/10" : "bg-black border-[#E4E3E0]/10"
                  )}>
                    <span className="opacity-60 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                    <span className="font-bold break-all">
                      {Array.isArray(value) ? value.join(', ') : String(value)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2 opacity-40">
              <TrendingUp className="w-4 h-4" />
              <p className="text-[10px] uppercase font-bold tracking-widest">Adherence Trend (Last 20 Samples)</p>
            </div>
            <div className={cn(
              "h-[250px] border p-4",
              theme === 'light' ? "bg-gray-50 border-[#141414]/10" : "bg-black/40 border-white/5"
            )}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={history}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={theme === 'light' ? '#00000010' : '#ffffff10'} />
                  <XAxis 
                    dataKey="time" 
                    hide 
                  />
                  <YAxis 
                    domain={[-policy.constraints.maxRiskValue * 1.5, policy.constraints.maxRiskValue * 1.5]} 
                    fontSize={9}
                    tickFormatter={(v) => v.toFixed(0)}
                    stroke={theme === 'light' ? '#00000040' : '#ffffff40'}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: theme === 'light' ? '#fff' : '#141414',
                      border: '1px solid #00000020',
                      fontSize: '10px',
                      fontFamily: 'monospace'
                    }}
                  />
                  <ReferenceLine y={policy.constraints.maxRiskValue} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'right', value: 'MAX', fill: '#ef4444', fontSize: 8 }} />
                  <ReferenceLine y={-policy.constraints.maxRiskValue} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'right', value: 'MIN', fill: '#ef4444', fontSize: 8 }} />
                  <ReferenceLine y={0} stroke={theme === 'light' ? '#00000040' : '#ffffff40'} />
                  <Area 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#2563eb" 
                    fillOpacity={1} 
                    fill="url(#colorValue)" 
                    animationDuration={500}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {stableState && (
        <div className={cn(
          "p-4 border space-y-3",
          theme === 'light' ? "bg-gray-100" : "bg-black"
        )}>
          <div className="flex items-center gap-2 opacity-40">
            <Info className="w-3 h-3" />
            <p className="text-[9px] uppercase font-bold tracking-widest">Runtime Adherence Analysis</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs">Current State Value:</p>
            <p className={cn(
              "text-xs font-bold",
              Math.abs(stableState.value ?? 0) > policy.constraints.maxRiskValue ? "text-red-600" : "text-green-600"
            )}>
              {(stableState.value ?? 0).toFixed(2)}
            </p>
          </div>
          <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden relative">
            <div 
              className="absolute top-0 bottom-0 bg-red-500/20" 
              style={{ left: '0%', width: '100%' }}
            />
            <div 
              className="absolute top-0 bottom-0 bg-green-500/20" 
              style={{ left: '50%', width: '0%', transform: 'translateX(-50%)' }}
            />
            <div 
              className="h-full bg-blue-600 transition-all duration-500" 
              style={{ 
                width: `${Math.min(100, (Math.abs(stableState.value ?? 0) / (policy.constraints.maxRiskValue * 1.5)) * 100)}%`,
                marginLeft: (stableState.value ?? 0) < 0 ? 'auto' : '0',
                marginRight: (stableState.value ?? 0) > 0 ? 'auto' : '0'
              }}
            />
            <div 
              className="absolute top-0 bottom-0 w-0.5 bg-[#141414] z-10" 
              style={{ left: `${(policy.constraints.maxRiskValue / (policy.constraints.maxRiskValue * 1.5)) * 100}%` }}
            />
          </div>
          <p className="text-[9px] opacity-40 text-center uppercase">Boundary Limit: ±{policy.constraints.maxRiskValue}</p>
        </div>
      )}
    </div>
  );
}
