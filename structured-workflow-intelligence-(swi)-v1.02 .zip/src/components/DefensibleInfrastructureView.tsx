import React, { useState } from "react";
import {
  Shield,
  BookOpen,
  Activity,
  Play,
  Eye,
  Users,
  FileText,
  FileCheck2,
  AlertTriangle,
  Zap,
  Terminal,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface Pillar {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  status: "PENDING" | "VERIFIED" | "ACTIVE";
  logs: string[];
}

export default function DefensibleInfrastructureView() {
  const [pillars, setPillars] = useState<Pillar[]>([
    {
      id: "invariant",
      title: "Formal Invariant Definitions",
      description:
        "Mathematical definitions mapping constraints across the entire architectural manifold.",
      icon: BookOpen,
      status: "VERIFIED",
      logs: [
        "[INFRA] Loading invariant definitions...",
        "[INFRA] Constraint limits locked: max_drift=0.4, threshold_variance=0.01",
        "[INFRA] Verified mathematical binding across all core states.",
      ],
    },
    {
      id: "exec_verify",
      title: "Executable Verification",
      description:
        "Continuous runtime validation bridging abstract specification with active memory state.",
      icon: Activity,
      status: "ACTIVE",
      logs: [
        "[INFRA] Runtime extraction initiated...",
        "[INFRA] Checking memory offsets -> OK",
        "[INFRA] Execution bound verified. Continuous validation loop active.",
      ],
    },
    {
      id: "open_adv",
      title: "Open Adversarial Harnesses",
      description:
        "Constantly-running simulated attacks challenging the defensive boundaries of the kernel.",
      icon: Shield,
      status: "VERIFIED",
      logs: [
        "[INFRA] Executed RED_TEAM_HARNESS_09",
        "[INFRA] Simulated threshold breach intercepted by Hot-Path Cryptography.",
        "[INFRA] Adversarial suite returned 0 successful bypasses.",
      ],
    },
    {
      id: "deterministic_logs",
      title: "Deterministic Replay Logs",
      description:
        "Cryptographically sealed ordered event logs that guarantee exact state reconstruction.",
      icon: Play,
      status: "VERIFIED",
      logs: [
        "[INFRA] Writing execution vector...",
        "[INFRA] Hash finalized: 0x9a8f...b2",
        "[INFRA] Replay tested against Genesis block -> 100% equivalence.",
      ],
    },
    {
      id: "peer_review",
      title: "Peer Review",
      description:
        "Consensus layer requiring cryptographic multisignature validation for state advancement.",
      icon: Users,
      status: "ACTIVE",
      logs: [
        "[INFRA] Pending state proposal intercepted by Quorum Nodes.",
        "[INFRA] Node A, Node B, Node C signed state.",
        "[INFRA] Byzantine constraint satisfied. State committed.",
      ],
    },
    {
      id: "guarantees",
      title: "Measurable Guarantees",
      description:
        "Quantifiable bounds on operational drift, time-to-finality, and structural fault tolerance.",
      icon: FileCheck2,
      status: "VERIFIED",
      logs: [
        "[INFRA] Measured fault tolerance: 33% byzantine limits.",
        "[INFRA] Time-to-finality observed at < 400ms.",
        "[INFRA] Deterministic bounds met.",
      ],
    },
    {
      id: "transparency",
      title: "Failure Transparency",
      description:
        "Mandated visibility into node disagreement, threshold breaches, and kernel isolations.",
      icon: AlertTriangle,
      status: "VERIFIED",
      logs: [
        "[INFRA] Logging injected simulated fault...",
        "[INFRA] Fault broadcasted to transparency ledger.",
        "[INFRA] Transparency requirements fulfilled.",
      ],
    },
  ]);

  const [selectedPillar, setSelectedPillar] = useState<string>("invariant");

  const activePillar =
    pillars.find((p) => p.id === selectedPillar) || pillars[0];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Zap className="w-5 h-5 text-yellow-500" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Defensible Infrastructure
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            Transitioning from visionary architecture into measurable,
            defensible engineering. SWI replaces simulated coordination with
            verifiable distributed agreement and formal laws.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Navigation / List */}
        <div className="lg:col-span-1 space-y-2">
          {pillars.map((pillar) => (
            <button
              key={pillar.id}
              onClick={() => setSelectedPillar(pillar.id)}
              className={cn(
                "w-full flex items-start gap-4 p-4 border transition-all text-left group",
                selectedPillar === pillar.id
                  ? "bg-black text-white dark:bg-white dark:text-black border-black dark:border-white"
                  : "bg-white text-black dark:bg-[#141414] dark:text-white border-black/10 dark:border-white/10 hover:border-black/50 dark:hover:border-white/50",
              )}
            >
              <div className="mt-1">
                <pillar.icon
                  className={cn(
                    "w-5 h-5",
                    selectedPillar === pillar.id
                      ? "opacity-100"
                      : "opacity-40 group-hover:opacity-100",
                  )}
                />
              </div>
              <div>
                <h3 className="text-[11px] font-bold uppercase tracking-widest">
                  {pillar.title}
                </h3>
                <div className="flex items-center gap-2 mt-2">
                  <span
                    className={cn(
                      "text-[9px] font-bold px-2 py-0.5 rounded-full border",
                      pillar.status === "VERIFIED"
                        ? "border-green-500 text-green-500 bg-green-500/10"
                        : "border-blue-500 text-blue-500 bg-blue-500/10",
                    )}
                  >
                    {pillar.status}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Details Panel */}
        <div className="lg:col-span-2 bg-[#141414] border border-white/10 text-white p-6 flex flex-col min-h-[500px]">
          <div className="flex items-center gap-3 mb-4">
            <activePillar.icon className="w-6 h-6 text-blue-400" />
            <h2 className="text-lg font-black uppercase tracking-widest">
              {activePillar.title}
            </h2>
          </div>

          <p className="text-sm font-mono opacity-80 mb-8 max-w-xl leading-relaxed">
            {activePillar.description}
          </p>

          <div className="flex-1 bg-black/50 border border-white/5 rounded-sm p-4 font-mono text-[10px] overflow-y-auto mb-6">
            <div className="flex items-center gap-2 text-white/40 mb-3">
              <Terminal className="w-3 h-3" />
              <span>EXECUTION_TRACE_LOG</span>
            </div>
            {activePillar.logs.map((log, idx) => (
              <div key={idx} className="text-green-400/80 mb-1">
                <span className="opacity-50 mr-2">
                  {String(idx + 1).padStart(2, "0")}
                </span>
                {log}
              </div>
            ))}
          </div>

          <ProofArtifacts
            id={`defensible-${activePillar.id}`}
            title={`${activePillar.title} Protocol Proof`}
            logs={activePillar.logs}
            data={{ pillar: activePillar }}
            variant="always-dark"
          />
        </div>
      </div>
    </div>
  );
}
