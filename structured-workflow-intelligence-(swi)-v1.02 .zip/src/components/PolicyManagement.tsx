import { useState, useEffect, KeyboardEvent } from 'react';
import { Shield, Save, History, AlertCircle, CheckCircle2, X, Plus, Download, ToggleLeft, ToggleRight } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface PolicyConstraint {
  id: string;
  name: string;
  type: 'threshold' | 'allowlist' | 'blocklist';
  value: string | number | string[];
  description: string;
}

interface PolicyHistory {
  timestamp: string;
  action: string;
  details: string;
}

interface InvariantRule {
  id: string;
  name: string;
  severity: string;
  category?: string;
  description: string;
  enabled?: boolean;
}

export default function PolicyManagement({ theme }: { theme: 'light' | 'dark' }) {
  const [policies, setPolicies] = useState<PolicyConstraint[]>([]);
  const [history, setHistory] = useState<PolicyHistory[]>([]);
  const [invariants, setInvariants] = useState<InvariantRule[]>([]);
  const [invariantSearch, setInvariantSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [tagInputs, setTagInputs] = useState<Record<string, string>>({});

  const fetchPolicyData = async () => {
    setLoading(true);
    try {
      const policyRes = await fetch('/api/policy');
      const policyData = await policyRes.json();
      
      // Transform policy object to array for easier management
      const policyArray: PolicyConstraint[] = [
        { id: 'drift_threshold', name: 'Global Drift Threshold', type: 'threshold', value: policyData.driftThreshold, description: 'Critical threshold for CEK drift analysis.' },
        { id: 'allowed_actions', name: 'Allowed Actions', type: 'allowlist', value: policyData.allowedActions || [], description: 'List of actions permitted by the system.' },
        { id: 'blocked_behaviors', name: 'Blocked Behaviors', type: 'blocklist', value: policyData.blockedBehaviors || [], description: 'Behaviors that trigger immediate refusal.' }
      ];
      setPolicies(policyArray);

      const historyRes = await fetch('/api/policy/history');
      const historyData = await historyRes.json();
      setHistory(historyData);

      const invRes = await fetch('/api/invariants');
      const invData = await invRes.json();
      setInvariants(invData.map((inv: any) => ({
        ...inv,
        category: inv.category || 'General',
        enabled: true
      })));
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch policy data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPolicyData();
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);
    try {
      const policyUpdate = {
        driftThreshold: policies.find(p => p.id === 'drift_threshold')?.value,
        allowedActions: policies.find(p => p.id === 'allowed_actions')?.value as string[],
        blockedBehaviors: policies.find(p => p.id === 'blocked_behaviors')?.value as string[]
      };

      const res = await fetch('/api/policy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(policyUpdate)
      });

      if (res.ok) {
        setMessage({ type: 'success', text: 'Policy updated successfully.' });
        fetchPolicyData();
      } else {
        const errorData = await res.json();
        setMessage({ type: 'error', text: errorData.error || 'Failed to update policy.' });
      }
    } catch {
      setMessage({ type: 'error', text: 'An error occurred while saving.' });
    } finally {
      setSaving(false);
    }
  };

  const updatePolicyValue = (id: string, value: string | number | string[]) => {
    setPolicies(prev => prev.map(p => p.id === id ? { ...p, value } : p));
  };

  const addTag = (id: string) => {
    const tagValue = tagInputs[id]?.trim();
    if (!tagValue) return;

    const policy = policies.find(p => p.id === id);
    if (policy && Array.isArray(policy.value)) {
      if (!policy.value.includes(tagValue)) {
        updatePolicyValue(id, [...policy.value, tagValue]);
      }
      setTagInputs(prev => ({ ...prev, [id]: '' }));
    }
  };

  const removeTag = (id: string, tagToRemove: string) => {
    const policy = policies.find(p => p.id === id);
    if (policy && Array.isArray(policy.value)) {
      updatePolicyValue(id, policy.value.filter(t => t !== tagToRemove));
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>, id: string) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag(id);
    } else if (e.key === 'Backspace' && !tagInputs[id]) {
      const policy = policies.find(p => p.id === id);
      if (policy && Array.isArray(policy.value) && policy.value.length > 0) {
        removeTag(id, policy.value[policy.value.length - 1]);
      }
    }
  };

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({
      policies,
      invariants
    }, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "compliance-manifest.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleBulkToggle = (category: string, enable: boolean) => {
    setInvariants(prev => prev.map(inv => inv.category === category ? { ...inv, enabled: enable } : inv));
  };

  const toggleInvariant = (id: string, enable: boolean) => {
    setInvariants(prev => prev.map(inv => inv.id === id ? { ...inv, enabled: enable } : inv));
  };

  const categories = Array.from(new Set(invariants.map(inv => inv.category || 'General')));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className={cn(
          "p-6 border",
          theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
        )}>
          <div className="flex items-center justify-between mb-6 border-b pb-4 border-[#141414]/10 dark:border-[#E4E3E0]/10">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-500" />
              <h3 className="text-sm font-bold uppercase tracking-widest">Active Policy Constraints</h3>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={handleExport}
                className={cn(
                  "px-4 py-2 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-all",
                  theme === 'light' ? "bg-black/5 text-[#141414] hover:bg-black/10" : "bg-white/5 text-[#E4E3E0] hover:bg-white/10"
                )}
              >
                <Download className="w-3 h-3" />
                Export JSON
              </button>
              <button 
                onClick={handleSave}
                disabled={saving || loading}
                className={cn(
                  "px-4 py-2 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-all",
                  theme === 'light' ? "bg-[#141414] text-white" : "bg-[#E4E3E0] text-[#141414]",
                  (saving || loading) && "opacity-50 cursor-not-allowed"
                )}
              >
                <Save className="w-3 h-3" />
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>

          {message && (
            <div className={cn(
              "p-4 mb-6 flex items-center gap-3 text-[10px] uppercase font-bold border",
              message.type === 'success' ? "bg-green-50 text-green-700 border-green-700" : "bg-red-50 text-red-700 border-red-700"
            )}>
              {message.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              {message.text}
            </div>
          )}

          <div className="space-y-8">
            {policies.map(policy => (
              <div key={policy.id} className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] uppercase font-bold opacity-60 tracking-wider">{policy.name}</label>
                  <span className="text-[8px] uppercase font-mono opacity-40">{policy.type}</span>
                </div>
                <div className="space-y-1">
                  {policy.type === 'threshold' ? (
                    <input 
                      type="number" 
                      step="0.01"
                      value={policy.value as number}
                      onChange={(e) => updatePolicyValue(policy.id, parseFloat(e.target.value))}
                      className="w-full bg-black/5 dark:bg-white/5 border border-[#141414]/10 dark:border-white/10 p-3 text-xs font-mono focus:outline-none focus:border-blue-500"
                    />
                  ) : (
                    <div className={cn(
                      "w-full bg-black/5 dark:bg-white/5 border border-[#141414]/10 dark:border-white/10 p-2 text-xs font-mono focus-within:border-blue-500 min-h-[44px] flex flex-wrap gap-2 items-center",
                      policy.type === 'blocklist' && "border-red-500/30 focus-within:border-red-500"
                    )}>
                      {Array.isArray(policy.value) && policy.value.map((tag, i) => (
                        <span 
                          key={i} 
                          className={cn(
                            "flex items-center gap-1 px-2 py-1 text-[10px] font-bold uppercase border",
                            policy.type === 'allowlist' 
                              ? "bg-blue-500/10 text-blue-500 border-blue-500/20" 
                              : "bg-red-500/10 text-red-500 border-red-500/20"
                          )}
                        >
                          {tag}
                          <button 
                            onClick={() => removeTag(policy.id, tag)}
                            className="hover:opacity-50 transition-opacity"
                          >
                            <X className="w-2.5 h-2.5" />
                          </button>
                        </span>
                      ))}
                      <div className="flex-1 flex items-center min-w-[120px]">
                        <input 
                          type="text"
                          value={tagInputs[policy.id] || ''}
                          onChange={(e) => setTagInputs(prev => ({ ...prev, [policy.id]: e.target.value }))}
                          onKeyDown={(e) => handleKeyDown(e, policy.id)}
                          placeholder={`Add ${policy.type === 'allowlist' ? 'action' : 'behavior'}...`}
                          className="w-full bg-transparent border-none outline-none p-1 text-xs"
                        />
                        <button 
                          onClick={() => addTag(policy.id)}
                          className="p-1 opacity-40 hover:opacity-100 transition-opacity"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )}
                  <p className="text-[9px] opacity-40 italic">{policy.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className={cn(
          "p-6 border",
          theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
        )}>
          <div className="flex items-center gap-2 mb-6 border-b pb-4 border-[#141414]/10 dark:border-[#E4E3E0]/10">
            <History className="w-4 h-4 opacity-40" />
            <h3 className="text-[10px] uppercase font-bold opacity-40 tracking-widest">Policy Version History</h3>
          </div>
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
            {history.length > 0 ? history.slice().reverse().map((h, i) => (
              <div key={i} className="p-3 border-l-2 border-blue-500 bg-black/5 dark:bg-white/5 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-[8px] font-mono opacity-40">{new Date(h.timestamp).toLocaleString()}</span>
                  <span className="text-[8px] font-bold uppercase text-blue-500">{h.action}</span>
                </div>
                <p className="text-[9px] opacity-70 leading-tight">{h.details}</p>
              </div>
            )) : (
              <p className="text-[9px] uppercase font-bold opacity-20 text-center py-8">No history available</p>
            )}
          </div>
        </div>
        
        <div className={cn(
          "p-6 border mt-6",
          theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
        )}>
          <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#141414]/10 dark:border-[#E4E3E0]/10">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 opacity-40" />
              <h3 className="text-[10px] uppercase font-bold opacity-40 tracking-widest">Formal Invariant Rules</h3>
            </div>
          </div>

          <div className="mb-4 space-y-3">
            <input 
              type="text" 
              placeholder="Search by Name, Status (enabled/disabled), or Threat-level tag (severity)..."
              value={invariantSearch}
              onChange={(e) => setInvariantSearch(e.target.value)}
              className="w-full bg-black/5 dark:bg-white/5 border border-[#141414]/10 dark:border-white/10 p-2 text-[10px] uppercase font-mono focus:outline-none focus:border-blue-500"
            />
            
            {categories.length > 0 && (
              <div className="flex flex-wrap gap-2 items-center p-2 border border-black/5 dark:border-white/5 bg-black/5 dark:bg-white/5">
                <span className="text-[9px] uppercase font-bold opacity-50 mr-2">Bulk Controls:</span>
                {categories.map(cat => {
                  const categoryInvariants = invariants.filter(inv => inv.category === cat);
                  const allEnabled = categoryInvariants.every(inv => inv.enabled);
                  return (
                    <button
                      key={cat}
                      onClick={() => handleBulkToggle(cat, !allEnabled)}
                      className={cn(
                        "text-[9px] uppercase font-bold px-2 py-1 rounded flex items-center gap-1 transition-colors",
                        allEnabled 
                          ? "bg-blue-500/20 text-blue-600 dark:text-blue-400" 
                          : "bg-black/10 dark:bg-white/10 opacity-60"
                      )}
                    >
                      {allEnabled ? <ToggleRight className="w-3 h-3" /> : <ToggleLeft className="w-3 h-3" />}
                      {cat}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
            {invariants.filter(inv => {
              const term = invariantSearch.toLowerCase();
              const statusStr = inv.enabled ? 'enabled' : 'disabled';
              return inv.name.toLowerCase().includes(term) || 
                     inv.id.toLowerCase().includes(term) || 
                     inv.severity.toLowerCase().includes(term) ||
                     statusStr.includes(term) ||
                     (inv.category && inv.category.toLowerCase().includes(term));
            }).map((inv) => (
              <div key={inv.id} className={cn(
                "p-2 border transition-all",
                inv.enabled ? "border-black/10 dark:border-white/10 bg-black/5 dark:bg-white/5" : "border-black/5 dark:border-white/5 bg-transparent opacity-50"
              )}>
                <div className="flex justify-between items-center mb-1">
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => toggleInvariant(inv.id, !inv.enabled)}
                      className={cn(
                        "focus:outline-none",
                        inv.enabled ? "text-blue-500" : "text-gray-400"
                      )}
                    >
                      {inv.enabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                    </button>
                    <span className="text-[10px] font-bold font-mono">{inv.id}</span>
                  </div>
                  <div className="flex gap-2">
                    {inv.category && (
                      <span className="text-[8px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider bg-black/10 dark:bg-white/10 text-black/60 dark:text-white/60">
                        {inv.category}
                      </span>
                    )}
                    <span className={cn(
                      "text-[8px] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider",
                      inv.severity === 'CRITICAL' ? "bg-red-500 text-white" : 
                      inv.severity === 'HIGH' ? "bg-orange-500 text-white" : "bg-yellow-500 text-black"
                    )}>{inv.severity}</span>
                  </div>
                </div>
                <div className="text-[10px] font-bold mb-1 opacity-80">{inv.name}</div>
                <div className="text-[9px] opacity-60 leading-tight">{inv.description}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
