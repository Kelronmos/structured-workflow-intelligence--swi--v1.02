// src/components/ContractEnforcementPanel.tsx
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, ShieldAlert, Activity, Zap } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { ContractDiagnostic } from '@/src/swi/middleware/ValidationMiddleware';

export default function ContractEnforcementPanel() {
  const [diagnostic, setDiagnostic] = useState<ContractDiagnostic | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchDiagnostics = async () => {
    try {
      const res = await fetch('/api/v3/health');
      const data = await res.json();
      if (data.contract) setDiagnostic(data.contract);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    }
  };

  useEffect(() => {
    fetchDiagnostics();
    const interval = setInterval(fetchDiagnostics, 3000);
    return () => clearInterval(interval);
  }, []);

  const injectFault = async () => {
    setLoading(true);
    try {
      await fetch('/api/v3/adversarial/inject-fault', { method: 'POST' });
      await fetchDiagnostics();
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setTimeout(() => setLoading(false), 500);
    }
  };

  if (!diagnostic) return null;

  return (
    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
            <ShieldCheck className="w-5 h-5 text-blue-500" />
          </div>
          <div>
            <h3 className="text-xs font-black text-white uppercase tracking-widest">Protocol Guard</h3>
            <p className="text-[10px] text-white/40 font-mono">Zod Runtime Enforcement: {diagnostic.version}</p>
          </div>
        </div>
        <div className="flex gap-2">
           <button 
            onClick={injectFault}
            disabled={loading}
            className="flex items-center gap-2 px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 rounded-lg text-[8px] font-bold text-red-500 uppercase transition-all"
           >
             <Zap className={cn("w-3 h-3", loading && "animate-pulse")} />
             Inject Adversarial Fault
           </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-black/20 rounded-2xl p-4 border border-white/5 space-y-3">
          <span className="text-[8px] font-bold text-white/40 uppercase tracking-widest block">Reliability Index</span>
          <div className="flex items-end gap-2">
            <span className={cn(
              "text-3xl font-black font-mono leading-none",
              (diagnostic.reliabilityIndex || 0) > 0.8 ? "text-green-500" : (diagnostic.reliabilityIndex || 0) > 0.4 ? "text-yellow-500" : "text-red-500"
            )}>
              {((diagnostic.reliabilityIndex || 0) * 100).toFixed(1)}
            </span>
            <span className="text-[10px] text-white/20 mb-1">% SCORE</span>
          </div>
          <div className="h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${diagnostic.reliabilityIndex * 100}%` }}
              className={cn(
                "h-full transition-all duration-1000",
                diagnostic.reliabilityIndex > 0.8 ? "bg-green-500" : diagnostic.reliabilityIndex > 0.4 ? "bg-yellow-500" : "bg-red-500"
              )}
            />
          </div>
        </div>

        <div className="bg-black/20 rounded-2xl p-4 border border-white/5 space-y-3">
          <span className="text-[8px] font-bold text-white/40 uppercase tracking-widest block">Contract Violations</span>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-black font-mono leading-none text-white">
              {(diagnostic.violationCount || 0).toFixed(1)}
            </span>
            <span className="text-[10px] text-white/20 mb-1">SIGMA</span>
          </div>
          <div className="flex gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <div 
                key={i} 
                className={cn(
                  "h-1 flex-1 rounded-full",
                  i < (diagnostic.violationCount / 2) ? "bg-red-500/50" : "bg-white/5"
                )} 
              />
            ))}
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {diagnostic.lastFailure ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-red-500/5 border border-red-500/10 rounded-2xl p-4 space-y-2"
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-3 h-3 text-red-500" />
                <span className="text-[8px] font-bold text-red-500 uppercase">Recent Trap Caught</span>
              </div>
              <span className="text-[8px] font-mono text-white/20">{new Date(diagnostic.lastFailure.timestamp).toLocaleTimeString()}</span>
            </div>
            <p className="text-[10px] font-mono text-white/60 leading-relaxed italic">
              "Violation at {diagnostic.lastFailure.error}"
            </p>
            <div className="pt-2 border-t border-red-500/10">
              <span className="text-[8px] font-mono text-white/20 uppercase">Interpreted Payload:</span>
              <pre className="text-[7px] text-white/30 truncate">
                {JSON.stringify(diagnostic.lastFailure.payload)}
              </pre>
            </div>
          </motion.div>
        ) : (
          <div className="h-20 flex flex-col items-center justify-center border border-dashed border-white/5 rounded-2xl bg-black/5">
             <Activity className="w-4 h-4 text-white/10 animate-pulse" />
             <span className="text-[8px] font-bold text-white/10 uppercase mt-2">Nominal Baseline Execution</span>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
