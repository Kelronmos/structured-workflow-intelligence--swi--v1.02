
import { useState } from 'react';
import { Brain, Zap, TrendingUp, RefreshCw } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { ACE, ACEResult } from '../swi/ace';
import { Trace } from '../types';

export default function PolicyLearningView({ history }: { history: Trace[] }) {
  const [result, setResult] = useState<ACEResult | null>(null);
  const [loading, setLoading] = useState(false);

  const runTuning = () => {
    setLoading(true);
    setTimeout(() => {
      const res = ACE.tune(history);
      setResult(res);
      setLoading(false);
    }, 1000);
  };

  const weights = ACE.getWeights();

  return (
    <div className="p-6 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-6">
      <div className="flex justify-between items-start">
        <div className="space-y-1">
          <h3 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2">
            <Brain className="w-4 h-4 text-purple-500" />
            ACE: Policy Learning System
          </h3>
          <p className="text-[10px] opacity-40 uppercase">Auto-tuning weights from historical drift</p>
        </div>
        <button 
          onClick={runTuning}
          disabled={loading}
          className="p-2 border border-[#141414]/10 hover:bg-black/5 dark:hover:bg-white/5 transition-all"
        >
          {loading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
         {[
           { label: 'Ethics (α)', val: weights.alpha, color: 'bg-blue-500' },
           { label: 'Env (β)', val: weights.beta, color: 'bg-green-500' },
           { label: 'Knowledge (γ)', val: weights.gamma, color: 'bg-orange-500' },
         ].map(w => (
           <div key={w.label} className="space-y-2">
             <div className="flex justify-between text-[8px] font-bold uppercase opacity-60">
               <span>{w.label}</span>
               <span>{(w.val * 100).toFixed(1)}%</span>
             </div>
             <div className="h-1 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
               <div className={cn("h-full", w.color)} style={{ width: `${w.val * 100}%` }} />
             </div>
           </div>
         ))}
      </div>

      {result && (
        <div className="p-3 bg-purple-500/5 border border-purple-500/20 space-y-3 animate-in fade-in slide-in-from-top-2">
           <div className="flex items-center gap-2 text-purple-500">
             <TrendingUp className="w-3 h-3" />
             <span className="text-[9px] font-bold uppercase">Learning Output</span>
           </div>
           <div className="grid grid-cols-1 gap-1 text-[8px] font-mono opacity-60">
              <p>Recommendation: {result.recommendation}</p>
              <p>Delta Beta: {result.tuning.beta.delta.toFixed(4)}</p>
           </div>
           <p className="text-[9px] italic opacity-40 leading-tight">
             "Engine has detected recurring Environmental instability. Increasing protection weights for Layer 2."
           </p>
        </div>
      )}
    </div>
  );
}
