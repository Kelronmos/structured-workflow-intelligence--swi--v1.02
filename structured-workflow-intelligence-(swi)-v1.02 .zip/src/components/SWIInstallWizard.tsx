import React, { useState } from 'react';
import { HardwareVerificationModule } from './HardwareVerificationModule';
import { SWIBootLoader } from './SWIBootLoader';
import { SystemReady } from './SystemReady';
import { SWIProgress } from './common/SWIProgress';
import { Shield, CheckSquare, Square, ChevronRight, Server, Cloud, Cpu, Lock } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const SWIInstallWizard: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
    const [step, setStep] = useState(1);
    
    // Step 2 State
    const [agreed, setAgreed] = useState({ eula: false, data: false, ethics: false });
    const allAgreed = agreed.eula && agreed.data && agreed.ethics;

    // Step 3 state
    const [target, setTarget] = useState<'cloud' | 'onprem' | 'edge' | null>(null);

    // Step 6 internal state
    const [provisionProgress, setProvisionProgress] = useState(0);

    const nextStep = () => setStep(s => Math.min(s + 1, 8));
    const prevStep = () => setStep(s => Math.max(s - 1, 1));

    const renderSplash = () => (
        <div className="flex flex-col items-center justify-center text-center space-y-8 animate-in fade-in duration-500">
            <div className="relative">
                <div className="absolute inset-0 bg-blue-600/20 blur-3xl rounded-full" />
                <Shield className="w-24 h-24 text-blue-500 relative" />
            </div>
            <h1 className="text-4xl font-serif italic text-white">Structured Workflow Intelligence (SWI) V1.01</h1>
            <p className="text-white/60 max-w-lg leading-relaxed">
                Welcome to the deployment wizard for the Secure World Initiative (SWI) core architecture. This process will provision trust anchors, verify hardware integrity, and establish the governance matrix.
            </p>
            <button onClick={nextStep} className="mt-8 px-8 py-3 bg-white text-black font-semibold rounded-full hover:bg-white/90 transition-colors">
                Begin Installation
            </button>
        </div>
    );

    const renderAgreements = () => (
        <div className="w-full max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
            <div>
                <h2 className="text-2xl font-serif italic text-white mb-2">Legal & Ethical Sovereignty</h2>
                <p className="text-white/60">Please review and accept the mandatory governance agreements.</p>
            </div>

            <div className="space-y-4">
                {[
                    { key: 'eula', label: 'End User License Agreement', desc: 'Standard usage rights and limitations.' },
                    { key: 'data', label: 'Data Processing Addendum', desc: 'Handling of telemetry and continuous trace logs.' },
                    { key: 'ethics', label: 'Human Safety Charter', desc: 'Override protocols and life-critical system directives.' },
                ].map(({ key, label, desc }) => (
                    <div 
                      key={key} 
                      className="flex items-start gap-4 p-4 rounded-xl border border-white/10 bg-white/5 cursor-pointer hover:bg-white/10 transition-colors"
                      onClick={() => setAgreed(p => ({ ...p, [key]: !p[key as keyof typeof agreed] }))}
                    >
                        <div className="mt-1">
                            {agreed[key as keyof typeof agreed] ? <CheckSquare className="text-blue-400" /> : <Square className="text-white/40" />}
                        </div>
                        <div>
                            <h4 className="text-white font-medium">{label}</h4>
                            <p className="text-sm text-white/50">{desc}</p>
                        </div>
                    </div>
                ))}
            </div>

            <div className="flex justify-between pt-6 border-t border-white/10">
                <button onClick={prevStep} className="px-6 py-2 text-white/60 hover:text-white transition-colors">Back</button>
                <button 
                  onClick={nextStep} 
                  disabled={!allAgreed}
                  className="px-6 py-2 bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-500 text-white font-medium rounded-lg transition-colors flex items-center gap-2"
                >
                    Continue <ChevronRight className="w-4 h-4" />
                </button>
            </div>
        </div>
    );

    const renderTargetSelection = () => (
        <div className="w-full max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
             <div>
                <h2 className="text-2xl font-serif italic text-white mb-2">Deployment Environment</h2>
                <p className="text-white/60">Select the infrastructure topology for the core stack.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                    { id: 'cloud', icon: <Cloud className="w-8 h-8" />, label: 'Cloud Native', desc: 'Distributed multi-region deployment' },
                    { id: 'onprem', icon: <Server className="w-8 h-8" />, label: 'On-Premises', desc: 'Air-gapped secure facility' },
                    { id: 'edge', icon: <Cpu className="w-8 h-8" />, label: 'Edge Node', desc: 'Resource-constrained remote unit' }
                ].map(({ id, icon, label, desc }) => (
                    <div 
                        key={id}
                        className={cn(
                            "p-6 rounded-xl border cursor-pointer transition-all flex flex-col items-center text-center gap-4",
                            target === id ? "border-blue-500 bg-blue-500/10 shadow-[0_0_15px_rgba(59,130,246,0.2)]" : "border-white/10 bg-white/5 hover:border-white/30"
                        )}
                        onClick={() => setTarget(id as any)}
                    >
                        <div className={target === id ? "text-blue-400" : "text-white/60"}>{icon}</div>
                        <div>
                            <h4 className="text-white font-medium">{label}</h4>
                            <p className="text-xs text-white/50 mt-2">{desc}</p>
                        </div>
                    </div>
                ))}
            </div>

             <div className="flex justify-between pt-6 border-t border-white/10">
                <button onClick={prevStep} className="px-6 py-2 text-white/60 hover:text-white transition-colors">Back</button>
                <button 
                  onClick={nextStep} 
                  disabled={!target}
                  className="px-6 py-2 bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-blue-500 text-white font-medium rounded-lg transition-colors flex items-center gap-2"
                >
                    Continue <ChevronRight className="w-4 h-4" />
                </button>
            </div>
        </div>
    );

    const renderHardware = () => (
        <div className="w-full animate-in fade-in duration-500">
            <HardwareVerificationModule onComplete={() => setTimeout(nextStep, 1000)} />
        </div>
    );

    const RenderProvisioning = () => {
        // Trigger simulated provisioning on mount
        React.useEffect(() => {
            let p = 0;
            const i = setInterval(() => {
                p += Math.random() * 4;
                if(p >= 100) {
                    p = 100;
                    clearInterval(i);
                    setTimeout(nextStep, 1000);
                }
                setProvisionProgress(p);
            }, 100);
            return () => clearInterval(i);
        }, []);

        return (
            <div className="w-full max-w-xl mx-auto space-y-12 animate-in fade-in duration-500 py-12">
                 <div className="text-center space-y-4">
                    <Lock className="w-12 h-12 text-blue-400 mx-auto animate-pulse" />
                    <h2 className="text-xl font-serif italic text-white">System Provisioning</h2>
                    <p className="text-white/50 font-mono text-sm">Compiling Zero-Knowledge circuits and initializing anchors...</p>
                 </div>
                 
                 <div className="space-y-2">
                     <div className="flex justify-between text-xs font-mono text-white/50 font-medium">
                         <span>Generating Keys...</span>
                         <span>{Math.floor(provisionProgress)}%</span>
                     </div>
                     <SWIProgress percent={provisionProgress} />
                 </div>
            </div>
        );
    }

    // Step Map
    let content;
    switch(step) {
        case 1: content = renderSplash(); break;
        case 2: content = renderAgreements(); break;
        case 3: content = renderTargetSelection(); break;
        case 4: content = renderHardware(); break;
        case 5: content = <RenderProvisioning />; break;
        case 6: return <SWIBootLoader onComplete={nextStep} />; 
        case 7: return <SystemReady onOpenDashboard={onComplete} onOpenConsole={onComplete} />;
        default: content = renderSplash(); break;
    }

    return (
        <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-center p-6 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-900/10 via-[#0a0a0a] to-[#0a0a0a]">
            {/* Top progress indicator - only show during actual wizard steps 1-5 */}
            {step > 1 && step < 6 && (
                <div className="fixed top-0 left-0 right-0 h-1 bg-white/5">
                    <div 
                      className="h-full bg-blue-500 transition-all duration-500 ease-out" 
                      style={{ width: `${(step / 5) * 100}%` }} 
                    />
                </div>
            )}
            
            <div className="w-full container mx-auto">
                {content}
            </div>
        </div>
    );
};
