import React, { useState, useEffect } from "react";
import {
  Network,
  Fingerprint,
  FileDigit,
  Database,
  Building,
  Scale,
  Activity,
  CheckCircle2,
  Lock,
  ArrowRight,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface WitnessNode {
  id: string;
  name: string;
  icon: React.ElementType;
  role: string;
  status: "WAITING" | "VERIFYING" | "SIGNED" | "REJECTED";
  signature?: string;
}

export default function IndependentWitnessNetworkView() {
  const [phase, setPhase] = useState<"IDLE" | "HASHING" | "BROADCASTING" | "CONSENSUS_REACHED">("IDLE");
  const [stateHash, setStateHash] = useState("");
  const [witnesses, setWitnesses] = useState<WitnessNode[]>([
    { id: "W1", name: "Hardware Org Auditor", icon: Database, role: "Validates TPM & Runtime Measurement", status: "WAITING" },
    { id: "W2", name: "Legal/Governance Node", icon: Scale, role: "Validates Policy & Human Authorization", status: "WAITING" },
    { id: "W3", name: "Civic Transparency Ledger", icon: Building, role: "Appends to Public Immutable Log", status: "WAITING" },
  ]);

  const startVerificationCycle = () => {
    setPhase("HASHING");
    setWitnesses(prev => prev.map(w => ({ ...w, status: "WAITING", signature: undefined })));
    
    // Simulate hashing
    setTimeout(() => {
      setStateHash("0x" + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join(''));
      setPhase("BROADCASTING");
    }, 1500);
  };

  useEffect(() => {
    if (phase === "BROADCASTING") {
      // Staggered signing
      witnesses.forEach((w, idx) => {
        setTimeout(() => {
          setWitnesses(curr => curr.map(node => node.id === w.id ? { ...node, status: "VERIFYING" } : node));
          
          setTimeout(() => {
            setWitnesses(curr => curr.map(node => node.id === w.id ? { 
              ...node, 
              status: "SIGNED", 
              signature: "sig_" + Math.random().toString(36).substring(2, 10) 
            } : node));
          }, 1000 + (Math.random() * 1500));
        }, idx * 800);
      });
    }
  }, [phase]);

  useEffect(() => {
    if (phase === "BROADCASTING" && witnesses.every(w => w.status === "SIGNED")) {
      setTimeout(() => setPhase("CONSENSUS_REACHED"), 500);
    }
  }, [witnesses, phase]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-2 relative z-10 w-full">
          <div className="flex items-center gap-3">
            <Network className="w-5 h-5 text-blue-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Independent Witness Network
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-80 max-w-2xl text-blue-100/70">
            Operationalizing the transition from self-declared architecture to a verifiable integrity system. SWI does not trust itself. It broadcasts its state hash to external witnessing nodes.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* SWI Core Broadcaster */}
        <div className="bg-[#141414] border border-white/10 p-5 flex flex-col items-center justify-center min-h-[300px] space-y-6 relative">
           
           <div className="text-center space-y-2 relative z-10">
              <div className={cn(
                "w-16 h-16 mx-auto rounded-full border-2 flex items-center justify-center transition-all duration-500",
                phase === "IDLE" ? "border-white/20" :
                phase === "HASHING" ? "border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.3)] animate-pulse" :
                phase === "BROADCASTING" ? "border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.4)]" :
                "border-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.4)]"
              )}>
                 <Fingerprint className={cn(
                   "w-8 h-8",
                   phase === "IDLE" ? "text-white/20" :
                   phase === "HASHING" ? "text-amber-500" :
                   phase === "BROADCASTING" ? "text-blue-500" :
                   "text-emerald-500"
                 )} />
              </div>
              <h3 className="text-[11px] font-bold uppercase tracking-widest text-[#E4E3E0]">
                SWI Core State
              </h3>
              <p className="text-[9px] font-mono text-white/40">
                State<sub>t</sub> || Policy<sub>t</sub> || Runtime<sub>t</sub>
              </p>
           </div>

           <div className="bg-black/50 border border-white/10 p-4 w-full max-w-sm rounded-sm">
              <div className="flex justify-between text-[9px] font-mono text-white/50 mb-2 uppercase tracking-widest">
                <span>Payload Hash</span>
                {phase !== "IDLE" && <Activity className="w-3 h-3 text-amber-500 animate-pulse" />}
              </div>
              <div className="text-[10px] font-mono text-amber-400 break-all min-h-[20px]">
                {phase === "IDLE" ? "Awaiting verification trigger..." :
                 phase === "HASHING" ? "Calculating deterministic cryptographic hash..." :
                 stateHash}
              </div>
           </div>

           <button
             onClick={startVerificationCycle}
             disabled={phase !== "IDLE" && phase !== "CONSENSUS_REACHED"}
             className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[10px] uppercase font-bold px-6 py-2 transition-all disabled:opacity-50"
           >
             {phase === "IDLE" || phase === "CONSENSUS_REACHED" ? "Broadcast State for Witnessing" : "Verification in Progress"}
           </button>
        </div>

        {/* Independent Witness Nodes */}
        <div className="space-y-4">
           {witnesses.map(node => (
             <div 
               key={node.id}
               className={cn(
                 "bg-[#141414] border p-4 transition-all duration-300 relative overflow-hidden",
                 node.status === "WAITING" ? "border-white/10" :
                 node.status === "VERIFYING" ? "border-amber-500/50 bg-amber-500/5" :
                 "border-emerald-500/50 bg-emerald-500/5"
               )}
             >
               {node.status === "VERIFYING" && (
                 <div className="absolute top-0 right-0 bottom-0 w-32 bg-gradient-to-l from-amber-500/10 to-transparent animate-pulse"></div>
               )}
               
               <div className="flex items-center justify-between mb-3 relative z-10">
                 <div className="flex items-center gap-2 text-white">
                   <node.icon className={cn(
                     "w-4 h-4",
                     node.status === "WAITING" ? "text-white/40" :
                     node.status === "VERIFYING" ? "text-amber-400" :
                     "text-emerald-400"
                   )} />
                   <div>
                     <div className="text-[10px] font-bold uppercase tracking-widest leading-none">{node.name}</div>
                     <div className="text-[8px] font-mono text-white/40 mt-1">{node.role}</div>
                   </div>
                 </div>
                 <div className={cn(
                   "text-[9px] font-bold uppercase px-2 py-0.5 rounded-sm font-mono border",
                   node.status === "WAITING" ? "border-white/10 text-white/30" :
                   node.status === "VERIFYING" ? "border-amber-500 text-amber-500 bg-amber-500/10 animate-pulse" :
                   "border-emerald-500 text-emerald-500 bg-emerald-500/10"
                 )}>
                   {node.status}
                 </div>
               </div>

               <div className="bg-black/40 border border-white/5 p-2 flex items-center justify-between text-[9px] font-mono min-h-[36px]">
                  <span className="text-white/30">Signature:</span>
                  {node.status === "WAITING" && <span className="text-white/20">-</span>}
                  {node.status === "VERIFYING" && <span className="text-amber-400/50">Analyzing...</span>}
                  {node.status === "SIGNED" && (
                     <div className="flex items-center gap-1.5 text-emerald-400">
                        <Lock className="w-3 h-3" />
                        {node.signature}
                     </div>
                  )}
               </div>
             </div>
           ))}
        </div>

      </div>

      {/* Trust Formula Enforcement */}
      {phase === "CONSENSUS_REACHED" && (
        <div className="bg-emerald-950/20 border border-emerald-500/30 p-6 flex flex-col items-center justify-center animate-in fade-in zoom-in duration-500">
           <div className="flex items-center gap-3 text-emerald-400 mb-3">
             <CheckCircle2 className="w-6 h-6" />
             <h3 className="text-sm font-black uppercase tracking-widest">
               Verifiable Integrity Confirmed
             </h3>
           </div>
           <div className="text-[10px] font-mono text-emerald-200/70 text-center max-w-lg mb-4 space-y-1">
             <div className="text-emerald-400 font-bold mb-2 break-all">Consensus ≥ Threshold (3/3 Signatures Acquired)</div>
             <div>The runtime state is mathematically bound to independent witnesses.</div>
             <div>Execution history cannot be altered without breaking the cryptographic chain.</div>
           </div>
           
           <div className="bg-black/50 border border-emerald-500/20 p-3 flex items-center gap-4 text-[9px] font-mono overflow-x-auto w-full max-w-2xl">
              <div className="text-white/40 shrink-0">Consensus Graph:</div>
              <div className="flex items-center gap-2 w-full">
                <span className="text-blue-400 truncate">{stateHash.substring(0,10)}...</span>
                <ArrowRight className="w-3 h-3 text-white/20 shrink-0" />
                <span className="text-emerald-500 font-bold">W1</span> + <span className="text-emerald-500 font-bold">W2</span> + <span className="text-emerald-500 font-bold">W3</span>
                <ArrowRight className="w-3 h-3 text-white/20 shrink-0" />
                <span className="text-white bg-emerald-600 px-2 py-0.5 rounded-sm">STATE APPENDED</span>
              </div>
           </div>
        </div>
      )}

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-white/10 mt-6">
        <ProofArtifacts
          id="witness-consensus"
          title="Multi-Party Validator Consensus Log"
          data={{
            phase,
            targetHash: stateHash || "NULL",
            signatures: witnesses.map(w => w.signature).filter(Boolean).length,
            adversarialSurvivability: "Verified"
          }}
          variant="always-dark"
        />
      </div>
    </div>
  );
}
