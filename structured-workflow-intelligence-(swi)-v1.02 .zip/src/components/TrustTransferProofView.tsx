import React from "react";
import {
  ShieldCheck,
  Link,
  Cpu,
  Users,
  AlertOctagon,
  ArrowRight,
  Calculator,
  ListOrdered,
  FileCheck2,
  PackageCheck,
  RefreshCw
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function TrustTransferProofView() {
  const proofSurfaces = [
    {
      title: "1. BUILD PROOF",
      icon: PackageCheck,
      details: "Can another party reproduce the same binaries from source?",
      requirements: [
        "Deterministic builds",
        "Signed SBOMs",
        "Dependency locking",
        "Reproducible containers",
        "Hash reproducibility",
      ],
      concept: "Hash(Build_A) = Hash(Build_B) // If false, integrity collapses"
    },
    {
      title: "2. RUNTIME PROOF",
      icon: Cpu,
      details: "Can the system prove what is executing right now?",
      requirements: [
        "TPM measured boot",
        "Secure Boot",
        "Enclave attestation",
        "Kernel measurement",
        "Memory integrity checks",
        "Signed runtime manifests"
      ],
      concept: "Report must match actual executing software"
    },
    {
      title: "3. CONSENSUS PROOF",
      icon: Users,
      details: "Can malicious or compromised nodes alter history?",
      requirements: [
        "Byzantine fault tolerance",
        "Quorum signing",
        "Validator diversity",
        "Replay protection",
        "Rollback prevention",
        "Append-only audit chains"
      ],
      concept: "Mathematical limit on trust concentration"
    },
    {
      title: "4. GOVERNANCE PROOF",
      icon: FileCheck2,
      details: "Can rules be bypassed by operators?",
      requirements: [
        "Policy immutability",
        "Approval thresholds",
        "Escalation chains",
        "Human review locks",
        "Emergency halt protocols",
        "Separation of duties"
      ],
      concept: "Governance must be enforced, not just UI decoration"
    },
    {
      title: "5. HUMAN SAFETY PROOF",
      icon: AlertOctagon,
      details: "Can the system demonstrate bounded behavior under stress?",
      requirements: [
        "Adversarial testing",
        "Red-team reports",
        "Failure simulations",
        "Rollback drills",
        "Safe degradation",
        "Containment guarantees"
      ],
      concept: "Safety is proven by failure handling and bounded damage"
    }
  ];

  const transitions = [
    { current: "Self-declared hashes", required: "Externally attestable signatures" },
    { current: "Simulated consensus", required: "Multi-party validator consensus" },
    { current: "Internal logs", required: "Independent append-only audit logs" },
    { current: "Claimed runtime", required: "Measured runtime attestation" },
    { current: "Conceptual governance", required: "Enforced governance invariants" },
    { current: "Module labels", required: "Cryptographically bound policy execution" },
    { current: "Internal timestamps", required: "Trusted timestamp authority" },
    { current: "Replay capability", required: "Deterministic replay reproducibility" },
  ];

  const roadmap = [
    "Local deterministic runtime",
    "Signed manifests",
    "External timestamping",
    "Multi-node attestations",
    "Hardware-rooted trust",
    "Replay determinism",
    "Independent auditors",
    "Formal invariant verification",
    "Adversarial simulation environments",
    "Legal/governance review boards"
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute -right-20 -top-20 w-64 h-64 bg-emerald-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full">
          <div className="flex items-center gap-3">
            <Link className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Trust Transfer & Verifiable Integrity
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-80 max-w-3xl text-emerald-100/70 border-l-2 border-emerald-500/50 pl-3">
            Transitioning SWI from {"\""}a self-described architecture{"\""} into {"\""}a verifiable integrity system.{"\""}
            <br/><br/>
            The missing layer is not "more modules." It is independent witness systems, reproducibility, and adversarial survivability.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* State Transition Table */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2 text-cyan-400 mb-3">
            <RefreshCw className="w-4 h-4" />
            <h3 className="text-[10px] font-bold uppercase tracking-widest">
              The Critical Transition
            </h3>
          </div>
          <div className="grid grid-cols-[1fr_auto_1fr] gap-x-3 gap-y-2 text-[9px] font-mono">
            <div className="text-white/40 font-bold uppercase border-b border-white/10 pb-1">Current State</div>
            <div></div>
            <div className="text-cyan-400 font-bold uppercase border-b border-white/10 pb-1">Required State</div>
            
            {transitions.map((t, i) => (
               <React.Fragment key={i}>
                  <div className="text-white/50 bg-white/5 p-1.5 flex items-center">{t.current}</div>
                  <div className="text-white/20 flex items-center justify-center"><ArrowRight className="w-3 h-3" /></div>
                  <div className="text-cyan-300/80 bg-cyan-950/30 p-1.5 flex items-center border border-cyan-500/20">{t.required}</div>
               </React.Fragment>
            ))}
          </div>
        </div>

        {/* Math Models */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4 flex flex-col justify-between">
           <div>
              <div className="flex items-center gap-2 text-purple-400 mb-3">
                <Calculator className="w-4 h-4" />
                <h3 className="text-[10px] font-bold uppercase tracking-widest">
                  Mathematical Trust-Chain
                </h3>
              </div>
              <div className="space-y-4">
                 <div className="bg-black/50 border border-white/5 p-4 rounded-sm">
                    <div className="text-white/40 text-[9px] uppercase tracking-widest mb-2">Attestation Formula</div>
                    <div className="font-mono text-[11px] text-purple-300">
                      Attestation = Sign<sub className="text-[8px]">Validator</sub>(Hash(State<sub className="text-[8px]">t</sub> || Policy<sub className="text-[8px]">t</sub> || Runtime<sub className="text-[8px]">t</sub>))
                    </div>
                 </div>
                 
                 <div className="bg-black/50 border border-white/5 p-4 rounded-sm">
                    <div className="text-white/40 text-[9px] uppercase tracking-widest mb-2">Quorum Verification</div>
                    <div className="font-mono text-[11px] text-purple-300 flex items-center gap-2">
                       Consensus = <span className="text-xl">∑</span> ValidSignature<sub className="text-[8px]">i</sub> &ge; Threshold
                    </div>
                 </div>
              </div>
           </div>
           
           <div className="mt-4 p-3 bg-white/5 border border-white/10 text-[9px] font-mono text-white/50 italic border-l-4 border-l-purple-500/50">
             "A layered governance, observability, safety, and integrity orchestration framework with cryptographic traceability concepts, audit-chain structures, and modular policy enforcement."
           </div>
        </div>

      </div>

      {/* Proof Surfaces */}
      <div className="bg-[#141414] border border-white/10 p-5">
         <div className="flex items-center gap-2 text-amber-400 mb-6">
            <ShieldCheck className="w-4 h-4" />
            <h3 className="text-[11px] font-bold uppercase tracking-widest">
              The 5 Proof Surfaces
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
             {proofSurfaces.map((surface, idx) => (
                <div key={idx} className="bg-black/40 border border-white/5 p-4 flex flex-col">
                   <div className="flex items-center gap-2 text-amber-500 mb-2">
                      <surface.icon className="w-4 h-4" />
                      <span className="text-[10px] font-bold">{surface.title}</span>
                   </div>
                   <div className="text-[9px] font-mono text-white/70 italic mb-4 border-b border-white/5 pb-2">
                      {surface.details}
                   </div>
                   <ul className="space-y-1.5 text-[8px] font-mono text-white/50 mb-4 flex-1">
                      {surface.requirements.map((req, i) => (
                         <li key={i} className="flex items-start gap-1">
                            <span className="text-amber-500/50 mt-0.5">•</span> {req}
                         </li>
                      ))}
                   </ul>
                   <div className="text-[8px] font-mono text-amber-200/50 bg-amber-950/20 p-2 rounded-sm border border-amber-500/10">
                      {surface.concept}
                   </div>
                </div>
             ))}
          </div>
      </div>

      {/* Hardened Roadmap */}
      <div className="bg-[#141414] border border-white/10 p-5">
         <div className="flex items-center gap-2 text-emerald-400 mb-4">
            <ListOrdered className="w-4 h-4" />
            <h3 className="text-[11px] font-bold uppercase tracking-widest">
              Hardened SWI Roadmap
            </h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
             {roadmap.map((step, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-black/40 border border-white/5 p-2">
                   <div className="text-[10px] font-black text-emerald-500/50 w-4">{idx + 1}.</div>
                   <div className="text-[9px] font-mono text-white/70">{step}</div>
                </div>
             ))}
          </div>
      </div>

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-white/10 mt-6 overflow-x-auto">
        <ProofArtifacts
          id="trust-transfer"
          title="Verifiable Orchestration Substrate Readiness"
          data={{
            phase: "Transition to Verifiable Integrity",
            proofSurfacesActive: "0/5",
            roadmapStage: "1. Local deterministic runtime (approaching)",
            attestationModel: "Sign_v(Hash(State || Policy || Runtime))"
          }}
          variant="always-dark"
        />
      </div>

    </div>
  );
}
