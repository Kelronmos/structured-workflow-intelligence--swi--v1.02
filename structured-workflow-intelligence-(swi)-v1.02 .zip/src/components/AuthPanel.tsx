import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { auth } from '../firebase';
import { Lock, Mail, Key, ShieldCheck, LogOut } from 'lucide-react';
import { useAuthState } from 'react-firebase-hooks/auth';

export default function AuthPanel() {
  const [user, loading, error] = useAuthState(auth);
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      setAuthError(err.message || 'Authentication failed');
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  if (loading) {
    return <div className="p-4 text-xs font-mono text-gray-500">Checking authentication state...</div>;
  }

  if (user) {
    return (
      <div className="flex items-center gap-4 bg-[#111] p-3 rounded border border-[#333] shadow-md">
        <div className="p-2 bg-emerald-500/10 rounded-full border border-emerald-500/30">
          <ShieldCheck className="w-5 h-5 text-emerald-500" />
        </div>
        <div className="flex flex-col flex-1">
          <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-widest">Authenticated Identity</span>
          <span className="text-xs text-gray-300 font-mono truncate">{user.email}</span>
        </div>
        <button 
          onClick={handleLogout}
          className="p-2 hover:bg-red-500/10 rounded text-gray-500 hover:text-red-500 transition-colors"
          title="Sign Out"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="bg-[#111] p-4 rounded border border-[#333] shadow-lg max-w-sm w-full font-mono">
      <div className="flex items-center gap-2 mb-4 text-blue-400 border-b border-[#333] pb-2">
        <Lock className="w-4 h-4" />
        <h3 className="text-sm font-bold uppercase tracking-wider">{isLogin ? 'Identity Gateway' : 'Register New Identity'}</h3>
      </div>
      
      {authError && (
        <div className="mb-4 p-2 bg-red-500/10 border border-red-500/30 text-red-400 text-[10px] uppercase font-bold rounded">
          {authError}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-[10px] text-gray-400 uppercase tracking-widest mb-1">Email Coordinates</label>
          <div className="relative">
            <Mail className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
            <input 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#333] text-white rounded p-2 pl-8 text-xs focus:outline-none focus:border-blue-500 transition-colors"
              placeholder="operator@swi-network.local"
              required
            />
          </div>
        </div>
        <div>
           <label className="block text-[10px] text-gray-400 uppercase tracking-widest mb-1">Cryptographic Secret</label>
           <div className="relative">
            <Key className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-gray-500" />
            <input 
              type="password" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-[#333] text-white rounded p-2 pl-8 text-xs focus:outline-none focus:border-blue-500 transition-colors"
              placeholder="••••••••••"
              required
            />
          </div>
        </div>
        <button 
          type="submit" 
          className="w-full bg-blue-600 hover:bg-blue-500 text-white p-2 rounded text-xs font-bold uppercase tracking-widest transition-colors"
        >
          {isLogin ? 'Provide Credentials' : 'Mint Identity'}
        </button>
      </form>
      <div className="mt-4 pt-4 border-t border-[#333] text-center">
        <button 
          onClick={() => setIsLogin(!isLogin)}
          className="text-[10px] text-gray-500 hover:text-blue-400 transition-colors uppercase tracking-widest"
        >
          {isLogin ? 'Request New Identity Key' : 'Switch to Existing Key'}
        </button>
      </div>
    </div>
  );
}
