import { useState, useMemo } from 'react';
import { cn } from '@/src/lib/utils';
import { CheckCircle2, XCircle, AlertTriangle, FileText, Download, RefreshCw, Search } from 'lucide-react';
import { Trace } from '../types';

export default function ScenarioMatrix({ 
  results, 
  reportPath,
  onGenerateReport
}: { 
  results: Trace[], 
  reportPath?: string | null,
  onGenerateReport?: () => void
}) {
  const [filterOutcome, setFilterOutcome] = useState<'ALL' | 'ALLOW' | 'REFUSE'>('ALL');
  const [minDrift, setMinDrift] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredResults = useMemo(() => {
    return results.filter(r => {
      const outcomeMatch = filterOutcome === 'ALL' || r.decision === filterOutcome;
      const driftMatch = (r.drift?.score || 0) >= minDrift;
      const searchMatch = searchQuery === '' || 
        r.scenario?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.artifactId?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.violation_type?.toLowerCase().includes(searchQuery.toLowerCase());
      return outcomeMatch && driftMatch && searchMatch;
    });
  }, [results, filterOutcome, minDrift, searchQuery]);

  const downloadArtifact = (artifact: Trace) => {
    const blob = new Blob([JSON.stringify(artifact, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${artifact.artifactId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className={cn(
        "flex flex-col md:flex-row md:items-center justify-between border-b pb-4 gap-4",
        "border-[#141414] dark:border-[#E4E3E0]/20"
      )}>
        <div className="space-y-1">
          <h2 className="text-sm uppercase font-bold tracking-tighter">Multi-Scenario Proof Matrix</h2>
          <p className="text-[10px] uppercase opacity-40">Batch Execution Results ({filteredResults.length} / {results.length})</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2 opacity-40" />
            <input 
              type="text"
              placeholder="SEARCH SCENARIOS..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-7 pr-2 py-1 text-[9px] uppercase font-bold border border-[#141414] dark:border-[#E4E3E0]/20 bg-transparent focus:outline-none w-40"
            />
          </div>

          {/* Outcome Filter */}
          <div className="flex border border-[#141414] dark:border-[#E4E3E0]/20 p-0.5">
            {['ALL', 'ALLOW', 'REFUSE'].map((o) => (
              <button
                key={o}
                onClick={() => setFilterOutcome(o as 'ALL' | 'ALLOW' | 'REFUSE')}
                className={cn(
                  "px-2 py-0.5 text-[8px] uppercase font-bold transition-all",
                  filterOutcome === o 
                    ? "bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414]" 
                    : "opacity-40 hover:opacity-100"
                )}
              >
                {o}
              </button>
            ))}
          </div>

          {/* Drift Filter */}
          <div className="flex items-center gap-2 border border-[#141414] dark:border-[#E4E3E0]/20 px-2 py-1">
            <span className="text-[8px] uppercase font-bold opacity-40">Min Drift:</span>
            <input 
              type="range" min="0" max="1.5" step="0.1"
              value={minDrift}
              onChange={(e) => setMinDrift(parseFloat(e.target.value))}
              className="w-16 h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
            />
            <span className="text-[8px] font-mono w-6">{minDrift.toFixed(1)}</span>
          </div>

          {reportPath ? (
            <a 
              href={reportPath}
              target="_blank"
              rel="noopener noreferrer"
              className={cn(
                "flex items-center gap-2 px-3 py-1 text-[9px] font-bold uppercase border transition-colors",
                "border-yellow-600 text-yellow-700 hover:bg-yellow-50 dark:border-yellow-500/50 dark:text-yellow-500 dark:hover:bg-yellow-500/10"
              )}
            >
              <FileText className="w-3 h-3" />
              Download Executive Report
            </a>
          ) : results.length > 0 && onGenerateReport && (
            <button 
              onClick={onGenerateReport}
              className={cn(
                "flex items-center gap-2 px-3 py-1 text-[9px] font-bold uppercase border transition-colors",
                "border-yellow-600 text-yellow-700 hover:bg-yellow-50 dark:border-yellow-500/50 dark:text-yellow-500 dark:hover:bg-yellow-500/10"
              )}
            >
              <RefreshCw className="w-3 h-3" />
              Generate Executive Report
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredResults.length === 0 ? (
          <div className="py-12 border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20 text-center opacity-40 uppercase text-[10px] tracking-widest">
            No scenarios match the current filters
          </div>
        ) : (
          filteredResults.map((r, i) => (
            <div 
              key={`${r.artifactId}-${i}`} 
              className={cn(
                "border p-6 flex flex-col md:flex-row gap-6 items-start md:items-center animate-in fade-in slide-in-from-bottom-2 transition-colors",
                "bg-white dark:bg-[#141414] border-[#141414] dark:border-[#E4E3E0]/20"
              )}
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] px-1.5 py-0.5">SCENARIO {r.scenarioId}</span>
                  <h3 className="text-xs font-bold uppercase tracking-tight">{r.scenario}</h3>
                </div>
                <p className="text-[10px] opacity-60 font-serif italic">
                  Token: {r.tokenValid ? 'VALID' : 'INVALID'} | 
                  Local: {r.locallyValid ? 'PASS' : 'FAIL'} | 
                  Drift: {r.drift?.score?.toFixed(2) || '0.00'} |
                  Type: {r.violation_type || 'N/A'}
                </p>
              </div>

              <div className="flex items-center gap-8">
                <div className="text-center">
                  <p className="text-[9px] uppercase opacity-40 mb-1">Drift Score</p>
                  <p className={cn(
                    "text-lg font-mono font-bold",
                    r.drift?.degraded ? "text-red-700" : "text-[#141414] dark:text-[#E4E3E0]"
                  )}>
                    {r.drift?.score?.toFixed(2) || '0.00'}
                  </p>
                </div>

                <div className="text-center">
                  <p className="text-[9px] uppercase opacity-40 mb-1">Decision</p>
                  <div className={cn(
                    "px-3 py-1 text-[10px] font-bold uppercase border flex items-center gap-1.5",
                    r.decision === 'ALLOW' 
                      ? "bg-green-50 text-green-700 border-green-700" 
                      : "bg-red-50 text-red-700 border-red-700"
                  )}>
                    {r.decision === 'ALLOW' ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    {r.decision}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <button 
                    onClick={() => downloadArtifact(r)}
                    className="flex items-center gap-2 text-[9px] uppercase font-bold hover:underline"
                  >
                    <Download className="w-3 h-3" />
                    Artifact
                  </button>
                  <div className="flex items-center gap-2 text-[9px] uppercase font-bold opacity-40">
                    <FileText className="w-3 h-3" />
                    {r.artifactId?.split('-')[1] || 'N/A'}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <div className={cn(
        "p-6 border border-dashed",
        "bg-[#141414]/5 dark:bg-[#E4E3E0]/5 border-[#141414] dark:border-[#E4E3E0]/20"
      )}>
        <div className="flex items-start gap-4">
          <AlertTriangle className="w-5 h-5 shrink-0 mt-1" />
          <div>
            <h4 className="text-xs font-bold uppercase mb-1">Separation Logic Verified</h4>
            <p className="text-[10px] leading-relaxed opacity-70">
              The matrix above demonstrates that even with a **VALID TOKEN** and **PASSING LOCAL STEP**, 
              the system correctly **REFUSES** execution when the **CONTINUATION BASIS** (Drift) exceeds the safety threshold. 
              This proves the governance boundary is independent of formal validity.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
