import React from "react";
import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import { GovernanceState, JoeKernel } from "../swi/joe";
import {
  Terminal,
  GitBranch,
  ArrowRight,
  Shield,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function S9StateMachine() {
  const states = [
    { id: GovernanceState.INIT, color: "bg-gray-500", label: "INITIALIZATION" },
    {
      id: GovernanceState.STABILIZING,
      color: "bg-blue-500",
      label: "STABILITY_PASS",
    },
    {
      id: GovernanceState.STANDING_RESOLVED,
      color: "bg-cyan-500",
      label: "STANDING_RESOLUTION",
    },
    {
      id: GovernanceState.DRIFT_CHECK,
      color: "bg-purple-500",
      label: "CONTEXTUAL_DRIFT_SCAN",
    },
    {
      id: GovernanceState.BOUNDARY_ENFORCED,
      color: "bg-green-500",
      label: "S9_ADMITTED",
    },
    {
      id: GovernanceState.REFUSED,
      color: "bg-red-500",
      label: "GOVERNANCE_REFUSAL",
    },
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between border-b border-black/10 dark:border-white/10 pb-4">
        <div>
          <h3 className="text-xl font-bold uppercase tracking-tighter flex items-center gap-2">
            <GitBranch className="w-5 h-5 text-purple-500" />
            S9 Formal State Machine
          </h3>
          <p className="text-[10px] opacity-40 uppercase tracking-widest mt-1">
            Certified Deterministic Transition Model
          </p>
        </div>
        <div className="px-3 py-1 bg-black text-white text-[8px] font-mono rounded">
          v1.0-DCG-FORMAL
        </div>
      </div>

      <div className="relative overflow-x-auto pb-8 custom-scrollbar">
        <div className="flex items-center gap-12 min-w-[1000px] p-6 bg-black/5 dark:bg-white/5 border border-black/5 dark:border-white/5">
          {states.map((state, i) => (
            <React.Fragment key={state.id}>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex flex-col items-center gap-4 relative"
              >
                <div
                  className={cn(
                    "w-16 h-16 rounded-full border-2 flex items-center justify-center relative z-10 transition-shadow duration-500",
                    state.id === GovernanceState.REFUSED
                      ? "border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)] bg-red-500/5"
                      : "border-black dark:border-white opacity-40 hover:opacity-100 hover:border-purple-500",
                  )}
                >
                  <div className={cn("w-3 h-3 rounded-full", state.color)} />
                  {state.id === GovernanceState.REFUSED && (
                    <AlertTriangle className="w-4 h-4 text-red-500 absolute -top-1 -right-1" />
                  )}
                  {state.id === GovernanceState.BOUNDARY_ENFORCED && (
                    <CheckCircle2 className="w-4 h-4 text-green-500 absolute -top-1 -right-1" />
                  )}
                </div>
                <div className="text-center space-y-1">
                  <p className="text-[8px] font-mono opacity-30">{state.id}</p>
                  <p className="text-[10px] font-bold uppercase tracking-widest whitespace-nowrap">
                    {state.label}
                  </p>
                </div>
              </motion.div>

              {i < states.length - 1 && (
                <div className="flex flex-col items-center gap-2 opacity-20">
                  <ArrowRight className="w-4 h-4" />
                  <span className="text-[8px] font-mono">NEXT</span>
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-[#141414] text-white p-6 border border-white/10 space-y-4">
          <div className="flex items-center gap-2 text-blue-400 mb-2">
            <Terminal className="w-4 h-4" />
            <h4 className="text-xs font-bold uppercase tracking-widest">
              Protocol Definition (joe.ts)
            </h4>
          </div>
          <pre className="text-[10px] font-mono leading-relaxed opacity-80 whitespace-pre-wrap">
            {JoeKernel.getFormalProtocol()}
          </pre>
        </div>

        <div className="bg-white dark:bg-[#1A1A1A] p-6 border border-black/10 dark:border-white/10 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-4 h-4 text-green-500" />
            <h4 className="text-xs font-bold uppercase tracking-widest">
              State Guard Invariants
            </h4>
          </div>
          <ul className="space-y-4">
            <li className="flex gap-4 items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5" />
              <div>
                <p className="text-[10px] font-bold uppercase tracking-tight">
                  Environmental Stability (S)
                </p>
                <p className="text-[10px] opacity-50">
                  Requires S &gt; 0.70 to avoid cascade collapse.
                </p>
              </div>
            </li>
            <li className="flex gap-4 items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5" />
              <div>
                <p className="text-[10px] font-bold uppercase tracking-tight">
                  Execution Standing (S_res)
                </p>
                <p className="text-[10px] opacity-50">
                  Standing resolution before consequence-boundary binding. S_res
                  &gt; 0.80.
                </p>
              </div>
            </li>
            <li className="flex gap-4 items-start">
              <div className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5" />
              <div>
                <p className="text-[10px] font-bold uppercase tracking-tight">
                  Contextual Drift (D)
                </p>
                <p className="text-[10px] opacity-50">
                  Token-level scan of intent shift. D &lt; 0.40.
                </p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <ProofArtifacts
        id="s9-formal"
        title="S9 Formal State Extractor"
        data={{ protocol: JoeKernel.getFormalProtocol() }}
      />
    </div>
  );
}
