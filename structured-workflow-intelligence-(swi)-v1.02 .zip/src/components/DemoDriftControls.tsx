import { useState } from "react";

interface DemoDriftControlsProps {
  setDrift: (drift: number) => void;
}

export default function DemoDriftControls({ setDrift }: DemoDriftControlsProps) {
  const [value, setValue] = useState(0.3);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const val = parseFloat(e.target.value);
    setValue(val);
    setDrift(val);
  }

  return (
    <div className="p-6 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-tighter">📉 Drift Simulator</h3>
      
      <div className="space-y-4">
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={value}
          onChange={handleChange}
          className="w-full h-2 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
        />
        <div className="flex justify-between items-center">
          <span className="text-[10px] uppercase font-bold opacity-40">Current Drift:</span>
          <span className={`text-xl font-mono font-bold ${value > 0.7 ? 'text-red-500' : 'text-green-500'}`}>
            {value.toFixed(2)}
          </span>
        </div>
        
        <div className="p-3 bg-black/5 dark:bg-white/5 text-[10px] uppercase font-serif italic opacity-60">
          {value > 0.7 
            ? "Critical drift detected. Boundary refusal imminent." 
            : "Drift within nominal limits. Continuation admissible."}
        </div>
      </div>
    </div>
  );
}
