import React, { useState, useEffect } from "react";
import { runVerificationPipeline, VerificationResult } from "../core/refinement/VerificationPipeline";
import { Shield, CheckCircle, XCircle, Play } from "lucide-react";

export default function RefinementDashboard() {
  const [results, setResults] = useState<VerificationResult[]>([]);

  const runVerification = () => {
    const res = runVerificationPipeline();
    setResults(res);
  };

  useEffect(() => {
    runVerification();
  }, []);

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-[#E4E3E0] min-h-screen font-mono text-xs">
      <div className="flex items-center justify-between border-b border-[#333] pb-4">
        <div>
          <h1 className="text-xl font-bold uppercase tracking-widest text-[#00ffcc] flex items-center gap-2">
            <Shield className="w-5 h-5" /> Refinement Verification Pipeline
          </h1>
          <p className="text-[#888] mt-1">Formal Proof Obligations & Invariant Guards</p>
        </div>
        <button
          onClick={runVerification}
          className="px-4 py-2 bg-[#1a1a1a] border border-[#333] hover:border-[#00ffcc] text-[#00ffcc] transition-colors flex items-center gap-2 rounded"
        >
          <Play className="w-4 h-4" /> Run CI Pipeline
        </button>
      </div>

      <div className="space-y-4">
        {results.map((req, idx) => (
          <div key={idx} className="p-4 bg-[#111] border border-[#333] rounded space-y-3">
            <div className="flex justify-between items-center border-b border-[#222] pb-2">
              <div className="font-bold uppercase text-sm text-[#E4E3E0]">{req.scenario}</div>
              <div className="flex items-center gap-4">
                <div className="text-[#888]">
                  Decision: <span className={`font-bold ${req.decision === 'EXECUTE' ? 'text-green-500' : req.decision === 'HALT' ? 'text-red-500' : 'text-yellow-500'}`}>{req.decision}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className={`p-2 border rounded flex items-center justify-between ${req.invariants.safetyPreservation ? 'border-green-500/30 bg-green-500/5' : 'border-red-500/30 bg-red-500/5'}`}>
                <span className="text-gray-400">PO1: Safety Preservation</span>
                {req.invariants.safetyPreservation ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
              </div>
              <div className={`p-2 border rounded flex items-center justify-between ${req.invariants.haltLifting ? 'border-green-500/30 bg-green-500/5' : 'border-red-500/30 bg-red-500/5'}`}>
                <span className="text-gray-400">PO2: Halt Lifting</span>
                {req.invariants.haltLifting ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
              </div>
              <div className={`p-2 border rounded flex items-center justify-between ${req.invariants.refusalClosure ? 'border-green-500/30 bg-green-500/5' : 'border-red-500/30 bg-red-500/5'}`}>
                <span className="text-gray-400">PO3: Refusal Closure</span>
                {req.invariants.refusalClosure ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-red-500" />}
              </div>
              <div className={`p-2 border rounded flex items-center justify-between ${req.invariants.allHold ? 'border-[#00ffcc]/30 bg-[#00ffcc]/5 text-[#00ffcc]' : 'border-red-500/30 bg-red-500/5 text-red-500'}`}>
                <span className="font-bold">VERIFIED REFINEMENT</span>
                {req.invariants.allHold ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
              </div>
            </div>

            <div className="pt-2 text-[10px] text-[#666]">
              Receipt Hash: {req.receipt}
            </div>
          </div>
        ))}
        {results.length === 0 && <div className="text-center text-[#555] p-6 border dashed border-[#333]">Run the pipeline to verify obligations.</div>}
      </div>
    </div>
  );
}
