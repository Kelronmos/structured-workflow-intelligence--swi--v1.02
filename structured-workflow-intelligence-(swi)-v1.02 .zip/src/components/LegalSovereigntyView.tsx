// src/components/LegalSovereigntyView.tsx
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Scale, Gavel, BookOpen, ExternalLink, ShieldCheck, Map } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface Article {
    id: string;
    title: string;
    text: string;
    mapping: string;
}

interface RegulatoryDocument {
    id: string;
    title: string;
    source: string;
    version: string;
    lastUpdated: string;
    content: string;
    articles: Article[];
}

export default function LegalSovereigntyView() {
    const [docs, setDocs] = useState<RegulatoryDocument[]>([]);
    const [selectedDoc, setSelectedDoc] = useState<RegulatoryDocument | null>(null);
    const [loading, setLoading] = useState(true);

    const fetchCorpus = async () => {
        try {
            const res = await fetch('/api/v4/legal/corpus');
            const data = await res.json();
            setDocs(data);
            if (data.length > 0 && !selectedDoc) setSelectedDoc(data[0]);
        } catch (e) {
            console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCorpus();
    }, []);

    if (loading) return <div className="p-12 text-center text-white/20 animate-pulse font-black uppercase tracking-widest">Ingesting Regulatory Corpus...</div>;

    return (
        <div className="bg-white/5 border border-white/10 rounded-[2rem] p-8 backdrop-blur-3xl overflow-hidden relative">
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-blue-500/20 rounded-2xl">
                        <Scale className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                        <h3 className="text-lg font-black uppercase tracking-tighter text-white/90">L1/L2 Legal Sovereignty</h3>
                        <p className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]">Gold-Standard Ingested Law</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    {docs.map(doc => (
                        <button
                            key={doc.id}
                            onClick={() => setSelectedDoc(doc)}
                            className={cn(
                                "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                                selectedDoc?.id === doc.id ? "bg-blue-500 text-white shadow-xl shadow-blue-500/20" : "bg-white/5 text-white/40 hover:bg-white/10"
                            )}
                        >
                            {doc.id}
                        </button>
                    ))}
                </div>
            </div>

            <AnimatePresence mode="wait">
                {selectedDoc && (
                    <motion.div
                        key={selectedDoc.id}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="grid grid-cols-1 lg:grid-cols-3 gap-8"
                    >
                        {/* Doc Info */}
                        <div className="lg:col-span-1 space-y-6">
                            <div className="p-6 bg-black/40 border border-white/5 rounded-3xl space-y-4">
                                <h4 className="text-sm font-black text-white/90 leading-tight">{selectedDoc.title}</h4>
                                <div className="space-y-2">
                                    <div className="flex items-center justify-between text-[10px]">
                                        <span className="text-white/30 uppercase font-bold">Source</span>
                                        <span className="text-white/60">{selectedDoc.source}</span>
                                    </div>
                                    <div className="flex items-center justify-between text-[10px]">
                                        <span className="text-white/30 uppercase font-bold">Version</span>
                                        <span className="text-blue-400 font-mono">{selectedDoc.version}</span>
                                    </div>
                                    <div className="flex items-center justify-between text-[10px]">
                                        <span className="text-white/30 uppercase font-bold">Updated</span>
                                        <span className="text-white/60">{new Date(selectedDoc.lastUpdated).toLocaleDateString()}</span>
                                    </div>
                                </div>
                                <div className="pt-4 border-t border-white/5">
                                    <div className="flex items-center gap-2 text-green-500 mb-2">
                                        <ShieldCheck className="w-4 h-4" />
                                        <span className="text-[10px] font-black uppercase tracking-widest">Verified Ingestion</span>
                                    </div>
                                    <p className="text-[11px] text-white/40 leading-relaxed italic">
                                        "{selectedDoc.content.substring(0, 150)}..."
                                    </p>
                                </div>
                            </div>

                            <div className="p-6 bg-blue-500/5 border border-blue-500/20 rounded-3xl">
                                <div className="flex items-center gap-2 mb-3">
                                    <Gavel className="w-4 h-4 text-blue-400" />
                                    <span className="text-[10px] font-black uppercase tracking-widest text-blue-400">Jurisdictional Bound</span>
                                </div>
                                <p className="text-[11px] text-white/60 leading-relaxed">
                                    This corpus is strictly bound to the SWI L1 Jurisdiction Validator. All execution threads must prove alignment with these statutes.
                                </p>
                            </div>
                        </div>

                        {/* Article Stream */}
                        <div className="lg:col-span-2 space-y-4 max-h-[600px] overflow-y-auto pr-4 custom-scrollbar">
                            <div className="flex items-center gap-2 mb-2 px-2">
                                <BookOpen className="w-4 h-4 text-white/20" />
                                <span className="text-[10px] font-black uppercase tracking-widest text-white/30">Active Statutes in Kernel Execution</span>
                            </div>
                            {selectedDoc.articles.map((art) => (
                                <div key={art.id} className="p-6 bg-white/5 border border-white/5 rounded-3xl group hover:border-blue-500/30 transition-all">
                                    <div className="flex justify-between items-start mb-4">
                                        <div>
                                            <h5 className="text-blue-400 font-mono text-xs font-bold mb-1">{art.id}</h5>
                                            <h6 className="text-sm font-black text-white/90">{art.title}</h6>
                                        </div>
                                        <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/5 rounded-full">
                                            <Map className="w-3 h-3 text-white/40" />
                                            <span className="text-[8px] font-black uppercase text-white/40">{art.mapping}</span>
                                        </div>
                                    </div>
                                    <p className="text-xs text-white/60 leading-relaxed mb-4">
                                        {art.text}
                                    </p>
                                    <div className="flex items-center justify-between pt-4 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-all">
                                        <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest">Compliance Active</span>
                                        <button className="flex items-center gap-1 text-[9px] font-black uppercase text-blue-400">
                                            View Official Source <ExternalLink className="w-3 h-3" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}
