// src/components/UserPersonaSelector.tsx
import React from 'react';
import { User, Shield, Baby, Eye, Settings, Terminal } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { AuthorityLevel } from '@/swi-core/kernel/UniverseTypes';

interface UserPersonaSelectorProps {
    currentAuthority: AuthorityLevel;
    onAuthorityChange: (authority: AuthorityLevel) => void;
}

export default function UserPersonaSelector({ currentAuthority, onAuthorityChange }: UserPersonaSelectorProps) {
    const roles = [
        { id: AuthorityLevel.CHILD, label: 'Child / User', icon: Baby, color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/20' },
        { id: AuthorityLevel.MODERATOR, label: 'Moderator', icon: Eye, color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/20' },
        { id: AuthorityLevel.REVIEWER, label: 'Reviewer', icon: Shield, color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/20' },
        { id: AuthorityLevel.GOVERNANCE, label: 'Governance', icon: Settings, color: 'text-purple-400', bg: 'bg-purple-400/10', border: 'border-purple-400/20' },
        { id: AuthorityLevel.SECURITY, label: 'Security Auditor', icon: Shield, color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/20' },
        { id: AuthorityLevel.SYSTEM_CORE, label: 'System Core', icon: Terminal, color: 'text-white', bg: 'bg-white/10', border: 'border-white/20' },
    ];

    return (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-4">
            <div className="flex items-center gap-2 mb-2">
                <User className="w-4 h-4 text-white/40" />
                <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Authority Level Selection</h3>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {roles.map((role) => (
                    <button
                        key={role.id}
                        onClick={() => onAuthorityChange(role.id)}
                        className={cn(
                            "flex items-center gap-3 p-3 rounded-xl border transition-all text-left",
                            currentAuthority === role.id 
                                ? `${role.bg} ${role.border} ring-1 ring-white/20 scale-[1.02]` 
                                : "bg-black/20 border-white/5 opacity-60 hover:opacity-100 hover:bg-black/40"
                        )}
                    >
                        <role.icon className={cn("w-4 h-4", role.color)} />
                        <div className="overflow-hidden">
                            <p className={cn("text-[9px] font-black uppercase tracking-widest truncate", currentAuthority === role.id ? role.color : "text-white/60")}>
                                {role.label}
                            </p>
                            <p className="text-[7px] text-white/20 font-bold uppercase truncate">
                                {currentAuthority === role.id ? 'Active Persona' : 'Switch Level'}
                            </p>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );
}
