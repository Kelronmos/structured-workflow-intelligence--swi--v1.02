import { useState } from "react";
import { executeSWI } from "../api";

interface DemoControlPanelProps {
  setResult: (result: Record<string, unknown>) => void;
  drift: number;
}

export default function DemoControlPanel({ setResult, drift }: DemoControlPanelProps) {
  const [env, setEnv] = useState("stable");
  const [behavior, setBehavior] = useState("normal");

  async function runTest() {
    const payload = {
      event_id: "E-" + Date.now(),
      action: "TRANSFER",
      actor: behavior === "normal" ? "USER_001" : "SYSTEM_SEEDER",
      corridor: "FINANCIAL",
      details: {
        cost_owner: env === "stable" ? "FINANCE_DEPT" : null,
        rollback_owner: env === "stable" ? "OPS_TEAM" : null,
        rollback_plan: env === "stable" ? "ROLLBACK_V1" : null
      },
      signatures: behavior === "normal" ? ["LEGAL", "TPM"] : [],
      authority_token: behavior === "normal" ? "VALID_TOKEN_12345" : "",
      ahmr_token: behavior === "normal" ? "AHMR_LEGAL_APPROVED" : "",
      drift_score: drift
    };

    const res = await executeSWI(payload);
    setResult(res);
  }

  return (
    <div className="p-6 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-6">
      <h3 className="text-lg font-bold uppercase tracking-tighter">🧠 SWI Control Panel</h3>

      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-[10px] uppercase font-bold opacity-40 block">Environment:</label>
          <select 
            onChange={(e) => setEnv(e.target.value)}
            className="w-full p-2 border border-[#141414] dark:border-[#E4E3E0]/20 bg-transparent text-sm focus:outline-none"
          >
            <option value="stable">Stable</option>
            <option value="unstable">Unstable</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] uppercase font-bold opacity-40 block">User Behavior:</label>
          <select 
            onChange={(e) => setBehavior(e.target.value)}
            className="w-full p-2 border border-[#141414] dark:border-[#E4E3E0]/20 bg-transparent text-sm focus:outline-none"
          >
            <option value="normal">Normal</option>
            <option value="anomalous">Anomalous</option>
          </select>
        </div>

        <button 
          onClick={runTest}
          className="w-full py-3 bg-[#141414] text-white dark:bg-[#E4E3E0] dark:text-[#141414] font-bold uppercase text-sm hover:opacity-90 transition-opacity active:scale-[0.98]"
        >
          🚀 Execute
        </button>
      </div>
    </div>
  );
}
