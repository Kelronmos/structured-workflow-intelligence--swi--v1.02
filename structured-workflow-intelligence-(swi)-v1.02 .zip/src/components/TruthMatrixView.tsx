// src/components/TruthMatrixView.tsx
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Activity, CheckCircle2, ShieldAlert, AlertTriangle } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface ModuleStatus {
    module: string;
    status: string;
    confidence: number;
    health: string;
    isOperational: boolean;
}

interface TruthMatrixResponse {
    matrix: ModuleStatus[];
    coherence: {
        score: number;
        collisions: string[];
        stabilityIntent: string;
        level: string;
    };
    eventCount: number;
    failsafe: {
        route: 'NORMAL' | 'DEGRADED' | 'RESTRICTED' | 'SAFE_MODE';
        restrictions: string[];
    };
}

export default function TruthMatrixView() {
    const [matrix, setMatrix] = useState<ModuleStatus[]>([]);
    const [coherence, setCoherence] = useState<TruthMatrixResponse['coherence'] | null>(null);
    const [failsafe, setFailsafe] = useState<TruthMatrixResponse['failsafe'] | null>(null);
    const [eventCount, setEventCount] = useState(0);
    const [loading, setLoading] = useState(true);

    const fetchMatrix = async () => {
        try {
            const res = await fetch('/api/v4/truth-matrix');
            const data: TruthMatrixResponse = await res.json();
            setMatrix(data.matrix);
            setCoherence(data.coherence);
            setEventCount(data.eventCount);
            setFailsafe(data.failsafe);
        } catch (e) {
            console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMatrix();
        const interval = setInterval(fetchMatrix, 5000);
        return () => clearInterval(interval);
    }, []);

    if (loading) return <div className="animate-pulse h-64 bg-white/5 rounded-3xl" />;

    return (
        <div className="bg-black/20 rounded-3xl p-6 border border-white/5 space-y-6">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-white/40" />
                    <h3 className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Capability Registry (Real-Time Truth)</h3>
                </div>
                <div className="flex items-center gap-3">
                    <div className="px-3 py-1 bg-white/5 border border-white/10 rounded-full">
                        <span className="text-[8px] font-mono text-white/60">EVENTS: {eventCount}</span>
                    </div>
                    <div className="px-3 py-1 bg-blue-500/10 border border-blue-500/30 rounded-full">
                        <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest">v4 Grounded</span>
                    </div>
                </div>
            </div>

            {failsafe && failsafe.route !== 'NORMAL' && (
                <div className={cn(
                    "p-3 rounded-2xl border-2 animate-pulse mb-2",
                    failsafe.route === 'SAFE_MODE' ? "bg-red-500/10 border-red-500/40" : "bg-yellow-500/10 border-yellow-500/40"
                )}>
                    <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className={cn("w-4 h-4", failsafe.route === 'SAFE_MODE' ? "text-red-500" : "text-yellow-500")} />
                        <span className={cn("text-[10px] font-black uppercase tracking-widest", failsafe.route === 'SAFE_MODE' ? "text-red-500" : "text-yellow-500")}>
                            Sovereign Failsafe: {failsafe.route}
                        </span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                        {failsafe.restrictions.map((r, i) => (
                            <span key={i} className="text-[7px] font-black uppercase px-2 py-0.5 bg-black/20 rounded-md opacity-70">
                                {r}
                            </span>
                        ))}
                    </div>
                </div>
            )}
            
            {coherence && (
                <div className={cn(
                    "p-4 rounded-2xl border transition-all flex flex-col gap-3",
                    coherence.score > 0.8 ? "bg-green-500/5 border-green-500/20" : "bg-red-500/5 border-red-500/20"
                )}>
                    <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <ShieldAlert className={cn("w-4 h-4", coherence.score > 0.8 ? "text-green-500" : "text-red-500")} />
                            <span className="text-[10px] font-black uppercase tracking-widest leading-none">C1 Meta-Coherence: {coherence.level}</span>
                        </div>
                        <span className="text-[10px] font-mono font-bold">λ {(1 - coherence.score).toFixed(4)}</span>
                    </div>
                    <div className="flex flex-col gap-1">
                        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                            <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${coherence.score * 100}%` }}
                                className={cn("h-full", coherence.score > 0.8 ? "bg-green-500" : "bg-red-500")} 
                            />
                        </div>
                        <p className="text-[8px] text-white/40 uppercase font-bold tracking-widest italic">{coherence.stabilityIntent}</p>
                    </div>
                    {coherence.collisions.length > 0 && (
                        <div className="space-y-1 mt-1">
                            {coherence.collisions.map((c, i) => (
                                <p key={i} className="text-[8px] text-red-500/80 font-bold border-l border-red-500/40 pl-2">
                                    [Collision-{i+1}]: {c}
                                </p>
                            ))}
                        </div>
                    )}
                </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                {matrix.map((mod) => (
                    <motion.div
                        key={mod.module}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className={cn(
                            "p-3 rounded-xl border flex flex-col gap-2 transition-all",
                            mod.isOperational ? "bg-green-500/5 border-green-500/20" : "bg-red-500/5 border-red-500/20"
                        )}
                    >
                        <div className="flex justify-between items-start">
                            <span className="text-[9px] font-black text-white truncate max-w-[80%]">{mod.module}</span>
                            {mod.isOperational ? (
                                <CheckCircle2 className="w-3 h-3 text-green-500" />
                            ) : (
                                <ShieldAlert className="w-3 h-3 text-red-500" />
                            )}
                        </div>
                        <div className="flex justify-between items-center">
                             <div className="h-1 flex-1 bg-white/5 rounded-full overflow-hidden mr-2">
                                <motion.div 
                                    initial={{ width: 0 }}
                                    animate={{ width: mod.health }}
                                    className={cn("h-full", mod.isOperational ? "bg-green-500" : "bg-red-500")} 
                                />
                             </div>
                             <span className={cn("text-[8px] font-mono", mod.isOperational ? "text-green-500" : "text-red-500")}>{mod.health}</span>
                        </div>
                        <span className="text-[7px] uppercase font-bold opacity-40">{mod.status}</span>
                    </motion.div>
                ))}
            </div>
        </div>
    );
}
