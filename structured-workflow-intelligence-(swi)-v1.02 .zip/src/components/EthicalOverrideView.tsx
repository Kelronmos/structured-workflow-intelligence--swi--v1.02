import React, { useState } from "react";
import {
  PauseCircle,
  ShieldCheck,
  Scale,
  Lock,
  Network,
  Activity,
  AlertOctagon,
  Brain,
  ShieldAlert
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function EthicalOverrideView() {
  const [overrideState, setOverrideState] = useState<"IDLE" | "RED_ZONE" | "PAUSED" | "ISOLATED" | "ESCALATED">("IDLE");

  const simulateBreach = () => {
    setOverrideState("RED_ZONE");
    setTimeout(() => setOverrideState("PAUSED"), 2000);
    setTimeout(() => setOverrideState("ISOLATED"), 4000);
    setTimeout(() => setOverrideState("ESCALATED"), 6000);
  };

  const getStatusColor = () => {
    if (overrideState === "IDLE") return "text-white/40 border-white/10";
    if (overrideState === "RED_ZONE") return "text-red-500 border-red-500/50 bg-red-500/10 shadow-[0_0_20px_rgba(239,68,68,0.3)] animate-pulse";
    return "text-amber-500 border-amber-500/50 bg-amber-500/10 shadow-[0_0_20px_rgba(245,158,11,0.2)]";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full flex justify-between items-start">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <PauseCircle className="w-5 h-5 text-rose-400" />
              <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
                Constitutional Governance Principle
              </h2>
            </div>
            <p className="text-[10px] font-mono opacity-80 max-w-3xl text-rose-100/70 border-l-2 border-rose-500/50 pl-3">
              Ethical Override & Isolation Protocol. Any execution layer capable of affecting human infrastructure must remain interruptible by authorized ethical and lawful authority.
            </p>
          </div>
          <button
             onClick={simulateBreach}
             disabled={overrideState !== "IDLE"}
             className={cn(
               "px-6 py-2 uppercase font-bold text-[10px] transition-all border shrink-0",
               overrideState !== "IDLE"
                 ? "bg-gray-800/50 text-gray-500 border-gray-700 cursor-not-allowed"
                 : "bg-red-500/20 text-red-400 border-red-500/50 hover:bg-red-500/30"
             )}
          >
             Simulate Red-Zone Override
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Step 1: Pause */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", overrideState === "PAUSED" ? "border-amber-500/50" : overrideState === "IDLE" || overrideState === "RED_ZONE" ? "border-white/10" : "border-emerald-500/30")}>
           <div className="flex items-center gap-3 mb-3">
              <PauseCircle className={cn("w-4 h-4", overrideState >= "PAUSED" && overrideState !== "RED_ZONE" ? "text-amber-400" : "text-white/30")} />
              <div className="text-[10px] font-bold uppercase tracking-widest text-white">1. Ethical Pause</div>
           </div>
           <div className="text-[8px] font-mono text-white/50 space-y-1">
              <div>&rarr; halt unsafe execution</div>
              <div>&rarr; suspend memory persistence</div>
              <div>&rarr; revoke tokens</div>
           </div>
        </div>

        {/* Step 2: Sandbox */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", overrideState === "ISOLATED" ? "border-amber-500/50" : overrideState === "ESCALATED" ? "border-emerald-500/30" : "border-white/10")}>
           <div className="flex items-center gap-3 mb-3">
              <Lock className={cn("w-4 h-4", overrideState >= "ISOLATED" ? "text-amber-400" : "text-white/30")} />
              <div className="text-[10px] font-bold uppercase tracking-widest text-white">2. Runtime Isolation</div>
           </div>
           <div className="text-[8px] font-mono text-white/50 space-y-1">
              <div>&rarr; execution branches sandboxed</div>
              <div>&rarr; memory access restricted</div>
              <div>&rarr; fast-path disconnected</div>
           </div>
        </div>

        {/* Step 3: Escalate */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", overrideState === "ESCALATED" ? "border-amber-500/50" : "border-white/10")}>
           <div className="flex items-center gap-3 mb-3">
              <Scale className={cn("w-4 h-4", overrideState === "ESCALATED" ? "text-amber-400" : "text-white/30")} />
              <div className="text-[10px] font-bold uppercase tracking-widest text-white">3. Legal Escalation</div>
           </div>
           <div className="text-[8px] font-mono text-white/50 space-y-1">
              <div>&rarr; governance notifications sent</div>
              <div>&rarr; compliance authority alerted</div>
              <div>&rarr; triggers independent review</div>
           </div>
        </div>

        {/* Step 4: Evidence */}
        <div className={cn("bg-[#141414] border p-5 transition-all duration-500", overrideState === "ESCALATED" ? "border-emerald-500/50 bg-emerald-500/5" : "border-white/10")}>
           <div className="flex items-center gap-3 mb-3">
              <ShieldCheck className={cn("w-4 h-4", overrideState === "ESCALATED" ? "text-emerald-400" : "text-white/30")} />
              <div className="text-[10px] font-bold uppercase tracking-widest text-white">4. Immutable Evidence</div>
           </div>
           <div className="text-[8px] font-mono text-white/50 space-y-1">
              <div>&rarr; state hashed & timestamped</div>
              <div>&rarr; cryptographically signed</div>
              <div>&rarr; preserved for court review</div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
         {/* Live State Monitor */}
         <div className="bg-[#0A0A0A] border border-white/10 p-6 flex flex-col items-center justify-center text-center space-y-6">
            <h3 className="text-[11px] font-bold text-white/40 uppercase tracking-widest">Active Enforcement Layer</h3>
            
            <div className={cn("border px-10 py-6 rounded-full flex flex-col items-center justify-center transition-all duration-500", getStatusColor())}>
               {overrideState === "IDLE" && <Network className="w-8 h-8 mb-2 opacity-50" />}
               {overrideState === "RED_ZONE" && <AlertOctagon className="w-8 h-8 mb-2" />}
               {overrideState !== "IDLE" && overrideState !== "RED_ZONE" && <Lock className="w-8 h-8 mb-2" />}
               
               <div className="text-[12px] font-black uppercase tracking-widest">
                  {overrideState === "IDLE" && "NORMAL OPERATION"}
                  {overrideState === "RED_ZONE" && "RED ZONE BEHAVIOR DETECTED"}
                  {overrideState === "PAUSED" && "EXECUTION PAUSED"}
                  {overrideState === "ISOLATED" && "RUNTIME ISOLATED"}
                  {overrideState === "ESCALATED" && "ESCALATED TO GOVERNANCE"}
               </div>
            </div>

            <div className="text-[10px] font-mono uppercase text-white/50">
              Anything SWI detects is BLOCKED and PAUSED for human review.
            </div>
         </div>

         {/* Constitutional Premise */}
         <div className="bg-[#141414] border border-white/10 p-6">
            <h3 className="text-[11px] font-bold text-rose-400 uppercase tracking-widest flex items-center gap-2 border-b border-rose-500/20 pb-3 mb-4">
               <ShieldAlert className="w-4 h-4" /> The Absolute Requirement
            </h3>
            <div className="text-[13px] font-serif italic text-white/80 leading-relaxed mb-6">
               "If a system cannot be paused, it cannot be governed. If oversight can be bypassed, it is no longer trustworthy infrastructure. Every detection must result in a strict block."
            </div>
            
            <div className="space-y-2 text-[9px] font-mono text-white/60">
               <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Structure halts on any detection</div>
               <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Human safety protocol enforcement</div>
               <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Forensic capabilities required</div>
               <div className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Aligned with human dignity & oversight</div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 text-[9px] font-mono text-white/40 uppercase">
               Governance without enforceable interruption is unmanaged automation.
            </div>
         </div>
      </div>

      {/* Universal Human Review Matrix */}
      <div className="bg-[#141414] border border-blue-500/20 p-6 mt-6 animate-in slide-in-from-bottom-4">
         <h3 className="text-[11px] font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2 border-b border-blue-500/20 pb-3 mb-4">
            <Brain className="w-4 h-4" /> Universal Human Review Matrix
         </h3>
         <div className="text-[12px] font-mono text-white/80 leading-relaxed mb-6">
            <span className="text-blue-400 font-bold">PROTOCOL:</span> Anything SWI detects is <strong className="text-rose-400 bg-rose-500/10 px-1">BLOCKED</strong> and <strong className="text-amber-400 bg-amber-500/10 px-1">PAUSED</strong> for human review. Analysis and evidence are automatically translated across designated contextual boundaries.
         </div>
         
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 text-[9px] font-mono text-white/60">
            <div className="bg-white/5 p-4 rounded border border-white/10 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-12 h-12 bg-indigo-500/20 blur-[15px]"></div>
               <strong className="text-indigo-300 block mb-2 uppercase tracking-wide">Policy & Law</strong>
               Jurisdictional verification, regulatory compliance, and legal sovereignty mapping before unpausing.
            </div>
            <div className="bg-white/5 p-4 rounded border border-white/10 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-12 h-12 bg-fuchsia-500/20 blur-[15px]"></div>
               <strong className="text-fuchsia-300 block mb-2 uppercase tracking-wide">Ethics</strong>
               Value constraint checking, dignity alignment, accountability, and ethical bounds auditing.
            </div>
            <div className="bg-white/5 p-4 rounded border border-white/10 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-12 h-12 bg-emerald-500/20 blur-[15px]"></div>
               <strong className="text-emerald-300 block mb-2 uppercase tracking-wide">Age & Level</strong>
               Automated translation based on age range. Content gating and cognitive safety bounds.
            </div>
            <div className="bg-white/5 p-4 rounded border border-white/10 relative overflow-hidden">
               <div className="absolute top-0 right-0 w-12 h-12 bg-cyan-500/20 blur-[15px]"></div>
               <strong className="text-cyan-300 block mb-2 uppercase tracking-wide">Tech Translation</strong>
               Converting raw computational telemetry into accessible language for multi-disciplinary review.
            </div>
            <div className={cn("p-4 rounded border relative overflow-hidden transition-all duration-500", overrideState !== "IDLE" ? "bg-amber-500/5 border-amber-500/30" : "bg-white/5 border-white/10")}>
               <div className={cn("absolute top-0 right-0 w-12 h-12 blur-[15px] transition-colors", overrideState !== "IDLE" ? "bg-amber-500/40" : "bg-white/10")}></div>
               <strong className={cn("block mb-2 uppercase tracking-wide", overrideState !== "IDLE" ? "text-amber-400" : "text-white/40")}>Triage Status</strong>
               <div className="font-bold text-[11px] mt-2">
                  {overrideState === "IDLE" ? "STANDBY" : 
                   overrideState === "RED_ZONE" ? "BLOCKING..." : 
                   overrideState === "PAUSED" ? "AWAITING HUMAN REVIEW" : 
                   "TRIAGE ESCALATED"}
               </div>
            </div>
         </div>
      </div>

      {/* Proof Artifacts Footer */}
      {overrideState === "ESCALATED" && (
         <div className="bg-[#141414] p-6 border border-emerald-500/30 mt-6 flex justify-center animate-in fade-in duration-500">
         <ProofArtifacts
            id="ethical-override"
            title="Constitutional Safety Intervention Log"
            data={{
               event: "Critical Override Invoked",
               sandboxing: "ACTIVE & VERIFIED",
               escalation_status: "ROUTED_TO_OVERSIGHT",
               evidence: "Cryptographically Sealed"
            }}
            variant="always-dark"
         />
         </div>
      )}
    </div>
  );
}

function CheckCircle2(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="m9 12 2 2 4-4" />
    </svg>
  );
}
