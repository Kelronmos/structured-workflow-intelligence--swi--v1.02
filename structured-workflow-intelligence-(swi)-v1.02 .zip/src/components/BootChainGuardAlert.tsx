import React, { useState, useEffect } from "react";
import { AlertTriangle, Terminal } from "lucide-react";

export default function BootChainGuardAlert() {
  const [criticalFailure, setCriticalFailure] = useState(false);
  const [reason, setReason] = useState("");

  useEffect(() => {
    const handleBootStatus = (e: any) => {
      if (!e.detail.valid) {
        setCriticalFailure(true);
        setReason(e.detail.reason || "Unknown Boot Failure");
      }
    };

    window.addEventListener("boot-status", handleBootStatus);
    return () => {
        window.removeEventListener("boot-status", handleBootStatus);
    };
  }, []);

  if (!criticalFailure) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#1a0a0a]/95 flex flex-col items-center justify-center text-[#E4E3E0] backdrop-blur-md p-6 font-mono">
      <AlertTriangle className="w-24 h-24 text-red-500 mb-6 animate-pulse drop-shadow-[0_0_15px_rgba(255,0,0,0.8)]" />
      <h1 className="text-4xl md:text-5xl font-extrabold uppercase tracking-widest mb-4 text-red-500 text-center drop-shadow-[0_0_10px_rgba(255,0,0,0.5)]">
        CRITICAL_BOOT_FAILURE
      </h1>
      
      <div className="max-w-3xl w-full bg-[#111] border border-red-500/50 p-6 rounded mb-8 relative overflow-hidden">
        <div className="absolute top-0 w-full h-1 bg-red-500 left-0 animate-pulse"></div>
        <div className="flex items-center gap-2 mb-4 text-red-400 font-bold uppercase border-b border-[#333] pb-2">
            <Terminal className="w-5 h-5" /> Kernel Panic / Attestation Failed
        </div>
        <p className="text-lg text-[#ffaaaa]">
          {reason}
        </p>
        <p className="mt-4 text-[#888] text-sm leading-relaxed">
          The system has detected a mismatch in the Platform Configuration Registers (PCRs). The current boot chain integrity cannot be verified against the known good TPM snapshot. 
        </p>
        <p className="mt-2 text-[#888] text-sm leading-relaxed">
          Execution has been HALTED to prevent untrusted or maliciously injected code from running in the enclave.
        </p>
      </div>

      <button 
        onClick={() => {
            setCriticalFailure(false);
            window.dispatchEvent(new CustomEvent('request-hardware-reset'));
        }}
        className="px-8 py-4 bg-red-600 hover:bg-red-500 text-white font-bold uppercase tracking-widest transition-colors rounded shadow-[0_0_20px_rgba(255,0,0,0.4)] flex items-center gap-2"
      >
        Acknowledge & Force Reboot Enclave
      </button>
    </div>
  );
}
