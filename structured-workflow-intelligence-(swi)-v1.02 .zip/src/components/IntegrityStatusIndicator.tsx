import React, { useEffect, useState } from "react";
import { ShieldCheck, Server, AlertTriangle } from "lucide-react";
import { verifyLedgerIntegrity } from "../adversarial/ledgerCheck";
import { cn } from "../lib/utils";

export function IntegrityStatusIndicator() {
  const [ledgerHealthy, setLedgerHealthy] = useState(true);
  const [consensusNodeCount, setConsensusNodeCount] = useState(3);
  
  useEffect(() => {
    const interval = setInterval(() => {
      try {
        setLedgerHealthy(verifyLedgerIntegrity());
        // Simulating a ping to PBFT consensus cluster to get active node count
        setConsensusNodeCount((Math.random() > 0.05) ? 3 : 2);
      } catch (err) {
        setLedgerHealthy(false);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={cn(
      "px-3 py-1.5 flex items-center gap-3 rounded text-xs font-mono font-bold uppercase tracking-widest border",
      ledgerHealthy ? "bg-blue-500/10 border-blue-500/30 text-blue-400" : "bg-red-500/10 border-red-500/30 text-red-500"
    )}>
      <div className="flex items-center gap-1 border-r border-current pr-2 mr-1">
        {ledgerHealthy ? <ShieldCheck className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
        <span>Ledger: {ledgerHealthy ? "VALID" : "COMPROMISED"}</span>
      </div>
      <div className="flex items-center gap-1">
        <Server className="w-4 h-4" />
        <span>Consensus: {consensusNodeCount}/3</span>
      </div>
    </div>
  );
}
