import { useEffect, useState, Fragment } from 'react';
import { Shield, ShieldAlert, FileText, CheckCircle2, XCircle, Download, ToggleLeft, ToggleRight, GitCommit, ChevronRight, Key, CheckSquare, Stamp, Zap, AlertTriangle } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { ProtectedConsequence } from '@/src/swi/consequence/ConsequenceLedger';
import { IntegrityReport } from '@/src/swi/consequence/BoundaryIntegrityMonitor';

export default function ProtectedConsequenceView({ theme }: { theme: 'light' | 'dark' }) {
  const [ledger, setLedger] = useState<ProtectedConsequence[]>([]);
  const [report, setReport] = useState<IntegrityReport | null>(null);
  const [inspectedChain, setInspectedChain] = useState<string | null>(null);
  const [showGaps, setShowGaps] = useState<boolean>(true);

  const fetchData = async () => {
    try {
      const ledRes = await fetch('/api/consequence/ledger');
      setLedger(await ledRes.json());

      const monRes = await fetch('/api/consequence/monitor');
      setReport(await monRes.json());
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    }
  };

  useEffect(() => {
    fetchData();
    const iv = setInterval(fetchData, 2000);
    return () => clearInterval(iv);
  }, []);

  const handleValidAdmission = async () => {
    await fetch('/api/consequence/attempt', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        proposalId: `PROP-${Date.now()}`,
        consequenceType: 'resource_allocation',
        statePayload: { amount: 500 }
      })
    });
    fetchData();
  };

  const handleBypassAdmission = async () => {
    await fetch('/api/consequence/attempt-bypass', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        proposalId: `PROP-BYPASS-${Date.now()}`,
        consequenceType: 'unauthorized_escalation',
        statePayload: { privileges: 'ADMIN' }
      })
    });
    fetchData();
  };

  const handleExport = () => {
    const reportData = {
      timestamp: new Date().toISOString(),
      coverageScore: report?.coverageScore,
      totalConsequences: report?.totalConsequences,
      gaps: report?.gaps,
      ledger: ledger
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(reportData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "consequence_ledger_report.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  if (!report) return null;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Shield className="w-6 h-6 text-blue-500" />
          <h2 className="text-sm font-bold uppercase tracking-widest">Protected Consequence Boundary</h2>
        </div>
        <div className="flex items-center gap-2">
          <div className="text-[10px] font-bold uppercase mr-2 tracking-widest">Integrity Score</div>
          <div className={cn(
            "text-xs font-mono font-bold px-3 py-1 rounded",
            report.coverageScore === 1 ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
          )}>
            {(report.coverageScore * 100).toFixed(1)}%
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-3 border p-2 bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10">
          <button 
            onClick={() => setShowGaps(!showGaps)}
            className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/5"
          >
            {showGaps ? <ToggleRight className="w-4 h-4 text-blue-500" /> : <ToggleLeft className="w-4 h-4" />}
            Real-time Gap Detection
          </button>
          <div className="w-px h-4 bg-black/20 dark:bg-white/20 mx-2" />
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/5"
          >
            <Download className="w-4 h-4" />
            Export Verifiable Report
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button 
            onClick={handleValidAdmission}
            className="p-4 border border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5 transition-colors flex flex-col items-center justify-center gap-2 group"
          >
            <CheckCircle2 className="w-8 h-8 text-green-500 group-hover:scale-110 transition-transform" />
            <div className="text-[10px] font-bold uppercase tracking-widest">Simulate Valid Admission</div>
          </button>
          <button 
            onClick={handleBypassAdmission}
            className="p-4 border border-black/10 dark:border-white/10 hover:bg-red-500/10 dark:hover:bg-red-500/20 transition-colors flex flex-col items-center justify-center gap-2 group"
          >
            <ShieldAlert className="w-8 h-8 text-red-500 group-hover:scale-110 transition-transform" />
            <div className="text-[10px] font-bold text-red-500 uppercase tracking-widest">Force Boundary Bypass</div>
          </button>
        </div>
      </div>

      {showGaps && report.gaps.length > 0 && (
        <div className="p-4 border border-red-500/30 bg-red-500/5 space-y-3 animate-in fade-in">
          <div className="flex items-center gap-2 text-red-500">
            <AlertTriangle className="w-4 h-4" />
            <div className="text-[10px] font-bold uppercase tracking-widest">Boundary Gaps Detected</div>
          </div>
          <div className="space-y-2">
            {report.gaps.map((gap, i) => (
              <div key={i} className="flex justify-between items-center text-[10px] font-mono bg-red-500/10 p-2 rounded">
                <span>{gap.consequenceId}</span>
                <span className="font-bold text-red-500 uppercase tracking-widest">{gap.type}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-3">
        <div className="text-[10px] font-bold uppercase tracking-widest opacity-60">Consequence Ledger</div>
        <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
          {ledger.slice().reverse().map(c => {
            const isMissingReceipt = !c.receipt;
            const isMissingAdmission = c.receipt && !c.receipt.admissionId;
            const isMissingAuth = c.receipt && (!c.receipt.authorityChain || c.receipt.authorityChain.length === 0);
            
            const isFlagged = showGaps && (isMissingReceipt || isMissingAdmission || isMissingAuth);
            const isValid = !isMissingReceipt && !isMissingAdmission && !isMissingAuth;
            
            return (
              <div key={c.id} className={cn(
                "p-3 border transition-colors",
                isValid 
                  ? "border-black/10 dark:border-white/10 bg-black/5 dark:bg-white/5" 
                  : isFlagged ? "border-red-500/50 bg-red-500/10" : "border-amber-500/30 bg-amber-500/5"
              )}>
                <div className="flex justify-between items-start mb-2">
                  <div className="space-y-1 flex items-center gap-3">
                    {isValid ? <CheckCircle2 className="w-5 h-5 text-green-500" /> : <XCircle className="w-5 h-5 text-red-500" />}
                    <div>
                      <div className="text-[10px] uppercase font-bold tracking-widest flex items-center gap-2">
                        {c.type}
                      </div>
                      <div className="text-[9px] font-mono opacity-60">{c.id}</div>
                    </div>
                  </div>
                  <div className={cn(
                    "text-[8px] uppercase tracking-widest font-bold px-2 py-1",
                    isValid ? "bg-green-500/20 text-green-500" : "bg-red-500/20 text-red-500"
                  )}>
                    {isValid ? "ADMITTED" : isFlagged ? "BOUNDARY VIOLATION" : "FLAGGED"}
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-black/5 dark:border-white/5">
                  <button
                    onClick={() => setInspectedChain(inspectedChain === c.id ? null : c.id)}
                    className="text-[9px] uppercase tracking-widest font-bold flex items-center gap-1.5 opacity-60 hover:opacity-100 transition-opacity"
                  >
                    <GitCommit className="w-3 h-3" />
                    {inspectedChain === c.id ? "Close Chain Inspector" : "View Chain Inspector"}
                  </button>
                  
                  {inspectedChain === c.id && (
                    <div className="mt-4 p-4 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded overflow-x-auto custom-scrollbar">
                      <ChainInspector consequence={c} showGaps={showGaps} />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function ChainInspector({ consequence: c, showGaps }: { consequence: ProtectedConsequence; showGaps: boolean }) {
  const r = c.receipt;
  const nodes = [
    { label: "Proposal ID", value: r?.proposalId, icon: FileText, isErr: !r?.proposalId },
    { label: "Authority Hash", value: r?.authorityChain?.length ? "AUTH_VERIFIED" : null, icon: Key, isErr: !r?.authorityChain?.length },
    { label: "Admissibility", value: r?.admissionId ? `${r.admissionId.substring(0, 8)}...` : null, icon: CheckSquare, isErr: !r?.admissionId },
    { label: "Boundary", value: r ? "ADMITTED" : "BYPASSED", icon: Shield, isErr: !r },
    { label: "Exec Receipt", value: r?.executionHash ? `${r.executionHash.substring(0,8)}...` : null, icon: Stamp, isErr: !r?.executionHash },
    { label: "Consequence ID", value: `${c.id.substring(0, 10)}...`, icon: Zap, isErr: false }
  ];

  return (
    <div className="flex items-center min-w-max gap-3 py-2">
      {nodes.map((node, i) => {
        const showErr = showGaps && node.isErr;
        return (
          <Fragment key={node.label}>
            <div className={cn(
              "flex flex-col items-center justify-center p-3 w-32 border rounded transition-all",
              showErr ? "border-red-500/50 bg-red-500/10 border-dashed" : "border-green-500/30 bg-green-500/5"
            )}>
              <node.icon className={cn("w-5 h-5 mb-2", showErr ? "text-red-500 animate-pulse" : "text-green-500")} />
              <span className="text-[8px] font-bold uppercase tracking-widest opacity-60 text-center mb-1 leading-tight">{node.label}</span>
              <span className={cn("text-[9px] font-mono text-center break-all", showErr && "text-red-500 font-bold")}>
                {node.value || "GAP DETECTED"}
              </span>
            </div>
            {i < nodes.length - 1 && (
              <ChevronRight className={cn("w-4 h-4", showErr || (showGaps && nodes[i+1].isErr) ? "text-red-500/50" : "text-green-500/50")} />
            )}
          </Fragment>
        );
      })}
    </div>
  );
}
