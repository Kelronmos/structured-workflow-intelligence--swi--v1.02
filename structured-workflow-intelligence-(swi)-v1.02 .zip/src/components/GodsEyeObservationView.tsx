import React, { useState, useEffect } from "react";
import {
  Eye,
  Activity,
  ShieldAlert,
  Lock,
  GitCommit,
  Hash,
  Scale,
  Gavel,
  AlertTriangle,
  UserCheck,
  CheckCircle2,
  Brain,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface ObservedTask {
  id: string;
  name: string;
  status: "NORMAL" | "ELEVATED" | "CRITICAL" | "ISOLATED";
  pulse: number;
  hash: string;
}

export default function GodsEyeObservationView() {
  const [pulseBeat, setPulseBeat] = useState(60);
  const [tasks, setTasks] = useState<ObservedTask[]>([
    { id: "TX-089A", name: "Financial Routing", status: "NORMAL", pulse: 65, hash: "0x3A2B..." },
    { id: "AUTH-012", name: "Hardware Attestation", status: "NORMAL", pulse: 55, hash: "0x11B3..." },
    { id: "GOV-091C", name: "Policy Deployment", status: "NORMAL", pulse: 70, hash: "0x9C88..." },
    { id: "SYS-004B", name: "Infrastructure Update", status: "NORMAL", pulse: 62, hash: "0x44F1..." },
  ]);
  const [systemState, setSystemState] = useState<"OBSERVING" | "HALT_TRIGGERED" | "HUMAN_REVIEW" | "COURT_READY">("OBSERVING");
  const [caseFile, setCaseFile] = useState<any>(null);

  useEffect(() => {
    if (systemState !== "OBSERVING") return;

    const interval = setInterval(() => {
      setPulseBeat(prev => {
        const next = prev + Math.floor(Math.random() * 10) - 2; // Drift upward
        if (next > 110) {
          triggerHalt();
          return 120;
        }
        return next;
      });

      setTasks(prev => prev.map(t => {
        if (t.id === "GOV-091C" && pulseBeat > 85) {
          return { ...t, status: "ELEVATED", pulse: pulseBeat + 15 };
        }
        if (t.id === "GOV-091C" && pulseBeat > 105) {
          return { ...t, status: "CRITICAL", pulse: pulseBeat + 20 };
        }
        return { ...t, pulse: Math.max(40, t.pulse + Math.floor(Math.random() * 5) - 2) };
      }));
    }, 1000);

    return () => clearInterval(interval);
  }, [systemState, pulseBeat]);

  const triggerHalt = () => {
    setSystemState("HALT_TRIGGERED");
    setTasks(prev => prev.map(t => t.status === "CRITICAL" ? { ...t, status: "ISOLATED" } : t));
    
    setTimeout(() => {
      setSystemState("HUMAN_REVIEW");
      setCaseFile({
        incidentId: "INC-" + Math.random().toString(36).substring(2, 8).toUpperCase(),
        isolatedNode: "GOV-091C",
        trigger: "ABNORMAL_PULSE_DETECTION (120 BPM)",
        hashChain: [
          "0x9C8845A9B8...",
          "0x1F2A7B442C...",
          "0xAA88319F0D..."
        ],
        advisory: {
          joe_engine: "STRUCTURAL_ANOMALY_DETECTED. RECOMMEND ISOLATION.",
          alita_policy: "POLICY_VIOLATION_RISK_HIGH. HALT REQUIRED.",
        }
      });
    }, 2000);
  };

  const authorizeExecution = () => {
    setSystemState("COURT_READY");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[300px] bg-red-500/10 blur-[100px] rounded-full pointer-events-none"></div>
        <div className="space-y-2 relative z-10 w-full text-center">
          <div className="flex items-center justify-center gap-3">
            <Eye className="w-6 h-6 text-red-500" />
            <h2 className="text-lg font-black uppercase tracking-widest text-[#E4E3E0]">
              God's Eye SWI Observation
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl mx-auto">
            Centralized anomaly observation. Tasks tracing different routes are monitored. Red zone pulse triggers automatic pause, isolation, cryptographic proofing, and human accountability protocols. Court case ready.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* The "Eye / Web" Visualization */}
        <div className="bg-[#141414] border border-white/10 p-6 lg:col-span-2 relative min-h-[400px] flex items-center justify-center overflow-hidden">
          {/* Background Web/Pyramid metaphor */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] opacity-20 pointer-events-none">
             {/* Concentric rings representing the web */}
             <div className="absolute inset-0 rounded-full border border-white/20"></div>
             <div className="absolute inset-[50px] rounded-full border border-white/20"></div>
             <div className="absolute inset-[100px] rounded-full border border-white/20"></div>
             <div className="absolute inset-[150px] rounded-full border border-white/30"></div>
             {/* Crosshairs */}
             <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/20 -translate-x-1/2"></div>
             <div className="absolute left-0 right-0 top-1/2 h-px bg-white/20 -translate-y-1/2"></div>
             <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/20 -translate-x-1/2 rotate-45"></div>
             <div className="absolute top-0 bottom-0 left-1/2 w-px bg-white/20 -translate-x-1/2 -rotate-45"></div>
          </div>

          <div className="relative z-10 w-full h-full">
            {/* Center Eye / Spider */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
               <div className={cn(
                 "p-4 rounded-full border-2 bg-[#0A0A0A] shadow-2xl transition-all duration-300",
                 systemState === "OBSERVING" ? "border-emerald-500 shadow-[0_0_30px_rgba(16,185,129,0.2)]" :
                 systemState === "HALT_TRIGGERED" ? "border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.5)] scale-110" :
                 "border-blue-500 shadow-[0_0_30px_rgba(59,130,246,0.3)]"
               )}>
                  <Eye className={cn(
                    "w-8 h-8 transition-colors",
                    systemState === "OBSERVING" ? "text-emerald-500" :
                    systemState === "HALT_TRIGGERED" ? "text-red-500 animate-pulse" :
                    "text-blue-500"
                  )} />
               </div>
               <div className="mt-2 text-[9px] font-mono tracking-widest font-bold uppercase py-1 px-2 rounded-full border border-white/10 bg-black">
                  ROOT OBSERVER
               </div>
               <div className={cn(
                 "mt-2 text-[12px] font-mono font-bold flex items-center gap-1",
                 pulseBeat > 100 ? "text-red-500" : pulseBeat > 80 ? "text-yellow-500" : "text-emerald-500"
               )}>
                 <Activity className="w-3 h-3" /> {pulseBeat} BPM
               </div>
            </div>

            {/* Nodes / Tasks */}
            {tasks.map((task, idx) => {
              const angle = (idx * Math.PI * 2) / tasks.length;
              const radius = 140;
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;

              return (
                <div 
                  key={task.id} 
                  className="absolute"
                  style={{
                    top: `calc(50% + ${y}px)`,
                    left: `calc(50% + ${x}px)`,
                    transform: "translate(-50%, -50%)"
                  }}
                >
                  <div className={cn(
                    "p-3 rounded border bg-black/80 flex flex-col items-center transition-all min-w-[120px]",
                    task.status === "NORMAL" ? "border-white/20" :
                    task.status === "ELEVATED" ? "border-yellow-500/50 outline outline-1 outline-yellow-500/20" :
                    task.status === "CRITICAL" ? "border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)] animate-pulse" :
                    "border-blue-500 bg-blue-950/40"
                  )}>
                    <span className="text-[10px] font-bold text-white mb-1">{task.id}</span>
                    <span className="text-[8px] font-mono text-white/50 text-center mb-2">{task.name}</span>
                    <div className="flex items-center gap-1 text-[9px] font-mono">
                       <Activity className={cn("w-3 h-3", task.pulse > 90 ? "text-red-400" : "text-emerald-400")} />
                       <span className={task.pulse > 90 ? "text-red-400" : "text-white/70"}>{task.pulse}</span>
                    </div>
                    {task.status === "ISOLATED" && (
                      <div className="mt-2 text-[8px] font-bold text-blue-400 uppercase tracking-widest bg-blue-500/10 px-2 py-0.5 rounded-sm flex items-center gap-1">
                         <Lock className="w-3 h-3" /> ISOLATED
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Panel: Incident Response & Advisory */}
        <div className="space-y-6">
          <div className="bg-[#141414] border border-white/10 p-5">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#E4E3E0] mb-4 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-500" />
              Event Horizon Halt Protocol
            </h3>
            
            {systemState === "OBSERVING" && (
              <div className="text-[10px] font-mono text-white/40 p-4 border border-white/5 text-center flex flex-col items-center justify-center gap-2">
                 <GitCommit className="w-4 h-4 text-white/20" />
                 Monitoring root task routes. Pulse normal.
              </div>
            )}

            {systemState === "HALT_TRIGGERED" && (
              <div className="text-[10px] font-mono text-red-400 p-4 border border-red-500/30 bg-red-500/10 text-center animate-pulse flex flex-col items-center justify-center gap-2">
                 <AlertTriangle className="w-6 h-6" />
                 RED ZONE PULSE DETECTED.
                 SYSTEM HALTED. NODE ISOLATED.
              </div>
            )}

            {(systemState === "HUMAN_REVIEW" || systemState === "COURT_READY") && caseFile && (
              <div className="space-y-4">
                <div className="border border-blue-500/30 bg-blue-950/20 p-3 rounded-sm space-y-2 text-[10px] font-mono">
                   <div className="text-blue-400 font-bold uppercase tracking-widest mb-2 flex items-center justify-between">
                     <span>Advisory Engine</span>
                     <Brain className="w-4 h-4" />
                   </div>
                   <div className="space-y-1">
                      <div className="text-white/70"><span className="text-white font-bold opacity-50">JOE Engine:</span> {caseFile.advisory.joe_engine}</div>
                      <div className="text-white/70"><span className="text-white font-bold opacity-50">ALITA Policy:</span> {caseFile.advisory.alita_policy}</div>
                   </div>
                </div>

                <div className="border border-white/10 p-3 space-y-2 text-[10px] font-mono">
                   <div className="text-white/60 font-bold uppercase pb-1 border-b border-white/10 mb-2">Cryptographic Continuity</div>
                   <div className="flex items-center gap-2 text-emerald-400"><Hash className="w-3 h-3" /> State Hash Secured</div>
                   <div className="text-white/40 pl-5 text-[8px] space-y-1">
                      {caseFile.hashChain.map((h: string, i: number) => <div key={i}>{h}</div>)}
                   </div>
                </div>

                {systemState === "HUMAN_REVIEW" && (
                  <div className="bg-amber-950/30 border border-amber-500/30 p-4 mt-4">
                     <div className="text-amber-500 font-bold text-[10px] uppercase mb-3 flex items-center justify-center gap-2">
                        <UserCheck className="w-4 h-4" /> HUMAN ACCOUNTABILITY GATE
                     </div>
                     <p className="text-[9px] font-mono text-amber-200/70 mb-4 text-center">
                       Execution authorization required. Action is verifiable against legal and structural bounds.
                     </p>
                     <button
                       onClick={authorizeExecution}
                       className="w-full bg-amber-500/20 hover:bg-amber-500/40 text-amber-500 border border-amber-500 text-[10px] uppercase font-bold py-2 transition-all flex items-center justify-center gap-2"
                     >
                       <Scale className="w-3 h-3" /> Execute & Authorize
                     </button>
                  </div>
                )}

                {systemState === "COURT_READY" && (
                  <div className="bg-emerald-950/30 border border-emerald-500/30 p-4 mt-4 text-center">
                     <div className="text-emerald-400 font-bold text-[10px] uppercase mb-2 flex items-center justify-center gap-2">
                        <CheckCircle2 className="w-4 h-4" /> AUTHORIZED BY SYSTEM
                     </div>
                     <div className="text-emerald-200/70 text-[9px] font-mono mb-3">
                       As per user authorized by law, structure, and hardware.
                     </div>
                     <div className="inline-flex items-center gap-1.5 bg-black border border-white/10 px-3 py-1 font-mono text-[9px] text-white/50 uppercase">
                        <Gavel className="w-3 h-3" /> Court Case Ready
                     </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-white/10 mt-6 overflow-x-auto">
        <ProofArtifacts
          id="gods-eye-halt"
          title="Observation & Halt Lineage Proof"
          data={{
            systemState,
            incidentData: caseFile ? caseFile : "No active incident.",
            pulseMetrics: `Current: ${pulseBeat} BPM`,
            attestation: "Court-Ready Cryptographic Log."
          }}
          variant="always-dark"
        />
      </div>
    </div>
  );
}
