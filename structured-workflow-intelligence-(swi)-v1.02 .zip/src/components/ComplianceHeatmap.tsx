import React, { useEffect, useState } from "react";
import { AdmissibilityResult } from "../swi/InvariantValidator";
import { Shield, CheckCircle2, AlertTriangle } from "lucide-react";
import { cn } from "@/src/lib/utils";

export default function ComplianceHeatmap() {
  const [results, setResults] = useState<AdmissibilityResult[]>([]);

  useEffect(() => {
    const fetchAdmissibility = async () => {
      try {
        // Fallback to mock data since API is not available in browser build
        setResults([
          { 
            traceId: "b0c1x9", 
            overallStatus: "PASS" as const,
            evaluations: [{ name: "No Commercial Advertising", status: "PASS" as const, invariantId: "inv-1", severity: "CRITICAL" as const }] 
          }
        ]);
      } catch (e) {
        console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch admissibility", e);
      }
    };

    fetchAdmissibility();
    const inv = setInterval(fetchAdmissibility, 2000);
    return () => clearInterval(inv);
  }, []);

  if (results.length === 0) {
    return (
      <div className="p-6 border border-slate-800 bg-slate-900 rounded-md">
        <div className="text-center py-8 text-slate-500 font-mono text-xs uppercase font-bold tracking-widest">
          Awaiting Execution Traces...
        </div>
      </div>
    );
  }

  // Get unique invariant IDs from the first result or all results
  const invariantNames = results[0]?.evaluations.map(e => e.name) || [];

  return (
    <div className="p-6 border border-slate-800 bg-slate-950 rounded-md">
      <div className="flex items-center gap-2 mb-6 border-b pb-4 border-slate-800">
        <Shield className="w-5 h-5 text-indigo-400" />
        <h3 className="text-sm font-bold uppercase tracking-widest text-slate-200">Compliance Heatmap</h3>
      </div>
      
      <div className="overflow-x-auto custom-scrollbar pb-4">
        <table className="w-full text-left border-collapse min-w-max">
          <thead>
            <tr>
              <th className="p-2 border-b border-slate-800 text-[10px] font-mono text-slate-500 uppercase">Invariant Rule</th>
              {results.map((r, i) => (
                <th key={r.traceId} className="p-2 border-b border-slate-800 text-[8px] font-mono text-slate-500 font-normal">
                  <div className="truncate w-12" title={r.traceId}>{r.traceId.substring(0, 8)}</div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {invariantNames.map((name, invIdx) => (
              <tr key={name} className="hover:bg-slate-900/50">
                <td className="p-2 border-b border-slate-800/50 text-[10px] font-bold text-slate-300 w-48 truncate" title={name}>
                  {name}
                </td>
                {results.map((r) => {
                  const evalRes = r.evaluations[invIdx];
                  const isPass = evalRes?.status === "PASS";
                  return (
                    <td key={r.traceId} className="p-2 border-b border-slate-800/50 text-center">
                      <div 
                        className={cn(
                          "w-3 h-3 mx-auto rounded-sm",
                          isPass ? "bg-emerald-500" : "bg-red-500"
                        )}
                        title={`${name}: ${evalRes?.status}`}
                      />
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="flex items-center gap-4 mt-4 pt-4 border-t border-slate-800 text-[10px] font-mono">
        <div className="flex items-center gap-1.5 text-emerald-400">
          <div className="w-3 h-3 rounded-sm bg-emerald-500" /> PASS
        </div>
        <div className="flex items-center gap-1.5 text-red-400">
          <div className="w-3 h-3 rounded-sm bg-red-500" /> FAIL
        </div>
      </div>
    </div>
  );
}
