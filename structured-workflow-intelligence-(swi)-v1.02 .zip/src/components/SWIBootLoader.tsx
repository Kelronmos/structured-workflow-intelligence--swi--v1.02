import React, { useState, useEffect } from 'react';
import { SWIProgress } from './common/SWIProgress';
import { Shield } from 'lucide-react';

const BOOT_STAGES = [
    "Kernel Initialization",
    "Authority Validation",
    "Ethics Enforcement",
    "Audit Synchronization"
];

interface SWIBootLoaderProps {
    onComplete: () => void;
}

export const SWIBootLoader: React.FC<SWIBootLoaderProps> = ({ onComplete }) => {
    const [progress, setProgress] = useState(0);
    const [stageIdx, setStageIdx] = useState(0);
    const [logs, setLogs] = useState<string[]>([]);
    const [exiting, setExiting] = useState(false);

    useEffect(() => {
        let currentProgress = 0;
        let isMounted = true;
        const interval = setInterval(() => {
            currentProgress += Math.random() * 2.5; 
            if (currentProgress >= 100) {
                currentProgress = 100;
                clearInterval(interval);
                if (isMounted) {
                   setProgress(100);
                   setStageIdx(3);
                   setExiting(true);
                   setTimeout(onComplete, 1200);
                }
                return;
            }
            if (isMounted) {
               setProgress(currentProgress);
               
               // Map progress to stages
               const mappedStage = Math.min(Math.floor(currentProgress / 25), 3);
               if (mappedStage > stageIdx) {
                   setStageIdx(mappedStage);
                   setLogs(prev => [`[SYS] ${BOOT_STAGES[mappedStage - 1]}... OK`, ...prev]);
               }
            }
        }, 50);

        return () => {
           clearInterval(interval);
           isMounted = false;
        };
    }, [onComplete, stageIdx]);

    return (
        <div className={`fixed inset-0 z-50 bg-[#0a0a0a] flex items-center justify-center p-4 transition-all duration-1000 ${exiting ? 'opacity-0 scale-105 blur-sm' : 'opacity-100 scale-100 blur-none'}`}>
             <div className="w-full max-w-md space-y-10 p-8">
                 <div className="flex flex-col items-center justify-center space-y-8 text-center">
                     <div className="relative">
                         <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full animate-pulse" />
                         <Shield className="w-20 h-20 text-blue-400 relative drop-shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
                     </div>
                     <div className="space-y-3">
                         <h2 className="text-3xl font-bold font-serif text-white tracking-[0.2em] uppercase">SWI <span className="text-blue-400">V1.01</span></h2>
                         <p className="font-mono text-sm text-blue-400/80 uppercase tracking-widest bg-blue-500/10 py-1.5 px-4 rounded-full border border-blue-500/20 inline-block">
                             {BOOT_STAGES[stageIdx]}
                         </p>
                     </div>
                 </div>

                 <div className="space-y-3">
                     <div className="flex justify-between font-mono text-xs text-white/50 tracking-wider">
                         <span>BOOT SEQUENCE</span>
                         <span className="text-cyan-400">{Math.floor(progress)}%</span>
                     </div>
                     <SWIProgress percent={progress} />
                 </div>
                 
                 <div className="font-mono flex flex-col gap-1.5 text-xs text-white/30 h-24 overflow-hidden relative" style={{ maskImage: 'linear-gradient(to bottom, black 20%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, black 20%, transparent 100%)' }}>
                    <div className="text-blue-400 opacity-90 truncate animate-pulse">[SYS] {BOOT_STAGES[stageIdx]}... IN PROGRESS</div>
                    {logs.map((log, i) => (
                        <div key={i} className="opacity-60 truncate">{log}</div>
                    ))}
                 </div>
             </div>
        </div>
    );
};
