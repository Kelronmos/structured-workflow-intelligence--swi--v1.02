import React, { useEffect, useState } from 'react';
import { CheckCircle2, ChevronRight, Terminal, LayoutDashboard } from 'lucide-react';

interface SystemReadyProps {
    onOpenDashboard: () => void;
    onOpenConsole: () => void;
}

export const SystemReady: React.FC<SystemReadyProps> = ({ onOpenDashboard, onOpenConsole }) => {
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    return (
        <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center space-y-10 p-12 text-center animate-in fade-in duration-700">
            <div className="relative">
                <div className={`absolute inset-0 bg-emerald-500/30 blur-[40px] rounded-full transition-all duration-1000 ${mounted ? 'scale-150 opacity-50' : 'scale-50 opacity-0'}`} />
                <CheckCircle2 className={`relative w-36 h-36 text-emerald-400 drop-shadow-[0_0_15px_rgba(52,211,153,0.5)] transition-all duration-700 delay-300 ${mounted ? 'scale-100 opacity-100' : 'scale-50 opacity-0'}`} strokeWidth={1.5} />
            </div>
            
            <div className={`space-y-4 transition-all duration-700 delay-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
                <h1 className="text-4xl font-bold font-serif italic text-white tracking-wide">System Ready</h1>
                <p className="text-white/60 max-w-md mx-auto text-lg">
                    The Structured Workflow Intelligence (SWI) has been successfully provisioned. All integrity anchors and consensus modules are currently active.
                </p>
            </div>

            <div className={`bg-black/40 backdrop-blur-md border border-white/10 rounded-2xl p-8 w-full text-left space-y-6 shadow-2xl transition-all duration-700 delay-700 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
                <h3 className="font-mono text-sm text-white/50 uppercase tracking-widest">Active Core Components</h3>
                <ul className="space-y-4 font-mono text-sm">
                    <li className="flex justify-between items-center text-white/80 border-b border-white/5 pb-2">
                        <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>ZkOS Kernel</span> 
                        <span className="text-emerald-400 px-2 py-0.5 bg-emerald-400/10 rounded">ONLINE</span>
                    </li>
                    <li className="flex justify-between items-center text-white/80 border-b border-white/5 pb-2">
                        <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>Ethical Enforcement Matrix</span> 
                        <span className="text-emerald-400 px-2 py-0.5 bg-emerald-400/10 rounded">ONLINE</span>
                    </li>
                    <li className="flex justify-between items-center text-white/80 border-b border-white/5 pb-2">
                        <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>Byzantine Consensus Nodes</span> 
                        <span className="text-emerald-400 px-2 py-0.5 bg-emerald-400/10 rounded">ONLINE</span>
                    </li>
                    <li className="flex justify-between items-center text-white/80 border-b border-white/5 pb-2">
                        <span className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>Immutable Audit Trail</span> 
                        <span className="text-emerald-400 px-2 py-0.5 bg-emerald-400/10 rounded">ONLINE</span>
                    </li>
                </ul>
            </div>

            <div className={`flex w-full gap-4 pt-6 transition-all duration-700 delay-1000 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
                <button 
                  onClick={onOpenConsole}
                  className="flex-1 py-4 px-6 bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 text-white font-medium rounded-xl flex items-center justify-center gap-3 transition-all duration-300 group"
                >
                    <Terminal className="w-5 h-5 text-white/40 group-hover:text-white/70 transition-colors" />
                    Open Debug Console
                </button>
                <button 
                  onClick={onOpenDashboard}
                  className="flex-[2] py-4 px-6 bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/40 font-medium rounded-xl flex items-center justify-center gap-3 transition-all duration-300 transform hover:-translate-y-0.5 group"
                >
                    <LayoutDashboard className="w-5 h-5" />
                    Launch Dashboard
                    <ChevronRight className="w-5 h-5 opacity-50 group-hover:translate-x-1 group-hover:opacity-100 transition-all" />
                </button>
            </div>
        </div>
    );
};
