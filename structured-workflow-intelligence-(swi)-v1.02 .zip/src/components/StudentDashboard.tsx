import React, { useState } from "react";
import {
  Users,
  Activity,
  AlertTriangle,
  Sparkles,
  Sliders,
  FileCheck,
  Brain,
  Scale,
  Fingerprint,
  CheckCircle2,
  FileText,
  Shield,
  Gavel,
  Database
} from "lucide-react";
import { cn } from "../lib/utils";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

// ==========================================
// SWIAIAssistant Sub-component Interfacing
// ==========================================
interface Student {
  id: string;
  name: string;
  region: string;
  attendance: number;
  performance: number;
  participation: number;
  incidents: number;
  engagement: number;
  sleep: number;
  mood: number;
}

interface IAIAssistantProps {
  student: Student;
  history: string[];
  onTriggerSuggestion: () => void;
  loading: boolean;
}

export function SWIAIAssistant({ student, history, onTriggerSuggestion, loading }: IAIAssistantProps) {
  return (
    <div className="bg-[#0a0a0a] border border-white/10 p-5 space-y-4 rounded-lg relative overflow-hidden">
      <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/5 blur-[60px] pointer-events-none"></div>
      <div className="flex justify-between items-center border-b border-white/10 pb-3">
        <h3 className="text-sm font-bold uppercase tracking-widest text-blue-400 flex items-center gap-2">
          <Brain className="w-4 h-4" /> SWI AI Assistant Engine
        </h3>
        <span className="text-[10px] font-mono text-white/40">Status: Secure Active v3.5</span>
      </div>

      <div className="space-y-3">
        <div className="text-xs text-white/70 leading-relaxed font-sans bg-blue-500/10 p-3 rounded border border-blue-500/20">
          <strong className="text-blue-400 block mb-2 uppercase tracking-widest text-[10px]">AI Suggestions Are Advisory Only.</strong>
          <span className="text-[10px] uppercase font-bold text-white/50 mb-1 block">The AI:</span>
          <ul className="space-y-1.5 text-[10px] font-mono text-white/80">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-blue-400" /> Cannot grade students</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-blue-400" /> Cannot punish students</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-blue-400" /> Cannot change records</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-blue-400" /> Cannot make disciplinary decisions</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-blue-400" /> Cannot rank wellbeing</li>
          </ul>
        </div>

        <button
          onClick={onTriggerSuggestion}
          disabled={loading}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs uppercase tracking-widest transition-all disabled:opacity-40 flex items-center justify-center gap-2 border border-blue-500/30"
        >
          {loading ? (
            <Activity className="w-4.5 h-4.5 animate-spin" />
          ) : (
            <>
              <Sparkles className="w-4.5 h-4.5" />
              Trigger Proactive AI Suggestion
            </>
          )}
        </button>

        {/* Local suggestions log */}
        <div className="space-y-2 mt-4">
          <h4 className="text-[10px] uppercase font-bold text-white/50 tracking-wider">AI Suggestion History Audit Trail</h4>
          {history.length === 0 ? (
            <p className="text-[11px] italic text-white/30">No proactive advice triggered yet. Click the generator button to output state suggestions.</p>
          ) : (
            <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
              {history.map((item, idx) => (
                <div key={idx} className="p-2.5 bg-white/5 border border-white/5 rounded text-xs leading-relaxed space-y-1">
                  <div className="flex justify-between text-[9px] text-white/40 font-mono">
                    <span>SUGGESTION {idx + 1}</span>
                    <span>UTC RECEIVED</span>
                  </div>
                  <div className="text-white/90 font-serif">{item}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


// ==========================================
// Main StudentDashboard Component
// ==========================================
export default function StudentDashboard() {
  // Preset Botswana educational nodes and students
  const baselineStudents: Student[] = [
    {
      id: "student_4477",
      name: "Student 4477",
      region: "Gaborone West District Node",
      attendance: 0.92,
      performance: 0.81,
      participation: 0.75,
      incidents: 0.05,
      engagement: 0.88,
      sleep: 6.0,
      mood: 0.8
    },
    {
      id: "student_4592",
      name: "Student 4592",
      region: "Francistown Central Node",
      attendance: 0.85,
      performance: 0.78,
      participation: 0.60,
      incidents: 0.10,
      engagement: 0.75,
      sleep: 5.5,
      mood: 0.6
    },
    {
      id: "student_4601",
      name: "Student 4601",
      region: "Maun Delta Node",
      attendance: 0.96,
      performance: 0.91,
      participation: 0.85,
      incidents: 0.0,
      engagement: 0.93,
      sleep: 7.0,
      mood: 0.9
    }
  ];

  const [students, setStudents] = useState<Student[]>(baselineStudents);
  const [selectedId, setSelectedId] = useState("student_4477");
  const activeStudent = students.find(s => s.id === selectedId) || students[0];

  // Specific student assignments list styled with status badges ('Pending', 'Submitted', 'Graded')
  const assignmentsData: Record<string, { title: string; category: string; status: "Pending" | "Submitted" | "Graded"; date: string }[]> = {
    student_4477: [
      { title: "Gaborone Local Geography Project", category: "Social Studies", status: "Graded", date: "2026-05-10" },
      { title: "Calculus Limits Portfolio Tasks", category: "Mathematics", status: "Submitted", date: "2026-05-22" },
      { title: "Student Advocacy Wellbeing Diary Part 1", category: "SAMH Studies", status: "Pending", date: "2026-05-28" }
    ],
    student_4592: [
      { title: "Botswana Pre-Independence Constitutional Outline", category: "Civics", status: "Submitted", date: "2026-05-20" },
      { title: "Immutable Graph Node Intersect Formulas", category: "Computer Science", status: "Pending", date: "2026-05-29" },
      { title: "Vector Calculus Integration Exercises", category: "Mathematics", status: "Graded", date: "2026-05-08" }
    ],
    student_4601: [
      { title: "Environmental Delta Biosphere Report", category: "Sciences", status: "Graded", date: "2026-05-15" },
      { title: "Algorithmic Ethics Essay", category: "Leadership & Rights", status: "Graded", date: "2026-05-19" },
      { title: "SAMH Advocacy Public Speaking Session Video", category: "SAMH Studies", status: "Submitted", date: "2026-05-24" }
    ]
  };

  const activeAssignments = assignmentsData[selectedId] || [];

  // Suggestions history for each student
  const [aiSuggestions, setAiSuggestions] = useState<Record<string, string[]>>({
    student_4477: [],
    student_4592: [],
    student_4601: []
  });

  const [aiLoading, setAiLoading] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Gaborone Protocol - R. Mosidila Signature States
  // "new signed with smaller Edward scrit, R. Mosidila any modification r.mosidila disappear n pull report for review approve or escalate to tech, or denies"
  const [signatureActive, setSignatureActive] = useState(true);
  const [isModified, setIsModified] = useState(false);
  const [reviewStatus, setReviewStatus] = useState<"IDLE" | "PENDING_REVIEW" | "APPROVED" | "DENIED" | "ESCALATED">("IDLE");
  const [reviewLog, setReviewLog] = useState<string[]>([
    "[LEDGER] Signature signed initially by Ronald Mosidila",
    "[STATUS] Verification Status: Invariants (12/12), Audit (7/7), Ethical (15/15)."
  ]);

  // Handle adjustments of sliders
  const handleMetricChange = (field: keyof Student, val: number) => {
    // If we make modifications:
    // 1) r.mosidila signature immediately disappears!
    // 2) pulls active dossier report for manual review (PENDING_REVIEW)
    if (signatureActive && !isModified) {
      setSignatureActive(false);
      setIsModified(true);
      setReviewStatus("PENDING_REVIEW");
      setReviewLog(prev => [
        `[SIGNATURE_ALERT] Parameter '${field}' modified to ${val}. Mosidila signature has disappeared! Report pulled for verification review.`,
        ...prev
      ]);
    }

    setStudents(prev => prev.map(s => {
      if (s.id === selectedId) {
        return { ...s, [field]: val };
      }
      return s;
    }));
  };

  const handleApprove = () => {
    setSignatureActive(true);
    setIsModified(false);
    setReviewStatus("APPROVED");
    setReviewLog(prev => [
      `[ADMIN_ACTION] Supervisor approved modified student metrics dossier. Signature fully restored. Ronald Mosidila Security Seal active.`,
      ...prev
    ]);
  };

  const handleDeny = () => {
    // Revert to baselines
    setStudents(baselineStudents);
    setSignatureActive(true);
    setIsModified(false);
    setReviewStatus("DENIED");
    setReviewLog(prev => [
      `[ADMIN_ACTION] Review denied. Reverted all student vectors to safe baselines. Signature fully reasserted.`,
      ...prev
    ]);
  };

  const handleEscalate = () => {
    setReviewStatus("ESCALATED");
    setReviewLog(prev => [
      `[ESCALATION] System modifications escalated directly to District Tech Council for hardware review. Signature locked in validation queue.`,
      ...prev
    ]);
  };

  const triggerProactiveSuggestion = () => {
    setAiLoading(true);
    setTimeout(() => {
      let advice = "";
      if (activeStudent.mood < 0.7 || activeStudent.sleep < 6) {
        advice = `[SWI RECOMMENDATION] Active mental-hygiene check required. Sleep index is ${activeStudent.sleep} Hr, mood score is ${activeStudent.mood * 10}/10. Protect the minor from excessive academic pressure. Support intrinsic intuition.`;
      } else if (activeStudent.performance < 0.8) {
        advice = `[SWI RECOMMENDATION] Build auxiliary classroom study aids without visible performance ranking. The student shows strong participation (${Math.round(activeStudent.participation * 100)}%). Leverage participation over stressful exam reviews.`;
      } else {
        advice = `[SWI RECOMMENDATION] Optimal baseline aligned. Recommend advanced elective studies in zero-trust ledger compliance and leadership rights. Maintaining high wellbeing markers.`;
      }

      setAiSuggestions(prev => ({
        ...prev,
        [selectedId]: [advice, ...(prev[selectedId] || [])]
      }));
      setAiLoading(false);
    }, 1200);
  };

  const generatePDF = async () => {
    setIsGeneratingPdf(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));

      const doc = new jsPDF();
      
      const pageWidth = doc.internal.pageSize.width;
      const pageHeight = doc.internal.pageSize.height;

      // Custom Header
      doc.setFillColor(30, 30, 30);
      doc.rect(0, 0, pageWidth, 40, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.setFont("helvetica", "bold");
      doc.text("SWI Analytics Report", 14, 25);
      
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`Region: ${activeStudent.region}`, pageWidth - 14, 25, { align: "right" });
      
      // Basic Info
      doc.setTextColor(50, 50, 50);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text(`Student Profile: ${activeStudent.name}`, 14, 55);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`Student ID: ${activeStudent.id}`, 14, 62);
      doc.text(`Date Generated: ${new Date().toLocaleDateString()}`, 14, 68);

      // Metrics Table
      doc.setFontSize(14);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(20, 20, 20);
      doc.text("Current Metrics", 14, 85);
      
      autoTable(doc, {
        startY: 90,
        headStyles: { fillColor: [150, 50, 150], textColor: [255, 255, 255] },
        alternateRowStyles: { fillColor: [245, 245, 245] },
        head: [["Metric Category", "Value"]],
        body: [
          ["Attendance Rate", `${(activeStudent.attendance * 100).toFixed(0)}%`],
          ["Performance Index", `${(activeStudent.performance * 100).toFixed(0)}%`],
          ["Participation Level", `${(activeStudent.participation * 100).toFixed(0)}%`],
          ["Engagement Score", `${(activeStudent.engagement * 100).toFixed(0)}%`],
          ["Rest / Sleep Index", `${activeStudent.sleep} Hours`],
          ["Average Mood Score", `${(activeStudent.mood * 10).toFixed(0)} / 10`],
          ["Recorded Incidents", `${activeStudent.incidents}`]
        ]
      });

      // Assignments Table
      let finalY = (doc as any).lastAutoTable.finalY || 150;
      doc.setFontSize(14);
      doc.text("Academic Assignments", 14, finalY + 15);
      
      autoTable(doc, {
        startY: finalY + 20,
        headStyles: { fillColor: [50, 50, 50] },
        head: [["Title", "Category", "Status", "Date"]],
        body: activeAssignments.map(a => [a.title, a.category, a.status, a.date])
      });

      // AI Suggestions Table
      finalY = (doc as any).lastAutoTable.finalY || finalY + 50;
      doc.setFontSize(14);
      doc.text("AI Governance Suggestions", 14, finalY + 15);
      
      const suggestionsBody = aiSuggestions[selectedId]?.length 
        ? aiSuggestions[selectedId].map(s => [s]) 
        : [["No suggestions generated yet."]];
        
      autoTable(doc, {
        startY: finalY + 20,
        headStyles: { fillColor: [50, 100, 150] },
        head: [["Analysis Output"]],
        body: suggestionsBody
      });

      // Footer
      const totalPages = (doc.internal as any).getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(9);
        doc.setTextColor(150);
        doc.text(
          `Page ${i} of ${totalPages}  |  SWI Secure Report Engine`,
          pageWidth / 2,
          pageHeight - 10,
          { align: "center" }
        );
      }

      doc.save(`SWI_Report_${activeStudent.id}.pdf`);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div id="student-dashboard" className="space-y-6 max-w-7xl mx-auto p-1 text-white animate-in fade-in duration-300">
      
      {/* Upper Grid - Profile selector & Live Signature Seal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Profile Card Selector */}
        <div className="lg:col-span-2 bg-[#0c0c0c] border border-white/10 p-5 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start flex-wrap gap-4">
              <h2 className="text-xl font-black uppercase tracking-widest text-white font-serif flex items-center gap-2">
                <Users className="w-5 h-5 text-fuchsia-500" />
                Governance-Aware Student Analytics & Insights
              </h2>
              <button
                onClick={generatePDF}
                disabled={isGeneratingPdf}
                className="bg-fuchsia-600 hover:bg-fuchsia-500 text-white px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-2 transition-colors rounded-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGeneratingPdf ? (
                  <>
                    <Activity className="w-3.5 h-3.5 animate-spin" /> Generating...
                  </>
                ) : (
                  <>
                    <FileText className="w-3.5 h-3.5" /> Download PDF Report
                  </>
                )}
              </button>
            </div>
            <p className="text-xs text-white/55 mt-1">
              Select student node files to monitor, analyze, and provide decision support recommendations within safe ethical benchmarks.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            {students.map(s => (
              <button
                key={s.id}
                onClick={() => setSelectedId(s.id)}
                className={cn(
                  "p-4 border text-left transition-all relative overflow-hidden",
                  selectedId === s.id
                    ? "border-fuchsia-500 bg-fuchsia-500/5 text-white"
                    : "border-white/10 bg-[#070707] text-white/60 hover:border-white/30"
                )}
              >
                <div className="text-xs font-mono text-fuchsia-400 font-bold">{s.id}</div>
                <div className="font-bold text-sm mt-1">{s.name}</div>
                <div className="text-[10px] mt-1 opacity-60 font-mono">{s.region}</div>
                {selectedId === s.id && (
                  <div className="absolute right-2 top-2 w-2 h-2 rounded-full bg-fuchsia-500 animate-ping"></div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Dynamic Trust Signature Seal Module */}
        <div className="bg-[#0b0b0b] border border-white/10 p-5 space-y-4 flex flex-col justify-between relative overflow-hidden">
          <div className={cn(
            "p-3 border rounded text-xs flex flex-col gap-1",
            signatureActive 
              ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-300"
              : "bg-red-950/20 border-red-500/30 text-red-300 animate-pulse"
          )}>
            <div className="flex justify-between items-center font-bold">
              <span className="uppercase tracking-wider flex items-center gap-1.5 text-[10px]">
                <Fingerprint className="w-4 h-4" />
                SWI Node Verification Seal
              </span>
              <span className={cn(
                "px-2 py-0.5 rounded text-[8px] font-mono",
                signatureActive ? "bg-emerald-500/40 text-white" : "bg-red-500/40 text-white"
              )}>
                {signatureActive ? "SIGNED" : "SUSPENDED"}
              </span>
            </div>

            {signatureActive ? (
              <div className="font-mono text-[10px] mt-2 space-y-1">
                <div className="flex items-center gap-1 text-emerald-400 mb-2"><CheckCircle2 className="w-3 h-3" /> Verified</div>
                <div className="flex justify-between items-center gap-4">
                  <span className="opacity-60">Hash:</span>
                  <span className="text-[9px] bg-black/40 px-1 rounded truncate">0xA7D3f9e8b2c41094002d1</span>
                </div>
                <div className="flex justify-between items-center gap-4">
                  <span className="opacity-60">Signed By:</span>
                  <strong className="text-white">Ronald Mosidila</strong>
                </div>
                <div className="flex justify-between items-center gap-4">
                  <span className="opacity-60">Time:</span>
                  <span className="text-[9px]">2026-05-29T18:00:00Z</span>
                </div>
              </div>
            ) : (
              <div className="text-left py-1 text-[11px] leading-relaxed space-y-1">
                <p className="font-black text-red-400">SIGNATURE INVALIDATED</p>
                <p className="text-[10px] uppercase font-bold opacity-80 font-mono">REQUIRES RE-SIGNING</p>
              </div>
            )}
          </div>

          {/* Interactive Review Actions if signature disappears */}
          {reviewStatus === "PENDING_REVIEW" && (
            <div className="p-3 bg-white/5 border border-white/10 rounded space-y-2">
              <div className="text-[9px] uppercase font-bold text-yellow-400 tracking-wider">Awaiting Manual Sign-Off:</div>
              <div className="flex flex-col gap-1.5">
                <button
                  onClick={handleApprove}
                  className="w-full py-1.5 bg-emerald-700 hover:bg-emerald-600 font-bold text-[10px] uppercase tracking-wider text-white transition-colors"
                >
                  Approve Updates
                </button>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleDeny}
                    className="py-1.5 bg-red-800 hover:bg-red-700 font-bold text-[10px] uppercase tracking-wider text-white transition-colors"
                  >
                    Deny & Revert
                  </button>
                  <button
                    onClick={handleEscalate}
                    className="py-1.5 bg-zinc-800 hover:bg-zinc-700 font-bold text-[9px] uppercase tracking-wider text-yellow-400 transition-colors"
                  >
                    Escalate to Tech
                  </button>
                </div>
              </div>
            </div>
          )}

          {reviewStatus === "ESCALATED" && (
            <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 text-yellow-300 rounded text-xs space-y-1.5">
              <div className="font-bold uppercase tracking-wider text-[10px]">Escalated to Tech Council</div>
              <p className="text-[10px] opacity-85 leading-relaxed">
                Changes submitted. Waiting for technocratic ledger approval before signature re-assertion.
              </p>
              <button
                onClick={() => {
                  setSignatureActive(true);
                  setReviewStatus("IDLE");
                }}
                className="px-2 py-1 bg-yellow-500 text-black text-[9px] font-bold uppercase hover:bg-yellow-400 transition-colors"
              >
                Force Release Lock
              </button>
            </div>
          )}

          <div className="text-[9px] font-mono text-white/30 max-h-24 overflow-y-auto space-y-1 border-t border-white/5 pt-2">
            {reviewLog.slice(0, 3).map((log, index) => (
              <div key={index} className="truncate">{log}</div>
            ))}
          </div>
        </div>

      </div>

      {/* Main Grid - Metrics & Sliders vs Assignments List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Sliders & Parameters (Metrics Adjustment) */}
        <div className="bg-[#0b0b0b] border border-white/10 p-5 space-y-5">
          <div className="border-b border-white/10 pb-2">
            <h3 className="text-sm font-bold uppercase tracking-widest text-fuchsia-400 flex items-center gap-1.5">
              <Sliders className="w-4 h-4" /> Student Vector Parameters
            </h3>
            <p className="text-[10px] text-white/50 mt-1">
              Adjust sliders to balance student loads. Note: Tweaking these will trigger a verification audit, suspending signatures.
            </p>
          </div>

          <div className="space-y-4">
            {/* Slide 1: Sleep Hours */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/60">Sleep Hours</span>
                <span className="text-fuchsia-400 font-bold">{activeStudent.sleep} Hr</span>
              </div>
              <input
                type="range"
                min="4.0"
                max="9.0"
                step="0.1"
                value={activeStudent.sleep}
                onChange={(e) => handleMetricChange("sleep", parseFloat(e.target.value))}
                className="w-full accent-fuchsia-500 cursor-ew-resize opacity-80 hover:opacity-100"
              />
              <div className="flex justify-between text-[9px] text-white/30 font-mono">
                <span>Severe Deprived</span>
                <span>Fully Rested</span>
              </div>
            </div>

            {/* Slide 2: Mood Rating */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/60">Mood Score</span>
                <span className="text-fuchsia-400 font-bold">{(activeStudent.mood * 10).toFixed(0)}/10</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="1.0"
                step="0.05"
                value={activeStudent.mood}
                onChange={(e) => handleMetricChange("mood", parseFloat(e.target.value))}
                className="w-full accent-fuchsia-500 cursor-ew-resize opacity-80 hover:opacity-100"
              />
              <div className="flex justify-between text-[9px] text-white/30 font-mono">
                <span>Withdrawn</span>
                <span>Bright Index</span>
              </div>
            </div>

            {/* Slide 3: Performance Math/General */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/60">Academic Performance</span>
                <span className="text-fuchsia-400 font-bold">{Math.round(activeStudent.performance * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.4"
                max="1.0"
                step="0.01"
                value={activeStudent.performance}
                onChange={(e) => handleMetricChange("performance", parseFloat(e.target.value))}
                className="w-full accent-fuchsia-500 cursor-ew-resize opacity-80 hover:opacity-100"
              />
            </div>

            {/* Slide 4: Attendance */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/60">Attendance Rate</span>
                <span className="text-fuchsia-400 font-bold">{Math.round(activeStudent.attendance * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="1.0"
                step="0.01"
                value={activeStudent.attendance}
                onChange={(e) => handleMetricChange("attendance", parseFloat(e.target.value))}
                className="w-full accent-fuchsia-500 cursor-ew-resize opacity-80 hover:opacity-100"
              />
            </div>
          </div>
        </div>

        {/* Assignment Track Render Table with indicators ('Pending', 'Submitted', 'Graded') */}
        <div className="bg-[#0b0b0b] border border-white/10 p-5 space-y-4">
          <div className="border-b border-white/10 pb-2">
            <h3 className="text-sm font-bold uppercase tracking-widest text-fuchsia-400 flex items-center gap-1.5">
              <FileCheck className="w-4 h-4" /> Academic Assignment Trail
            </h3>
            <p className="text-[10px] text-white/50 mt-1">
              Active milestones mapped securely on node. Indicators next to each assignment title represent evaluation state.
            </p>
          </div>

          <div className="space-y-3">
            {activeAssignments.map((ass, index) => (
              <div key={index} className="p-3 bg-black/40 border border-white/5 flex justify-between items-center font-sans hover:border-white/25 transition-all">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white leading-tight font-sans">
                      {ass.title}
                    </span>
                    {/* Status indicator badge next to name */}
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[8px] font-mono tracking-widest uppercase font-bold",
                      ass.status === "Pending" ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/25" :
                      ass.status === "Submitted" ? "bg-blue-500/20 text-blue-400 border border-blue-500/25" :
                      "bg-emerald-500/20 text-emerald-400 border border-emerald-500/25"
                    )}>
                      {ass.status}
                    </span>
                  </div>
                  <div className="text-[9px] font-mono text-white/40 flex items-center gap-3">
                    <span>Topic: {ass.category}</span>
                    <span>Due: {ass.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SWIAIAssistant component render block */}
        <div>
          <SWIAIAssistant
            student={activeStudent}
            history={aiSuggestions[selectedId] || []}
            onTriggerSuggestion={triggerProactiveSuggestion}
            loading={aiLoading}
          />
        </div>

      </div>

      {/* Verifiable Ethical Governance Platform */}
      <div className="bg-[#0c0812] border border-fuchsia-500/20 p-6 space-y-8 rounded-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-fuchsia-500/5 blur-[120px] pointer-events-none"></div>
        
        <div className="border-b border-fuchsia-500/20 pb-4 flex items-center gap-2.5">
          <Scale className="w-5 h-5 text-fuchsia-400" />
          <h3 className="text-xl font-bold uppercase tracking-widest text-fuchsia-300 font-sans">
            Verifiable Ethical Governance Platform
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 font-sans">
          
          {/* Fix 3: Student Data Rights */}
          <div className="space-y-3 bg-[#0a0a0a] p-4 border border-white/10 rounded">
            <h4 className="text-xs font-bold uppercase text-fuchsia-400 font-sans tracking-widest flex items-center gap-2">
              <Shield className="w-4 h-4" /> Student Data Rights
            </h4>
            <ul className="space-y-2 text-[11px] font-mono text-white/80">
              <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Right To Review</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Right To Correction</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Right To Explanation</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Right To Appeal</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Right To Privacy</li>
              <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Right To Human Review</li>
            </ul>
            <div className="text-[9px] uppercase tracking-wider text-yellow-400 font-bold border-t border-white/5 pt-2 mt-2">
              No automated action allowed.
            </div>
          </div>

          {/* Fix 5: Ethical Safety Invariants */}
          <div className="space-y-3 bg-[#0a0a0a] p-4 border border-white/10 rounded">
            <h4 className="text-xs font-bold uppercase text-fuchsia-400 font-sans tracking-widest flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" /> Ethical Safety Invariants
            </h4>
            <div className="space-y-2 text-[10px] font-mono">
              <div className="flex flex-col"><span className="text-blue-400 font-bold">INV1</span> <span className="text-white/80">No Child Profile Sold</span></div>
              <div className="flex flex-col"><span className="text-blue-400 font-bold">INV2</span> <span className="text-white/80">No Commercial Advertising</span></div>
              <div className="flex flex-col"><span className="text-blue-400 font-bold">INV3</span> <span className="text-white/80">No Wellbeing Ranking</span></div>
              <div className="flex flex-col"><span className="text-blue-400 font-bold">INV4</span> <span className="text-white/80">No Automated Punishment</span></div>
              <div className="flex flex-col"><span className="text-blue-400 font-bold">INV5</span> <span className="text-white/80">Human Review Required</span></div>
            </div>
          </div>

          {/* Fix 7: Governance Review Board */}
          <div className="space-y-3 bg-[#0a0a0a] p-4 border border-white/10 rounded">
            <h4 className="text-xs font-bold uppercase text-fuchsia-400 font-sans tracking-widest flex items-center gap-2">
              <Users className="w-4 h-4" /> Governance Review Board
            </h4>
            <ul className="space-y-1.5 text-[11px] font-mono text-white/80">
              <li className="flex items-center gap-2 text-white/90">• Student Advocate</li>
              <li className="flex items-center gap-2 text-white/90">• Parent Representative</li>
              <li className="flex items-center gap-2 text-white/90">• Educator</li>
              <li className="flex items-center gap-2 text-white/90">• Ethics Reviewer</li>
              <li className="flex items-center gap-2 text-white/90">• System Auditor</li>
            </ul>
            <div className="text-[9px] text-fuchsia-300 font-bold border-t border-white/5 pt-2 mt-2 leading-relaxed">
              No single individual can approve sensitive actions.
            </div>
          </div>

          {/* Fix 8: Formal Verification Layer */}
          <div className="lg:col-span-2 space-y-3 bg-[#0a0a0a] p-4 border border-white/10 rounded">
            <h4 className="text-xs font-bold uppercase text-fuchsia-400 font-sans tracking-widest flex items-center gap-2">
              <Gavel className="w-4 h-4" /> Formal Verification Layer (PLANNED)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <pre className="text-[9px] font-mono text-blue-300 bg-black p-2 rounded border border-white/5 relative overflow-hidden">
                {`NoPunitiveAction ==
    /\\ StudentMood < 0.3
    => Decision # Punishment`}
              </pre>
              <pre className="text-[9px] font-mono text-emerald-300 bg-black p-2 rounded border border-white/5 relative overflow-hidden">
                {`NoCommercialProfiling ==
    StudentDataUsed = FALSE`}
              </pre>
              <pre className="text-[9px] font-mono text-fuchsia-300 bg-black p-2 rounded border border-white/5 relative overflow-hidden">
                {`HumanReviewRequired ==
    RecommendationIssued
    => HumanApproval`}
              </pre>
            </div>
            <div className="text-[9px] uppercase tracking-wider text-white/50 text-right mt-2">
              All must hold in every reachable state.
            </div>
          </div>

          {/* Fix 9 & Fix 6: Evidence Dashboard */}
          <div className="space-y-3 bg-[#0a0a0a] p-4 border border-white/10 rounded">
            <h4 className="text-xs font-bold uppercase text-fuchsia-400 font-sans tracking-widest flex items-center gap-2">
              <Database className="w-4 h-4" /> Verification Evidence
            </h4>
            <div className="space-y-1.5 text-[10px] font-mono text-white/70">
              <div className="flex justify-between border-b border-white/5 pb-1"><span>System Hash:</span> <span className="text-white">0x8F9A...C2</span></div>
              <div className="flex justify-between border-b border-white/5 pb-1"><span>Policy Hash:</span> <span className="text-white">0x4D2B...E1</span></div>
              <div className="flex justify-between border-b border-white/5 pb-1"><span>Record Hash:</span> <span className="text-white">0xA7D3...D1</span></div>
              <div className="flex justify-between items-center pt-1"><span className="opacity-80">Signature Status:</span> <span className="px-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[9px] font-bold">VERIFIED</span></div>
              <div className="flex justify-between items-center"><span className="opacity-80">Audit Status:</span> <span className="px-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[9px] font-bold">CLEARED</span></div>
              <div className="flex justify-between items-center"><span className="opacity-80">Model Check:</span> <span className="px-1.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded text-[9px] font-bold">PASSED</span></div>
              <div className="flex justify-between items-center"><span className="opacity-80">Governance:</span> <span className="px-1.5 bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/30 rounded text-[9px] font-bold">ACTIVE</span></div>
            </div>
          </div>
        </div>

        {/* Fix 6: Ledger Evidence Bottom Banner */}
        <div className="bg-black/50 p-4 rounded border border-white/5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex flex-col gap-2">
            <div className="text-[11px] font-bold text-fuchsia-400 uppercase tracking-widest flex items-center gap-2">
              <FileText className="w-4 h-4" /> Ledger Entry
            </div>
            <div className="text-[10px] font-mono text-white/50 flex flex-wrap gap-x-6 gap-y-2">
              <span><strong className="text-white/80">Block:</strong> 1574</span>
              <span><strong className="text-white/80">Hash:</strong> 0x91FA...</span>
              <span><strong className="text-white/80">Previous:</strong> 0x882B...</span>
              <span><strong className="text-white/80">Timestamp:</strong> 2026-05-29T18:00:00Z</span>
            </div>
          </div>
          <div className="text-[11px] font-mono bg-emerald-500/10 px-4 py-2 border border-emerald-500/30 text-emerald-400 font-bold tracking-widest rounded-sm">
            STATUS: VERIFIED
          </div>
        </div>

      </div>

    </div>
  );
}
