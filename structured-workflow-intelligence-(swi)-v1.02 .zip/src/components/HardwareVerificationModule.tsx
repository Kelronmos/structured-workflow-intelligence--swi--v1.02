import React, { useState, useEffect } from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Cpu, HardDrive, Network, Monitor, MemoryStick, Loader2 } from 'lucide-react';
import { cn } from '../lib/utils';

type ScanState = 'idle' | 'scanning' | 'complete';
type ComponentState = 'pending' | 'scanning' | 'pass' | 'warn' | 'fail';

interface HardwareComponent {
  id: string;
  name: string;
  icon: React.ElementType;
  state: ComponentState;
  progress: number;
  message: string;
}

interface HardwareVerificationProps {
  onComplete?: () => void;
}

export function HardwareVerificationModule({ onComplete }: HardwareVerificationProps) {
  const [scanState, setScanState] = useState<ScanState>('idle');
  const [components, setComponents] = useState<HardwareComponent[]>([
    { id: 'cpu', name: 'CPU Integrity', icon: Cpu, state: 'pending', progress: 0, message: 'Waiting to start...' },
    { id: 'mem', name: 'Memory Diagnostics', icon: MemoryStick, state: 'pending', progress: 0, message: 'Waiting to start...' },
    { id: 'storage', name: 'Storage Array', icon: HardDrive, state: 'pending', progress: 0, message: 'Waiting to start...' },
    { id: 'gpu', name: 'GPU Compute', icon: Monitor, state: 'pending', progress: 0, message: 'Waiting to start...' },
    { id: 'network', name: 'Network Interfaces', icon: Network, state: 'pending', progress: 0, message: 'Waiting to start...' },
  ]);

  const startScan = async () => {
    setScanState('scanning');
    
    // Reset components
    setComponents(prev => prev.map(c => ({ ...c, state: 'pending', progress: 0, message: 'Initializing...' })));

    for (let i = 0; i < components.length; i++) {
      const comp = components[i];
      
      // Set to scanning
      setComponents(prev => prev.map((c, idx) => idx === i ? { ...c, state: 'scanning', message: `Scanning ${c.name}...` } : c));
      
      // Simulate progress
      for (let p = 10; p <= 100; p += 20) {
        await new Promise(r => setTimeout(r, 150));
        setComponents(prev => prev.map((c, idx) => idx === i ? { ...c, progress: p } : c));
      }

      // Determine result (simulate some random warnings, mostly passes)
      const isNetwork = comp.id === 'network';
      const isWarn = isNetwork && Math.random() > 0.5;
      
      setComponents(prev => prev.map((c, idx) => {
        if (idx === i) {
          return {
            ...c,
            state: isWarn ? 'warn' : 'pass',
            message: isWarn ? 'Sub-optimal latency detected' : 'Verification passed',
            progress: 100
          };
        }
        return c;
      }));
    }

    setScanState('complete');
    if (onComplete) {
      onComplete();
    }
  };

  const getStatusColor = (state: ComponentState) => {
    switch (state) {
      case 'pass': return 'text-emerald-500';
      case 'warn': return 'text-amber-500';
      case 'fail': return 'text-red-500';
      case 'scanning': return 'text-blue-400';
      default: return 'text-gray-500';
    }
  };

  const getProgressColor = (state: ComponentState) => {
    switch (state) {
      case 'pass': return 'bg-emerald-500';
      case 'warn': return 'bg-amber-500';
      case 'fail': return 'bg-red-500';
      case 'scanning': return 'bg-blue-400';
      default: return 'bg-gray-700';
    }
  };

  return (
    <div className="bg-[#0A0A0A] border border-[#1A1A1A] rounded-xl p-6 text-white font-mono w-full max-w-3xl">
      <div className="flex justify-between items-center mb-6 border-b border-[#222] pb-4">
        <div>
          <h2 className="text-xl font-bold tracking-wider">HARDWARE VERIFICATION MODULE</h2>
          <p className="text-sm text-gray-500 mt-1">SWI System Node Diagnostics</p>
        </div>
        
        {scanState === 'idle' && (
          <button 
            onClick={startScan}
            className="bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 px-4 py-2 rounded transition-colors uppercase text-sm font-bold tracking-wider"
          >
            Initiate Scan
          </button>
        )}
        
        {scanState === 'scanning' && (
          <div className="flex items-center gap-2 text-blue-400">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="uppercase text-sm tracking-wider">Scanning...</span>
          </div>
        )}
        
        {scanState === 'complete' && (
          <button 
            onClick={startScan}
            className="bg-gray-800 hover:bg-gray-700 text-gray-300 border border-gray-600 px-4 py-2 rounded transition-colors uppercase text-sm tracking-wider"
          >
            Re-run Scan
          </button>
        )}
      </div>

      <div className="space-y-6">
        {components.map((comp) => (
          <div key={comp.id} className="bg-[#111] border border-[#222] p-4 rounded-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <comp.icon className={cn("w-5 h-5", getStatusColor(comp.state))} />
                <span className="text-sm font-semibold tracking-wide">{comp.name}</span>
              </div>
              <div className={cn("flex items-center gap-2 text-xs font-bold uppercase", getStatusColor(comp.state))}>
                {comp.state === 'pass' && <CheckCircle2 className="w-4 h-4" />}
                {comp.state === 'warn' && <AlertTriangle className="w-4 h-4" />}
                {comp.state === 'fail' && <XCircle className="w-4 h-4" />}
                {comp.state === 'scanning' && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>{comp.state === 'pending' ? 'WAITING' : comp.state}</span>
              </div>
            </div>
            
            <div className="w-full bg-gray-900 h-2 rounded-full overflow-hidden mb-2">
              <div 
                className={cn("h-full transition-all duration-300 ease-out", getProgressColor(comp.state))}
                style={{ width: `${comp.progress}%` }}
              />
            </div>
            
            <div className="flex justify-between items-center text-xs text-gray-500">
              <span className="font-mono">{comp.message}</span>
              <span className="font-mono">{comp.progress}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
