import React, { useState, useEffect } from "react";
import {
  Network,
  Server,
  Activity,
  ShieldAlert,
  Terminal,
  Play,
  RotateCw,
  RefreshCw,
  CheckCircle2,
  Lock,
  Zap,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface NodeState {
  id: string;
  role: "LEADER" | "FOLLOWER" | "PARTITIONED" | "BYZANTINE";
  state: "GENESIS" | "PROPOSING" | "PRE_VOTE" | "PRE_COMMIT" | "COMMIT";
  height: number;
  lastHash: string;
}

export default function DistributedAgreementView() {
  const [nodes, setNodes] = useState<NodeState[]>([
    {
      id: "hotstuff-01",
      role: "LEADER",
      state: "COMMIT",
      height: 1204,
      lastHash: "0x8f3a",
    },
    {
      id: "hotstuff-02",
      role: "FOLLOWER",
      state: "COMMIT",
      height: 1204,
      lastHash: "0x8f3a",
    },
    {
      id: "hotstuff-03",
      role: "FOLLOWER",
      state: "COMMIT",
      height: 1204,
      lastHash: "0x8f3a",
    },
    {
      id: "hotstuff-04",
      role: "FOLLOWER",
      state: "COMMIT",
      height: 1204,
      lastHash: "0x8f3a",
    },
  ]);

  const [isRunning, setIsRunning] = useState(true);
  const [logs, setLogs] = useState<string[]>([
    "[P2P] Genesis block established.",
    "[BFT] Node hotstuff-01 elected as initial Leader.",
    "[SYNC] 4/4 nodes synchronized to height 1204.",
  ]);

  const addLog = (log: string) => {
    setLogs((prev) => [...prev, log].slice(-10));
  };

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setNodes((prevNodes) => {
        const nextNodes = [...prevNodes];

        // Randomly simulate block proposal and commit
        if (Math.random() > 0.4) {
          const leader = nextNodes.find((n) => n.role === "LEADER");
          const newHeight = (leader?.height || 0) + 1;
          const newHash =
            "0x" +
            Math.floor(Math.random() * 65536)
              .toString(16)
              .padStart(4, "0");

          let votes = 0;
          for (let i = 0; i < nextNodes.length; i++) {
            if (
              nextNodes[i].role !== "PARTITIONED" &&
              nextNodes[i].role !== "BYZANTINE"
            ) {
              nextNodes[i].height = newHeight;
              nextNodes[i].lastHash = newHash;
              nextNodes[i].state = "COMMIT";
              votes++;
            }
          }

          if (votes >= 3) {
            addLog(
              `[QUORUM] 2f+1 signatures valid. Block #${newHeight} committed.`,
            );
          } else {
            addLog(
              `[FAULT] Quorum failed for Block #${newHeight}. Votes: ${votes}`,
            );
          }
        }

        return nextNodes;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [isRunning]);

  const handleInjectPartition = () => {
    setNodes((prev) => {
      const next = [...prev];
      if (next[3].role === "PARTITIONED") {
        next[3].role = "FOLLOWER";
        addLog("[P2P] Network partition resolved. Subnet reunified.");
      } else {
        next[3].role = "PARTITIONED";
        next[3].state = "PRE_VOTE";
        addLog("[FAULT] Injected network partition. Node 4 isolated.");
      }
      return next;
    });
  };

  const handleByzantineFault = () => {
    setNodes((prev) => {
      const next = [...prev];
      if (next[2].role === "BYZANTINE") {
        next[2].role = "FOLLOWER";
        addLog("[HEALTH] Node 3 returned to nominal execution.");
      } else {
        next[2].role = "BYZANTINE";
        addLog(
          "[SECURITY] Node 3 injected with Byzantine mutation (invalid state signatures).",
        );
      }
      return next;
    });
  };

  const handleLeaderRotation = () => {
    setNodes((prev) => {
      const next = [...prev];
      const prevLeaderIdx = next.findIndex((n) => n.role === "LEADER");
      if (prevLeaderIdx >= 0) {
        next[prevLeaderIdx].role = "FOLLOWER";
      }
      // Pick next available follower
      const nextLeaderIdx = next.findIndex((n) => n.role === "FOLLOWER");
      if (nextLeaderIdx >= 0) {
        next[nextLeaderIdx].role = "LEADER";
        addLog(
          `[ROTATION] View Change triggered. ${next[nextLeaderIdx].id} elected leader.`,
        );
      }
      return next;
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Network className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Verifiable Distributed Agreement
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            Real CometBFT / HotStuff node execution with Byzantine quorum
            validation. Verifies continuity under distributed disagreement.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right border-r border-white/10 pr-4">
            <div className="text-[10px] font-bold uppercase tracking-widest text-white/50">
              Cluster Mode
            </div>
            <div className="font-mono text-xs font-bold text-indigo-400">
              {isRunning ? "ACTIVE_CONSENSUS" : "HALTED"}
            </div>
          </div>
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="bg-indigo-500/20 hover:bg-indigo-500/40 text-indigo-400 border border-indigo-500/50 px-4 py-2 text-[10px] uppercase font-bold tracking-widest flex items-center gap-2"
          >
            {isRunning ? (
              <RefreshCw className="w-3 h-3 animate-spin" />
            ) : (
              <Play className="w-3 h-3" />
            )}
            {isRunning ? "Running" : "Start Node"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#141414] border border-white/10 p-6 flex flex-col min-h-[400px]">
            <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 border-b border-indigo-400/20 pb-2 mb-4">
              CometBFT / HotStuff Quorum State
            </h3>
            <div className="grid grid-cols-2 gap-4 mb-6">
              {nodes.map((node) => (
                <div
                  key={node.id}
                  className={cn(
                    "p-4 border font-mono rounded-sm",
                    node.role === "LEADER"
                      ? "border-yellow-500/50 bg-yellow-500/5"
                      : node.role === "PARTITIONED"
                        ? "border-red-500/50 bg-red-500/5"
                        : node.role === "BYZANTINE"
                          ? "border-purple-500/50 bg-purple-500/5"
                          : "border-indigo-500/20 bg-indigo-500/5",
                  )}
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[11px] font-bold text-white">
                      {node.id}
                    </span>
                    <span
                      className={cn(
                        "text-[9px] font-bold uppercase px-2 py-0.5 rounded-full border",
                        node.role === "LEADER"
                          ? "border-yellow-500 text-yellow-500"
                          : node.role === "PARTITIONED"
                            ? "border-red-500 text-red-500"
                            : node.role === "BYZANTINE"
                              ? "border-purple-500 text-purple-500"
                              : "border-indigo-500 text-indigo-400",
                      )}
                    >
                      {node.role}
                    </span>
                  </div>
                  <div className="space-y-1 text-[10px] text-white/60">
                    <div className="flex justify-between">
                      <span>Height:</span>
                      <span className="text-white">{node.height}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>State:</span>
                      <span className="text-white">{node.state}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Hash:</span>
                      <span className="text-white">{node.lastHash}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex-1 bg-black/50 border border-white/5 rounded-sm p-4 font-mono text-[10px] overflow-y-auto">
              <div className="flex items-center gap-2 text-indigo-400/60 mb-3 border-b border-indigo-500/20 pb-2">
                <Terminal className="w-3 h-3" />
                <span>REPLICATED_LOG_OUTPUT</span>
              </div>
              {logs.map((log, idx) => {
                let color = "text-green-400";
                if (log.includes("[FAULT]")) color = "text-red-400";
                if (log.includes("[SECURITY]") || log.includes("[BYZANTINE]"))
                  color = "text-purple-400";
                if (log.includes("[ROTATION]")) color = "text-yellow-400";

                return (
                  <div key={idx} className={cn("mb-1", color)}>
                    {log}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="lg:col-span-1 space-y-4">
          <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/70 border-b border-white/10 pb-2">
              Adversarial Injections
            </h3>

            <button
              onClick={handleInjectPartition}
              className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/30 p-3 text-left transition-all group"
            >
              <div className="flex items-center gap-2 mb-1">
                <Activity className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest">
                  Network Partition
                </span>
              </div>
              <p className="text-[9px] font-mono text-red-400/70">
                Isolate nodes from the quorum. Verifies continuity and liveness
                under unreliable P2P delivery.
              </p>
            </button>

            <button
              onClick={handleByzantineFault}
              className="w-full bg-purple-500/10 hover:bg-purple-500/20 text-purple-500 border border-purple-500/30 p-3 text-left transition-all group"
            >
              <div className="flex items-center gap-2 mb-1">
                <ShieldAlert className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest">
                  Byzantine Mutation
                </span>
              </div>
              <p className="text-[9px] font-mono text-purple-400/70">
                Inject incorrect state hashes to simulate malicious nodes.
                Verifies cryptographic signature thresholds (2f+1).
              </p>
            </button>

            <button
              onClick={handleLeaderRotation}
              className="w-full bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-500 border border-yellow-500/30 p-3 text-left transition-all group"
            >
              <div className="flex items-center gap-2 mb-1">
                <RotateCw className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase tracking-widest">
                  Leader Rotation
                </span>
              </div>
              <p className="text-[9px] font-mono text-yellow-400/70">
                Force a View Change election. Proves resilience against leader
                failures or liveness deadlocks.
              </p>
            </button>
          </div>

          <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest text-white/70 border-b border-white/10 pb-2">
              Structural Properties
            </h3>
            <ul className="space-y-2 text-[10px] font-mono text-white/60">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3 h-3 text-green-500" /> Byzantine
                Quorum Validation
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3 h-3 text-green-500" /> Signed State
                Propagation
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3 h-3 text-green-500" /> P2P
                Synchronization
              </li>
              <li className="flex items-center gap-2">
                <Lock className="w-3 h-3 text-green-500" /> Replay Protection
              </li>
            </ul>
          </div>
        </div>

        <div className="lg:col-span-3">
          <ProofArtifacts
            id="distributed-agreement-proof"
            title="Consensus Continuity Proof"
            logs={logs}
            data={{ nodesConfig: nodes }}
            variant="always-dark"
          />
        </div>
      </div>
    </div>
  );
}
