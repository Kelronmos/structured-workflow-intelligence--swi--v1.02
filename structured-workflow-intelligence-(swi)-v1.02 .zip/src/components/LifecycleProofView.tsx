import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  ShieldAlert,
  Zap,
  History,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface LifecycleStep {
  label: string;
  status: "PENDING" | "SUCCESS" | "FAILURE" | "HALT";
  detail: string;
}

interface CaseStudy {
  id: string;
  title: string;
  description: string;
  input: string;
  standing: "NOMINAL" | "DEGRADED" | "COLLAPSED";
  outcome: "EXECUTE" | "REFUSE" | "HALT";
  steps: LifecycleStep[];
}

const CASES: CaseStudy[] = [
  {
    id: "valid",
    title: "Baseline Valid Execution",
    description:
      "Clean state matching all 10-dimensional manifold constraints.",
    input: '{"action": "TRANSFER", "amount": 1000}',
    standing: "NOMINAL",
    outcome: "EXECUTE",
    steps: [
      {
        label: "Input Admissibility",
        status: "SUCCESS",
        detail: "Payload valid context verified.",
      },
      {
        label: "Manifold Standing",
        status: "SUCCESS",
        detail: "Authority > 0.95 | Drift < 0.05",
      },
      {
        label: "Arbitration",
        status: "SUCCESS",
        detail: "Triple-engine consensus reached.",
      },
      {
        label: "Merkle Bond",
        status: "SUCCESS",
        detail: "Root signed by HSM attestation.",
      },
    ],
  },
  {
    id: "invalid",
    title: "Adversarial Refusal",
    description:
      "Detection of intentional policy bypass or invalid authorization.",
    input: '{"action": "TRANSFER", "amount": 1000000}',
    standing: "DEGRADED",
    outcome: "REFUSE",
    steps: [
      {
        label: "Input Admissibility",
        status: "SUCCESS",
        detail: "Payload syntax valid.",
      },
      {
        label: "Manifold Standing",
        status: "FAILURE",
        detail: "Capacity mismatch | Policy violation.",
      },
      {
        label: "Arbitration",
        status: "FAILURE",
        detail: "Consensus rejected: REFUSE_BEYOND_CORRIDOR",
      },
      {
        label: "Merkle Bond",
        status: "SUCCESS",
        detail: "Rejection event committed to ledger.",
      },
    ],
  },
  {
    id: "collapsed",
    title: "Systemic Drift (Halt)",
    description:
      "High-dimensional instability detected in the execution boundary.",
    input: '{"action": "SYSTEM_UPGRADE", "id": "v9"}',
    standing: "COLLAPSED",
    outcome: "HALT",
    steps: [
      {
        label: "Input Admissibility",
        status: "SUCCESS",
        detail: "Context captured.",
      },
      {
        label: "Manifold Standing",
        status: "HALT",
        detail: "CRITICAL_DRIFT | Continuity break detected.",
      },
      {
        label: "Arbitration",
        status: "HALT",
        detail: "Emergency Halt: MANIFOLD_COLLAPSE",
      },
      {
        label: "Merkle Bond",
        status: "SUCCESS",
        detail: "System state snapshotted for forensic audit.",
      },
    ],
  },
];

export default function LifecycleProofView() {
  const [selectedCase, setSelectedCase] = useState(CASES[0]);
  const [isReplaying, setIsReplaying] = useState(false);
  const [replaySuccess, setReplaySuccess] = useState<boolean | null>(null);

  const runReplay = async () => {
    setIsReplaying(true);
    setReplaySuccess(null);

    // Simulate complex replay derivation
    await new Promise((r) => setTimeout(r, 1500));

    // In a real system, we'd call /api/v3/replay with the actual receipt
    setReplaySuccess(selectedCase.id === "valid");
    setIsReplaying(false);
  };

  return (
    <div className="grid lg:grid-cols-12 gap-6">
      <div className="lg:col-span-4 space-y-3">
        <h3 className="text-[10px] font-bold uppercase tracking-widest opacity-40 mb-4 px-2">
          Lifecycle Case Selection
        </h3>
        {CASES.map((c) => (
          <button
            key={c.id}
            onClick={() => {
              setSelectedCase(c);
              setReplaySuccess(null);
            }}
            className={cn(
              "w-full text-left p-4 rounded-xl border transition-all group relative overflow-hidden",
              selectedCase.id === c.id
                ? "bg-blue-500/10 border-blue-500/50 shadow-[0_0_15px_-5px_rgba(59,130,246,0.5)]"
                : "bg-white/5 border-white/10 hover:border-white/20",
            )}
          >
            <div className="flex justify-between items-start">
              <div>
                <h4
                  className={cn(
                    "text-[10px] font-bold uppercase tracking-wider mb-1",
                    selectedCase.id === c.id ? "text-blue-400" : "opacity-80",
                  )}
                >
                  {c.title}
                </h4>
                <p className="text-[8px] opacity-40 uppercase leading-relaxed">
                  {c.description}
                </p>
              </div>
              {selectedCase.id === c.id && (
                <ChevronRight className="w-3 h-3 text-blue-500" />
              )}
            </div>
            {selectedCase.id === c.id && (
              <motion.div
                layoutId="caseIndicator"
                className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500"
              />
            )}
          </button>
        ))}
      </div>

      <div className="lg:col-span-8 space-y-6">
        <div className="bg-black/40 border border-white/5 rounded-2xl p-6 relative overflow-hidden">
          <div className="flex justify-between items-start mb-8">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <div
                  className={cn(
                    "px-2 py-0.5 rounded text-[8px] font-bold uppercase",
                    selectedCase.standing === "NOMINAL"
                      ? "bg-green-500/20 text-green-500 border border-green-500/20"
                      : selectedCase.standing === "DEGRADED"
                        ? "bg-yellow-500/20 text-yellow-500 border border-yellow-500/20"
                        : "bg-red-500/20 text-red-500 border border-red-500/20",
                  )}
                >
                  Standing: {selectedCase.standing}
                </div>
                <div className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-[8px] font-mono opacity-60">
                  {selectedCase.outcome}
                </div>
              </div>
              <h2 className="text-xl font-bold tracking-tight">
                {selectedCase.title} Proof
              </h2>
            </div>

            <button
              onClick={runReplay}
              disabled={isReplaying}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-blue-600 transition-colors disabled:opacity-50"
            >
              {isReplaying ? (
                <>
                  <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Verifying...
                </>
              ) : (
                <>
                  <History className="w-3 h-3" />
                  Trigger Replay Proof
                </>
              )}
            </button>
          </div>

          <div className="space-y-4">
            {selectedCase.steps.map((step, idx) => (
              <div key={idx} className="flex items-start gap-4">
                <div className="flex flex-col items-center">
                  <div
                    className={cn(
                      "w-6 h-6 rounded-full flex items-center justify-center border text-[10px] font-bold",
                      step.status === "SUCCESS"
                        ? "bg-green-500/20 border-green-500/50 text-green-500"
                        : step.status === "FAILURE"
                          ? "bg-yellow-500/20 border-yellow-500/50 text-yellow-500"
                          : step.status === "HALT"
                            ? "bg-red-500/20 border-red-500/50 text-red-500"
                            : "bg-white/5 border-white/10 opacity-30",
                    )}
                  >
                    {idx + 1}
                  </div>
                  {idx < selectedCase.steps.length - 1 && (
                    <div className="w-px h-8 bg-white/10 my-1" />
                  )}
                </div>
                <div className="flex-1 pt-1">
                  <div className="flex justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider">
                      {step.label}
                    </span>
                    <span
                      className={cn(
                        "text-[8px] font-mono",
                        step.status === "SUCCESS"
                          ? "text-green-500"
                          : step.status === "FAILURE"
                            ? "text-yellow-500"
                            : "text-red-500",
                      )}
                    >
                      {step.status}
                    </span>
                  </div>
                  <p className="text-[9px] opacity-40 uppercase tracking-widest mt-1">
                    {step.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <AnimatePresence>
            {replaySuccess !== null && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={cn(
                  "mt-8 p-4 rounded-xl border flex items-center gap-4",
                  replaySuccess
                    ? "bg-green-500/10 border-green-500/30 text-green-400"
                    : "bg-red-500/10 border-red-500/30 text-red-400",
                )}
              >
                {replaySuccess ? (
                  <ShieldCheck className="w-5 h-5" />
                ) : (
                  <ShieldAlert className="w-5 h-5" />
                )}
                <div>
                  <h5 className="text-[10px] font-bold uppercase tracking-widest">
                    Replay Lifecycle Verification:{" "}
                    {replaySuccess ? "MATCH" : "TAMPER_DETECTED"}
                  </h5>
                  <p className="text-[9px] opacity-70">
                    {replaySuccess
                      ? "The recorded receipt hash matches the re-derived execution path from the state archive."
                      : "Replay derivation resulted in a decision mismatch. The boundary may have been compromised."}
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Background Grid Pattern */}
          <div
            className="absolute inset-0 pointer-events-none opacity-[0.03]"
            style={{
              backgroundImage:
                "radial-gradient(circle at 1px 1px, white 1px, transparent 0)",
              backgroundSize: "24px 24px",
            }}
          />
        </div>

        <ProofArtifacts
          id={selectedCase.id}
          title={`${selectedCase.title} Cryptographic Proof`}
          data={{ ...selectedCase }}
        />

        <div className="p-4 bg-black/20 border border-white/5 rounded-xl font-mono text-[9px] opacity-50">
          <div className="flex items-center gap-2 text-blue-400 mb-2 font-bold italic">
            <Zap className="w-3 h-3" /> INPUT_VECTOR_STREAM_DEBUG
          </div>
          {selectedCase.input}
        </div>
      </div>
    </div>
  );
}
