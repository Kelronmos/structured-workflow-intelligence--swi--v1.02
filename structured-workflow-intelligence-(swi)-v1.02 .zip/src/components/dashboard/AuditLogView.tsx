import React, { useState, useEffect } from "react";
import { Search, Filter, ShieldCheck, AlertTriangle, FileText, ChevronDown } from "lucide-react";
import { motion } from "framer-motion";

export const AuditLogView = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    // In a real app this would call /api/audit
    // Simulating API fetch
    setTimeout(() => {
      setLogs([
        { id: "AUD-001", timestamp: Date.now() - 10000, module: "Governance", policy: "BP-2026-LAW-001", decision: "APPROVED", hash: "a8f3b1...9c", signature: "Verified", severity: "Info" },
        { id: "AUD-002", timestamp: Date.now() - 45000, module: "Security", policy: "SEC-L1-AUTH", decision: "DENIED", hash: "b4c9e2...1f", signature: "Rejected", severity: "Warning" },
        { id: "AUD-003", timestamp: Date.now() - 120000, module: "Firefly", policy: "DRIFT-MONITOR", decision: "LOGGED", hash: "f7d2a5...3e", signature: "Verified", severity: "Info" },
        { id: "AUD-004", timestamp: Date.now() - 360000, module: "Truth Kernel", policy: "SYS-CORE-01", decision: "HALT_OVERRIDDEN", hash: "e1b8c4...5a", signature: "Verified", severity: "Critical" },
      ]);
      setLoading(false);
    }, 800);
  }, []);

  const filteredLogs = logs.filter(log => 
    (filter === "all" || log.severity.toLowerCase() === filter.toLowerCase()) &&
    (search === "" || log.module.toLowerCase().includes(search.toLowerCase()) || log.policy.toLowerCase().includes(search.toLowerCase()) || log.id.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="flex flex-col gap-6 h-full">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Compliance Audit Log</h2>
          <p className="text-gray-500 text-sm mt-1">Immutable timeline of system decisions, signatures, and hash references.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-gray-900 border border-gray-700 rounded text-sm text-gray-300 hover:text-white hover:bg-gray-800 transition-colors flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </div>

      <div className="flex gap-4 items-center bg-gray-900/50 p-3 rounded border border-gray-800">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input 
            type="text" 
            placeholder="Search by ID, Module, or Policy..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-black border border-gray-800 rounded pl-10 pr-4 py-2 text-sm text-gray-200 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>
        <div className="flex items-center gap-2 border-l border-gray-800 pl-4">
          {["All", "Info", "Warning", "Critical"].map(f => (
            <button 
              key={f}
              onClick={() => setFilter(f.toLowerCase())}
              className={`px-3 py-1 text-xs rounded uppercase tracking-wider ${filter === f.toLowerCase() ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30' : 'bg-black text-gray-500 border border-gray-800 hover:text-gray-300'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex-1 bg-gray-900/20 border border-gray-800 rounded flex items-center justify-center">
          <div className="animate-pulse flex flex-col items-center gap-3">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-gray-500 text-sm">Synchronizing ledger...</span>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-auto bg-gray-950 border border-gray-800 rounded">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-900 text-gray-400 text-xs uppercase tracking-wider sticky top-0">
              <tr>
                <th className="px-6 py-4 font-medium border-b border-gray-800">Timestamp</th>
                <th className="px-6 py-4 font-medium border-b border-gray-800">Module / Policy</th>
                <th className="px-6 py-4 font-medium border-b border-gray-800">Decision</th>
                <th className="px-6 py-4 font-medium border-b border-gray-800">Hash Ref</th>
                <th className="px-6 py-4 font-medium border-b border-gray-800">Signature</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/50">
              {filteredLogs.map((log, i) => (
                <motion.tr 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  key={log.id} 
                  className="hover:bg-gray-900/50 transition-colors"
                >
                  <td className="px-6 py-4 text-gray-400 whitespace-nowrap">
                    <div className="flex flex-col">
                      <span className="text-gray-300">{new Date(log.timestamp).toLocaleTimeString()}</span>
                      <span className="text-xs text-gray-600">{new Date(log.timestamp).toLocaleDateString()}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="text-gray-200 font-medium">{log.module}</span>
                      <span className="text-xs text-indigo-400 font-mono mt-1">{log.policy}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium ${
                      log.decision === 'APPROVED' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                      log.decision === 'DENIED' ? 'bg-red-500/10 text-red-400 border border-red-500/20' :
                      'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                    }`}>
                      {log.decision}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-500 font-mono text-xs">{log.hash}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className={`w-4 h-4 ${log.signature === 'Verified' ? 'text-green-500' : 'text-gray-600'}`} />
                      <span className="text-gray-400">{log.signature}</span>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
          {filteredLogs.length === 0 && (
            <div className="p-12 text-center text-gray-500">
              No audit logs match your filters.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
