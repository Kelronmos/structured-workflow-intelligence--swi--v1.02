import React, { useState, useEffect } from "react";
import { Database, Link2, Shield, Hash, Clock, FileCheck } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export const TruthKernel = () => {
  const [nodes, setNodes] = useState<any[]>([]);
  const [selectedNode, setSelectedNode] = useState<any>(null);

  useEffect(() => {
    // Simulated Graph Data
    setNodes([
      { id: "EVID-01", type: "Evidence", label: "User Action Trace", hash: "a8f3b1...9c", confidence: 98, time: "10:42:01" },
      { id: "POL-01", type: "Policy", label: "EU-AI-ART13", hash: "b2d4e5...1a", confidence: 100, time: "Static" },
      { id: "DEC-01", type: "Decision", label: "Governance Approval", hash: "c9f1a2...3d", confidence: 96, time: "10:42:05" },
      { id: "REP-01", type: "Replay", label: "Deterministic Verification", hash: "d4b2c1...9e", confidence: 99, time: "10:42:15" },
      { id: "AUD-01", type: "Audit", label: "Immutable Ledger Entry", hash: "e1a5b4...7f", confidence: 100, time: "10:42:20" },
    ]);
  }, []);

  return (
    <div className="flex flex-col gap-6 h-full">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Database className="w-6 h-6 text-indigo-400" />
          Truth Kernel
        </h2>
        <p className="text-gray-500 text-sm mt-1">Cryptographically verified evidence graphs and execution lineage.</p>
      </div>

      <div className="flex flex-1 gap-6 min-h-0">
        {/* Graph Area */}
        <div className="flex-[2] bg-gray-900 border border-gray-800 rounded-lg relative overflow-hidden flex items-center justify-center">
          <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at center, #3730a3 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
          
          <div className="flex gap-12 items-center relative z-10 p-12">
            {nodes.map((node, i) => (
              <React.Fragment key={node.id}>
                <motion.div 
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => setSelectedNode(node)}
                  className={`w-32 h-32 rounded-full border-2 flex flex-col items-center justify-center cursor-pointer transition-all ${
                    selectedNode?.id === node.id 
                      ? 'border-indigo-400 bg-indigo-500/20 shadow-[0_0_30px_rgba(99,102,241,0.3)]' 
                      : 'border-gray-700 bg-gray-800 hover:border-gray-500'
                  }`}
                >
                  <span className="text-xs uppercase tracking-widest text-gray-400 font-medium">{node.type}</span>
                  <span className="text-sm font-bold text-gray-200 mt-2 text-center px-2">{node.id}</span>
                </motion.div>
                {i < nodes.length - 1 && (
                  <motion.div 
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: 48 }}
                    transition={{ delay: i * 0.1 + 0.1 }}
                    className="h-0.5 bg-gray-700 w-12 shrink-0 relative"
                  >
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 border-t-2 border-r-2 border-gray-700 rotate-45"></div>
                  </motion.div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Inspector Panel */}
        <div className="flex-1 bg-gray-900 border border-gray-800 rounded-lg flex flex-col overflow-hidden">
          <div className="p-4 border-b border-gray-800 bg-gray-950 flex items-center justify-between shrink-0">
            <h3 className="text-sm font-bold text-gray-200 uppercase tracking-widest">Node Inspector</h3>
          </div>
          
          <div className="p-6 flex-1 overflow-auto">
            <AnimatePresence mode="wait">
              {selectedNode ? (
                <motion.div 
                  key={selectedNode.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col gap-6"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-indigo-500/20 border border-indigo-500/50 flex items-center justify-center shrink-0">
                      <FileCheck className="w-6 h-6 text-indigo-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-white">{selectedNode.id}</h4>
                      <p className="text-sm text-gray-400">{selectedNode.label}</p>
                    </div>
                  </div>

                  <div className="grid gap-4">
                    <div className="bg-black border border-gray-800 rounded p-4">
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest flex items-center gap-1.5 mb-2"><Hash className="w-3 h-3" /> Integrity Hash</span>
                      <span className="text-sm text-indigo-300 font-mono break-all">{selectedNode.hash}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-black border border-gray-800 rounded p-4">
                        <span className="text-[10px] text-gray-500 uppercase tracking-widest flex items-center gap-1.5 mb-2"><Shield className="w-3 h-3" /> Confidence</span>
                        <span className="text-2xl font-bold text-green-400">{selectedNode.confidence}%</span>
                      </div>
                      <div className="bg-black border border-gray-800 rounded p-4">
                        <span className="text-[10px] text-gray-500 uppercase tracking-widest flex items-center gap-1.5 mb-2"><Clock className="w-3 h-3" /> Timestamp</span>
                        <span className="text-lg font-bold text-gray-300">{selectedNode.time}</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3 border-b border-gray-800 pb-2">Lineage Links</h4>
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center gap-3 text-sm text-gray-400 bg-gray-900 border border-gray-800 p-2 rounded">
                        <Link2 className="w-4 h-4" />
                        <span>Parents: <span className="text-gray-300">N/A</span></span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-gray-400 bg-gray-900 border border-gray-800 p-2 rounded">
                        <Link2 className="w-4 h-4" />
                        <span>Children: <span className="text-indigo-400">DEC-01</span></span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-50">
                  <Database className="w-12 h-12 mb-4" />
                  <p className="text-sm">Select a node in the graph to view details.</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};
