import React, { ReactNode } from "react";
import { usePlatform } from "../../contexts/PlatformContext";
import { Shield, Activity, FileText, Database, ShieldAlert, Settings, CheckCircle2, CircleDashed } from "lucide-react";
import { motion } from "framer-motion";
import { SkeletonLoader } from "../ui/SkeletonLoader";

interface DashboardShellProps {
  children: ReactNode;
  activeRoute: string;
  onNavigate: (route: string) => void;
}

const BootStage = ({ label, done, loading }: { label: string, done: boolean, loading?: boolean }) => (
  <div className={`flex items-center gap-3 ${done ? 'text-green-400' : loading ? 'text-indigo-400' : 'text-gray-600'}`}>
    {done ? <CheckCircle2 className="w-4 h-4" /> : <CircleDashed className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />}
    <span className="text-sm uppercase tracking-widest">{label}</span>
  </div>
);

export const DashboardShell: React.FC<DashboardShellProps> = ({ children, activeRoute, onNavigate }) => {
  const { identity, loading, error, bootStages } = usePlatform();

  if (error) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-white flex items-center justify-center font-mono">
        <div className="bg-red-950/40 border border-red-500/50 p-8 rounded-lg max-w-md w-full shadow-2xl">
          <div className="flex items-center gap-3 mb-6">
            <ShieldAlert className="w-8 h-8 text-red-500" />
            <h2 className="text-xl text-red-400 font-bold uppercase tracking-wider">Platform Boot Failure</h2>
          </div>
          
          <div className="space-y-4 text-sm text-gray-300">
             <div className="p-4 bg-black/50 rounded border border-red-900/50 font-mono text-xs overflow-x-auto whitespace-pre-wrap">
                {error}
             </div>
             
             <div className="pt-4 flex justify-between items-center border-t border-gray-800">
                <span className="text-gray-500 text-xs uppercase tracking-widest">System Halt</span>
                <button onClick={() => window.location.reload()} className="px-4 py-2 bg-red-900/30 hover:bg-red-900/50 border border-red-500/30 rounded text-red-300 transition-colors">
                  Retry Boot
                </button>
             </div>
          </div>
        </div>
      </div>
    );
  }

  if (loading || !identity) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] text-gray-300 font-mono flex items-center justify-center">
        <div className="w-96 border border-gray-800 bg-black/50 p-8 rounded-lg shadow-2xl flex flex-col gap-6">
           <h2 className="text-xl font-bold tracking-widest text-white border-b border-gray-800 pb-4">Booting Platform...</h2>
           <div className="flex flex-col gap-4">
               <BootStage label="Configuration Loaded" done={bootStages?.config ?? false} />
               <BootStage label="Environment Verified" done={bootStages?.environment ?? false} />
               <BootStage label="Backend Reachable" done={bootStages?.health ?? false} loading={!bootStages?.health} />
               <BootStage label="Platform Identity" done={bootStages?.identity ?? false} loading={bootStages?.health && !bootStages?.identity} />
               <BootStage label="Firefly Metrics" done={false} loading={bootStages?.identity} />
               <BootStage label="Truth Kernel" done={false} />
               <BootStage label="Dashboard Ready" done={false} />
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-gray-200 font-mono flex flex-col overflow-hidden">
      {/* Header / Identity Banner */}
      <header className="h-16 border-b border-gray-800 bg-gray-950 flex items-center px-6 justify-between shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded bg-indigo-600 flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-widest text-white uppercase">
              {loading ? "BOOTING..." : identity?.platform_name || "SWI PLATFORM"}
            </h1>
            <p className="text-xs text-gray-500">
              {loading ? "Establishing consensus..." : `v${identity?.version} - Build ${identity?.build} - ${identity?.environment.toUpperCase()}`}
            </p>
          </div>
        </div>
        {!loading && identity && (
          <div className="flex items-center gap-6">
            <div className="flex flex-col items-end">
              <span className="text-[10px] text-gray-500 uppercase tracking-widest">Security Standing</span>
              <span className={`text-sm font-bold ${identity.security_standing >= 0.9 ? 'text-green-400' : 'text-yellow-400'}`}>
                {(identity.security_standing * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-[10px] text-gray-500 uppercase tracking-widest">Truth Kernel</span>
              <span className="text-sm text-indigo-400 font-mono">
                {identity.truth_kernel_hash.substring(0, 12)}...
              </span>
            </div>
          </div>
        )}
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 border-r border-gray-800 bg-gray-950/50 flex flex-col shrink-0">
          <nav className="p-4 flex flex-col gap-2">
            <NavItem active={activeRoute === "firefly"} onClick={() => onNavigate("firefly")} icon={<Activity className="w-4 h-4" />} label="Firefly Metrics" />
            <NavItem active={activeRoute === "truth-kernel"} onClick={() => onNavigate("truth-kernel")} icon={<Database className="w-4 h-4" />} label="Truth Kernel" />
            <NavItem active={activeRoute === "audit"} onClick={() => onNavigate("audit")} icon={<FileText className="w-4 h-4" />} label="Audit Log" />
            <NavItem active={activeRoute === "security"} onClick={() => onNavigate("security")} icon={<ShieldAlert className="w-4 h-4" />} label="Security" />
            <NavItem active={activeRoute === "settings"} onClick={() => onNavigate("settings")} icon={<Settings className="w-4 h-4" />} label="Platform Config" />
          </nav>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-auto bg-[#0a0a0a] p-6">
          {loading ? <SkeletonLoader /> : children}
        </main>
      </div>
    </div>
  );
};

const NavItem = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: ReactNode, label: string }) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded text-sm transition-colors text-left ${
      active ? "bg-indigo-500/10 text-indigo-300 border border-indigo-500/20" : "text-gray-400 hover:bg-gray-800/50 hover:text-gray-200 border border-transparent"
    }`}
  >
    {icon}
    {label}
  </button>
);
