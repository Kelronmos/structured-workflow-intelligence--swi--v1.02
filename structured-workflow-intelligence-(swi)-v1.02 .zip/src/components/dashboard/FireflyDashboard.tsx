import React, { useState, useEffect } from "react";
import { Activity, AlertTriangle, TrendingUp, TrendingDown, ServerCrash, Shield } from "lucide-react";
import { motion } from "framer-motion";

export const FireflyDashboard = () => {
  const [metrics, setMetrics] = useState<any>(null);

  useEffect(() => {
    // Simulating initial fetch
    setTimeout(() => {
      setMetrics({
        drift: 0.14,
        driftTrend: "stable",
        refusals: 21,
        refusalsTrend: "down",
        shadowEvents: 2,
        replayQueue: 4,
        violations: 0,
        confidence: 94,
        recentDrift: [
          { time: "09:42", value: 0.21 },
          { time: "09:43", value: 0.18 },
          { time: "09:44", value: 0.15 },
          { time: "09:45", value: 0.14 },
        ]
      });
    }, 600);
  }, []);

  if (!metrics) {
    return (
      <div className="grid grid-cols-4 gap-4 animate-pulse">
        {[...Array(8)].map((_, i) => (
          <div key={i} className={`bg-gray-900/50 border border-gray-800 rounded p-6 h-32 ${i === 0 ? 'col-span-2 row-span-2 h-full' : ''}`}></div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 h-full">
      <div>
        <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
          <Activity className="w-6 h-6 text-indigo-400" />
          Firefly Telemetry
        </h2>
        <p className="text-gray-500 text-sm mt-1">Live execution metrics, drift indicators, and event bus throughput.</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {/* Main Drift KPI */}
        <div className="col-span-2 row-span-2 bg-gradient-to-br from-gray-900 to-black border border-gray-800 rounded-lg p-6 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Activity className="w-32 h-32" />
          </div>
          <div>
            <h3 className="text-gray-400 text-sm uppercase tracking-widest font-medium mb-1">Current Drift</h3>
            <div className="flex items-baseline gap-4">
              <span className="text-6xl font-bold text-white tracking-tighter">{metrics.drift.toFixed(2)}</span>
              <span className="flex items-center gap-1 text-sm font-medium px-2.5 py-1 rounded-full bg-gray-800 text-gray-300 border border-gray-700">
                {metrics.driftTrend === 'stable' ? <TrendingDown className="w-3 h-3 text-green-400" /> : <TrendingUp className="w-3 h-3 text-yellow-400" />}
                Stable
              </span>
            </div>
          </div>
          
          <div className="mt-8">
            <h4 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Recent Drift Timeline</h4>
            <div className="flex gap-1 items-end h-16">
              {metrics.recentDrift.map((d: any, i: number) => (
                <div key={i} className="flex-1 flex flex-col items-center justify-end gap-2 group">
                  <span className="text-[10px] text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity absolute -mt-6">{d.value}</span>
                  <div 
                    className="w-full bg-indigo-500/20 border-t-2 border-indigo-500 rounded-t-sm transition-all duration-500"
                    style={{ height: `${(d.value / 0.3) * 100}%` }}
                  ></div>
                  <span className="text-[10px] text-gray-500">{d.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <StatCard title="Prompt Refusals" value={metrics.refusals} trend={metrics.refusalsTrend} trendValue="12% from 1h" color="text-yellow-400" />
        <StatCard title="Shadow Events" value={metrics.shadowEvents} color="text-gray-300" />
        <StatCard title="Replay Queue" value={metrics.replayQueue} color="text-indigo-400" />
        <StatCard title="Policy Violations" value={metrics.violations} color={metrics.violations === 0 ? "text-green-400" : "text-red-400"} />
        <div className="col-span-2 bg-gray-900 border border-gray-800 rounded-lg p-6 flex items-center justify-between">
          <div>
            <h3 className="text-gray-400 text-sm uppercase tracking-widest font-medium mb-1">System Confidence</h3>
            <span className="text-3xl font-bold text-white">{metrics.confidence}%</span>
          </div>
          <div className="h-full w-px bg-gray-800 mx-4"></div>
          <div>
            <h3 className="text-gray-400 text-sm uppercase tracking-widest font-medium mb-1">Integrity</h3>
            <span className="text-xl font-bold text-green-400 flex items-center gap-2">
              <Shield className="w-5 h-5" /> PASS
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, trend, trendValue, color }: any) => (
  <div className="bg-gray-900 border border-gray-800 rounded-lg p-6 flex flex-col justify-between">
    <h3 className="text-gray-400 text-xs uppercase tracking-widest font-medium">{title}</h3>
    <div className="mt-4 flex items-end justify-between">
      <span className={`text-3xl font-bold ${color}`}>{value}</span>
      {trend && (
        <span className={`flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded ${trend === 'down' ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'}`}>
          {trend === 'down' ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
          {trendValue}
        </span>
      )}
    </div>
  </div>
);
