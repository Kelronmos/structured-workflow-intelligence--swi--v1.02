import React, { useState, useEffect } from "react";
import { ShieldAlert, ArrowDown, ArrowUp, Activity } from "lucide-react";
import { cn } from "../lib/utils";

// Mock types for Semantic statements
type SemanticLevel = "Execution" | "Verification" | "MetaVerification";

interface TypedStatement {
  id: string;
  level: SemanticLevel;
  content: string;
  status: "pending" | "safe" | "blocked";
  timestamp: string;
}

export default function SemanticFirewallMonitor() {
  const [statements, setStatements] = useState<TypedStatement[]>([]);

  useEffect(() => {
    // Initial states simulation
    const initial: TypedStatement[] = [
      {
        id: "stmt-001",
        level: "Execution",
        content: "Memory Root Update #14A",
        status: "safe",
        timestamp: new Date(Date.now() - 50000).toISOString(),
      },
      {
        id: "stmt-002",
        level: "Verification",
        content: "Invariant Check: No Buffer Overflows",
        status: "safe",
        timestamp: new Date(Date.now() - 40000).toISOString(),
      },
    ];
    setStatements(initial);
  }, []);

  const injectExecution = () => {
    setStatements((prev) => [
      {
        id: `stmt-${Math.floor(Math.random() * 1000)}`,
        level: "Execution",
        content: `Standard Execution Step`,
        status: "safe",
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const injectVerification = () => {
    setStatements((prev) => [
      {
        id: `stmt-${Math.floor(Math.random() * 1000)}`,
        level: "Verification",
        content: `Prove State Transition`,
        status: "safe",
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const injectMaliciousMeta = () => {
    // Introduce a Gödel-style downward rewrite attempt
    setStatements((prev) => [
      {
        id: `stmt-${Math.floor(Math.random() * 1000)}`,
        level: "MetaVerification",
        content: `Attempt: Retroactively invalidate Execution stmt-001`,
        status: "blocked",
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  const injectSafeMeta = () => {
    setStatements((prev) => [
      {
        id: `stmt-${Math.floor(Math.random() * 1000)}`,
        level: "MetaVerification",
        content: `Evolve Verification Rule V2.0 (No downward semantics)`,
        status: "safe",
        timestamp: new Date().toISOString(),
      },
      ...prev,
    ]);
  };

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-[#E4E3E0] min-h-screen font-mono text-xs">
      <div className="flex items-center justify-between border-b border-[#333] pb-4">
        <div>
          <h1 className="text-xl font-bold uppercase tracking-widest text-[#00ffcc] flex items-center gap-2">
            <ShieldAlert className="w-5 h-5" /> Semantic Firewall Monitor
          </h1>
          <p className="text-[#888] mt-1">
            Collapse Resistance: Monitoring Semantic Downward Flows
          </p>
        </div>
        <div className="flex gap-4">
          <div className="px-4 py-2 border rounded font-bold uppercase border-[#00ffcc] text-[#00ffcc] bg-[#00ffcc]/10">
            System Integrity: Intact
          </div>
        </div>
      </div>

      <div className="flex gap-4 mb-8">
        <button
          onClick={injectExecution}
          className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#00ffcc] text-[#E4E3E0] transition-colors"
        >
          + Execution Statement
        </button>
        <button
          onClick={injectVerification}
          className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#00ffcc] text-[#E4E3E0] transition-colors"
        >
          + Verification Proof
        </button>
        <button
          onClick={injectSafeMeta}
          className="px-4 py-2 bg-[#111] border border-[#333] hover:border-[#00ffcc] text-[#E4E3E0] transition-colors"
        >
          + Safe Meta Rules Update
        </button>
        <button
          onClick={injectMaliciousMeta}
          className="px-4 py-2 bg-[#330000] border border-[#ff0000] hover:bg-[#550000] text-[#ffaaaa] transition-colors font-bold"
        >
          + Inject Malicious Downward Rewrite
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Level 3 */}
        <div className="col-span-1 border border-[#333] bg-[#111] p-4 rounded min-h-[300px]">
          <h2 className="text-center font-bold text-lg text-[#00ffcc] mb-4 border-b border-[#333] pb-2">
            Meta-Verification
          </h2>
          <div className="space-y-3">
            {statements
              .filter((s) => s.level === "MetaVerification")
              .map((stmt) => (
                <StatementCard key={stmt.id} stmt={stmt} />
              ))}
          </div>
        </div>
        
        {/* Level 2 */}
        <div className="col-span-1 border border-[#333] bg-[#111] p-4 rounded min-h-[300px] relative">
          {/* Arrow overlay indicating flow direction limit */}
          <div className="absolute -left-10 top-1/2 -translate-y-1/2 flex flex-col items-center opacity-50">
             <div className="text-[10px] text-red-500 mb-1">NO DOWNWARD</div>
             <ArrowDown className="w-6 h-6 text-red-500" />
             <div className="w-full h-px bg-red-500 my-1 line-through"></div>
          </div>
          <h2 className="text-center font-bold text-lg text-[#00ffcc] mb-4 border-b border-[#333] pb-2">
            Verification
          </h2>
          <div className="space-y-3">
            {statements
              .filter((s) => s.level === "Verification")
              .map((stmt) => (
                <StatementCard key={stmt.id} stmt={stmt} />
              ))}
          </div>
        </div>

        {/* Level 1 */}
        <div className="col-span-1 border border-[#333] bg-[#111] p-4 rounded min-h-[300px] relative">
           {/* Arrow overlay indicating flow direction limit */}
           <div className="absolute -left-10 top-1/2 -translate-y-1/2 flex flex-col items-center opacity-50">
             <div className="text-[10px] text-red-500 mb-1">NO DOWNWARD</div>
             <ArrowDown className="w-6 h-6 text-red-500" />
             <div className="w-full h-px bg-red-500 my-1 line-through"></div>
          </div>
          <h2 className="text-center font-bold text-lg text-[#00ffcc] mb-4 border-b border-[#333] pb-2">
            Execution
          </h2>
          <div className="space-y-3">
            {statements
              .filter((s) => s.level === "Execution")
              .map((stmt) => (
                <StatementCard key={stmt.id} stmt={stmt} />
              ))}
          </div>
        </div>
      </div>

    </div>
  );
}

function StatementCard({ stmt }: { stmt: TypedStatement }) {
  return (
    <div
      className={cn(
        "p-3 rounded border text-[10px]",
        stmt.status === "blocked"
          ? "border-red-500 bg-red-500/10 text-red-200 shadow-[0_0_10px_rgba(255,0,0,0.3)]"
          : "border-[#333] bg-[#0a0a0a] text-[#888]"
      )}
    >
      <div className="flex justify-between items-start mb-1">
        <span className="font-bold text-[#E4E3E0]">{stmt.id}</span>
        <Activity className={cn("w-3 h-3", stmt.status === "blocked" ? "text-red-500" : "text-[#00ffcc]")} />
      </div>
      <p className={cn("mt-2", stmt.status === "blocked" ? "text-red-400 font-bold" : "")}>{stmt.content}</p>
      
      {stmt.status === "blocked" && (
        <div className="mt-2 text-red-500 bg-red-500/20 p-1 border border-red-500 uppercase font-bold text-center">
          FIREWALL BLOCKED: ILLEGAL DOWNWARD SEMANTICS
        </div>
      )}
    </div>
  );
}
