// src/components/SWIExecutionSimulator.tsx
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cpu, ShieldAlert, Database, Activity, Terminal, ChevronRight } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { SWI_ISA_v1 } from '@/swi-core/kernel/ISA_Definition';

interface ExecutionStep {
    id: string;
    mnemonic: string;
    code: string;
    status: 'PENDING' | 'EXECUTING' | 'COMMITTED' | 'HALTED';
    timestamp: number;
    register_delta?: string;
}

export default function SWIExecutionSimulator() {
    const [steps, setSteps] = useState<ExecutionStep[]>([]);
    const [isAutoPlaying, setIsAutoPlaying] = useState(true);
    const scrollRef = useRef<HTMLDivElement>(null);

    const [registers] = useState<{ name: string; value: string }[]>(() => 
        SWI_ISA_v1.registers.map(reg => ({
            name: reg.split(' ')[0],
            value: `0x${Math.floor(Math.random() * 65535).toString(16).toUpperCase().padStart(4, '0')}`
        }))
    );
    const [cycleId] = useState(() => Math.floor(Math.random() * 9999).toString().padStart(4, '0'));
    const [verificationRoot] = useState(() => `0x${Math.floor(Math.random() * 0xFFFFFFFF).toString(16).toUpperCase().padStart(8, '0')}`);

    const generateStep = (): ExecutionStep => {
        const instr = SWI_ISA_v1.instructions[Math.floor(Math.random() * SWI_ISA_v1.instructions.length)];
        const reg = SWI_ISA_v1.registers[Math.floor(Math.random() * SWI_ISA_v1.registers.length)];
        
        return {
            id: Math.random().toString(36).substring(2, 9).toUpperCase(),
            mnemonic: instr.mnemonic,
            code: instr.code,
            status: 'PENDING',
            timestamp: Date.now(),
            register_delta: `${reg} -> 0x${Math.random().toString(16).substring(2, 6).toUpperCase()}`
        };
    };

    useEffect(() => {
        if (!isAutoPlaying) return;

        const interval = setInterval(() => {
            setSteps(prev => {
                const nextSteps = [...prev];
                // Update previous step to COMMITTED
                if (nextSteps.length > 0) {
                    nextSteps[nextSteps.length - 1].status = 'COMMITTED';
                }
                // Add new step
                const newStep = generateStep();
                newStep.status = 'EXECUTING';
                return [...nextSteps.slice(-15), newStep];
            });
        }, 800);

        return () => clearInterval(interval);
    }, [isAutoPlaying]);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [steps]);

    return (
        <div className="bg-[#050505] border border-white/5 rounded-[2rem] p-6 font-mono overflow-hidden relative group">
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-500/20 rounded-lg">
                        <Cpu className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                        <h3 className="text-xs font-black text-white/90 uppercase tracking-widest">SWI-ISA v1.0 Pipeline</h3>
                        <p className="text-[8px] text-white/30 uppercase tracking-[0.2em]">Deterministic Hardware Simulator</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/5 rounded-full">
                        <Activity className="w-3 h-3 text-green-500 animate-pulse" />
                        <span className="text-[9px] text-white/40 uppercase font-black">Cycle: 0.{cycleId}</span>
                    </div>
                    <button 
                        onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                        className={cn(
                            "px-3 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all",
                            isAutoPlaying ? "bg-red-500/10 text-red-500 border border-red-500/20" : "bg-green-500/10 text-green-500 border border-green-500/20"
                        )}
                    >
                        {isAutoPlaying ? 'PAUSE' : 'RESUME'}
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[400px]">
                {/* Instruction Stream */}
                <div className="lg:col-span-8 flex flex-col h-full bg-black/40 rounded-2xl border border-white/5 overflow-hidden">
                    <div className="px-4 py-2 border-b border-white/5 flex items-center justify-between bg-white/5">
                        <span className="text-[9px] font-black text-white/30 uppercase">Opcode Stream (SWI-v6)</span>
                        <ChevronRight className="w-3 h-3 text-white/20" />
                    </div>
                    <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
                        <AnimatePresence initial={false}>
                            {steps.map((step) => (
                                <motion.div
                                    key={step.id}
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    className={cn(
                                        "flex items-center justify-between p-2 rounded-lg border text-[10px] transition-colors",
                                        step.status === 'EXECUTING' ? "bg-blue-500/10 border-blue-500/30 text-blue-400" : "bg-white/5 border-white/5 text-white/40"
                                    )}
                                >
                                    <div className="flex items-center gap-4">
                                        <span className="font-mono opacity-40">[{step.id}]</span>
                                        <span className="font-black tracking-widest">{step.mnemonic}</span>
                                        <span className="text-[9px] opacity-30 font-bold">{step.code}</span>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <span className="text-[8px] font-mono italic opacity-60">{step.register_delta}</span>
                                        <span className={cn(
                                            "px-2 py-0.5 rounded-full text-[8px] font-black",
                                            step.status === 'EXECUTING' ? "bg-blue-500 text-white" : "bg-white/10 text-white/20"
                                        )}>
                                            {step.status}
                                        </span>
                                    </div>
                                </motion.div>
                            ))}
                        </AnimatePresence>
                    </div>
                </div>

                {/* Register State & Failsafe */}
                <div className="lg:col-span-4 space-y-4">
                    <div className="p-4 bg-white/5 border border-white/5 rounded-2xl h-1/2">
                        <h4 className="text-[9px] font-black text-white/30 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <Database className="w-3 h-3" /> Core Registers
                        </h4>
                        <div className="space-y-2">
                            {registers.map((reg, i) => (
                                <div key={i} className="flex justify-between items-center text-[10px]">
                                    <span className="text-white/40">{reg.name}</span>
                                    <span className="text-blue-400 font-mono">{reg.value}</span>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-2xl h-1/2 relative overflow-hidden">
                        <div className="absolute inset-0 bg-red-500/5 animate-pulse" />
                        <div className="relative z-10">
                            <h4 className="text-[9px] font-black text-red-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                                <ShieldAlert className="w-3 h-3" /> R1 Failsafe Status
                            </h4>
                            <div className="space-y-4">
                                <div>
                                    <div className="flex justify-between items-center text-[9px] mb-1">
                                        <span className="text-red-400/60 uppercase font-black">Drift (λ)</span>
                                        <span className="text-red-400 font-mono">0.002</span>
                                    </div>
                                    <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                        <div className="h-full bg-red-500 w-[2%]" />
                                    </div>
                                </div>
                                <div className="p-2 border border-red-500/20 rounded-xl bg-black/40">
                                    <p className="text-[9px] text-red-300 italic">
                                        "Kernel state locked. All instructions verified against Proxima v6.0 Standard."
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <Terminal className="w-3 h-3 text-white/20" />
                        <span className="text-[8px] font-bold text-white/20 uppercase tracking-[0.2em]">Verification Root: {verificationRoot}</span>
                    </div>
                </div>
                <div className="px-4 py-2 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                    <span className="text-[9px] font-black text-blue-400 uppercase tracking-widest italic">Continuity Locked (S9-v6)</span>
                </div>
            </div>
        </div>
    );
}
