import React, { useState, useEffect } from "react";
import {
  Activity,
  AlertTriangle,
  Brain,
  Network,
  Crosshair,
  ShieldAlert,
  Terminal,
  Zap,
  CheckCircle2,
  Lock,
  RefreshCw,
  Gauge
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

type DriftState = "NOMINAL" | "WARNING" | "DANGER_DRIFT" | "LOCKDOWN_REFLEX";

interface SimulationState {
  tick: number;
  driftScore: number;
  trustMass: number;
  reflexTriggered: boolean;
  state: DriftState;
  lastHeartbeatTick: number;
  logs: string[];
}

export default function SWIPhysicsSimulationGrounds() {
  const [activeTab, setActiveTab] = useState<"MATRIX" | "GROUNDS" | "INVARIANTS">("MATRIX");
  const [simState, setSimState] = useState<SimulationState>({
    tick: 0,
    driftScore: 0,
    trustMass: 100,
    reflexTriggered: false,
    state: "NOMINAL",
    lastHeartbeatTick: 0,
    logs: ["[SYSTEM BOOT] Governance Physics Engine online.", "[ONTOLOGY] Strict invariant bounds initialized."]
  });

  const [simRunning, setSimRunning] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (simRunning && !simState.reflexTriggered) {
      interval = setInterval(() => {
        setSimState(prev => {
          const driftIncrement = (Math.random() - 0.5) * 15; // Unpredictable positive/negative drift
          const newDrift = prev.driftScore + driftIncrement;
          const newTrust = Math.max(0, prev.trustMass - (Math.abs(newDrift) * 0.05));
          const timeSinceHeartbeat = prev.tick - prev.lastHeartbeatTick;
          
          let nextState: DriftState = "NOMINAL";
          let reflex = false;
          let logs = [...prev.logs];

          if (Math.abs(newDrift) > 50) {
             nextState = "LOCKDOWN_REFLEX";
             reflex = true;
             logs.push(`[TICK ${prev.tick}] CRITICAL: |D(t)| > 50 (+50/-50 Tolerance breached). Reflex Trigger executing.`);
          } else if (timeSinceHeartbeat > 8) {
             nextState = "LOCKDOWN_REFLEX";
             reflex = true;
             logs.push(`[TICK ${prev.tick}] CRITICAL: Δt > T_max (Clock heartbeat missed). Temporal Continuity failed.`);
          } else if (Math.abs(newDrift) > 25) {
             nextState = "WARNING";
             if (prev.state !== "WARNING") logs.push(`[TICK ${prev.tick}] WARNING: Drift oscillating toward boundary limits.`);
          } else {
             nextState = "NOMINAL";
          }

          if (logs.length > 8) logs.splice(0, logs.length - 8);

          return {
            ...prev,
            tick: prev.tick + 1,
            driftScore: newDrift,
            trustMass: newTrust,
            reflexTriggered: reflex,
            state: nextState,
            logs
          };
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [simRunning, simState.reflexTriggered]);

  const injectChaos = () => {
    setSimState(prev => ({
      ...prev,
      driftScore: prev.driftScore > 0 ? prev.driftScore + 25 : prev.driftScore - 25,
      logs: [...prev.logs, `[INJECT] Adversarial divergence inserted. Drift computationally accelerated.`].slice(-8)
    }));
  };

  const heartbeatSync = () => {
     setSimState(prev => ({
        ...prev,
        lastHeartbeatTick: prev.tick,
        logs: [...prev.logs, `[SYNC] Heartbeat verified. Governance timestamp anchored.`].slice(-8)
     }));
  };

  const stabilize = () => {
    setSimState(prev => ({
      ...prev,
      driftScore: 0,
      trustMass: 100,
      reflexTriggered: false,
      lastHeartbeatTick: prev.tick,
      state: "NOMINAL",
      logs: [...prev.logs, `[REFLEX] Governance intervention complete. State reconciled to origin.`].slice(-8)
    }));
    setSimRunning(false);
  };

  const resetSim = () => {
    setSimState({
      tick: 0,
      driftScore: 0,
      trustMass: 100,
      reflexTriggered: false,
      state: "NOMINAL",
      lastHeartbeatTick: 0,
      logs: ["[RESET] Simulation grounded to zero origin."]
    });
    setSimRunning(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      <div className="bg-[#050510] border border-blue-500/20 p-6 md:p-8 flex items-center justify-between overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 blur-[120px] pointer-events-none"></div>
        <div className="relative z-10 w-full">
           <h2 className="text-xl md:text-2xl font-black uppercase tracking-widest text-[#E4E3E0] flex items-center gap-3">
              <Network className="w-6 h-6 text-blue-500" /> SWI Governance Physics Engine
           </h2>
           <p className="text-xs font-mono text-blue-300/60 mt-2 max-w-3xl leading-relaxed">
              Symbolic architecture mapped to deterministic transitions. Trust behaves like mass, drift as entropy, 
              governance as constraint, and reflex as the immune response. A system without a defined root reference 
              cannot reliably maintain continuity of state.
           </p>
        </div>
      </div>

      <div className="flex gap-2 border-b border-white/10 pb-4 overflow-x-auto">
        {["MATRIX", "GROUNDS", "INVARIANTS"].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={cn(
              "px-4 py-2 text-xs font-bold uppercase tracking-widest transition-all whitespace-nowrap",
              activeTab === tab ? "bg-white/10 text-white border-b-2 border-blue-500" : "text-white/40 hover:text-white/80"
            )}
          >
            {tab === "MATRIX" ? "Ontology Matrix" : tab === "GROUNDS" ? "Simulation Grounds" : "Formal Invariants"}
          </button>
        ))}
      </div>

      <div className="bg-[#141414] border border-white/10 p-6 min-h-[500px]">
         {activeTab === "MATRIX" && (
            <div className="space-y-6 animate-in slide-in-from-bottom-4">
               <h3 className="text-sm font-bold uppercase tracking-widest text-blue-400 mb-4 border-b border-blue-500/30 pb-2">Periodic System of Governance Logic</h3>
               <p className="text-xs font-mono text-white/60">The ontology matrix defines the invariant meaning behind state hashes. Adjacent "elements" interact to form governance compounds.</p>
               
               {/* Minimal abstract representation of a periodic table layout */}
               <div className="grid grid-cols-12 gap-1 overflow-x-auto min-w-[800px] mt-8 opacity-80 hover:opacity-100 transition-opacity">
                 {/* Row 1 */}
                 <div className="col-span-1 aspect-square bg-blue-900/40 border border-blue-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-blue-300 font-bold">Rn</span></div>
                 <div className="col-span-10"></div>
                 <div className="col-span-1 aspect-square bg-emerald-900/40 border border-emerald-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-emerald-300 font-bold">Ob</span></div>
                 
                 {/* Row 2 */}
                 <div className="col-span-1 aspect-square bg-purple-900/40 border border-purple-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-purple-300 font-bold">Et</span></div>
                 <div className="col-span-1 aspect-square bg-purple-900/40 border border-purple-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-purple-300 font-bold">Sf</span></div>
                 <div className="col-span-8"></div>
                 <div className="col-span-1 aspect-square bg-cyan-900/40 border border-cyan-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-cyan-300 font-bold">Tr</span></div>
                 <div className="col-span-1 aspect-square bg-cyan-900/40 border border-cyan-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-cyan-300 font-bold">Vd</span></div>

                 {/* Row 3 - Full */}
                 <div className="col-span-1 aspect-square bg-amber-900/40 border border-amber-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-amber-300 font-bold">Gv</span></div>
                 <div className="col-span-1 aspect-square bg-amber-900/40 border border-amber-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-amber-300 font-bold">Pl</span></div>
                 <div className="col-span-1 aspect-square bg-orange-900/40 border border-orange-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-orange-300 font-bold">Df</span></div>
                 <div className="col-span-1 aspect-square bg-orange-900/40 border border-orange-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-orange-300 font-bold">Rx</span></div>
                 <div className="col-span-1 aspect-square bg-orange-900/40 border border-orange-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-orange-300 font-bold">Lk</span></div>
                 <div className="col-span-1 aspect-square bg-red-900/40 border border-red-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-red-300 font-bold">An</span></div>
                 <div className="col-span-1 aspect-square bg-red-900/40 border border-red-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-red-300 font-bold">Cr</span></div>
                 <div className="col-span-1 aspect-square bg-emerald-900/40 border border-emerald-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-emerald-300 font-bold">Lg</span></div>
                 <div className="col-span-1 aspect-square bg-emerald-900/40 border border-emerald-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-emerald-300 font-bold">Hp</span></div>
                 <div className="col-span-1 aspect-square bg-cyan-900/40 border border-cyan-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-cyan-300 font-bold">Id</span></div>
                 <div className="col-span-1 aspect-square bg-cyan-900/40 border border-cyan-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-cyan-300 font-bold">Sy</span></div>
                 <div className="col-span-1 aspect-square bg-cyan-900/40 border border-cyan-500/30 p-1 flex flex-col justify-end"><span className="text-[10px] text-cyan-300 font-bold">Qk</span></div>
               </div>

               <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                 <div className="p-3 bg-blue-900/10 border border-blue-500/20 text-[10px] font-mono"><strong className="text-blue-400 block mb-1">Root (Rn)</strong>The definitive origin. Zero state.</div>
                 <div className="p-3 bg-emerald-900/10 border border-emerald-500/20 text-[10px] font-mono"><strong className="text-emerald-400 block mb-1">Observability (Ob)</strong>Continuous lineage and metric logs.</div>
                 <div className="p-3 bg-purple-900/10 border border-purple-500/20 text-[10px] font-mono"><strong className="text-purple-400 block mb-1">Ethics (Et)</strong>Value constraint bindings.</div>
                 <div className="p-3 bg-red-900/10 border border-red-500/20 text-[10px] font-mono"><strong className="text-red-400 block mb-1">Anomaly (An)</strong>Detected adversarial drift or corruption.</div>
               </div>
            </div>
         )}

         {activeTab === "GROUNDS" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in slide-in-from-bottom-4">
               {/* Controls & Metrics */}
               <div className="space-y-6">
                  <div className="bg-[#0a0a0a] border border-white/10 p-5 flex flex-col gap-4">
                     <h3 className="text-[11px] font-bold uppercase tracking-widest text-white/50 mb-2 flex items-center gap-2">
                        <Gauge className="w-4 h-4" /> Runtime Telemetry
                     </h3>
                     
                     <div>
                        <div className="flex justify-between text-[10px] font-mono mb-1">
                           <span className="text-white/60">Drift Entropy (+50/-50 Tolerance)</span>
                           <span className={cn(Math.abs(simState.driftScore) > 50 ? "text-red-400 font-bold" : "text-emerald-400")}>
                              {simState.driftScore > 0 ? "+" : ""}{Math.floor(simState.driftScore)} Δ
                           </span>
                        </div>
                        <div className="w-full bg-white/5 h-2 relative border border-white/10">
                           <div className="absolute top-0 bottom-0 left-[50%] w-[1px] bg-white/30 z-10"></div>
                           <div className={cn(
                              "h-full absolute top-0 bottom-0 transition-all duration-300",
                              Math.abs(simState.driftScore) > 50 ? "bg-red-500" : Math.abs(simState.driftScore) > 25 ? "bg-amber-500" : "bg-emerald-500"
                           )} 
                           style={{ 
                              left: simState.driftScore < 0 ? `${Math.max(0, 50 + simState.driftScore)}%` : "50%",
                              width: `${Math.min(50, Math.abs(simState.driftScore))}%` 
                           }}></div>
                        </div>
                     </div>

                     <div>
                        <div className="flex justify-between text-[10px] font-mono mb-1">
                           <span className="text-white/60">Trust Mass</span>
                           <span className="text-blue-400">{Math.floor(simState.trustMass)} kg</span>
                        </div>
                        <div className="w-full bg-white/5 h-2">
                           <div className="bg-blue-500 h-full transition-all duration-300" style={{ width: `${simState.trustMass}%` }}></div>
                        </div>
                     </div>

                     <div className="flex justify-between items-center p-3 border border-white/10 bg-white/5 mt-2">
                        <span className="text-[10px] font-mono text-white/50">System State</span>
                        <span className={cn(
                           "text-[10px] font-black uppercase tracking-widest px-2 py-1",
                           simState.state === "LOCKDOWN_REFLEX" ? "bg-red-500/20 text-red-400 border border-red-500/50 animate-pulse" :
                           simState.state === "DANGER_DRIFT" ? "bg-amber-500/20 text-amber-400" :
                           simState.state === "WARNING" ? "bg-yellow-500/20 text-yellow-500" :
                           "bg-emerald-500/20 text-emerald-400"
                        )}>
                           {simState.state}
                        </span>
                     </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                     {!simRunning && !simState.reflexTriggered && simState.tick === 0 ? (
                        <button onClick={() => setSimRunning(true)} className="col-span-2 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] uppercase tracking-widest rounded-sm transition-all flex items-center justify-center gap-2">
                           <Activity className="w-4 h-4" /> Start Runtime Clock
                        </button>
                     ) : simState.reflexTriggered ? (
                        <button onClick={stabilize} className="col-span-2 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-[10px] uppercase tracking-widest rounded-sm transition-all flex items-center justify-center gap-2">
                           <ShieldAlert className="w-4 h-4" /> Execute Reflex Stabilization
                        </button>
                     ) : (
                        <>
                           <button onClick={() => setSimRunning(!simRunning)} className="py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-[10px] uppercase tracking-widest transition-all border border-white/10 relative overflow-hidden group">
                              <div className="absolute inset-0 bg-blue-500/10 blur-[10px] group-hover:bg-blue-500/20"></div>
                              <span className="relative z-10">{simRunning ? "Pause Sim" : "Resume Sim"}</span>
                           </button>
                           <button onClick={heartbeatSync} disabled={simState.reflexTriggered || !simRunning} className="py-2 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 text-blue-300 flex justify-center items-center font-bold text-[10px] uppercase tracking-widest transition-all gap-2 disabled:opacity-50 relative group">
                              <RefreshCw className="w-3 h-3 group-hover:rotate-180 transition-transform duration-500" /> Verify Clock (Heartbeat)
                           </button>
                           <button onClick={resetSim} className="py-2 bg-white/5 hover:bg-white/10 text-white flex justify-center items-center font-bold text-[10px] uppercase tracking-widest transition-all gap-2">
                              Reset
                           </button>
                           <button onClick={injectChaos} disabled={simState.reflexTriggered || !simRunning} className="py-2 bg-red-900/40 hover:bg-red-800/60 border border-red-500/30 text-red-300 font-bold text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                              <Crosshair className="w-4 h-4" /> Inject Path Drift
                           </button>
                        </>
                     )}
                  </div>
               </div>

               {/* Log Engine */}
               <div className="bg-[#0a0a0a] border border-white/10 p-4 font-mono text-[9px] relative flex flex-col h-[350px]">
                  <div className="flex border-b border-white/10 pb-2 mb-2 uppercase tracking-widest text-white/40 gap-2 items-center">
                     <Terminal className="w-3 h-3" /> Event Log & Reflex Engine
                  </div>
                  <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar flex flex-col">
                     {simState.logs.map((log, idx) => (
                        <div key={idx} className={cn(
                           "py-1",
                           log.includes("CRITICAL") || log.includes("IMMUNE") ? "text-red-400 font-bold" :
                           log.includes("WARNING") ? "text-amber-400" :
                           log.includes("REFLEX") ? "text-blue-400" :
                           log.includes("INJECT") ? "text-fuchsia-400" :
                           "text-white/60"
                        )}>
                           {log}
                        </div>
                     ))}
                     {simRunning && !simState.reflexTriggered && (
                        <div className="text-white/30 animate-pulse mt-auto pt-2">_ computing vector drift...</div>
                     )}
                  </div>
               </div>
            </div>
         )}

         {activeTab === "INVARIANTS" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in slide-in-from-bottom-4">
               <div className="bg-[#141414] border border-blue-500/20 p-5 space-y-4 font-mono text-[10px]">
                  <h4 className="text-xs font-bold text-blue-400 uppercase tracking-widest border-b border-blue-500/30 pb-2"><Zap className="w-4 h-4 inline mr-2 relative -top-0.5" /> Formal Definitions</h4>
                  
                  <div>
                     <strong className="text-cyan-300 block mb-1">Definition 1: Danger Drift</strong>
                     <p className="text-white/60 leading-relaxed">
                        A persistent condition where <span className="text-blue-300 bg-blue-900/30 px-1">ΔState &gt; Tolerated Variance</span> over sequential ticks without a self-correcting reflex trigger. If vector alignment to root genesis is broken, state linearity collapses.
                     </p>
                  </div>
                  
                  <div>
                     <strong className="text-cyan-300 block mb-1">Definition 2: Reflex Trigger</strong>
                     <p className="text-white/60 leading-relaxed">
                        An autonomous, non-overridable state interrupt that executes when trust mass depletes below <span className="text-blue-300 bg-blue-900/30 px-1">M_min</span>. Reverts runtime to baseline verification bounds.
                     </p>
                  </div>

                  <div>
                     <strong className="text-cyan-300 block mb-1">Definition 3: Nominal State</strong>
                     <p className="text-white/60 leading-relaxed">
                        A state where all policy gradients correlate positively with human-centric ethics values (<span className="text-purple-300 bg-purple-900/30 px-1">Et</span>) and execute within bounded logical constraints.
                     </p>
                  </div>

                  <div>
                     <strong className="text-amber-300 block mb-1">Definition 4: Drift Envelope</strong>
                     <p className="text-white/60 leading-relaxed font-mono">
                        <span className="text-amber-300 bg-amber-900/30 px-1 py-0.5">-50 ≤ D(t) ≤ 50</span><br/>
                        Controlled deviation and temporary uncertainty is permitted, but reflex isolation triggers instantly when <span className="text-red-300 bg-red-900/30 px-1">|D(t)| &gt; 50</span>.
                     </p>
                  </div>
                  
                  <div>
                     <strong className="text-amber-300 block mb-1">Definition 5: Clock Verification</strong>
                     <p className="text-white/60 leading-relaxed font-mono">
                        <span className="text-amber-300 bg-amber-900/30 px-1 py-0.5">Δt ≤ T_max</span><br/>
                        Synchronization delay cannot exceed the maximum tolerated continuity interval. Failure to sync triggers lockdown.
                     </p>
                  </div>
               </div>

               <div className="bg-[#141414] border border-blue-500/20 p-5 flex flex-col items-center justify-center text-center">
                  <Lock className="w-12 h-12 text-blue-500/30 mb-4" />
                  <h4 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0] mb-2">Definition Precedes Continuity</h4>
                  <p className="text-[10px] font-mono text-white/50 max-w-sm leading-relaxed mb-6">
                     Without defining direction, origin, measurement, and transformation rules, a state hash has no semantic meaning. High-trust systems separate the execution layer, observation layer, validation layer, and root authority to prevent self-justified corruption.
                  </p>
                  
                  <div className="w-full text-left">
                     <ProofArtifacts
                        id="formal-bounds"
                        title="SWI Physics Grounding"
                        data={{
                           layer: "Governance Ontology",
                           root_anchor: "SECURE",
                           continuity: "DEFINED"
                        }}
                        variant="always-dark"
                     />
                  </div>
               </div>
            </div>
         )}
      </div>
    </div>
  );
}
