import { useState, useEffect, useRef } from 'react';
import { Shield, AlertTriangle, CheckCircle2, RefreshCw, Zap, Eye, History, FileJson, Download, ShieldCheck, XCircle, TrendingUp, User } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import SecurityMazeGraph from './SecurityMazeGraph';

interface MazeArtifact {
  countdown: number;
  state: Record<string, number | string | boolean>;
  selected: {
    value: number;
    risk: 'LOW' | 'MEDIUM' | 'HIGH';
    policyViolation?: boolean;
  };
  signature: string;
  event?: string;
  humanInput?: {
    accepted: boolean;
    message?: string;
    input?: { value: number };
  };
  fix?: string;
  outcomes?: {
    value: number;
    risk: 'LOW' | 'MEDIUM' | 'HIGH';
    policyViolation?: boolean;
  }[];
  insights?: Record<string, number>;
  futureScenarios?: {
    predictedValue: number;
    predictedRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  }[];
  predictedDecision?: {
    predictedValue: number;
    predictedRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  };
  s9?: {
    rebooting: boolean;
  };
  reportFile?: string;
  simulationCount?: number;
}

interface ExternalPolicy {
  id: string;
  name: string;
  description: string;
  constraints: {
    maxRiskValue: number;
    minCountdownForReboot: number;
    requiredSignatureAlgorithm: string;
  };
  version: string;
  updatedAt: string;
}

interface SecurityMazeViewProps {
  theme: 'light' | 'dark';
}

interface StableState {
  rootHash: string;
  decision: 'ALLOW' | 'REFUSE';
  drift: {
    score: number;
  };
  reason: string;
}

interface VerificationResult {
  type: string;
  fileName?: string;
  result: {
    valid: boolean;
    hash?: string;
    totalEvents?: number;
    verifiedEvents?: number;
    failedEvents?: number;
    message?: string;
  };
}

export default function SecurityMazeView({ theme }: SecurityMazeViewProps) {
  const [artifacts, setArtifacts] = useState<MazeArtifact[]>([]);
  const [currentArtifact, setCurrentArtifact] = useState<MazeArtifact | null>(null);
  const [stableState, setStableState] = useState<StableState | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [reports, setReports] = useState<string[]>([]);
  const [policy, setPolicy] = useState<ExternalPolicy | null>(null);
  const [verificationResult, setVerificationResult] = useState<VerificationResult | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const prevRootHash = useRef<string | null>(null);
  const [isPromoted, setIsPromoted] = useState(false);

  useEffect(() => {
    if (stableState && stableState.rootHash !== prevRootHash.current) {
      setIsPromoted(true);
      prevRootHash.current = stableState.rootHash;
      
      const timeout = setTimeout(() => setIsPromoted(false), 1000);
      return () => clearTimeout(timeout);
    }
  }, [stableState]);

  useEffect(() => {
    fetch('/api/policy')
      .then(res => res.json())
      .then(setPolicy)
      .catch(err => console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch policy:", err));

    // 🖥️ 1) ZERO-BLINK DISPLAY LAYER (POLLING)
    const pollStableState = () => {
      fetch('/api/stable-state')
        .then(res => res.json())
        .then(setStableState)
        .catch(() => {}); // Silent if not ready
    };

    pollStableState();
    const interval = setInterval(pollStableState, 2000);
    return () => clearInterval(interval);
  }, []);

  const startMaze = () => {
    setArtifacts([]);
    setCurrentArtifact(null);
    setReports([]);
    setVerificationResult(null);
    setIsRunning(true);

    const eventSource = new EventSource('/api/run-maze');

    eventSource.onmessage = (event) => {
      const artifact = JSON.parse(event.data);
      setCurrentArtifact(artifact);
      setArtifacts((prev) => [artifact, ...prev].slice(0, 50));
      
      if (artifact.reportFile) {
        setReports(prev => [artifact.reportFile, ...prev]);
      }
    };

    eventSource.addEventListener('end', () => {
      setIsRunning(false);
      eventSource.close();
    });

    eventSource.addEventListener('error', (e) => {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "SSE Error:", e);
      setIsRunning(false);
      eventSource.close();
    });
  };

  const verifyData = async (data: MazeArtifact) => {
    setIsVerifying(true);
    setVerificationResult(null);
    try {
      const res = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await res.json();
      setVerificationResult(result);
    } catch (err) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Verification failed:", err);
    } finally {
      setIsVerifying(false);
    }
  };

  const verifyReport = async (fileName: string) => {
    setIsVerifying(true);
    setVerificationResult(null);
    try {
      const res = await fetch(`/reports/${fileName}`);
      const reportData = await res.json();
      const verifyRes = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportData)
      });
      const result = await verifyRes.json();
      setVerificationResult({ ...result, fileName });
    } catch (err) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Report verification failed:", err);
    } finally {
      setIsVerifying(false);
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [artifacts]);

  return (
    <div className="space-y-8">
      {/* 🖥️ 1) ZERO-BLINK DISPLAY LAYER (ALWAYS STABLE) */}
      <motion.div
        animate={{
          backgroundColor: isPromoted 
            ? (theme === 'light' ? '#f0fdf4' : '#064e3b') 
            : (theme === 'light' ? '#ffffff' : '#141414'),
          borderColor: isPromoted ? '#22c55e' : (theme === 'light' ? '#141414' : 'rgba(228, 227, 224, 0.2)')
        }}
        transition={{ duration: 0.5 }}
        className={cn(
          "p-6 border relative overflow-hidden",
          theme === 'light' ? "border-[#141414]" : "border-[#E4E3E0]/20"
        )}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-green-500" />
            <h3 className="text-sm uppercase font-bold tracking-widest">Stable Display Layer (Verified)</h3>
          </div>
          {stableState && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold opacity-40">Root Hash:</span>
              <span className="text-[10px] font-mono opacity-60">{stableState.rootHash?.slice(0, 16) || 'N/A'}...</span>
            </div>
          )}
        </div>

        {stableState ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold opacity-40 block">Verified Decision</span>
              <div className={cn(
                "text-2xl font-bold tracking-tighter uppercase",
                stableState.decision === 'ALLOW' ? "text-green-500" : "text-red-500"
              )}>
                {stableState.decision}
              </div>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold opacity-40 block">Current Drift</span>
              <div className="text-2xl font-bold tracking-tighter font-mono">
                {stableState.drift?.score?.toFixed(4) || '0.0000'}
              </div>
            </div>
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold opacity-40 block">Reasoning</span>
              <div className="text-xs opacity-60 italic leading-tight">
                {stableState.reason}
              </div>
            </div>
          </div>
        ) : (
          <div className="h-16 flex items-center justify-center text-[10px] uppercase font-bold opacity-20 tracking-widest italic">
            Awaiting first verified promotion from sandbox...
          </div>
        )}
      </motion.div>

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Zap className="w-6 h-6 text-yellow-500" />
          <h2 className="text-2xl font-bold uppercase tracking-tighter">Security Maze Runtime</h2>
        </div>
        <div className="flex items-center gap-4">
          {isRunning && (
            <div className="flex items-center gap-4">
              {currentArtifact?.s9?.rebooting && (
                <div className="flex items-center gap-2 px-3 py-1 bg-yellow-500/10 border border-yellow-500/20 rounded-full animate-pulse">
                  <RefreshCw className="w-3 h-3 text-yellow-500 animate-spin" />
                  <span className="text-[10px] font-bold uppercase text-yellow-600 dark:text-yellow-400">S9: Silent Rebooting</span>
                </div>
              )}
              <div className="flex items-center gap-2 px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-[10px] font-bold uppercase text-green-600 dark:text-green-400">Continuous Learning Active</span>
              </div>
            </div>
          )}
          <button
            onClick={startMaze}
            disabled={isRunning}
            className={cn(
              "px-6 py-3 border font-bold uppercase text-sm transition-all flex items-center gap-2",
              theme === 'light'
                ? "border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0]"
                : "border-[#E4E3E0] hover:bg-[#E4E3E0] hover:text-[#141414]",
              isRunning && "opacity-50 cursor-not-allowed"
            )}
          >
            {isRunning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            {isRunning ? "Maze Active" : "Activate Security Maze"}
          </button>
        </div>
      </div>

      {/* Verification Result Overlay */}
      <AnimatePresence>
        {verificationResult && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setVerificationResult(null)}
          >
            <div 
              className={cn(
                "w-full max-w-md p-8 border shadow-2xl space-y-6",
                theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
              )}
              onClick={e => e.stopPropagation()}
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <ShieldCheck className={cn("w-8 h-8", verificationResult.result.valid ? "text-green-500" : "text-red-500")} />
                  <h3 className="text-xl font-bold uppercase tracking-tighter">Verification Result</h3>
                </div>
                <button onClick={() => setVerificationResult(null)} className="opacity-40 hover:opacity-100 transition-opacity">
                  <XCircle className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-4">
                <div className={cn(
                  "p-4 border font-bold uppercase text-xs tracking-widest text-center",
                  verificationResult.result.valid ? "bg-green-500/10 text-green-600 border-green-500/20" : "bg-red-500/10 text-red-600 border-red-500/20"
                )}>
                  {verificationResult.result.valid ? "INTEGRITY CONFIRMED" : "INTEGRITY COMPROMISED"}
                </div>

                <div className="space-y-2 font-mono text-[10px]">
                  <div className="flex justify-between">
                    <span className="opacity-40">TYPE:</span>
                    <span>{verificationResult.type}</span>
                  </div>
                  {verificationResult.fileName && (
                    <div className="flex justify-between">
                      <span className="opacity-40">FILE:</span>
                      <span className="truncate max-w-[200px]">{verificationResult.fileName}</span>
                    </div>
                  )}
                  {verificationResult.result.hash && (
                    <div className="space-y-1">
                      <span className="opacity-40 block">CALCULATED HASH:</span>
                      <span className="block break-all opacity-60">{verificationResult.result.hash}</span>
                    </div>
                  )}
                  {verificationResult.result.totalEvents !== undefined && (
                    <div className="grid grid-cols-3 gap-2 pt-2 border-t border-black/5 dark:border-white/5">
                      <div className="text-center">
                        <span className="opacity-40 block">TOTAL</span>
                        <span className="font-bold">{verificationResult.result.totalEvents}</span>
                      </div>
                      <div className="text-center">
                        <span className="opacity-40 block text-green-500">VERIFIED</span>
                        <span className="font-bold text-green-500">{verificationResult.result.verifiedEvents}</span>
                      </div>
                      <div className="text-center">
                        <span className="opacity-40 block text-red-500">FAILED</span>
                        <span className="font-bold text-red-500">{verificationResult.result.failedEvents}</span>
                      </div>
                    </div>
                  )}
                </div>

                <p className="text-xs opacity-60 leading-relaxed italic">
                  {verificationResult.result.message || "The report has been fully audited against the cryptographic signatures stored in the runtime memory."}
                </p>
              </div>

              <button 
                onClick={() => setVerificationResult(null)}
                className={cn(
                  "w-full py-3 border font-bold uppercase text-xs tracking-widest transition-all",
                  theme === 'light' ? "border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0]" : "border-[#E4E3E0] hover:bg-[#E4E3E0] hover:text-[#141414]"
                )}
              >
                Close Audit Window
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {currentArtifact ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Visualization */}
          <div className="lg:col-span-8 space-y-6">
            {/* Countdown & Status */}
            <div className={cn(
              "p-8 border relative overflow-hidden",
              theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
            )}>
              <div className="absolute top-0 left-0 w-full h-1 bg-black/5 dark:bg-white/5">
                <motion.div 
                  className="h-full bg-yellow-500"
                  initial={{ width: "100%" }}
                  animate={{ width: `${currentArtifact.countdown}%` }}
                  transition={{ duration: 0.1 }}
                />
              </div>

              <div className="flex justify-between items-end">
                <div>
                  <label className="text-[10px] uppercase font-bold opacity-40 block tracking-widest mb-2">Execution Countdown</label>
                  <div className="text-8xl font-bold tracking-tighter font-mono leading-none">
                    {String(currentArtifact.countdown).padStart(3, '0')}
                  </div>
                </div>
                <div className="text-right space-y-2">
                  <div className="flex items-center gap-2 justify-end">
                    <span className="text-[10px] uppercase font-bold opacity-40">Risk Level:</span>
                    <span className={cn(
                      "px-2 py-0.5 text-[10px] font-bold uppercase border",
                      currentArtifact.selected.risk === 'HIGH' ? "text-red-600 border-red-600" :
                      currentArtifact.selected.risk === 'MEDIUM' ? "text-yellow-600 border-yellow-600" :
                      "text-green-600 border-green-600"
                    )}>
                      {currentArtifact.selected.risk}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 justify-end">
                    <span className="text-[10px] uppercase font-bold opacity-40">System State:</span>
                    <span className="text-xs font-mono">{JSON.stringify(currentArtifact.state)}</span>
                  </div>
                  {currentArtifact.simulationCount !== undefined && (
                    <div className="flex items-center gap-2 justify-end">
                      <span className="text-[10px] uppercase font-bold opacity-40">Simulations:</span>
                      <span className="text-xs font-mono text-yellow-500 font-bold">
                        {currentArtifact.simulationCount.toLocaleString()}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Event Notification Overlay */}
              <AnimatePresence mode="wait">
                {currentArtifact.event && (
                  <motion.div
                    key={currentArtifact.event}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="mt-6 p-3 bg-yellow-500/10 border border-yellow-500/30 flex items-center gap-3"
                  >
                    <Zap className="w-4 h-4 text-yellow-500" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-yellow-600 dark:text-yellow-400">
                      {currentArtifact.event}
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Simulation Grid */}
              <div className="space-y-4">
                <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest block">Sandbox Simulation Matrix</label>
                <div className="grid grid-cols-5 gap-2">
                  {currentArtifact.outcomes?.map((outcome, idx) => (
                    <motion.div 
                      key={idx}
                      whileHover={{ scale: 1.05, borderColor: '#eab308' }}
                      whileTap={{ scale: 0.95 }}
                      transition={{ type: 'spring', stiffness: 400, damping: 17 }}
                      className={cn(
                        "aspect-square border flex flex-col items-center justify-center p-1 transition-all duration-300 relative cursor-pointer",
                        outcome.value === currentArtifact.selected?.value 
                          ? "border-yellow-500 bg-yellow-500/10 scale-110 z-10" 
                          : theme === 'light' ? "border-[#141414]/10 bg-white" : "border-[#E4E3E0]/10 bg-[#141414]",
                        outcome.risk === 'HIGH' ? "opacity-40" : "opacity-100"
                      )}
                    >
                      <span className="text-[8px] font-mono opacity-40">{outcome.value}</span>
                      <div className={cn(
                        "w-1.5 h-1.5 rounded-full mt-1",
                        outcome.risk === 'HIGH' ? "bg-red-500" :
                        outcome.risk === 'MEDIUM' ? "bg-yellow-500" :
                        "bg-green-500"
                      )} />
                      {outcome.policyViolation && (
                        <div className="absolute top-0 right-0 p-0.5">
                          <Shield className="w-2 h-2 text-red-500" />
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Predictive Simulation */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest block">Predictive Future Scenarios</label>
                  <TrendingUp className="w-3 h-3 opacity-40" />
                </div>
                <div className={cn(
                  "border p-4 space-y-3",
                  theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
                )}>
                  {currentArtifact.futureScenarios?.map((scenario, idx) => (
                    <div key={idx} className="flex items-center justify-between text-[10px] font-mono">
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "w-1 h-1 rounded-full",
                          scenario.predictedRisk === 'HIGH' ? "bg-red-500" :
                          scenario.predictedRisk === 'MEDIUM' ? "bg-yellow-500" :
                          "bg-green-500"
                        )} />
                        <span className="opacity-60">VAL: {scenario.predictedValue.toFixed(2)}</span>
                      </div>
                      <span className={cn(
                        "font-bold",
                        scenario.predictedRisk === 'HIGH' ? "text-red-500" :
                        scenario.predictedRisk === 'MEDIUM' ? "text-yellow-500" :
                        "text-green-500"
                      )}>{scenario.predictedRisk}</span>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-black/5 dark:border-white/5 mt-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] uppercase font-bold opacity-40">Next Direction:</span>
                      <span className="text-[10px] font-mono font-bold text-yellow-500">
                        {currentArtifact.predictedDecision?.predictedValue.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* D3 Security Node Relationship Graph */}
            <div className={cn(
              "p-6 border",
              theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
            )}>
              <div className="flex items-center gap-2 mb-4">
                <Zap className="w-4 h-4 opacity-40" />
                <h3 className="text-xs uppercase font-bold tracking-widest">System Nodes Trust Topology</h3>
              </div>
              <SecurityMazeGraph theme={theme} currentDrift={stableState?.drift?.score || 0} />
            </div>

            {/* Human Intervention Window */}
            <div className={cn(
              "p-6 border",
              theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
            )}>
              <div className="flex items-center gap-2 mb-4">
                <Eye className="w-4 h-4 opacity-40" />
                <h3 className="text-xs uppercase font-bold tracking-widest">Observer Intervention Window</h3>
              </div>
              
              <div className="flex items-center gap-6">
                <div className="flex-1">
                  {currentArtifact.humanInput ? (
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "p-3 rounded-full",
                        currentArtifact.humanInput.accepted ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                      )}>
                        {currentArtifact.humanInput.accepted ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="text-xs font-bold uppercase">
                          {currentArtifact.humanInput.accepted ? "Input Accepted" : "Input Rejected"}
                        </p>
                        <p className="text-[10px] opacity-60">
                          {currentArtifact.humanInput.accepted 
                            ? `Value: ${currentArtifact.humanInput.input?.value ?? '?'}` 
                            : currentArtifact.humanInput.message}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="h-10 flex items-center text-[10px] uppercase font-bold opacity-20 tracking-widest">
                      Awaiting Window (Every 20 ticks)
                    </div>
                  )}
                </div>
                <div className="w-px h-10 bg-black/10 dark:bg-white/10" />
                <div className="flex items-center gap-3">
                  <User className="w-4 h-4 opacity-40" />
                  <span className="text-[10px] uppercase font-bold opacity-40">Role: Observer</span>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar: Policy, Memory & Log */}
          <div className="lg:col-span-4 space-y-6">
            {/* External Policy Anchor */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 opacity-40" />
                <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest">External Policy Anchor</label>
              </div>
              <div className={cn(
                "p-4 border space-y-3",
                theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
              )}>
                {policy ? (
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold text-yellow-500">{policy.id}</span>
                      <span className="text-[8px] opacity-40">v{policy.version}</span>
                    </div>
                    <p className="text-[10px] font-bold uppercase tracking-tighter leading-tight">{policy.name}</p>
                    <div className="space-y-1.5 pt-2 border-t border-black/5 dark:border-white/5">
                      <div className="flex justify-between text-[9px]">
                        <span className="opacity-40 uppercase">Max Risk Val:</span>
                        <span className="font-mono">{policy.constraints.maxRiskValue}</span>
                      </div>
                      <div className="flex justify-between text-[9px]">
                        <span className="opacity-40 uppercase">Min Reboot T:</span>
                        <span className="font-mono">{policy.constraints.minCountdownForReboot}</span>
                      </div>
                      <div className="flex justify-between text-[9px]">
                        <span className="opacity-40 uppercase">Algorithm:</span>
                        <span className="font-mono">{policy.constraints.requiredSignatureAlgorithm}</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="h-20 flex items-center justify-center text-[10px] uppercase font-bold opacity-20 tracking-widest">
                    Loading Policy...
                  </div>
                )}
              </div>
            </div>

            {/* S9 Continuous Reporting */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <FileJson className="w-4 h-4 opacity-40" />
                <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest">S9 Continuous Reporting</label>
              </div>
              <div className={cn(
                "p-4 border space-y-4 max-h-[200px] overflow-y-auto",
                theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
              )}>
                {reports.length > 0 ? (
                  <div className="space-y-2">
                    {reports.map((report, idx) => (
                      <div 
                        key={idx}
                        className="flex items-center justify-between p-2 bg-black/5 dark:bg-white/5 hover:bg-yellow-500/10 transition-colors group"
                      >
                        <span className="text-[9px] font-mono opacity-60 truncate max-w-[120px]">{report}</span>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => verifyReport(report)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-yellow-500 hover:scale-110"
                            title="Verify Report Integrity"
                          >
                            <ShieldCheck className="w-3 h-3" />
                          </button>
                          <a 
                            href={`/reports/${report}`}
                            target="_blank"
                            rel="noreferrer"
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-yellow-500 hover:scale-110"
                            title="Download Report"
                          >
                            <Download className="w-3 h-3" />
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="h-20 flex items-center justify-center text-[10px] uppercase font-bold opacity-20 tracking-widest text-center">
                    Awaiting Report Generation (Every 30 ticks)
                  </div>
                )}
              </div>
            </div>

            {/* Scarmatic Memory Insights */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 opacity-40" />
                <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest">Scarmatic Memory (Insights)</label>
              </div>
              <div className={cn(
                "p-4 border space-y-4",
                theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
              )}>
                {currentArtifact.insights ? (
                  <div className="space-y-3">
                    {Object.entries(currentArtifact.insights).map(([risk, count]) => (
                      <div key={risk} className="space-y-1">
                        <div className="flex justify-between text-[10px] uppercase font-bold">
                          <span className="opacity-60">{risk} RISK</span>
                          <span>{count as number}</span>
                        </div>
                        <div className="h-1 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden">
                          <motion.div 
                            className={cn(
                              "h-full",
                              risk === 'HIGH' ? "bg-red-500" :
                              risk === 'MEDIUM' ? "bg-yellow-500" :
                              "bg-green-500"
                            )}
                            initial={{ width: 0 }}
                            animate={{ width: `${((count as number) / artifacts.length) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="h-20 flex items-center justify-center text-[10px] uppercase font-bold opacity-20 tracking-widest">
                    No Patterns Learned
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-[10px] uppercase font-bold opacity-40 tracking-widest block flex justify-between items-center">
                <span>Live Artifact Log</span>
                {isVerifying && <span className="text-[8px] animate-pulse text-yellow-500">VERIFYING...</span>}
              </label>
              <div 
                ref={scrollRef}
                className={cn(
                  "h-[300px] border overflow-y-auto p-4 space-y-2 font-mono text-[9px]",
                  theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
                )}
              >
                <AnimatePresence initial={false}>
                  {artifacts.map((art) => (
                    <motion.div
                      key={art.countdown}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={cn(
                        "p-2 border-b last:border-0 group",
                        art.event ? "bg-yellow-500/5 border-yellow-500/20" : "border-black/5 dark:border-white/5"
                      )}
                    >
                      <div className="flex justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-yellow-500 font-bold">T-{art.countdown}</span>
                          <button 
                            onClick={() => verifyData(art)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity text-yellow-500"
                            title="Verify Artifact Integrity"
                          >
                            <ShieldCheck className="w-3 h-3" />
                          </button>
                        </div>
                        <span className="opacity-40">{art.signature.slice(0, 8)}...</span>
                      </div>
                      <div className="opacity-60 truncate">
                        STATE: {JSON.stringify(art.state)}
                      </div>
                      <div className="opacity-60 truncate">
                        SEL: {JSON.stringify(art.selected)}
                      </div>
                      {art.event && (
                        <div className="text-yellow-600 dark:text-yellow-400 font-bold mt-1">
                          EVENT: {art.event}
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className={cn(
          "h-[400px] border flex flex-col items-center justify-center space-y-4 opacity-20",
          theme === 'light' ? "bg-white border-[#141414]" : "bg-[#141414] border-[#E4E3E0]/20"
        )}>
          <Zap className="w-16 h-16 stroke-[0.5]" />
          <p className="uppercase tracking-[0.2em] text-sm">Security Maze Engine Offline</p>
          <p className="text-[10px] max-w-xs text-center leading-relaxed">
            Activate the runtime engine to begin continuous simulation, self-healing, and governed execution.
          </p>
        </div>
      )}
    </div>
  );
}
