import React, { useState } from "react";

type Event = {
  id: string;
  stage: string;
  before?: any;
  after?: any;
  status: "PASS" | "FAIL" | "WARN";
  hashes?: Record<string, string>;
};

export default function FailureReplayDebugger({
  events
}: {
  events: Event[];
}) {
  const [index, setIndex] = useState(0);

  if (!events || events.length === 0) {
      return <div className="p-4 text-white">No events to replay.</div>;
  }

  const current = events[index];

  return (
    <div className="flex bg-[#141414] text-white overflow-hidden border border-white/10" style={{ height: "600px", fontFamily: "monospace" }}>

      {/* LEFT: TIMELINE */}
      <div className="w-[25%] border-r border-[#333] flex flex-col">
        <div className="p-4 bg-black/40 border-b border-[#333]">
           <h3 className="text-xs uppercase font-bold tracking-widest text-fuchsia-400">Replay Timeline</h3>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {events.map((e, i) => (
            <div
                key={e.id}
                onClick={() => setIndex(i)}
                className={`p-2 cursor-pointer text-[10px] transition-colors border ${
                    i === index ? "bg-[#222] border-white/20" : "bg-transparent border-transparent hover:bg-white/5"
                } ${
                    e.status === "FAIL"
                    ? "text-red-400"
                    : e.status === "WARN"
                    ? "text-orange-400"
                    : "text-emerald-400"
                }`}
            >
                <div className="font-bold">{e.stage}</div>
                <div className="opacity-50 mt-1">{e.status}</div>
            </div>
            ))}
        </div>
      </div>

      {/* CENTER: DIFF VIEW */}
      <div className="w-[50%] p-4 flex flex-col">
        <h3 className="text-xs uppercase font-bold tracking-widest text-[#E4E3E0] mb-4">State Diff Viewer</h3>

        <div className="mb-4 text-[11px] p-2 bg-black/30 border border-white/10">
          <strong className="text-fuchsia-400">Stage:</strong> {current.stage}
        </div>

        <div className="flex gap-4 flex-1 overflow-hidden">
          <div className="flex-1 flex flex-col">
              <div className="text-[10px] bg-[#111] border border-[#333] border-b-0 p-1 text-center font-bold text-white/50">BEFORE</div>
              <pre className="flex-1 bg-[#0a0a0a] border border-[#333] p-3 text-[10px] overflow-auto text-white/80 whitespace-pre-wrap">
                {JSON.stringify(current.before, null, 2) || "null"}
              </pre>
          </div>

          <div className="flex-1 flex flex-col">
            <div className="text-[10px] bg-[#111] border border-[#333] border-b-0 p-1 text-center font-bold text-white/50">AFTER</div>
            <pre className="flex-1 bg-[#0a0a0a] border border-[#333] p-3 text-[10px] overflow-auto text-white/80 whitespace-pre-wrap">
                {JSON.stringify(current.after, null, 2) || "null"}
            </pre>
          </div>
        </div>
      </div>

      {/* RIGHT: INSPECTOR */}
      <div className="w-[25%] border-l border-[#333] p-4 flex flex-col bg-[#0f0f0f]">
        <h3 className="text-xs uppercase font-bold tracking-widest text-[#E4E3E0] mb-4">Inspector</h3>

        <div className="text-[11px] mb-4 flex items-center gap-2">
            <b className="text-white/50">Status:</b> 
            <span className={`px-2 py-0.5 font-bold ${
                current.status === "FAIL" ? "bg-red-500/20 text-red-400" :
                current.status === "WARN" ? "bg-orange-500/20 text-orange-400" :
                "bg-emerald-500/20 text-emerald-400"
            }`}>
                {current.status}
            </span>
        </div>

        {current.hashes && (
          <div className="space-y-4">
            <div>
                <p className="text-[10px] text-emerald-400 font-bold mb-1 uppercase">Content Hash</p>
                <code className="block bg-black p-2 border border-white/5 text-[9px] text-emerald-200/70 break-all">{current.hashes.contentHash || "N/A"}</code>
            </div>

            <div>
                <p className="text-[10px] text-blue-400 font-bold mb-1 uppercase">Layout Hash</p>
                <code className="block bg-black p-2 border border-white/5 text-[9px] text-blue-200/70 break-all">{current.hashes.layoutHash || "N/A"}</code>
            </div>

            <div>
                <p className="text-[10px] text-fuchsia-400 font-bold mb-1 uppercase">Font Hash</p>
                <code className="block bg-black p-2 border border-white/5 text-[9px] text-fuchsia-200/70 break-all">{current.hashes.fontHash || "N/A"}</code>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
