import { cn } from '@/src/lib/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, LineChart, Line } from 'recharts';
import { Info, History, Cpu, ShieldCheck, Activity, Search, X, ScanEye, AlertTriangle, Lock, Hash } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trace } from '../types';
import { ContextScanner } from '../swi/scanner';
import { ProofArtifacts } from './common/ProofArtifacts';
import { hash_step } from '../lib/crypto';

interface Module {
  moduleId: string;
  moduleName: string;
  moduleType: string;
  moduleDescription?: string;
  success: boolean;
  timestamp: string | number;
  signal: unknown;
  signature: string;
}

export default function TraceView({ trace, history = [] }: { trace: Trace, history?: Trace[] }) {
  const [filterTypes, setFilterTypes] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedModuleId, setSelectedModuleId] = useState<string | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [moduleHashes, setModuleHashes] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!trace?.modules) return;
    
    let isMounted = true;
    
    const calculateHashes = async () => {
      const hashes: Record<string, string> = {};
      let prevHash = "0".repeat(64);
      
      for (const m of trace.modules!) {
        const currentHash = await hash_step(m, prevHash);
        hashes[m.moduleId] = currentHash;
        prevHash = currentHash;
      }
      
      if (isMounted) {
        setModuleHashes(hashes);
      }
    };
    
    calculateHashes();
    return () => { isMounted = false; };
  }, [trace]);

  const selectedModule = trace.modules?.find((m: Module) => m.moduleId === selectedModuleId);

  const statusItems = [
    { label: 'Token Validity', value: trace?.tokenValid },
    { label: 'Local Admissibility', value: trace?.locallyValid },
    { label: 'Continuation Basis', value: !trace?.drift?.degraded },
  ];

  const historyData = history.map((t, i) => ({
    index: i + 1,
    score: t?.drift?.score || 0,
    threshold: 0.4
  }));

  const allTypes = ['premodule', 'security', 'ethics', 'governance', 'law', 'safety', 'ops'];

  const moduleGroups = trace?.modules ? {
    premodule: trace.modules.filter((m) => m.moduleType === 'premodule'),
    security: trace.modules.filter((m) => m.moduleType === 'security'),
    ethics: trace.modules.filter((m) => m.moduleType === 'ethics'),
    governance: trace.modules.filter((m) => m.moduleType === 'governance'),
    law: trace.modules.filter((m) => m.moduleType === 'law'),
    safety: trace.modules.filter((m) => m.moduleType === 'safety'),
    ops: trace.modules.filter((m) => m.moduleType === 'ops'),
  } : null;

  const filteredModuleGroups = moduleGroups ? Object.fromEntries(
    Object.entries(moduleGroups).map(([type, mods]: [string, Module[]]) => [
      type,
      mods.filter((m: Module) => 
        (filterTypes.length === 0 || filterTypes.includes(type)) &&
        (searchQuery === '' || m.moduleId.toLowerCase().includes(searchQuery.toLowerCase()) || m.moduleName.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    ]).filter(([, mods]) => (mods as Module[]).length > 0)
  ) : null;

  const toggleFilter = (type: string) => {
    setFilterTypes(prev => 
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  const data = [
    { name: 'Drift Score', value: trace?.drift?.score || 0, threshold: 0.4 },
  ];

  return (
    <div className="space-y-8 relative">
      <ProofArtifacts id={trace?.action || "trace"} title="Cryptographic Trace Execution Artifacts" data={{ drift: trace?.drift, valid: trace?.tokenValid }} />

      <AnimatePresence>
        {isDetailsOpen && selectedModule && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white dark:bg-[#0A0A0A] border-l border-[#141414] dark:border-[#E4E3E0]/20 z-[100] shadow-2xl p-0 overflow-y-auto"
          >
            <div className="sticky top-0 bg-inherit border-b border-[#141414]/10 dark:border-white/10 p-6 flex justify-between items-center z-10">
               <div className="flex items-center gap-3">
                 <ShieldCheck className={cn("w-5 h-5", selectedModule.success === false ? "text-red-500" : "text-green-500")} />
                 <h3 className="text-sm font-bold uppercase tracking-widest">Module Inspection</h3>
               </div>
               <button 
                onClick={() => setIsDetailsOpen(false)}
                className="p-2 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
               >
                 <X className="w-5 h-5" />
               </button>
            </div>

            <div className="p-8 space-y-8">
              {/* Module Header */}
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] font-mono opacity-40 uppercase tracking-widest">{selectedModule.moduleId}</p>
                    <h4 className="text-xl font-bold uppercase tracking-tight">{selectedModule.moduleName}</h4>
                  </div>
                  <span className={cn(
                    "px-3 py-1 text-[8px] font-bold uppercase border",
                    selectedModule.success !== false ? "border-green-500 text-green-500 bg-green-500/5" : "border-red-500 text-red-500 bg-red-500/5"
                  )}>
                    {selectedModule.success !== false ? "VERIFIED" : "FAILED"}
                  </span>
                </div>
                <p className="text-xs opacity-60 leading-relaxed uppercase font-medium">
                  {selectedModule.moduleDescription || "Processing state transition within the S9 kernel boundary."}
                </p>
              </div>

              {/* Error Information */}
              {selectedModule.success === false && (
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-sm space-y-3">
                  <div className="flex items-center gap-2 text-red-500">
                    <AlertTriangle className="w-4 h-4" />
                    <p className="text-[10px] uppercase font-bold">Critical Execution Fault</p>
                  </div>
                  <p className="text-xs font-mono bg-red-500/5 p-3 border border-red-500/10">
                    {(selectedModule.signal as Record<string, unknown>)?.error as string || "UNSPECIFIED_GOVERNANCE_FAULT"}
                  </p>
                </div>
              )}

              {/* Signal & Signature */}
                <div className="space-y-6">
                  <div className="space-y-2">
                    <p className="text-[9px] uppercase font-bold opacity-40 flex items-center gap-2">
                      <Hash className="w-3 h-3" />
                      Step Integrity Hash (Chained)
                    </p>
                    <div className="p-4 bg-black/5 dark:bg-black/20 border border-[#141414]/5 dark:border-white/5 rounded-sm overflow-hidden">
                      <p className="text-[8px] font-mono break-all opacity-60 leading-relaxed text-indigo-500">
                        {moduleHashes[selectedModule.moduleId] || 'Calculating...'}
                      </p>
                      <div className="mt-3 flex items-center gap-2 text-[8px] font-bold uppercase text-indigo-500/60">
                        <Lock className="w-3 h-3" />
                        Chained to execution trace history
                      </div>
                    </div>
                  </div>

                <div className="space-y-2">
                  <p className="text-[9px] uppercase font-bold opacity-40 flex items-center gap-2">
                    <History className="w-3 h-3" />
                    Signal Payload
                  </p>
                  <pre className="p-4 bg-black/5 dark:bg-black/40 border border-[#141414]/10 dark:border-white/10 text-[10px] font-mono overflow-x-auto">
                    {JSON.stringify(selectedModule.signal, null, 2)}
                  </pre>
                </div>

                <div className="space-y-2">
                  <p className="text-[9px] uppercase font-bold opacity-40 flex items-center gap-2">
                    <Lock className="w-3 h-3" />
                    Cryptographic Signature
                  </p>
                  <div className="p-4 bg-black/5 dark:bg-black/20 border border-[#141414]/5 dark:border-white/5 rounded-sm overflow-hidden">
                    <p className="text-[8px] font-mono break-all opacity-60 leading-relaxed">
                      {selectedModule.signature}
                    </p>
                    <div className="mt-3 flex items-center gap-2 text-[8px] font-bold uppercase text-green-500/60">
                      <ShieldCheck className="w-3 h-3" />
                      Authenticity Verified (SWI-v4-MERKLE)
                    </div>
                  </div>
                </div>

                {/* Token Scan */}
                <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-sm space-y-3">
                  <div className="flex items-center gap-2">
                    <ScanEye className="w-3 h-3 text-blue-500" />
                    <p className="text-[9px] uppercase font-bold text-blue-500">Token-Level Context Scan</p>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {ContextScanner.scan(selectedModule.moduleDescription || selectedModule.moduleName).map((token, i) => (
                      <div 
                        key={i} 
                        className={cn(
                          "px-1.5 py-0.5 text-[8px] font-mono border",
                          token.type === 'SENSITIVE' ? "bg-red-500 text-white border-red-600" : "bg-blue-500/10 text-blue-600 border-blue-500/20"
                        )}
                      >
                        {token.token}
                      </div>
                    ))}
                  </div>
                  <div className="pt-2 border-t border-blue-500/10 flex justify-between items-center">
                    <span className="text-[8px] opacity-40 uppercase font-bold">Vector Risk</span>
                    <span className={cn(
                      "text-[10px] font-mono font-bold",
                      ContextScanner.calculateAggregateRisk(ContextScanner.scan(selectedModule.moduleDescription || selectedModule.moduleName)) > 0.3 ? "text-red-500" : "text-green-500"
                    )}>
                      {ContextScanner.calculateAggregateRisk(ContextScanner.scan(selectedModule.moduleDescription || selectedModule.moduleName)).toFixed(4)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Execution Details */}
      <div className={cn(
        "border p-6 transition-colors",
        "bg-white dark:bg-[#141414] border-[#141414] dark:border-[#E4E3E0]/20"
      )}>
        <div className={cn(
          "flex items-center gap-2 mb-4 border-b pb-2",
          "border-[#141414] dark:border-[#E4E3E0]/20"
        )}>
          <Info className="w-4 h-4" />
          <h3 className="text-xs uppercase font-bold tracking-tighter">Execution Context</h3>
        </div>
        <div className="grid grid-cols-2 gap-4 text-[10px] uppercase">
            <div>
              <p className="opacity-40 mb-1">Action</p>
              <p className="font-bold">{trace?.action || 'N/A'}</p>
            </div>
            <div>
              <p className="opacity-40 mb-1">User Behavior</p>
              <p className="font-bold">{trace?.context?.userBehavior || 'N/A'}</p>
            </div>
            <div>
              <p className="opacity-40 mb-1">Environment</p>
              <p className="font-bold">{trace?.context?.environment || 'N/A'}</p>
            </div>
            <div>
              <p className="opacity-40 mb-1">Policy Mismatch</p>
              <p className="font-bold">{trace?.context?.policyMismatch ? 'Detected' : 'None'}</p>
            </div>
          
          {/* Expanded Token Section */}
          <div className={cn(
            "col-span-2 pt-4 border-t mt-2",
            "border-[#141414]/10 dark:border-[#E4E3E0]/10"
          )}>
            <div className="flex items-center gap-2 mb-3">
              <ShieldCheck className="w-3 h-3 opacity-40" />
              <p className="text-[8px] opacity-30 font-bold tracking-widest uppercase">Token Specification</p>
            </div>
            <div className="grid grid-cols-2 gap-4 bg-black/5 dark:bg-white/5 p-3 border border-[#141414]/5 dark:border-white/5">
              <div>
                <p className="opacity-40 mb-1">Status</p>
                <p className={cn(
                  "font-bold",
                  trace.tokenValid ? "text-green-600" : "text-red-600"
                )}>{trace.tokenValid ? 'VALID' : 'INVALID'}</p>
              </div>
              <div>
                <p className="opacity-40 mb-1">Permission</p>
                <p className="font-bold">{trace.locallyValid ? trace.action : 'RESTRICTED'}</p>
              </div>
            </div>
          </div>

          {/* Expanded Metadata Section */}
          <div className={cn(
            "col-span-2 pt-4 border-t mt-2",
            "border-[#141414]/10 dark:border-[#E4E3E0]/10"
          )}>
            <div className="flex items-center gap-2 mb-3">
              <Cpu className="w-3 h-3 opacity-40" />
              <p className="text-[8px] opacity-30 font-bold tracking-widest uppercase">Engine Metadata</p>
            </div>
            <div className="grid grid-cols-2 gap-4 bg-black/5 dark:bg-white/5 p-3 border border-[#141414]/5 dark:border-white/5">
              <div>
                <p className="opacity-40 mb-1">Governance Engine</p>
                <p className="font-bold">{trace.metadata?.engine || 'SWI-v3'}</p>
              </div>
              <div>
                <p className="opacity-40 mb-1">Drift Threshold</p>
                <p className="font-bold">{trace.metadata?.threshold || '0.40'}</p>
              </div>
            </div>
          </div>

          {/* Expanded Cryptographic Proof Section */}
          <div className={cn(
            "col-span-2 pt-4 border-t mt-2",
            "border-[#141414]/10 dark:border-[#E4E3E0]/10"
          )}>
            <div className="flex items-center gap-2 mb-3">
              <Lock className="w-3 h-3 opacity-40" />
              <p className="text-[8px] opacity-30 font-bold tracking-widest uppercase">Cryptographic Proof & Provenance</p>
            </div>
            <div className="space-y-4">
              <div className="bg-black/5 dark:bg-white/5 p-3 border border-[#141414]/5 dark:border-white/5">
                <p className="opacity-40 mb-1 text-[8px] uppercase font-bold">Provenance Chain</p>
                <p className="font-mono text-[9px] break-all leading-relaxed">{trace.provenance || 'S9-UNSPECIFIED-ROOT'}</p>
              </div>
              <div className="bg-black/5 dark:bg-white/5 p-3 border border-[#141414]/5 dark:border-white/5">
                <p className="opacity-40 mb-1 text-[8px] uppercase font-bold">Trace Signature</p>
                <p className="font-mono text-[9px] break-all leading-relaxed">{trace.signature || 'SIG_PENDING_COMMIT'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SWI Module Chain Simulation */}
      {filteredModuleGroups && (
        <div className={cn(
          "border p-6 transition-colors",
          "bg-white dark:bg-[#141414] border-[#141414] dark:border-[#E4E3E0]/20"
        )}>
          <div className={cn(
            "flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 border-b pb-4",
            "border-[#141414] dark:border-[#E4E3E0]/20"
          )}>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <h3 className="text-xs uppercase font-bold tracking-tighter">SWI Module Chain (Nodes: {trace.modules?.length})</h3>
            </div>
            
            <div className="flex flex-wrap gap-4 items-center">
              <div className="relative">
                <Search className="w-3 h-3 absolute left-2 top-1/2 -translate-y-1/2 opacity-40" />
                <input 
                  type="text"
                  placeholder="Search Module ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={cn(
                    "pl-7 pr-2 py-1 text-[9px] uppercase font-bold border bg-transparent focus:outline-none transition-all w-40",
                    "border-[#141414]/20 dark:border-[#E4E3E0]/20 focus:border-[#141414] dark:focus:border-[#E4E3E0]"
                  )}
                />
              </div>
              <div className="flex gap-2">
                {allTypes.map(type => (
                  <button
                    key={type}
                    onClick={() => toggleFilter(type)}
                    className={cn(
                      "px-2 py-1 text-[8px] uppercase font-bold border transition-all",
                      filterTypes.includes(type)
                        ? "bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] border-[#141414] dark:border-[#E4E3E0]"
                        : "border-[#141414]/20 dark:border-[#E4E3E0]/20 opacity-40 hover:opacity-100"
                    )}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="space-y-12">
            {Object.entries(filteredModuleGroups).map(([group, mods], groupIdx) => (
              <div key={group} className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full border border-black/10 dark:border-white/10 flex items-center justify-center text-[10px] font-mono font-bold opacity-40">
                    {groupIdx + 1}
                  </div>
                  <h4 className="text-[10px] uppercase font-bold opacity-60 tracking-[0.2em]">{group}</h4>
                </div>
                <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-10 gap-4">
                  {(mods as Module[]).map((m: Module) => (
                    <button 
                      key={m.moduleId}
                      onClick={() => {
                        setSelectedModuleId(m.moduleId);
                        setIsDetailsOpen(true);
                      }}
                      className={cn(
                        "group relative w-10 h-10 border flex flex-col items-center justify-center transition-all",
                        m.success === false ? "border-red-500 bg-red-500/10" : "border-[#141414]/20 dark:border-[#E4E3E0]/20 hover:border-blue-500 bg-white dark:bg-white/5",
                        selectedModuleId === m.moduleId && "ring-2 ring-blue-500"
                      )}
                    >
                      <span className="text-[7px] font-mono font-bold opacity-60">{m.moduleId}</span>
                      <div className={cn(
                        "w-1.5 h-1.5 rounded-full mt-1",
                        m.success === false ? "bg-red-500" : "bg-green-500"
                      )} />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Validation Matrix & Truth Matrix */}
      <div className={cn(
        "border p-6 transition-colors",
        "bg-white dark:bg-[#141414] border-[#141414] dark:border-[#E4E3E0]/20"
      )}>
        <h3 className="text-xs uppercase font-bold tracking-tighter mb-6 border-b pb-2 border-black/10 dark:border-white/10">SWI Module Truth Matrix (Honesty Layer)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            {statusItems.map((item) => (
              <div key={item.label} className="flex justify-between items-center">
                <span className="text-xs uppercase tracking-tight opacity-60">{item.label}</span>
                <div className={cn(
                  "px-2 py-0.5 text-[9px] font-bold uppercase border",
                  item.value ? "text-green-600 border-green-600" : "text-red-600 border-red-600"
                )}>
                  {item.value ? 'Verified' : 'Failed'}
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-black/5 dark:bg-white/5 p-4 rounded-sm border border-[#141414]/10 dark:border-white/10 flex flex-col justify-between">
            <div className="space-y-2 mb-4">
              <h4 className="text-[10px] font-bold uppercase text-purple-600 dark:text-purple-400">Zero-Knowledge Structural Proof</h4>
              <p className="text-[9px] opacity-60 leading-relaxed uppercase">Cryptographic verification that the manifold was preserved during execution without exposing state secrets to the orchestrator.</p>
            </div>
            <div className="bg-white/50 dark:bg-black/50 p-2 border border-black/5 dark:border-white/5 overflow-x-auto">
              <pre className="text-[8px] font-mono text-purple-600 dark:text-purple-400 break-all whitespace-pre-wrap">
                {JSON.stringify({
                    "pi_a": ["0x25a6b093...77fa8", "0x01235b2e...b38e0", "0x125a0b..."],
                    "pi_b": [
                        ["0x23a10...9fc", "0x1ae32...cc7"],
                        ["0x1d473...84c", "0x2bd0a...5ff"]
                    ],
                    "pi_c": ["0x21c8b3...5d1", "0x0c953a...f95", "0x0dbf..."],
                    "protocol": "groth16",
                    "curve": "bn128",
                    "public_signals": [trace?.drift?.score?.toString() || "0", trace?.tokenValid ? "1" : "0", "0x892aF"]
                }, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      </div>

      {/* Drift Analysis */}
      <div className={cn(
        "border p-6 transition-colors",
        "bg-white dark:bg-[#141414] border-[#141414] dark:border-[#E4E3E0]/20"
      )}>
        <h3 className="text-xs uppercase font-bold tracking-tighter mb-6 border-b pb-2 border-black/10 dark:border-white/10">CEK Drift Analysis</h3>
        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ left: -20, right: 20 }}>
              <XAxis type="number" domain={[0, 1]} hide />
              <YAxis dataKey="name" type="category" hide />
              <Tooltip cursor={{ fill: 'transparent' }} />
              <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={40}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.value > 0.4 ? '#ef4444' : '#141414'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* History */}
      {history.length > 1 && (
        <div className={cn(
          "border p-6 transition-colors",
          "bg-white dark:bg-[#141414] border-[#141414] dark:border-[#E4E3E0]/20"
        )}>
          <div className="flex items-center gap-2 mb-6 border-b pb-2 border-black/10 dark:border-white/10">
            <History className="w-4 h-4" />
            <h3 className="text-xs uppercase font-bold tracking-tighter">Drift History</h3>
          </div>
          <div className="h-32 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={historyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.1} />
                <XAxis dataKey="index" hide />
                <YAxis domain={[0, 1]} hide />
                <Line type="monotone" dataKey="score" stroke="#141414" strokeWidth={2} dot={{ r: 2 }} />
                <Line type="step" dataKey="threshold" stroke="#ef4444" strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}
