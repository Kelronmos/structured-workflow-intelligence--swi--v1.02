import React from 'react';
import { motion } from 'motion/react';
import { Database, Link as LinkIcon, ShieldCheck, Clock } from 'lucide-react';

interface MerkleNode {
  hash: string;
  data: unknown;
  timestamp: number;
  prevHash: string;
}

interface MerkleLedgerViewProps {
  chain: MerkleNode[];
}

export default function MerkleLedgerView({ chain }: MerkleLedgerViewProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-purple-500" />
          <h3 className="text-[10px] font-bold uppercase tracking-widest">Merkle Continuation Ledger</h3>
        </div>
        <div className="text-[8px] font-mono opacity-40 uppercase">
          Blocks: {chain?.length || 0} | Root: {chain?.[0]?.hash.substring(0, 12)}...
        </div>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
        {(!chain || chain.length === 0) && (
           <div className="p-8 text-center border border-dashed border-white/5 rounded-xl opacity-20">
              <p className="text-[10px] uppercase font-bold">No blocks committed to chain</p>
           </div>
        )}
        {chain && chain.map((node, idx) => (
          <motion.div 
            key={node.hash}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="p-3 bg-white/5 border border-white/10 rounded-lg hover:border-white/20 transition-all group relative overflow-hidden"
          >
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
                <span className="text-[9px] font-bold uppercase text-purple-400">Block #{chain.length - idx}</span>
              </div>
              <div className="flex items-center gap-2 opacity-50">
                <Clock className="w-3 h-3" />
                <span className="text-[8px] font-mono">{new Date(node.timestamp).toLocaleTimeString()}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                  <span className="text-[7px] uppercase font-bold opacity-30 leading-none">Merkle Hash</span>
                  <div className="text-[8px] font-mono truncate bg-black/30 p-1 rounded border border-white/5">{node.hash}</div>
               </div>
               <div className="space-y-1">
                  <span className="text-[7px] uppercase font-bold opacity-30 leading-none">Linked Parent</span>
                  <div className="text-[8px] font-mono truncate bg-black/30 p-1 rounded border border-white/5 opacity-50">{node.prevHash}</div>
               </div>
            </div>

            <div className="mt-3 flex items-center justify-between">
              <div className="flex gap-2">
                 <div className="px-2 py-0.5 bg-green-500/10 border border-green-500/20 rounded text-[7px] font-bold text-green-500 uppercase flex items-center gap-1">
                    <ShieldCheck className="w-2 h-2" /> Verified
                 </div>
                 <div className="px-2 py-0.5 bg-blue-500/10 border border-blue-500/20 rounded text-[7px] font-bold text-blue-500 uppercase">
                    {(node.data as Record<string, unknown>).status as string || (node.data as Record<string, unknown>).type as string || 'COMMITTED'}
                 </div>
              </div>
              <LinkIcon className="w-3 h-3 opacity-10 group-hover:opacity-100 transition-opacity" />
            </div>

            {/* Link indicator line */}
            {idx < chain.length - 1 && (
               <div className="absolute left-4 bottom-[-10px] w-0.5 h-4 bg-purple-500/20 z-0" />
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
}
