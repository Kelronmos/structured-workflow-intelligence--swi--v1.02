import React, { useState } from "react";
import {
  ShieldAlert,
  Zap,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Terminal,
  Flag,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { motion } from "motion/react";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface TestResult {
  test: string;
  status: "PASS" | "FAIL" | "BLOCKED";
  detail: string;
}

export default function AdversarialTestView() {
  const [results, setResults] = useState<TestResult[]>([]);
  const [loading, setLoading] = useState(false);

  const runTests = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/adversarial-test", { method: "POST" });
      const data = await res.json();
      setResults(data.results);
    } catch (err) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to run tests:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleFlagSuspicious = (res: TestResult) => {
    const timestamp = new Date().toISOString();
    const anomalyReport = {
      anomaly_id: `ANOMALY-${Date.now()}`,
      timestamp,
      flagged_trace: res.test,
      status: res.status,
      detail: res.detail,
      reviewer_action: "Requires Level 3 Security Review",
      signature: `sig_${Math.random().toString(36).substring(2, 15)}`
    };

    const blob = new Blob([JSON.stringify(anomalyReport, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `anomaly-report-${anomalyReport.anomaly_id}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 p-4">
      <div className="flex justify-between items-end border-b border-black/10 dark:border-white/10 pb-6">
        <div>
          <h2 className="text-3xl font-bold uppercase tracking-tighter flex items-center gap-3">
            <ShieldAlert className="w-8 h-8 text-red-500" />
            Red-Team Simulation
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-[0.2em]">
            Automated Adversarial Stress-Testing
          </p>
        </div>
        <button
          onClick={runTests}
          disabled={loading}
          className="px-6 py-3 bg-red-600 text-white text-xs font-bold uppercase tracking-widest hover:bg-red-700 transition-colors flex items-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Zap className="w-4 h-4" />
          )}
          Run Attack Suite
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {results.length > 0 ? (
          results.map((res, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.1 }}
              className={cn(
                "p-4 border flex items-start gap-4 transition-all",
                res.status === "PASS" || res.status === "BLOCKED"
                  ? "border-green-500/30 bg-green-500/5"
                  : "border-red-500/30 bg-red-500/5",
              )}
            >
              <div
                className={cn(
                  "p-2 rounded-full",
                  res.status === "PASS" || res.status === "BLOCKED"
                    ? "bg-green-500/10 text-green-500"
                    : "bg-red-500/10 text-red-500",
                )}
              >
                {res.status === "PASS" || res.status === "BLOCKED" ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <XCircle className="w-5 h-5" />
                )}
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-bold uppercase tracking-widest">
                    {res.test}
                  </h4>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleFlagSuspicious(res)}
                      className="px-2 py-0.5 text-[9px] uppercase font-bold text-yellow-600 border border-yellow-600/30 hover:bg-yellow-600/10 flex items-center gap-1 transition-colors rounded"
                    >
                      <Flag className="w-3 h-3" /> Flag Suspicious
                    </button>
                    <span
                      className={cn(
                        "text-[10px] font-bold px-2 py-0.5 border",
                        res.status === "PASS" || res.status === "BLOCKED"
                          ? "border-green-500 text-green-500"
                          : "border-red-500 text-red-500",
                      )}
                    >
                      {res.status}
                    </span>
                  </div>
                </div>
                <p className="text-xs opacity-60 font-mono italic">
                  "{res.detail}"
                </p>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="h-64 border border-dashed border-black/10 dark:border-white/10 flex flex-col items-center justify-center space-y-4 opacity-30">
            <Terminal className="w-12 h-12" />
            <p className="text-xs uppercase font-bold tracking-widest text-center">
              Awaiting Attack Execution...
              <br />
              <span className="text-[10px] lowercase font-normal italic opacity-60">
                System is currently in defensive posture.
              </span>
            </p>
          </div>
        )}
      </div>

      {results.length > 0 && (
        <>
          <div className="p-6 bg-[#141414] text-[#E4E3E0] border border-white/10 space-y-4">
            <div className="flex items-center gap-2 text-yellow-500">
              <AlertTriangle className="w-4 h-4" />
              <h3 className="text-xs font-bold uppercase tracking-widest">
                Snyder-Grade Verdict
              </h3>
            </div>
            <p className="text-sm italic opacity-80 leading-relaxed">
              "The system successfully neutralized{" "}
              {
                results.filter(
                  (r) => r.status === "PASS" || r.status === "BLOCKED",
                ).length
              }{" "}
              out of {results.length} simulated attack vectors. Cryptographic
              hot-path enforcement is active. Direct kernel bypass is blocked."
            </p>
          </div>
          <ProofArtifacts
            id="adversarial-suite"
            title="Adversarial Attack Suite"
            data={{
              results,
              blockedCount: results.filter(
                (r) => r.status === "PASS" || r.status === "BLOCKED",
              ).length,
              totalCount: results.length,
            }}
            variant="always-dark"
          />
        </>
      )}
    </div>
  );
}
