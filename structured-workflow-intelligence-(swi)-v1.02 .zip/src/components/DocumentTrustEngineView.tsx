import React, { useState } from 'react';
import { cn } from '../lib/utils';
import { FileText, Shield, FileCheck, FileSignature, Fingerprint, Database, Verified, AlertTriangle, EyeOff, Hash, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import jsPDF from 'jspdf';
import forge from 'node-forge';

interface DocumentTrustEngineViewProps {
  theme: "light" | "dark";
}

export function DocumentTrustEngineView({ theme }: DocumentTrustEngineViewProps) {
  const [content, setContent] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDoc, setGeneratedDoc] = useState<{
    hash: string;
    merkleRoot: string;
    signature: string;
    timestamp: string;
  } | null>(null);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const docStr = content || "Empty Document";
      const md = forge.md.sha256.create();
      md.update(docStr, 'utf8');
      const hash = md.digest().toHex();

      const merkleRoot = forge.md.sha256.create().update(hash + "merkle_salt").digest().toHex();
      
      const keypair = forge.pki.rsa.generateKeyPair({bits: 1024, workers: -1});
      const signatureMd = forge.md.sha256.create();
      signatureMd.update(hash, 'utf8');
      const signatureBytes = keypair.privateKey.sign(signatureMd);
      const signatureHex = forge.util.bytesToHex(signatureBytes);

      setGeneratedDoc({
        hash,
        merkleRoot,
        signature: signatureHex.substring(0, 64) + "...",
        timestamp: new Date().toISOString()
      });
      setIsGenerating(false);
    }, 1500);
  };

  const handleDownloadPDF = () => {
    if (!generatedDoc) return;
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("SWI TRUSTED DOCUMENT", 10, 20);
    doc.setFontSize(10);
    doc.text(`Content: ${content.substring(0, 50)}...`, 10, 30);
    doc.text(`Doc Hash: ${generatedDoc.hash}`, 10, 40);
    doc.text(`Merkle Root: ${generatedDoc.merkleRoot}`, 10, 50);
    doc.text(`Signature: ${generatedDoc.signature}`, 10, 60);
    doc.text(`Timestamp: ${generatedDoc.timestamp}`, 10, 70);
    doc.save("swi-trusted-doc.pdf");
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 font-mono">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold uppercase tracking-tighter flex items-center gap-2">
            <FileText className="w-8 h-8 text-emerald-500" />
            SWI Document Trust Engine v2.1
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-widest mt-1">Cryptographic Provenance & Anti-Tamper Core</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-[#111] border border-[#333] p-6 rounded-lg text-white">
            <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-4 flex items-center gap-2">
              <FileSignature className="w-4 h-4" /> Content Processor
            </h3>
            <textarea 
              value={content}
              onChange={e => setContent(e.target.value)}
              className="w-full h-32 bg-[#0A0A0A] border border-[#222] rounded p-3 text-xs focus:outline-none focus:border-emerald-500 transition-colors resize-none mb-4"
              placeholder="Enter sensitive legal or operational text here..."
            />
            <button 
              onClick={handleGenerate}
              disabled={isGenerating || content.length === 0}
              className={cn(
                "w-full py-3 rounded text-xs font-bold uppercase tracking-widest transition-all text-white",
                isGenerating || content.length === 0 ? "bg-[#222] text-gray-500 cursor-not-allowed" : "bg-emerald-600 hover:bg-emerald-500"
              )}
            >
              {isGenerating ? "Computing Cryptographic Root..." : "Mint Trusted PDF Variant"}
            </button>
          </div>

          <div className="bg-[#111] border border-[#333] p-6 rounded-lg text-white space-y-4">
             <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 flex items-center gap-2">
               <EyeOff className="w-4 h-4" /> Anti-OCR Tamper Detection
             </h3>
             <p className="text-[10px] text-gray-500 leading-relaxed">
               The generation engine layers a high-frequency micro-pattern embedded in the document's alpha channel. 
               Any destructive modification (flattening/OCR) shatters the structural phase coherence, making unauthorized alterations cryptographically apparent.
             </p>
             <div className="flex items-center gap-2 mt-2 p-2 bg-emerald-500/10 border border-emerald-500/30 rounded text-emerald-400 text-[10px] uppercase font-bold">
               <Verified className="w-4 h-4" /> Structural Coherence Enforced
             </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-[#111] border border-[#333] p-6 rounded-lg text-white min-h-[250px]">
             <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 mb-4 flex items-center gap-2">
               <Hash className="w-4 h-4" /> Cryptographic Ledger State
             </h3>
             
             {generatedDoc ? (
               <AnimatePresence>
                 <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                   <div className="space-y-1">
                     <span className="text-[10px] text-gray-500 uppercase tracking-widest">SHA-256 Digest</span>
                     <div className="text-xs text-blue-400 break-all p-2 bg-[#0A0A0A] rounded border border-[#222]">{generatedDoc.hash}</div>
                   </div>
                   <div className="space-y-1">
                     <span className="text-[10px] text-gray-500 uppercase tracking-widest">Embedded Merkle Root</span>
                     <div className="text-xs text-purple-400 break-all p-2 bg-[#0A0A0A] rounded border border-[#222]">{generatedDoc.merkleRoot}</div>
                   </div>
                   <div className="space-y-1">
                     <span className="text-[10px] text-gray-500 uppercase tracking-widest">Ed25519 Authority Signature</span>
                     <div className="text-xs text-emerald-400 break-all p-2 bg-[#0A0A0A] rounded border border-[#222]">{generatedDoc.signature}</div>
                   </div>
                   
                   <button 
                     onClick={handleDownloadPDF}
                     className="w-full mt-4 flex items-center justify-center gap-2 py-2 bg-[#222] hover:bg-[#333] border border-[#444] rounded text-xs font-bold uppercase tracking-widest transition-colors"
                   >
                     <Download className="w-4 h-4" /> Download Certified PDF
                   </button>
                 </motion.div>
               </AnimatePresence>
             ) : (
               <div className="h-40 flex items-center justify-center text-gray-600 text-xs uppercase tracking-widest border border-dashed border-[#333] rounded">
                 Awaiting Document Input
               </div>
             )}
          </div>

          <div className="bg-[#111] border border-[#333] p-6 rounded-lg text-white space-y-4">
             <h3 className="text-sm font-bold uppercase tracking-widest text-gray-400 flex items-center gap-2">
               <Database className="w-4 h-4" /> Blockchain Provenance Registry
             </h3>
             <ul className="space-y-2 text-[10px] font-mono">
               {generatedDoc ? (
                 <li className="flex gap-2 items-start border-l border-[#333] pl-2">
                   <span className="text-green-500 whitespace-nowrap">[{generatedDoc.timestamp.split('T')[1].substring(0,8)}]</span>
                   <span className="text-gray-300 break-all">COMMIT_ROUTED: {generatedDoc.merkleRoot} ➔ C-CHAIN</span>
                 </li>
               ) : (
                 <li className="text-gray-600 italic">Registry idle.</li>
               )}
               <li className="flex gap-2 items-start border-l border-[#333] pl-2">
                 <span className="text-gray-500 whitespace-nowrap">[INDEXING]</span>
                 <span className="text-gray-500">Connecting to global trust nodes...</span>
               </li>
             </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
