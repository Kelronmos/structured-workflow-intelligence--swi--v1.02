import React, { useState, useEffect } from "react";
import { createKernel } from "../kernel/init";
import { Terminal, CheckCircle2, ShieldAlert, ServerCrash, History, X } from "lucide-react";
import { cn } from "../lib/utils";

// Initialize a singleton kernel for the debugger
const debugKernel = createKernel();

type KernelMode = "NORMAL" | "DEGRADED" | "HALT" | "RECOVERY";
type CostGuardianTransaction = {
  id: string;
  txHash: string;
  costOwnerId: string;
  projectedCost: number;
  resourceMetrics: string;
  currency: string;
  budgetThreshold?: number;
  status: "BINDING_ACTIVE" | "PENDING_APPROVAL" | "LIQUIDATED";
  timestamp: string;
};
type StateHistoryEvent = {
  id: string;
  triggerReason: string;
  snapshotId: string;
  previousMode: KernelMode;
  newMode: KernelMode;
  timestamp: string;
};

import { DeterminismMonitor } from "./DeterminismMonitor";

export default function KernelDebugger() {
  const [force, setForce] = useState(0);

  const [currentMode, setCurrentMode] = useState<KernelMode>("NORMAL");
  const [activeTransactions, setActiveTransactions] = useState<CostGuardianTransaction[]>([]);
  const [history, setHistory] = useState<StateHistoryEvent[]>([
    {
      id: "init-genesis",
      triggerReason: "SYSTEM_BOOTSTRAP",
      snapshotId: "snap_genesis_0000",
      previousMode: "NORMAL",
      newMode: "NORMAL",
      timestamp: new Date().toISOString()
    }
  ]);

  useEffect(() => {
    // Refresh the UI periodically to show real-time changes
    const i = setInterval(() => setForce(x => x + 1), 500);
    return () => clearInterval(i);
  }, []);

  useEffect(() => {
    const txs: CostGuardianTransaction[] = [
      {
        id: "tx-gov-1001",
        txHash: "0x89a3f234",
        costOwnerId: "DEPT_SECURITY_OPS",
        projectedCost: 4.50,
        resourceMetrics: "12ms CPU, 45KB RAM",
        currency: "USD",
        budgetThreshold: 10,
        status: "BINDING_ACTIVE",
        timestamp: new Date().toISOString()
      },
      {
        id: "tx-gov-1002",
        txHash: "0x12b9cfdf",
        costOwnerId: "ML_TRAINING_PIPELINE",
        projectedCost: 1540.00,
        resourceMetrics: "4 GPU hrs, 12GB VRAM",
        currency: "USD",
        budgetThreshold: 1800,
        status: "PENDING_APPROVAL",
        timestamp: new Date(Date.now() - 50000).toISOString()
      }
    ];
    setActiveTransactions(txs);
  }, []);

  const triggerStateTransition = (targetMode: KernelMode) => {
    if (currentMode === targetMode) return;

    let reason = "MANUAL_OVERRIDE";
    if (targetMode === "HALT") reason = "UNBOUND_GOVERNANCE_DETECTED";
    else if (targetMode === "RECOVERY") reason = "SAGA_COMPENSATION_INVOKED";
    else if (targetMode === "DEGRADED") reason = "ELEVATED_RISK_HEURISTIC";
    else if (targetMode === "NORMAL") reason = "SYSTEM_STABILIZED";

    const newEvent: StateHistoryEvent = {
      id: "ev-" + Math.random().toString(36).substr(2, 9),
      triggerReason: reason,
      snapshotId: "snap_" + Math.random().toString(16).substring(2, 10),
      previousMode: currentMode,
      newMode: targetMode,
      timestamp: new Date().toISOString()
    };

    setHistory(prev => [newEvent, ...prev]);
    setCurrentMode(targetMode);
  };

  const getModeColor = (mode: KernelMode) => {
    switch(mode) {
      case "NORMAL": return "text-emerald-400 bg-emerald-500/10 border-emerald-500/30";
      case "DEGRADED": return "text-yellow-400 bg-yellow-500/10 border-yellow-500/30";
      case "HALT": return "text-red-500 bg-red-500/10 border-red-500/30";
      case "RECOVERY": return "text-purple-400 bg-purple-500/10 border-purple-500/30";
    }
  };

  const liquidateAnchor = (id: string) => {
    setActiveTransactions(prev => prev.map(tx => tx.id === id ? { ...tx, status: "LIQUIDATED" } : tx));
  };

  const processes = Array.from(debugKernel.state.processes.values());

  return (
    <div className="p-6 space-y-6 bg-[#0a0a0a] text-[#E4E3E0] min-h-screen font-mono text-xs">
      <div className="flex items-center justify-between border-b border-[#333] pb-4">
        <div>
          <h1 className="text-xl font-bold uppercase tracking-widest text-[#00ffcc] flex items-center gap-2">
            <Terminal className="w-5 h-5" /> Kernel Debugger
          </h1>
          <p className="text-[#888] mt-1">Live inspection of isolated process memory and capabilities.</p>
        </div>
      </div>

      <DeterminismMonitor />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="space-y-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500">Kernel State Control Layer (FSK-v2)</h3>
          
          <div className={cn("flex flex-col gap-2 p-4 rounded border transition-colors", getModeColor(currentMode))}>
            <div className="flex justify-between items-center">
              <span className="text-xs uppercase font-bold tracking-widest text-inherit opacity-80">Active Mode</span>
              {currentMode === "NORMAL" && <CheckCircle2 className="w-5 h-5" />}
              {currentMode === "DEGRADED" && <ShieldAlert className="w-5 h-5" />}
              {currentMode === "HALT" && <ServerCrash className="w-5 h-5" />}
              {currentMode === "RECOVERY" && <History className="w-5 h-5" />}
            </div>
            <div className="text-2xl font-bold tracking-widest">{currentMode}</div>
            <div className="text-[10px] opacity-70 mt-1">
              {currentMode === "NORMAL" && "System fully operational. All execution pipelines hot."}
              {currentMode === "DEGRADED" && "Limited execution. Elevated risk heuristic detected."}
              {currentMode === "HALT" && "MANDATORY BLOCK. All mutations frozen. No cost generation allowed."}
              {currentMode === "RECOVERY" && "Saga compensations & CRDT reconciliation active."}
            </div>
          </div>

          <div className="bg-[#111] p-3 rounded border border-[#333]">
            <div className="text-xs text-gray-400 mb-2 uppercase tracking-wide">Inject Transition Signal</div>
            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={() => triggerStateTransition("NORMAL")}
                className="px-2 py-1.5 rounded bg-[#1a1a1a] border border-emerald-500/30 text-emerald-400 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Restore (Normal)
              </button>
              <button 
                onClick={() => triggerStateTransition("DEGRADED")}
                className="px-2 py-1.5 rounded bg-[#1a1a1a] border border-yellow-500/30 text-yellow-400 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Degrade
              </button>
              <button 
                onClick={() => triggerStateTransition("HALT")}
                className="px-2 py-1.5 rounded bg-[#1a1a1a] border border-red-500/30 text-red-500 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Panic / Halt
              </button>
              <button 
                onClick={() => triggerStateTransition("RECOVERY")}
                className="px-2 py-1.5 rounded bg-[#1a1a1a] border border-purple-500/30 text-purple-400 text-[10px] uppercase font-bold hover:bg-[#222] transition-colors"
              >
                Start Recovery
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500 flex justify-between items-center">
            <span>Cost Guardian Anchors</span>
            {currentMode === 'HALT' && <span className="text-[10px] text-red-500 bg-red-500/10 px-2 py-0.5 rounded font-bold tracking-widest border border-red-500/20">FROZEN</span>}
          </h3>

          <div className="bg-[#111] rounded border border-[#333] overflow-hidden flex flex-col h-full max-h-[350px]">
            <div className="overflow-y-auto custom-scrollbar flex-1 relative min-h-[160px]">
              {activeTransactions.length === 0 ? (
                 <div className="absolute inset-0 flex items-center justify-center text-xs text-gray-600">No active anchors.</div>
              ) : (
                <div className="flex flex-col">
                  {activeTransactions.map(tx => {
                    const isApproachingThreshold = tx.budgetThreshold && (tx.projectedCost / tx.budgetThreshold > 0.8);
                    return (
                    <div key={tx.id} className={cn("p-3 border-b border-[#222] last:border-0 hover:bg-[#1a1a1a] transition-colors relative", currentMode === 'HALT' ? 'opacity-50 grayscale' : '')}>
                      {isApproachingThreshold && (
                        <div className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-500 mr-2 mt-2 animate-pulse" title="Approaching Budget Threshold" />
                      )}
                      <div className="flex justify-between items-start mb-2 pr-4">
                        <span className="text-xs font-bold text-[#E4E3E0]">{tx.costOwnerId}</span>
                        <div className="text-right">
                          <span className={cn("text-xs font-bold block", tx.projectedCost > 1000 ? "text-yellow-400" : "text-gray-400")}>
                            ${tx.projectedCost.toFixed(2)} {tx.currency}
                            {tx.budgetThreshold && <span className="text-gray-600 font-normal ml-1">/ ${tx.budgetThreshold}</span>}
                          </span>
                          <span className="text-[9px] text-gray-500">{tx.resourceMetrics}</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-[10px]">
                        <span className="text-blue-400 truncate w-24 sm:w-28 font-mono">{tx.txHash}</span>
                        <div className="flex items-center gap-2">
                          {isApproachingThreshold && <span className="text-red-400 text-[8px] font-bold border border-red-500/30 px-1 rounded bg-red-500/10">WARN: DANGER</span>}
                          <span className={cn(
                            "px-1.5 py-0.5 rounded uppercase border whitespace-nowrap", 
                            tx.status === "BINDING_ACTIVE" ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : 
                            tx.status === "LIQUIDATED" ? "bg-red-500/10 border-red-500/20 text-red-400" :
                            "bg-yellow-500/10 border-yellow-500/20 text-yellow-400"
                          )}>
                            {tx.status.replace("_", " ")}
                          </span>
                          {tx.status !== "LIQUIDATED" && (
                            <button 
                              onClick={() => liquidateAnchor(tx.id)}
                              className="text-gray-500 hover:text-red-400 hover:bg-red-500/10 px-1.5 py-0.5 rounded border border-transparent hover:border-red-500/30 transition-colors"
                              title="Liquidate Anchor"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  )})}
                </div>
              )}
            </div>
            
            <div className="p-3 bg-[#1a1a1a] border-t border-[#333] shrink-0 mt-auto">
              <button
                className="w-full px-3 py-1.5 rounded bg-[#222] border border-[#444] text-[10px] uppercase text-gray-300 font-bold hover:bg-[#333] transition"
                onClick={() => {
                  if (currentMode === 'HALT') {
                    alert("Execution Frozen: Cannot span new cost guardian bounds in HALT state.");
                    return;
                  }
                  
                  const cost = Math.random() * 500;
                  const threshold = cost * (1 + (Math.random() * 0.5 - 0.1));

                  setActiveTransactions(prev => [
                    {
                      id: "tx-gov-" + Math.floor(Math.random()*10000),
                      txHash: "0x" + Math.random().toString(16).substring(2, 10),
                      costOwnerId: "AD_HOC_REQ",
                      projectedCost: cost,
                      resourceMetrics: Math.floor(Math.random() * 100) + "ms CPU, " + Math.floor(Math.random() * 500) + "KB RAM",
                      currency: "USD",
                      budgetThreshold: Math.max(cost, Math.floor(threshold)),
                      status: "BINDING_ACTIVE",
                      timestamp: new Date().toISOString()
                    },
                    ...prev
                  ])
                }}
              >
                + Span New Cost Anchor
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sm uppercase tracking-wider text-gray-500 flex justify-between items-center">
            <span>State History & Rollback Log</span>
          </h3>

          <div className="bg-[#111] rounded border border-[#333] overflow-hidden flex flex-col h-full max-h-[350px]">
             <div className="overflow-y-auto custom-scrollbar flex-1 p-3 space-y-3">
               {history.map((ev, i) => (
                 <div key={ev.id} className="relative pl-4 border-l border-[#333] pb-2 last:pb-0">
                   <div className="absolute w-2 h-2 rounded-full -left-[4.5px] top-1.5 bg-[#444]" />
                   <div className="flex justify-between items-start mb-1">
                     <span className="text-[10px] font-bold text-gray-400">
                       {new Date(ev.timestamp).toLocaleTimeString()}
                     </span>
                     <span className="text-[9px] text-purple-400 bg-purple-500/10 px-1 rounded border border-purple-500/20 font-mono text-right truncate max-w-[100px]">
                       {ev.snapshotId}
                     </span>
                   </div>
                   <div className="text-xs text-blue-400 font-bold break-words">{ev.triggerReason}</div>
                   <div className="text-[10px] text-gray-500 mt-1 uppercase tracking-widest flex items-center gap-1">
                     <span className={cn(
                       "px-1 rounded", 
                       ev.previousMode === 'NORMAL' ? 'text-emerald-500' :
                       ev.previousMode === 'DEGRADED' ? 'text-yellow-500' :
                       ev.previousMode === 'HALT' ? 'text-red-500' : 'text-purple-500'
                     )}>{ev.previousMode}</span>
                     ➔
                     <span className={cn(
                       "px-1 rounded font-bold", 
                       ev.newMode === 'NORMAL' ? 'text-emerald-400 bg-emerald-500/10' :
                       ev.newMode === 'DEGRADED' ? 'text-yellow-400 bg-yellow-500/10' :
                       ev.newMode === 'HALT' ? 'text-red-500 bg-red-500/10' : 'text-purple-400 bg-purple-500/10'
                     )}>{ev.newMode}</span>
                   </div>
                 </div>
               ))}
             </div>
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        <h2 className="text-lg font-bold text-[#bbbbbb] uppercase">Process Table</h2>
        {processes.map((p) => (
          <div key={p.pid} className="border border-[#333] bg-[#111] p-4 rounded-md">
            <div className="mb-2 font-bold text-[#E4E3E0]">PID: <span className="text-[#00ffcc]">{p.pid}</span></div>
            <div className="mb-4 text-[#888]">Capabilities: <span className="text-[#ff00ff]">{[...p.capabilities].join(", ")}</span></div>
            <div className="mb-2 font-bold text-[#E4E3E0] uppercase border-b border-[#333] pb-1">True Isolated Memory</div>
            <pre className="text-[#00ffcc] mt-2 overflow-x-auto text-[10px]">
              {JSON.stringify(
                Object.fromEntries(p.memoryRoot.entries()),
                null,
                2
              )}
            </pre>
          </div>
        ))}
      </div>
    </div>
  );
}
