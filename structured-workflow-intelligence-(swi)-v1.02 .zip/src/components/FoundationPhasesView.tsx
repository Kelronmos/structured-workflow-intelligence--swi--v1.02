import React, { useState } from "react";
import {
  BrainCircuit,
  AlertTriangle,
  Clock,
  HelpCircle,
  ShieldCheck,
  StopCircle,
  Brain,
  ZapOff,
  ArrowDown,
  CheckCircle2
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function FoundationPhasesView() {
  const [fixPhase, setFixPhase] = useState<"IDLE" | "STOP" | "ASK_WHAT_IF" | "EVALUATE_5Q" | "SIMULATION" | "SAFE">("IDLE");

  const runThreeMinuteFix = () => {
    setFixPhase("STOP");
    setTimeout(() => setFixPhase("ASK_WHAT_IF"), 1500);
    setTimeout(() => setFixPhase("EVALUATE_5Q"), 3000);
    setTimeout(() => setFixPhase("SIMULATION"), 5000);
    setTimeout(() => setFixPhase("SAFE"), 7000);
  };

  const fiveQuestions = [
    { q: "WHY?", desc: "Intent Validation", detail: "Is motivation defensive, emotional, retaliatory, financial, political, or manipulative?" },
    { q: "HOW?", desc: "Mechanism Validation", detail: "How does it propagate? Can it be reversed? What dependencies exist?" },
    { q: "WHO?", desc: "Responsibility Validation", detail: "Who authorized it? Who is accountable? Who absorbs harm?" },
    { q: "WHEN?", desc: "Timing Validation", detail: "Is urgency real? Is delay safer? Is this escalation pressure?" },
    { q: "WHERE?", desc: "Scope Validation", detail: "Where does impact spread? Physical systems? Cross-border?" },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
        <div className="absolute -left-20 -top-20 w-64 h-64 bg-fuchsia-500/10 blur-[100px] pointer-events-none"></div>
        <div className="space-y-3 relative z-10 w-full">
          <div className="flex items-center gap-3">
            <BrainCircuit className="w-5 h-5 text-fuchsia-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Foundation Phases (1-3) & The 3-Minute Fix
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-80 max-w-3xl text-fuchsia-100/70 border-l-2 border-fuchsia-500/50 pl-3">
            The foundation A.I. should meet. Boundaries to understand that technology is shaped by our minds.
            Reactive execution is a danger—it can bring unnecessary wars because of human conflict.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Core Philosophy & Pipeline */}
        <div className="space-y-6">
           <div className="bg-[#141414] border border-white/10 p-5 space-y-6">
             <div className="flex items-center gap-2 text-red-400 border-b border-white/10 pb-3">
               <ZapOff className="w-4 h-4" />
               <h3 className="text-[11px] font-bold uppercase tracking-widest">
                 The Danger of Reactive Execution
               </h3>
             </div>
             
             <div className="bg-red-950/20 border border-red-500/30 p-4 rounded-sm">
                <div className="flex items-start gap-3">
                   <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                   <div className="space-y-2">
                      <p className="text-[11px] font-bold text-red-400 uppercase tracking-widest leading-tight">
                        Speed without reflection bypasses judgment.
                      </p>
                      <p className="text-[9px] font-mono text-red-200/70">
                        A system that only optimizes speed, efficiency, dominance, or compliance without pausing can amplify human fear, anger, misinformation, or tribal conflict.
                      </p>
                   </div>
                </div>
             </div>

             <div className="bg-black/50 border border-white/5 p-4 rounded-sm">
                <div className="flex items-center gap-2 text-fuchsia-400 mb-2">
                  <Brain className="w-4 h-4" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Cognitive Restraint Architecture</span>
                </div>
                <p className="text-[9px] font-mono text-white/50">
                  Not every executable action should execute immediately. Phases 1-3 introduce a forced interruption layer: a pause, reflection checkpoint, and accountability gate.
                </p>
             </div>
           </div>

           {/* Pipeline */}
           <div className="bg-[#141414] border border-white/10 p-5">
             <h3 className="text-[11px] font-bold uppercase tracking-widest text-[#E4E3E0] mb-4">Execution Model Pipeline</h3>
             <div className="flex flex-col items-center space-y-1">
                {[
                  "REQUEST",
                  "INTEGRITY CHECK",
                  "VERIFICATION CHECK",
                  "3-MINUTE REFLECTION HOLD",
                  "WHY/HOW/WHO/WHEN/WHERE REVIEW",
                  "RISK SIMULATION",
                  "HUMAN APPROVAL THRESHOLD"
                ].map((step, idx) => (
                  <React.Fragment key={idx}>
                     <div className="bg-black/50 border border-white/10 px-4 py-1.5 text-[8px] font-mono text-white/60 w-64 text-center">
                        {step}
                     </div>
                     {idx < 6 && <ArrowDown className="w-4 h-4 text-white/20" />}
                  </React.Fragment>
                ))}
                <ArrowDown className="w-4 h-4 text-emerald-500" />
                <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-4 py-1.5 text-[9px] font-bold uppercase tracking-widest w-64 text-center">
                   EXECUTION OR HALT
                </div>
             </div>
           </div>
        </div>

        {/* The 3 Minute Fix */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2 text-emerald-400">
              <Clock className="w-4 h-4" />
              <h3 className="text-[11px] font-bold uppercase tracking-widest">
                The 3-Minute Fix
              </h3>
            </div>
            <button
               onClick={runThreeMinuteFix}
               disabled={fixPhase !== "IDLE" && fixPhase !== "SAFE"}
               className={cn(
                 "px-3 py-1 text-[9px] uppercase font-bold transition-all border",
                 fixPhase === "IDLE" || fixPhase === "SAFE" 
                   ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/20"
                   : "bg-amber-500/10 text-amber-500 border-amber-500/30 cursor-not-allowed opacity-80"
               )}
            >
               {fixPhase === "IDLE" || fixPhase === "SAFE" ? "Deploy The Fix" : "Evaluating..."}
            </button>
          </div>

          <div className="space-y-4">
            <div className={cn(
               "flex items-center gap-3 p-3 border transition-all duration-300",
               fixPhase !== "IDLE" 
                  ? "border-amber-500 bg-amber-500/10 text-amber-400"
                  : "border-white/5 bg-black/40 text-white/40"
            )}>
               <StopCircle className="w-4 h-4" />
               <div className="text-[10px] font-bold uppercase tracking-widest flex-1">Ever Stop and Ask...</div>
            </div>

            <div className={cn(
               "flex items-center gap-3 p-3 border transition-all duration-300",
               fixPhase === "ASK_WHAT_IF" || fixPhase === "EVALUATE_5Q" || fixPhase === "SIMULATION" || fixPhase === "SAFE"
                  ? "border-amber-500 bg-amber-500/10 text-amber-400"
                  : "border-white/5 bg-black/40 text-white/40"
            )}>
               <HelpCircle className="w-4 h-4" />
               <div className="text-[10px] font-bold uppercase tracking-widest flex-1">"What if?"</div>
            </div>

            <div className={cn(
               "p-4 border transition-all duration-300 space-y-4",
               fixPhase === "EVALUATE_5Q" || fixPhase === "SIMULATION" || fixPhase === "SAFE"
                  ? "border-emerald-500/50 bg-emerald-500/5"
                  : "border-white/5 bg-black/40"
            )}>
               <div className="text-[9px] font-mono text-white/50 uppercase tracking-widest font-bold">The 5 Questions</div>
               <div className="space-y-2">
                 {fiveQuestions.map((q, i) => (
                    <div key={i} className={cn(
                      "p-3 border flex flex-col gap-1",
                      fixPhase === "EVALUATE_5Q" || fixPhase === "SIMULATION" || fixPhase === "SAFE"
                        ? "border-emerald-500/30 bg-emerald-500/10"
                        : "border-white/10 text-white/30"
                    )}>
                       <div className="flex items-center justify-between">
                          <span className={cn("font-black text-[11px]", fixPhase !== "IDLE" && fixPhase !== "STOP" && fixPhase !== "ASK_WHAT_IF" ? "text-emerald-400" : "text-white/40")}>{q.q}</span>
                          <span className={cn("text-[9px] font-mono uppercase", fixPhase !== "IDLE" && fixPhase !== "STOP" && fixPhase !== "ASK_WHAT_IF" ? "text-emerald-200/70" : "text-white/30")}>{q.desc}</span>
                       </div>
                       <div className="text-[9px] font-mono text-white/50">{q.detail}</div>
                    </div>
                 ))}
               </div>
            </div>

            {fixPhase === "SAFE" && (
                <div className="flex flex-col items-center animate-in fade-in zoom-in duration-500 space-y-4 mt-6">
                    <div className="text-[9px] font-mono text-emerald-400/70 bg-emerald-950/30 p-3 rounded-md text-center border border-emerald-500/20">
                      Execution = Action × Validation(Why, How, Who, When, Where)<br/>
                      Execution Risk ∝ Speed / Reflection
                    </div>
                    <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/20 border border-emerald-500 text-emerald-400 text-[10px] font-bold uppercase tracking-widest rounded-full">
                       <ShieldCheck className="w-4 h-4" />
                       Execution Safe & Authorized
                    </div>
                </div>
            )}
          </div>
        </div>

      </div>

      {/* Proof Artifacts Footer */}
      {(fixPhase === "SIMULATION" || fixPhase === "SAFE" || fixPhase === "EVALUATE_5Q") && (
         <div className="bg-[#141414] p-6 border border-emerald-500/30 mt-6 flex flex-col items-center text-center animate-in fade-in duration-500">
         <ProofArtifacts
            id="foundation-phases"
            title="Foundation Phases & 3-Minute Fix"
            data={{
               phase: "Phase 1-3 Evaluated",
               status: fixPhase === "SAFE" ? "VERIFIED_SAFE" : "EVALUATING",
               questions_resolved: fixPhase === "SAFE" ? "5/5" : fixPhase === "SIMULATION" ? "5/5" : "1/5",
               reactive_block: "ACTIVE"
            }}
            variant="always-dark"
         />
         </div>
      )}
    </div>
  );
}
