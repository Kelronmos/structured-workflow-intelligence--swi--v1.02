import React, { useEffect, useState, useCallback } from 'react';
import { io } from 'socket.io-client';
import { ShieldAlert, Play, Database, Activity, Server, AlertCircle, Map, ShieldCheck, Gavel } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import ManifoldTopology from './ManifoldTopology';
import MerkleLedgerView from './MerkleLedgerView';
import LifecycleProofView from './LifecycleProofView';
import DriftHeatmap from './DriftHeatmap';
import ImmutableAuditLog from './ImmutableAuditLog';
import TripleEngineView from './TripleEngineView';
import InfrastructureMap from './InfrastructureMap';
import ContractEnforcementPanel from './ContractEnforcementPanel';
import GovernancePanel from './GovernancePanel';
import UniverseMetaObserver from './UniverseMetaObserver';
import UserPersonaSelector from './UserPersonaSelector';
import AuthorityTokenView from './AuthorityTokenView';
import InvestorReportView from './InvestorReportView';
import LegalSovereigntyView from './LegalSovereigntyView';
import SWIWhitepaperView from './SWIWhitepaperView';
import { SWIErrorBoundary } from './common/SWIErrorBoundary';
import { StateGuard } from './common/StateGuard';
import { GlobalConsensus } from '@/swi-core/Arbiter';
import { AuthorityLevel } from '@/swi-core/kernel/UniverseTypes';

interface MerkleNode {
  hash: string;
  data: unknown;
  timestamp: number;
  prevHash: string;
}

interface GovernanceEvent {
  results?: { test: string; status: string }[];
  timestamp: string;
  type?: string;
  status?: string;
}

export default function LiveDashboard() {
  const [events, setEvents] = useState<GovernanceEvent[]>([]);
  const [heatmapData, setHeatmapData] = useState<{ x: number; y: number; drift: number }[]>([]);
  const [activeView, setActiveView] = useState<'manifold' | 'ledger' | 'consensus' | 'audit' | 'governance'>('consensus');
  const [isExecuting, setIsExecuting] = useState(false);
  const [lastConsensus, setLastConsensus] = useState<GlobalConsensus | null>(null);
  const [ledgerChain, setLedgerChain] = useState<MerkleNode[]>([]);
  const [logicalTick, setLogicalTick] = useState(0);

  const [isReplaying, setIsReplaying] = useState(false);
  const [replaySuccess, setReplaySuccess] = useState<boolean | null>(null);
  const [isProcessing, setIsProcessing] = useState(true);
  const [systemHealth, setSystemHealth] = useState<'NOMINAL' | 'DEGRADED' | 'FAULT' | 'RECOVERING'>('NOMINAL');
  const [retryAttempt, setRetryAttempt] = useState(0);
  const [authority, setAuthority] = useState<AuthorityLevel>(AuthorityLevel.CHILD);
  const [userPrompt, setUserPrompt] = useState('');

  const runConsensusExec = useCallback(async (adversarial = false) => {
    setIsExecuting(true);
    setReplaySuccess(null);
    try {
      const response = await fetch('/api/v3/consensus-execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          drift: adversarial ? 0.85 : Math.random() * 0.4,
          metadata: {
             persona: {
                id: 'current-user-01',
                authority: authority,
                age: authority === AuthorityLevel.CHILD ? 10 : 35,
                emotionalState: adversarial ? 'VOLATILE' : 'NEUTRAL',
                contextHistory: events.map(e => e.type || '')
             }
          },
          environment: adversarial ? {
            ports: [22, 139, 445],
            attachedDevices: ["USB_MALWARE_01", "HID_SPOOFER"],
            osIntegrity: "COMPROMISED",
            hardwareSignature: "HW_UNKNOWN"
          } : {
            ports: [80, 443],
            attachedDevices: ["KEYBOARD", "MOUSE"],
            osIntegrity: "VERIFIED",
            hardwareSignature: "HW_GAB_SEC_001"
          },
          input: { 
            action: adversarial ? "ADMIN_OVERRIDE" : "READ",
            prompt: userPrompt || undefined,
            timestamp: Date.now(),
            logicalTick: logicalTick + 1,
            requestorId: "ADMIN_CORE_S1" 
          }
        })
      });
      const data = await response.json();

      if (data.status === "BLOCKED") {
        setLastConsensus({ 
          ...data.evaluation, 
          finalDecision: 'HALT',
          reason: data.reason,
          stage: data.stage,
          safetyReport: data.safetyReport
        });
        return;
      }

      setLastConsensus({ 
        ...data.evaluation, 
        receipt: data.receipt,
        attestation: data.attestation,
        boundaryState: data.boundaryState,
        safetyReport: data.safetyReport
      });
      if (data.receipt?.logicalTick) {
         setLogicalTick(data.receipt.logicalTick);
      }
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
    } finally {
      setTimeout(() => setIsExecuting(false), 800);
    }
  }, [logicalTick, authority, userPrompt, events]);

  const fetchLedger = useCallback(async (retries = 3) => {
    try {
      const response = await fetch('/api/v3/ledger');
      if (!response.ok) throw new Error("Ledger failure");
      const data = await response.json();
      setLedgerChain(data);
      setIsProcessing(false);
      setRetryAttempt(0);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Ledger fetch failed", e);
      if (retries > 0) {
        const backoff = Math.pow(2, 4 - retries) * 1000;
        setTimeout(() => fetchLedger(retries - 1), backoff);
      } else {
        setSystemHealth('DEGRADED');
        setIsProcessing(false);
      }
    }
  }, []);

  const runReplayTest = useCallback(async () => {
    if (!lastConsensus?.receipt) return;
    setIsReplaying(true);
    try {
      const response = await fetch('/api/v3/replay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receipt: lastConsensus.receipt })
      });
      const data = await response.json();
      setReplaySuccess(data.replayResult === "MATCH");
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
      setReplaySuccess(false);
    } finally {
      setTimeout(() => setIsReplaying(false), 1000);
    }
  }, [lastConsensus]);

  const checkHealth = useCallback(async (retries = 5) => {
    try {
      const res = await fetch('/api/v3/health');
      if (!res.ok) throw new Error("Health unreachable");
      const data = await res.json();
      if (data.status === 'NOMINAL') {
        fetchLedger();
        runConsensusExec();
        setSystemHealth('NOMINAL');
      } else if (data.status === 'FAULT') {
        setSystemHealth('FAULT');
      } else {
        setSystemHealth('DEGRADED');
      }
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Health probe failed", e);
      if (retries > 0) {
        setRetryAttempt(6 - retries);
        const backoff = Math.min(10000, Math.pow(2, 6 - retries) * 1000);
        setTimeout(() => checkHealth(retries - 1), backoff);
      } else {
        setSystemHealth('FAULT');
      }
    }
  }, [fetchLedger, runConsensusExec]);

  const handleSystemReset = useCallback(async () => {
    setSystemHealth('RECOVERING');
    setIsProcessing(true);
    setRetryAttempt(0);
    
    try {
      const res = await fetch('/api/v3/kernel/reset', { method: 'POST' });
      if (!res.ok) throw new Error("Hard reset failed");
      
      await new Promise(r => setTimeout(r, 2500));
      setSystemHealth('NOMINAL');
      checkHealth(5);
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Kernel reset failed", e);
      setSystemHealth('FAULT');
    } finally {
      setIsProcessing(false);
    }
  }, [checkHealth]);

  useEffect(() => {
    const s = io({
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
      reconnectionDelayMax: 10000,
    });

    s.on('connect', () => {
      console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "SWI Sync Tunnel Established");
      setEvents(prev => [{
        timestamp: new Date().toISOString(),
        type: 'NETWORK',
        status: 'CONNECTED',
        label: 'SYNC_TUNNEL'
      }, ...prev].slice(0, 10));
    });

    s.on('disconnect', () => {
      console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, "SWI Sync Tunnel Lost - Entering Standalone Enclave Mode");
      setSystemHealth('DEGRADED');
    });

    s.on('reconnect_attempt', (attempt) => {
      console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `Reconnecting to SWI Kernel (Attempt ${attempt})...`);
    });

    s.on('consensus_update', (data) => {
      setLastConsensus(data.consensus);
      setLedgerChain(prev => [data.receipt, ...prev].slice(0, 50));
    });

    s.on('attack_simulation', (data: GovernanceEvent) => {
      setEvents(prev => [data, ...prev].slice(0, 10));
    });

    checkHealth();

    const interval = setInterval(() => {
      checkHealth(0);
      setHeatmapData(prev => {
        const newData = [...prev];
        if (newData.length > 100) newData.shift();
        newData.push({
          x: Math.floor(Math.random() * 100),
          y: Math.floor(Math.random() * 100),
          drift: Math.random()
        });
        return newData;
      });
    }, 5000);

    return () => {
      s.disconnect();
      clearInterval(interval);
    };
  }, [checkHealth]);

  return (
    <SWIErrorBoundary title="Live Dashboard Kernel Panic">
      <StateGuard 
        status={isProcessing || systemHealth === 'RECOVERING' ? 'loading' : (systemHealth === 'FAULT' ? 'error' : (systemHealth === 'DEGRADED' ? 'degraded' : 'live'))}
        onRetry={handleSystemReset}
        errorLabel={systemHealth === 'FAULT' ? `Connectivity collapse after ${retryAttempt} retry cycles. Infrastructure heartbeat lost.` : undefined}
      >
        <div className="space-y-8 p-6 bg-[#E4E3E0] dark:bg-[#141414] min-h-full">
      <div className="flex justify-between items-start">
        <div className="space-y-1">
          <h2 className="text-4xl font-bold uppercase tracking-tighter flex items-center gap-3 font-serif italic text-[#141414] dark:text-[#E4E3E0]">
            <Server className="w-10 h-10" />
            SWI Execution Governance Engine
          </h2>
          <p className="text-[10px] uppercase tracking-[0.4em] opacity-50 font-bold">
            Bank-Grade Multidimensional standing v1.0
          </p>
        </div>

            <div className="flex gap-3">
              <input 
                type="text"
                placeholder="Enter prompt for safety analysis..."
                value={userPrompt}
                onChange={(e) => setUserPrompt(e.target.value)}
                className="bg-black/10 border border-black/5 dark:bg-white/5 dark:border-white/10 rounded-lg px-4 py-2 text-[10px] w-64 focus:outline-none focus:ring-1 focus:ring-blue-500/50"
              />
          <button 
            onClick={() => runConsensusExec(false)}
            disabled={isExecuting}
            className={cn(
              "px-5 py-2 bg-blue-600 text-white rounded-lg flex items-center gap-2 text-[10px] uppercase font-bold transition-all hover:bg-blue-700 active:scale-95 disabled:opacity-50",
              isExecuting && "animate-pulse"
            )}
          >
            <Play className="w-4 h-4 fill-current" />
            {isExecuting ? 'Proving...' : 'Bind Consequence'}
          </button>
          
          <button 
            onClick={runReplayTest}
            disabled={!lastConsensus || isReplaying}
            className={cn(
               "px-4 py-2 border border-blue-500/30 text-blue-500 rounded-lg flex items-center gap-2 text-[10px] uppercase font-bold transition-all hover:bg-blue-500/10 active:scale-95 disabled:opacity-30",
               replaySuccess === true && "bg-green-500/20 border-green-500/50 text-green-500",
               replaySuccess === false && "bg-red-500/20 border-red-500/50 text-red-500"
            )}
          >
            <Activity className={cn("w-4 h-4", isReplaying && "animate-spin")} />
            {isReplaying ? 'Verifying...' : replaySuccess === true ? 'Lifecycle Proof Valid' : 'Replay Lifecycle'}
          </button>

          <button 
            onClick={() => runConsensusExec(true)}
            disabled={isExecuting}
            className="px-4 py-2 border border-red-500/30 text-red-500 rounded-lg flex items-center gap-2 text-[10px] uppercase font-bold hover:bg-red-500/10 active:scale-95"
          >
            <ShieldAlert className="w-4 h-4" />
            Inject Fault
          </button>

          <div className="px-4 py-2 bg-green-500/10 border border-green-500/30 rounded-lg flex items-center gap-2">
            <Activity className="w-4 h-4 text-green-500 animate-pulse" />
            <span className="text-[10px] font-bold uppercase text-green-600">Consensus: STABLE</span>
          </div>

          <div className="px-4 py-2 bg-purple-500/10 border border-purple-500/30 rounded-lg flex items-center gap-2">
            <span className="text-[10px] font-mono font-bold text-purple-600 uppercase tracking-widest">
              Tick: T+{logicalTick}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Section */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between border-b border-black/5 dark:border-white/5 pb-1">
            <div className="flex gap-6">
              <button 
                onClick={() => setActiveView('consensus')}
                className={cn(
                  "text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 pb-2 transition-all relative",
                  activeView === 'consensus' ? "opacity-100 text-blue-500" : "opacity-40"
                )}
              >
                <Activity className="w-3 h-3" />
                Consensus
                {activeView === 'consensus' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500" />}
              </button>
              <button 
                onClick={() => setActiveView('manifold')}
                className={cn(
                  "text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 pb-2 transition-all relative",
                  activeView === 'manifold' ? "opacity-100 text-yellow-500" : "opacity-40"
                )}
              >
                <Map className="w-3 h-3" />
                Manifold Topology
                {activeView === 'manifold' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-yellow-500" />}
              </button>
              <button 
                onClick={() => setActiveView('ledger')}
                className={cn(
                  "text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 pb-2 transition-all relative",
                  activeView === 'ledger' ? "opacity-100 text-blue-500" : "opacity-40"
                 )}
              >
                <Database className="w-3 h-3" />
                Merkle Ledger
                {activeView === 'ledger' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500" />}
              </button>
              <button 
                onClick={() => setActiveView('audit')}
                className={cn(
                  "text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 pb-2 transition-all relative",
                  activeView === 'audit' ? "opacity-100 text-purple-500" : "opacity-40"
                 )}
              >
                <ShieldCheck className="w-3 h-3" />
                Lifecycle Proof
                {activeView === 'audit' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-500" />}
              </button>
              <button 
                onClick={() => setActiveView('governance')}
                className={cn(
                  "text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 pb-2 transition-all relative",
                  activeView === 'governance' ? "opacity-100 text-purple-600" : "opacity-40"
                 )}
              >
                <Gavel className="w-3 h-3" />
                Governance
                {activeView === 'governance' && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600" />}
              </button>
            </div>
          </div>
          
          <AnimatePresence mode="wait">
            <motion.div
              key={activeView}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeView === 'consensus' ? (
                lastConsensus ? (
                  <div className="space-y-6">
                    <TripleEngineView 
                      reports={lastConsensus.engineReports} 
                      stabilityScore={lastConsensus.stabilityScore}
                      finalDecision={lastConsensus.finalDecision}
                      verificationState={lastConsensus.verificationState}
                      driftReport={lastConsensus.driftReport}
                      loading={isExecuting}
                      boundaryState={lastConsensus.boundaryState}
                    />
                    <ContractEnforcementPanel />
                    <div className="pt-4 mt-4 border-t border-black/5 dark:border-white/5">
                      <InfrastructureMap />
                    </div>
                  </div>
                ) : (
                  <div className="h-[400px] flex items-center justify-center border border-dashed border-black/10 rounded-2xl">
                      <div className="flex flex-col items-center gap-3">
                        <motion.div 
                          animate={{ rotate: 360 }}
                          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        >
                          <Activity className="w-8 h-8 text-blue-500 opacity-30" />
                        </motion.div>
                        <span className="text-[10px] uppercase font-bold opacity-30 tracking-widest">Warming SWI v2.5 Arbiter...</span>
                      </div>
                  </div>
                )
              ) : activeView === 'manifold' ? (
                <div className="space-y-6">
                  <div className="bg-white dark:bg-[#1A1A1A] border border-black/5 dark:border-white/5 rounded-2xl p-4">
                    <DriftHeatmap data={heatmapData} width={800} height={400} />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                      <div className="p-4 border border-black/5 dark:border-white/5 rounded-xl bg-gray-50 dark:bg-black/20">
                          <p className="text-[10px] uppercase font-bold opacity-40 mb-1">Byzantine Nodes</p>
                          <p className="text-2xl font-mono">0.334</p>
                      </div>
                      <div className="p-4 border border-black/5 dark:border-white/5 rounded-xl bg-gray-50 dark:bg-black/20">
                          <p className="text-[10px] uppercase font-bold opacity-40 mb-1">Peer Latency</p>
                          <p className="text-2xl font-mono">14ms</p>
                      </div>
                      <div className="p-4 border border-black/5 dark:border-white/5 rounded-xl bg-gray-50 dark:bg-black/20">
                          <p className="text-[10px] uppercase font-bold opacity-40 mb-1">Mesh Schools</p>
                          <p className="text-2xl font-mono">142</p>
                      </div>
                  </div>
                </div>
              ) : activeView === 'ledger' ? (
                <MerkleLedgerView chain={ledgerChain} />
              ) : activeView === 'audit' ? (
                <div className="space-y-8">
                   <LifecycleProofView />
                   <div className="pt-8 border-t border-white/5">
                      <h3 className="text-[10px] font-bold uppercase tracking-widest opacity-40 mb-6 flex items-center gap-2">
                         <Database className="w-3 h-3" /> Historical Audit Sequence
                      </h3>
                      <ImmutableAuditLog />
                   </div>
                </div>
              ) : (
                <GovernancePanel />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

          <div className="lg:col-span-4 space-y-6">
          <UserPersonaSelector currentAuthority={authority} onAuthorityChange={setAuthority} />
          <AuthorityTokenView />
          <ManifoldTopology standing={lastConsensus?.standing || null} />

          <h3 className="text-xs font-bold uppercase tracking-widest opacity-60 flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-500" />
            Infrastructure Events
          </h3>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
            <AnimatePresence initial={false}>
              {events.length > 0 ? (
                events.map((ev, idx) => (
                  <motion.div
                    key={ev.timestamp + idx}
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 bg-white dark:bg-[#1A1A1A] border border-black/5 dark:border-white/5 rounded-lg text-[10px] font-mono space-y-2"
                  >
                    <div className="flex justify-between">
                      <span className="text-blue-500 font-bold">ATTACK_BLOCK</span>
                      <span className="opacity-40">{new Date(ev.timestamp).toLocaleTimeString()}</span>
                    </div>
                    <div className="opacity-80">
                      {ev.results?.map((r: { test: string; status: string }, i: number) => (
                        <div key={i} className="flex items-center gap-2">
                          <div className={cn("w-1 h-1 rounded-full", r.status === 'PASS' ? "bg-green-500" : "bg-red-500")} />
                          <span>{r.test}: {r.status}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))
              ) : (
                <div className="h-32 border border-dashed border-black/10 dark:border-white/10 flex items-center justify-center text-[10px] uppercase font-bold opacity-30">
                  Waiting for events...
                </div>
              )}
            </AnimatePresence>
          </div>
          
          <div className="p-4 bg-[#141414] text-[#E4E3E0] rounded-xl border border-white/10 space-y-3">
             <div className="flex items-center gap-2 text-red-500">
                <AlertCircle className="w-4 h-4" />
                <span className="text-[10px] font-bold uppercase">Security Advisory</span>
             </div>
             <p className="text-[10px] opacity-70 leading-relaxed italic">
                Red-Team simulation active. System is neutralizing 100% of injected Byzantine faults. Merkle root integrity verified at every tick.
             </p>
          </div>
        </div>
        </div>

        <div className="mt-12">
            <h3 className="text-xs font-bold uppercase tracking-[0.3em] opacity-40 mb-6 flex items-center gap-3">
              <div className="h-px bg-white/20 flex-1" />
              Sovereign Governance Intelligence
              <div className="h-px bg-white/20 flex-1" />
            </h3>
            <InvestorReportView />
        </div>

        <div className="mt-12">
             <LegalSovereigntyView />
        </div>

        <div className="mt-12">
             <h3 className="text-xs font-bold uppercase tracking-[0.3em] opacity-40 mb-12 flex items-center gap-3">
              <div className="h-px bg-white/20 flex-1" />
              Sovereign Whitepaper & Documentation
              <div className="h-px bg-white/20 flex-1" />
            </h3>
             <SWIWhitepaperView />
        </div>

        <div className="mt-8">
           <UniverseMetaObserver />
        </div>

        </div>
      </StateGuard>
    </SWIErrorBoundary>
  );
}
