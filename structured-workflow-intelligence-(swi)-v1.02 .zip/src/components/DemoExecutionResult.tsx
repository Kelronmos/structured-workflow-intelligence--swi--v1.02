interface DemoExecutionResultProps {
  result: Record<string, unknown> | null;
}

export default function DemoExecutionResult({ result }: DemoExecutionResultProps) {
  if (!result) return (
    <div className="p-12 border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20 flex flex-col items-center justify-center opacity-30">
      <p className="text-xs uppercase tracking-widest font-bold">No execution yet...</p>
    </div>
  );

  const color =
    result.status === "EXECUTION_COMPLETED"
      ? "text-green-500"
      : result.status === "HALT"
      ? "text-red-500"
      : "text-orange-500";

  const borderColor = 
    result.status === "EXECUTION_COMPLETED"
      ? "border-green-500/50"
      : result.status === "HALT"
      ? "border-red-500/50"
      : "border-orange-500/50";

  return (
    <div className={`p-6 border ${borderColor} bg-white dark:bg-[#141414] space-y-4 animate-in fade-in slide-in-from-bottom-4`}>
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-bold uppercase tracking-tighter">🧾 Execution Result</h3>
        <span className={`text-[10px] font-bold uppercase px-2 py-1 border ${borderColor} ${color}`}>
          {result.status as string}
        </span>
      </div>
      
      <pre className="p-4 bg-[#111] text-white font-mono text-xs overflow-x-auto border border-white/10">
        {JSON.stringify(result, null, 2)}
      </pre>

      {result.status === "HALT" && (
        <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] uppercase font-bold flex items-center gap-2">
          <span>⚠️</span>
          <span>Boundary Refusal: {result.reason as string}</span>
        </div>
      )}
    </div>
  );
}
