import React, { useEffect, useRef, useState } from "react";
import * as d3 from "d3";
import { cn } from "@/src/lib/utils";
import { AlertCircle, CheckCircle2, Download } from "lucide-react";

interface Scenario {
  id: string;
  name: string;
  expected: string;
  input: {
    token: { status: string; permission: string };
    action: string;
    context: {
      userBehavior: string;
      environment: string;
      policyMismatch: boolean;
    };
  };
}

interface PolicyDependencyGraphProps {
  theme: "light" | "dark";
}

const NODES = [
  { id: "token", label: "Auth Token Validator" },
  { id: "action", label: "Action Admissibility Engine" },
  { id: "behavior", label: "Drift Scorer (Behavior)" },
  { id: "environment", label: "Environment Stability Monitor" },
  { id: "policy", label: "Policy Alignment Checker" },
];

const EDGES = [
  { source: "token", target: "action" },
  { source: "action", target: "behavior" },
  { source: "behavior", target: "environment" },
  { source: "environment", target: "policy" },
];

export default function PolicyDependencyGraph({ theme }: PolicyDependencyGraphProps) {
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedScenario, setSelectedScenario] = useState<Scenario | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    fetch("/api/scenarios")
      .then((res) => res.json())
      .then((data) => {
        setScenarios(data);
        if (data.length > 0) {
          setSelectedScenario(data[0]);
        }
      })
      .finally(() => setLoading(false));
  }, []);

  // Determine failing node based on scenario
  const getFailingNodeId = (scenario: Scenario | null) => {
    if (!scenario || scenario.expected === "ALLOW") return null;
    
    if (scenario.input.token.status !== "valid") return "token";
    if (scenario.input.action === "blocked_action") return "action";
    if (scenario.input.context.userBehavior === "anomalous") return "behavior";
    if (scenario.input.context.environment === "unstable" || scenario.input.context.environment === "collapsing") return "environment";
    if (scenario.input.context.policyMismatch) return "policy";
    
    // Default fallback for other refuse cases
    return "policy"; 
  };

  useEffect(() => {
    if (!svgRef.current || !selectedScenario) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const width = svgRef.current.clientWidth;
    const height = 300;
    
    svg.attr("viewBox", `0 0 ${width} ${height}`);

    const failingNodeId = getFailingNodeId(selectedScenario);

    // Calculate positions
    const nodeWidth = 160;
    const nodeHeight = 50;
    const xSpacing = (width - nodeWidth) / (NODES.length - 1);
    
    const nodesWithPositions = NODES.map((n, i) => ({
      ...n,
      x: Math.max(nodeWidth / 2, Math.min(width - nodeWidth / 2, i * xSpacing + nodeWidth / 2)),
      y: height / 2,
    }));

    const edgesWithPositions = EDGES.map((e) => {
      const source = nodesWithPositions.find((n) => n.id === e.source)!;
      const target = nodesWithPositions.find((n) => n.id === e.target)!;
      return { source, target };
    });

    const isDarkMode = theme === "dark";
    const strokeColor = isDarkMode ? "#333" : "#e5e7eb";
    const activeStrokeColor = isDarkMode ? "#4b5563" : "#9ca3af";
    const textColor = isDarkMode ? "#f3f4f6" : "#111827";
    const nodeBg = isDarkMode ? "#1f2937" : "#ffffff";
    const errorBg = "#fef2f2";
    const errorStroke = "#ef4444";
    const errorText = "#991b1b";

    // Draw edges
    svg
      .selectAll("path")
      .data(edgesWithPositions)
      .join("path")
      .attr("d", (d) => {
        return `M ${d.source.x} ${d.source.y} L ${d.target.x} ${d.target.y}`;
      })
      .attr("stroke", (d) => {
        // If the source or a previous node failed, edge is inactive
        if (!failingNodeId) return activeStrokeColor;
        const sourceIdx = NODES.findIndex(n => n.id === d.source.id);
        const failIdx = NODES.findIndex(n => n.id === failingNodeId);
        return sourceIdx >= failIdx ? strokeColor : activeStrokeColor;
      })
      .attr("stroke-width", 2)
      .attr("fill", "none")
      .attr("marker-end", "url(#arrowhead)");

    // Arrowhead def
    svg
      .append("defs")
      .append("marker")
      .attr("id", "arrowhead")
      .attr("viewBox", "-0 -5 10 10")
      .attr("refX", 10)
      .attr("refY", 0)
      .attr("orient", "auto")
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("xoverflow", "visible")
      .append("svg:path")
      .attr("d", "M 0,-5 L 10 ,0 L 0,5")
      .attr("fill", activeStrokeColor);

    // Draw nodes
    const nodeGroup = svg
      .selectAll("g.node")
      .data(nodesWithPositions)
      .join("g")
      .attr("class", "node")
      .attr("transform", (d) => `translate(${d.x - nodeWidth / 2}, ${d.y - nodeHeight / 2})`);

    nodeGroup
      .append("rect")
      .attr("width", nodeWidth)
      .attr("height", nodeHeight)
      .attr("rx", 6)
      .attr("fill", (d) => (d.id === failingNodeId ? errorBg : nodeBg))
      .attr("stroke", (d) => (d.id === failingNodeId ? errorStroke : activeStrokeColor))
      .attr("stroke-width", 2)
      .style("filter", "drop-shadow(0 4px 6px rgba(0,0,0,0.1))");

    nodeGroup
      .append("text")
      .text((d) => d.label)
      .attr("x", nodeWidth / 2)
      .attr("y", nodeHeight / 2)
      .attr("text-anchor", "middle")
      .attr("dominant-baseline", "middle")
      .attr("fill", (d) => (d.id === failingNodeId ? errorText : textColor))
      .attr("font-size", "10px")
      .attr("font-weight", "bold")
      .style("font-family", "monospace");
      
    nodeGroup
      .append("circle")
      .attr("cx", nodeWidth / 2)
      .attr("cy", -10)
      .attr("r", 10)
      .attr("fill", (d) => {
        if (!failingNodeId) return "#10b981"; // green
        const idx = NODES.findIndex(n => n.id === d.id);
        const failIdx = NODES.findIndex(n => n.id === failingNodeId);
        if (idx < failIdx) return "#10b981"; // passed
        if (idx === failIdx) return "#ef4444"; // failed
        return strokeColor; // not reached
      });

  }, [selectedScenario, theme]);

  const handleExportComplianceReport = () => {
    if (!scenarios || scenarios.length === 0) return;
    
    const timestamp = new Date().toISOString();
    const activeParams = {
      simulationVersion: "SWI-CORE-vNext",
      totalScenarios: scenarios.length,
      currentScenario: selectedScenario?.id,
      nodes: NODES,
      edges: EDGES,
    };

    const reportData = {
      id: `COMPLIANCE-REPORT-${Date.now()}`,
      timestamp,
      parameters: activeParams,
      matrix_results: scenarios,
      integrity_signature: `sig_${Math.random().toString(36).substring(2, 15)}`
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `scenario-matrix-compliance-${timestamp.replace(/:/g, '-')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return <div className="p-6 border animate-pulse text-xs">Loading scenario data...</div>;
  }

  return (
    <div
      className={cn(
        "border p-6 font-mono space-y-4",
        theme === "light"
          ? "bg-white border-[#141414]"
          : "bg-[#141414] border-[#E4E3E0]/20"
      )}
    >
      <div className="flex items-center justify-between border-b pb-4">
        <div>
          <h2 className="text-sm uppercase font-bold tracking-tighter">
            Policy Dependency Graph
          </h2>
          <div className="text-[10px] opacity-60 mt-1">Real-time Execution Flow</div>
        </div>
        <button
          onClick={handleExportComplianceReport}
          className="flex items-center gap-2 px-3 py-1.5 text-[9px] uppercase font-bold border border-green-500/50 text-green-500 hover:bg-green-500/10 transition-all rounded"
        >
          <Download className="w-3 h-3" />
          Export Compliance JSON
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 border-r pr-6 space-y-4">
          <p className="text-[10px] uppercase font-bold opacity-40">Scenarios</p>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
            {scenarios.map((scenario) => (
              <button
                key={scenario.id}
                onClick={() => setSelectedScenario(scenario)}
                className={cn(
                  "w-full text-left p-3 text-xs border transition-colors",
                  selectedScenario?.id === scenario.id
                    ? theme === "light"
                      ? "bg-black text-white border-black"
                      : "bg-white text-black border-white"
                    : theme === "light"
                    ? "hover:bg-gray-100"
                    : "hover:bg-gray-800 border-[#E4E3E0]/20"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold truncate pr-2">{scenario.name}</span>
                  {scenario.expected === "ALLOW" ? (
                    <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="md:col-span-2 space-y-4 flex flex-col">
          <div className="p-4 border bg-gray-50 dark:bg-[#1a1a1a]">
            <p className="text-[10px] uppercase font-bold opacity-40 mb-2">Scenario Context</p>
            {selectedScenario && (
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="opacity-60">Action:</span> {selectedScenario.input.action}
                </div>
                <div>
                  <span className="opacity-60">Token:</span> {selectedScenario.input.token.status}
                </div>
                <div>
                  <span className="opacity-60">Behavior:</span> {selectedScenario.input.context.userBehavior}
                </div>
                <div>
                  <span className="opacity-60">Environment:</span> {selectedScenario.input.context.environment}
                </div>
              </div>
            )}
          </div>
          
          <div className="flex-1 min-h-[300px] border relative overflow-hidden bg-gray-50/50 dark:bg-black/50">
            <svg ref={svgRef} className="w-full h-full absolute inset-0" />
          </div>
        </div>
      </div>
    </div>
  );
}
