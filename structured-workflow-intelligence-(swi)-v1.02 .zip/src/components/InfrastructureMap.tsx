import React from 'react';
import { motion } from 'motion/react';
import { Globe, Server, Cpu, ShieldCheck, Activity } from 'lucide-react';
import { cn } from '@/src/lib/utils';

// Shared with backend representation
const GLOBAL_CLUSTERS = [
  { id: "swi-us-east-1", region: "Virginia, US", provider: "AWS", hardware: "NITRO", status: "ONLINE", latency: 12, load: 0.45 },
  { id: "swi-eu-west-2", region: "London, UK", provider: "BARE_METAL", hardware: "HSM_V3", status: "ONLINE", latency: 8, load: 0.12 },
  { id: "swi-ap-northeast-1", region: "Tokyo, JP", provider: "GCP", hardware: "SGX", status: "DEGRADED", latency: 240, load: 0.88 }
];

export default function InfrastructureMap() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-orange-500" />
          <h3 className="text-xs font-bold uppercase tracking-widest text-white/50">Global Deployment Clusters</h3>
        </div>
        <div className="flex items-center gap-4 text-[10px] font-mono text-white/30">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
            <span>Active Enclaves</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-orange-500" />
            <span>High Saturation</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {GLOBAL_CLUSTERS.map((node, i) => (
          <motion.div
            key={node.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={cn(
              "p-4 rounded-2xl border transition-all duration-300",
              node.status === "ONLINE" 
                ? "bg-white/5 border-white/10 hover:border-white/20" 
                : "bg-red-500/5 border-red-500/20"
            )}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="space-y-1">
                <div className="text-[10px] font-mono text-white/40 uppercase">{node.id}</div>
                <div className="text-sm font-medium text-white">{node.region}</div>
              </div>
              <div className={cn(
                "w-2 h-2 rounded-full",
                node.status === "ONLINE" ? "bg-green-500 animate-pulse" : "bg-red-500"
              )} />
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="space-y-1">
                <div className="text-[8px] font-bold uppercase text-white/30 flex items-center gap-1">
                  <Cpu className="w-2 h-2" />
                  Compute
                </div>
                <div className="text-xs font-mono text-white/80">{node.hardware}</div>
              </div>
              <div className="space-y-1 text-right">
                <div className="text-[8px] font-bold uppercase text-white/30 flex items-center gap-1 justify-end">
                  <Activity className="w-2 h-2" />
                  Latency
                </div>
                <div className={cn(
                  "text-xs font-mono font-bold",
                  node.latency > 100 ? "text-red-400" : "text-green-400"
                )}>
                  {node.latency}ms
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-[8px] uppercase font-bold text-white/20">
                <span>Load Factor</span>
                <span>{(node.load * 100).toFixed(0)}%</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${node.load * 100}%` }}
                  className={cn(
                    "h-full rounded-full transition-all duration-1000",
                    node.load > 0.8 ? "bg-orange-500" : "bg-blue-500"
                  )}
                />
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Server className="w-3 h-3 text-white/20" />
                <span className="text-[10px] font-mono text-white/30">{node.provider}</span>
              </div>
              {node.status === "ONLINE" && (
                <ShieldCheck className="w-3 h-3 text-green-500/40" />
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
