import React, { useState } from 'react';
import { Shield, EyeOff, CheckCircle2, FileKey, Zap } from 'lucide-react';
import { ZKAuditEngine } from '../zk/ZKAuditEngine';
import { cn } from '../lib/utils';

export function ZkAuditVisualization({ theme }: { theme: 'light' | 'dark' }) {
  const [proofData, setProofData] = useState<{
    commitment: string;
    proofHash: string;
    traceLength: number;
    verified: boolean | null;
  } | null>(null);

  const handleGenerateProof = () => {
    const engine = new ZKAuditEngine();
    
    // Highly sensitive sample data
    const inputPayload = {
      participantId: "P-8849-01",
      diagnosis: "Severe Depressive Episode",
      riskScore: 89,
      medicalHistory: "Confidential..."
    };
    
    const witness = {
      input: inputPayload,
      executionTrace: [
        { state: "INIT", ts: Date.now() },
        { state: "EVALUATE_POLICY", rule: "RISK_CRITICAL", triggered: true },
        { state: "ROUTED_CRISIS_TEAM", ts: Date.now() + 100 }
      ]
    };

    const commit = engine.commit(inputPayload);
    const proofResult = engine.prove(witness);
    
    setProofData({
      commitment: commit,
      proofHash: proofResult.proofHash,
      traceLength: witness.executionTrace.length,
      verified: null
    });
  };

  const handleVerify = () => {
    if (!proofData) return;
    const engine = new ZKAuditEngine();
    const isValid = engine.verify(
      { commitment: proofData.commitment, proofHash: proofData.proofHash }, 
      proofData.commitment
    );
    setProofData({ ...proofData, verified: isValid });
  };

  return (
    <div className="bg-[#111] border border-[#333] rounded-xl p-6 font-mono text-gray-300 mt-6 md:col-span-2">
      <div className="flex justify-between items-center mb-6 border-b border-[#333] pb-4">
         <div>
           <h3 className="text-lg font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-2">
             <EyeOff className="w-5 h-5" /> ZK-Audit Proof Verification
           </h3>
           <p className="text-xs text-gray-500 mt-1">Zero-Knowledge execution proof layer for external trust without data compromise.</p>
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <p className="text-[10px] text-gray-400">
            Simulate the generation of a cryptographic proof to guarantee valid system behavior.
            External actors verify validity without receiving sensitive payload data.
          </p>
          <button 
            onClick={handleGenerateProof}
            className="w-full py-2 bg-[#222] border border-[#444] hover:bg-[#333] text-[#E4E3E0] rounded uppercase text-xs font-bold transition-colors"
          >
            <Zap className="w-4 h-4 inline mr-2 text-yellow-500" /> Generate Proof & Commitment
          </button>

          {proofData && (
             <div className="bg-black border border-[#333] rounded p-4 animate-in fade-in space-y-3 mt-4">
                <div className="flex justify-between border-b border-[#222] pb-2">
                  <span className="text-[10px] text-gray-500 uppercase font-bold">Execution Steps Trace</span>
                  <span className="text-xs text-blue-400 font-bold">{proofData.traceLength} Validated</span>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] text-gray-500 uppercase font-bold">Input Payload Commitment (Zk-Hash)</span>
                  <div className="text-[10px] text-yellow-500 bg-yellow-500/10 p-2 rounded truncate border border-yellow-500/20 shadow-inner">
                    {proofData.commitment}
                  </div>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] text-gray-500 uppercase font-bold">Cryptographic Trace Proof</span>
                  <div className="text-[10px] text-emerald-400 bg-emerald-500/10 p-2 rounded truncate border border-emerald-500/20 shadow-inner">
                    {proofData.proofHash}
                  </div>
                </div>
             </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="bg-[#1a1a1a] p-4 rounded border border-[#333] h-full flex flex-col">
            <h4 className="text-sm font-bold uppercase tracking-widest mb-2 flex items-center gap-2">
              <Shield className="w-4 h-4 text-purple-400" /> Independent Verification
            </h4>
            <p className="text-[10px] text-gray-500 mb-6 flex-1">
              Submit the decoupled Proof and Commitment structures to an independent verifier module.
            </p>

            <button 
              onClick={handleVerify}
              disabled={!proofData}
              className={cn(
                "w-full py-2 rounded uppercase text-xs font-bold transition-colors",
                proofData ? "bg-[#222] border border-blue-500/30 text-blue-400 hover:bg-[#333]" : "bg-[#111] text-gray-600 cursor-not-allowed border border-[#222]"
              )}
            >
              <FileKey className="w-4 h-4 inline mr-2 text-blue-400" /> Verify Cryptographic Proof
            </button>

            {proofData?.verified !== null && (
               <div className="mt-4 bg-emerald-500/10 border border-emerald-500/30 p-3 rounded flex items-center gap-3 animate-in slide-in-from-bottom-2 shadow-lg">
                 <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                 <div>
                   <div className="text-xs uppercase font-bold text-emerald-400">Zero-Knowledge Protocol Verified</div>
                   <div className="text-[9px] text-gray-400 mt-1">Integrity verified under zero-knowledge constraint.</div>
                 </div>
               </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
