import React, { useState, useEffect } from "react";
import {
  Shield,
  Eye,
  Activity,
  Lock,
  AlertTriangle,
  Cpu,
  Database,
  BrainCircuit,
  CheckCircle2,
  XOctagon,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

export default function ObservationModuleView() {
  const [logs, setLogs] = useState<string[]>([
    "[INIT] Supervisory Integrity Kernel engaged.",
    "[VALIDATE] Process integrity baseline confirmed.",
    "[MONITOR] Drift detection heuristics activated.",
  ]);
  const [driftScore, setDriftScore] = useState(0.001);

  useEffect(() => {
    const interval = setInterval(() => {
      setDriftScore((prev) =>
        Math.max(
          0,
          parseFloat((prev + (Math.random() * 0.005 - 0.002)).toFixed(4)),
        ),
      );
      if (Math.random() > 0.7) {
        setLogs((prev) => {
          const newLog = `[OBSERVE] Memory state hash verified: 0x${Math.floor(Math.random() * 16777215).toString(16)}`;
          return [newLog, ...prev].slice(0, 8);
        });
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Eye className="w-5 h-5 text-indigo-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              SWI Observation Module
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            Continuously supervised bounded execution. Not "AI freedom."
            Preserves trusted structure under dynamic conditions.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-[10px] font-bold uppercase tracking-widest text-green-500">
              Supervisory Integrity
            </div>
            <div className="font-mono text-xs text-white/50">
              JOE_KERNEL_ACTIVE
            </div>
          </div>
          <Activity className="w-6 h-6 text-green-500" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Runtime Observation Layer */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2 text-blue-400 mb-2">
            <Activity className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              1. Runtime Observation
            </h3>
          </div>
          <p className="text-[10px] font-mono text-white/60 mb-2">
            Equivalent to aircraft instrumentation.
          </p>
          <div className="space-y-2 font-mono text-[10px]">
            <div className="flex justify-between items-center border-b border-white/10 pb-1">
              <span className="text-white/40">Process Integrity</span>
              <span className="text-green-400">VERIFIED</span>
            </div>
            <div className="flex justify-between items-center border-b border-white/10 pb-1">
              <span className="text-white/40">Memory State</span>
              <span className="text-green-400">NOMINAL</span>
            </div>
            <div className="flex justify-between items-center border-b border-white/10 pb-1">
              <span className="text-white/40">Kernel Hooks</span>
              <span className="text-green-400">SECURE</span>
            </div>
            <div className="flex justify-between items-center border-b border-white/10 pb-1">
              <span className="text-white/40">Timing Anomalies</span>
              <span className="text-green-400">NONE</span>
            </div>
          </div>
        </div>

        {/* Red-Zone Protection */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2 text-red-500 mb-2">
            <Lock className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              2. Red-Zone Protection
            </h3>
          </div>
          <p className="text-[10px] font-mono text-white/60 mb-2">
            Immutable unless verified authorization exists.
          </p>
          <div className="bg-black/50 p-3 rounded-sm border border-red-500/20 font-mono text-[9px] text-red-400">
            <div>IF modification_target == RED_ZONE</div>
            <div>AND authority != VERIFIED</div>
            <div>THEN</div>
            <div className="pl-4">BLOCK_OPERATION</div>
            <div className="pl-4">LOG_EVENT</div>
            <div className="pl-4">TRIGGER_ALERT</div>
          </div>
          <div className="text-[10px] font-mono text-white/40">
            Protected: Kernel Integrity, Crypto Keys, Governance.
          </div>
        </div>

        {/* Drift Detection */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2 text-yellow-500 mb-2">
            <AlertTriangle className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              3. Drift Detection
            </h3>
          </div>
          <p className="text-[10px] font-mono text-white/60 mb-2">
            Checks deviation from structural invariants.
          </p>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-[10px] font-bold uppercase mb-1">
                <span className="text-white/40">Behavioral Divergence</span>
                <span className="text-yellow-500">
                  {driftScore.toFixed(4)} Δ
                </span>
              </div>
              <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-yellow-500 transition-all duration-1000"
                  style={{ width: `${Math.min(100, driftScore * 1000)}%` }}
                />
              </div>
            </div>
            <div className="text-[9px] font-mono text-white/40 space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-500/50" />{" "}
                Isolate module
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-500/50" />{" "}
                Reduce permissions
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-500/50" />{" "}
                Enter safe mode
              </div>
            </div>
          </div>
        </div>

        {/* The "Joe" Layer */}
        <div className="bg-indigo-900/10 border border-indigo-500/20 p-5 space-y-4 lg:col-span-2">
          <div className="flex items-center gap-2 text-indigo-400 mb-2">
            <BrainCircuit className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              The "Joe" Layer (Supervisory Integrity Kernel)
            </h3>
          </div>
          <p className="text-[11px] font-mono text-indigo-200/80 mb-2 leading-relaxed">
            Not a personality. A supervisory integrity kernel that:
            <br />
            <span className="text-indigo-400">
              observes, validates, cross-checks, preserves continuity, prevents
              unsafe escalation.
            </span>
          </p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mt-4 text-[9px] font-bold uppercase">
            <div className="border border-indigo-500/20 bg-indigo-500/5 p-2 text-center text-indigo-300">
              Watchdog System
            </div>
            <div className="border border-indigo-500/20 bg-indigo-500/5 p-2 text-center text-indigo-300">
              Supervisory Controller
            </div>
            <div className="border border-indigo-500/20 bg-indigo-500/5 p-2 text-center text-indigo-300">
              Runtime Guardian
            </div>
            <div className="border border-indigo-500/20 bg-indigo-500/5 p-2 text-center text-indigo-300">
              Invariant Engine
            </div>
          </div>
        </div>

        {/* Most Important Principle */}
        <div className="bg-red-950/20 border border-red-500/30 p-5 flex flex-col justify-center">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-red-400 mb-3 text-center">
            Most Important Principle
          </h3>
          <div className="text-center">
            <p className="text-lg font-black text-white uppercase tracking-tight leading-tight">
              "Refuse modification
              <br />
              in red zones
              <br />
              without authority."
            </p>
            <p className="text-[9px] font-mono text-white/40 mt-4">
              Without this, corruption propagates, drift compounds, and recovery
              becomes impossible.
            </p>
          </div>
        </div>

        {/* Safety Philosophy */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4 lg:col-span-3">
          <div className="flex items-center gap-2 text-green-400 mb-2">
            <Shield className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              Safety Philosophy & Real-World Equivalents
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-[10px] uppercase font-bold text-white/60 mb-2">
                A mature safety runtime SHOULD NOT:
              </h4>
              <ul className="space-y-1 text-[10px] font-mono text-red-300/80">
                <li>
                  <XOctagon className="inline w-3 h-3 mr-1" /> Seek control
                </li>
                <li>
                  <XOctagon className="inline w-3 h-3 mr-1" /> Override humans
                  arbitrarily
                </li>
                <li>
                  <XOctagon className="inline w-3 h-3 mr-1" /> Self-authorize
                  expansion
                </li>
                <li>
                  <XOctagon className="inline w-3 h-3 mr-1" /> Bypass governance
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] uppercase font-bold text-white/60 mb-2">
                It SHOULD:
              </h4>
              <ul className="space-y-1 text-[10px] font-mono text-green-300/80">
                <li>
                  <CheckCircle2 className="inline w-3 h-3 mr-1" /> Preserve
                  operational coherence
                </li>
                <li>
                  <CheckCircle2 className="inline w-3 h-3 mr-1" /> Enforce
                  boundaries
                </li>
                <li>
                  <CheckCircle2 className="inline w-3 h-3 mr-1" /> Require
                  authenticated authority
                </li>
                <li>
                  <CheckCircle2 className="inline w-3 h-3 mr-1" /> Maintain
                  auditability
                </li>
                <li>
                  <CheckCircle2 className="inline w-3 h-3 mr-1" /> Fail safely
                  under uncertainty
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-white/10">
            <div className="flex flex-wrap gap-2 text-[8px] uppercase font-bold tracking-widest text-white/30">
              <span>Distributed Systems Safety</span> •{" "}
              <span>High-Assurance Computing</span> •{" "}
              <span>Fault-Tolerant Systems</span> •{" "}
              <span>Observability Engineering</span> •{" "}
              <span>Runtime Verification</span> •{" "}
              <span>Zero-Trust Architecture</span> •{" "}
              <span>Cyber-Physical Safety</span>
            </div>
          </div>
        </div>
      </div>

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-white/10 mt-6">
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/50 mb-3">
          Live Telemetry Feed
        </h3>
        <div className="font-mono text-[9px] space-y-1 h-24 overflow-y-auto w-full opacity-60">
          {logs.map((log, index) => (
            <div key={index} className="text-green-400">
              {log}
            </div>
          ))}
        </div>
        <ProofArtifacts
          id="observation-module"
          title="SWI Observation Runtime"
          data={{ logs, driftScore, protocol: "BOUNDED_EXECUTION" }}
          variant="always-dark"
        />
      </div>
    </div>
  );
}
