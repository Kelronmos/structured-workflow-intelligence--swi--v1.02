export type GateResult = "ACCEPT" | "HALT";

export interface PolicyContext {
    allowed(event: any): boolean;
    hash(): string;
}

export interface StateContext {
    integrity: {
        valid: boolean;
    };
    hash(): string;
}

export function execution_gate(event: any, state: StateContext, policy: PolicyContext): GateResult {
    if (!policy.allowed(event)) return "HALT";
    if (!state.integrity.valid) return "HALT";
    return "ACCEPT";
}
