import React, { useState } from "react";
import { cn } from "../lib/utils";
import {
  Database,
  ShieldCheck,
  Activity,
  CheckCircle2,
  ShieldAlert,
} from "lucide-react";
import { runProofTests } from "../kernel/proof_mode_test";

interface Props {
  theme: "light" | "dark";
}

export function SystemOrchestratorView({ theme }: Props) {
  const [proofResults, setProofResults] = useState<any>(null);

  const truths = [
    {
      feature: "Hash-chained execution log",
      type: "REAL",
      evidence: "SHA256 Chain + Ed25519",
    },
    {
      feature: "AI Court Policy Engine",
      type: "REAL",
      evidence: "Zod Schema Validated + Core Orchestrator",
    },
    {
      feature: "PBFT consensus",
      type: "SIMULATED",
      evidence: "Mock Module (In-browser sandbox)",
    },
    {
      feature: "SAMH Case Routing",
      type: "REAL",
      evidence: "Deterministic runtime evaluation",
    },
    {
      feature: "Merkle Data Integration",
      type: "HYBRID",
      evidence: "Real hash root, simulated state sync",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 font-mono pb-20">
      <div className="border-b border-[#333] pb-6">
        <h2 className="text-3xl font-bold uppercase tracking-tighter flex items-center gap-2">
          <Database className="w-8 h-8 text-indigo-500" />
          SWI Core Orchestrator
        </h2>
        <p className="text-xs opacity-50 uppercase tracking-widest mt-2 max-w-xl">
          Reality-to-Production Bridge (v5 Upgrade). Enforcing deterministic
          verifiable execution and the No False Implication Policy.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#111] p-6 rounded-xl border border-emerald-500/30">
          <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-2 mb-4">
            <ShieldCheck className="w-5 h-5" /> Measured Proof Properties
          </h3>
          <p className="text-[10px] text-gray-400 mb-6">
            Execute automated verification tests asserting deterministic output,
            hash chain integrity, and policy engine decision trace resolution.
          </p>

          <button
            onClick={() => {
              const res = runProofTests();
              setProofResults(res);
            }}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold uppercase tracking-widest text-[10px] rounded mb-6 transition-colors"
          >
            Execute Proof Mode Test Layer
          </button>

          {proofResults && (
            <div className="space-y-3 animate-in fade-in">
              <div className="flex justify-between items-center p-3 border border-[#333] rounded bg-[#1a1a1a]">
                <span className="text-xs text-gray-400 uppercase">
                  Determinism Score
                </span>
                <span className="text-lg font-bold text-emerald-400">
                  {proofResults.determinism_score.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 border border-[#333] rounded bg-[#1a1a1a]">
                <span className="text-xs text-gray-400 uppercase">
                  Audit Completeness
                </span>
                <span className="text-lg font-bold text-emerald-400">
                  {proofResults.audit_completeness.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 border border-[#333] rounded bg-[#1a1a1a]">
                <span className="text-xs text-gray-400 uppercase">
                  Simulation Ratio
                </span>
                <span className="text-lg font-bold text-yellow-400">
                  {proofResults.simulation_ratio.toFixed(2)}
                </span>
              </div>
              <div className="p-3 border border-[#333] rounded bg-[#1a1a1a] overflow-x-auto">
                <span className="text-xs text-gray-400 uppercase block mb-1">
                  Latest Hash Chain Root
                </span>
                <span className="text-[10px] text-blue-400 font-mono">
                  {proofResults.latest_hash}
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="bg-[#111] p-6 rounded-xl border border-[#333]">
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="w-5 h-5 text-yellow-500" />
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-widest">
                No False Implication Policy
              </h3>
            </div>
            <p className="text-[10px] text-gray-400 leading-relaxed">
              <strong>Strict System Rule:</strong> The interface must never
              imply cryptographic guarantees without an explicit implementation
              proof bound to the runtime. The classification table enforces this
              visibility.
            </p>
          </div>

          <div className="bg-[#1a1a1a] rounded-xl border border-[#333] overflow-hidden">
            <div className="p-4 border-b border-[#333] bg-[#111]">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-widest flex items-center gap-2">
                <Activity className="w-4 h-4" /> Truth Classification Table
              </h3>
            </div>
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0a0a0a] text-gray-500 uppercase tracking-widest text-[9px]">
                <tr>
                  <th className="p-3 font-medium">Feature</th>
                  <th className="p-3 font-medium">Execution Type</th>
                  <th className="p-3 font-medium">Evidence Vector</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#333] text-gray-300">
                {truths.map((t, i) => (
                  <tr key={i} className="hover:bg-[#111] transition-colors">
                    <td className="p-3 tracking-wide">{t.feature}</td>
                    <td className="p-3">
                      <span
                        className={cn(
                          "px-2 py-1 rounded text-[9px] uppercase font-bold tracking-widest border",
                          t.type === "REAL"
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                            : t.type === "HYBRID"
                              ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                              : "bg-red-500/10 text-red-400 border-red-500/20",
                        )}
                      >
                        {t.type}
                      </span>
                    </td>
                    <td className="p-3 text-[10px] text-gray-400 font-mono tracking-tighter">
                      {t.evidence}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
