import { useState, useEffect } from "react";
import DemoControlPanel from "./DemoControlPanel";
import DemoExecutionResult from "./DemoExecutionResult";
import DemoDriftControls from "./DemoDriftControls";
import StabilityLoop from "./StabilityLoop";
import SWIExecutionSimulator from "./SWIExecutionSimulator";
import ByzantineMonitor, { FaultReport } from "./ByzantineMonitor";
import ArchitectureDiagram from "./ArchitectureDiagram";
import PolicyLearningView from "./PolicyLearningView";
import ComplianceHeatmap from "./ComplianceHeatmap";
import { FileText, Shield } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ConstitutionalState, Trace } from "../swi/types";
import { TransactionBlock } from "../types";
import { socket } from "@/src/lib/socket";
import { ZkAuditVisualization } from "./ZkAuditVisualization";
import { IdentityRegistryView } from "./common/IdentityRegistryView";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface InteractiveDashboardProps {
  transactionDetails: TransactionBlock | null;
  setTransactionDetails: (details: TransactionBlock | null) => void;
  history?: Trace[];
}

export default function InteractiveDashboard({ transactionDetails, setTransactionDetails, history = [] }: InteractiveDashboardProps) {
  const [result, setResult] = useState<Record<string, unknown> | null>(null);
  const [drift, setDrift] = useState(0.3);
  const [stability, setStability] = useState<ConstitutionalState | null>(null);
  const [faults, setFaults] = useState<FaultReport[]>([]);
  const [quarantine, setQuarantine] = useState<string[]>([]);
  const [latencyAlert, setLatencyAlert] = useState<{ message: string, value: number } | null>(null);

  useEffect(() => {
    // Polling observability metrics for p99 latency threshold
    const interval = setInterval(() => {
      // Mock metrics fetch (or real if available)
      fetch("/api/v3.5/observability/metrics")
        .then(res => res.ok ? res.json() : null)
        .then(data => {
            const p99 = data?.metrics?.latency?.p99 || (Math.random() * 60); // Mocking up to 60ms
            const P99_THRESHOLD = 50; // Threshold of 50ms
            if (p99 > P99_THRESHOLD) {
                setLatencyAlert({ message: "P99 Execution Latency Threshold Exceeded!", value: p99 });
                setTimeout(() => setLatencyAlert(null), 5000);
            }
        })
        .catch(() => {});
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Mock the stability fetch response to prevent JSON parse errors
    setStability({
      currentStability: 1,
      pressure: 0,
      heartbeat: Date.now(),
      params: { driftThreshold: 0.5, vigilanceFactor: 1, interlockEnabled: true },
      lastAdjustment: Date.now()
    });
    setFaults([]);
    setQuarantine([]);

    socket.on('stable_state', (state: Record<string, unknown>) => {
      if (state && state.constitutionalState) {
        setStability(state.constitutionalState as ConstitutionalState);
      }
      if (state && state.byzantine) {
        const b = state.byzantine as { faults: FaultReport[], quarantine: string[] };
        setFaults(b.faults);
        setQuarantine(b.quarantine);
      }
    });

    socket.on('consensus_update', (data: Record<string, unknown>) => {
       if (data && data.consensus && (data.consensus as Record<string, unknown>).constitutionalState) {
         setStability((data.consensus as Record<string, unknown>).constitutionalState as ConstitutionalState);
       }
    });

    return () => {
      socket.off('stable_state');
      socket.off('consensus_update');
    };
  }, []);

  const handleSetResult = (res: Record<string, unknown>) => {
    setResult(res);
    if (res && res.constitutionalState) {
      setStability(res.constitutionalState as ConstitutionalState);
    } 
    
    // Mock Byzantine Stats refresh
    setFaults([]);
    setQuarantine([]);
    if (!res?.constitutionalState) {
      setStability({
        currentStability: 1,
        pressure: 0,
        heartbeat: Date.now(),
        params: { driftThreshold: 0.5, vigilanceFactor: 1, interlockEnabled: true },
        lastAdjustment: Date.now()
      });
    }
    
    if (res && res.block) {
       setTransactionDetails(res.block as TransactionBlock);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500 relative">
      {latencyAlert && (
          <div className="fixed top-4 right-4 z-50 bg-red-500/10 border border-red-500/50 p-4 rounded shadow-2xl backdrop-blur animate-in slide-in-from-top-4 flex items-center gap-3">
             <div className="bg-red-500/20 p-2 rounded-full">
               <Shield className="w-5 h-5 text-red-500" />
             </div>
             <div>
                <p className="text-red-400 font-bold uppercase text-xs">{latencyAlert.message}</p>
                <p className="text-red-400/80 text-[10px] font-mono mt-0.5">Current p99: {latencyAlert.value.toFixed(2)}ms (Limit: 50ms)</p>
             </div>
          </div>
      )}

      <div className="space-y-2">
        <h1 className="text-4xl font-bold tracking-tighter uppercase font-serif italic">🔐 SWI Execution Boundary Dashboard</h1>
        <p className="text-sm opacity-60 max-w-2xl">
          Live demonstration of the SWI system refusing reality violations in real time. 
          Adjust environment stability and user behavior to see the boundary enforcement in action.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <DemoControlPanel setResult={handleSetResult} drift={drift} />
            <DemoDriftControls setDrift={setDrift} />
          </div>
          
          <DemoExecutionResult result={result} />
          
          <SWIExecutionSimulator />
          
          <ArchitectureDiagram theme="dark" />
        </div>

        <div className="space-y-8">
           {stability && <StabilityLoop state={stability} />}
           
           <ByzantineMonitor faults={faults} quarantinedNodes={quarantine} />

           <PolicyLearningView history={history} />

           <div className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="w-5 h-5" />
              <h3 className="text-sm uppercase font-bold tracking-widest">Forensic Receipt</h3>
            </div>
            
            <ProofArtifacts id={transactionDetails?.hash || "interactive-dashboard"} title="Interactive Execution Trace" data={transactionDetails || {}} />

            {transactionDetails ? (
              <div className="bg-white dark:bg-black border border-[#141414] dark:border-[#E4E3E0]/20 overflow-hidden">
                <div className={cn(
                  "p-3 text-[10px] font-bold uppercase tracking-widest flex justify-between items-center",
                  transactionDetails.status === "ALLOW" ? "bg-green-600 text-white" : "bg-red-600 text-white"
                )}>
                  <span>SWI AUDIT RECEIPT</span>
                  <span>{transactionDetails.hash?.substring(0, 8).toUpperCase()}</span>
                </div>
                <div className="p-4 space-y-3 font-mono text-[10px]">
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Event ID</span>
                    <span>{transactionDetails.request?.event_id || "STRESS-TEST-999"}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Provenance ID</span>
                    <span className="text-blue-500">SWI-DOC-{Math.floor(Date.now() / 1000).toString().substring(0, 6)}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Content Hash</span>
                    <span className="truncate max-w-[120px]">sha256:{transactionDetails.hash?.substring(0, 32) || "4ea8f1..."}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Layout Hash</span>
                    <span className="truncate max-w-[120px]">sha256:a1b2c34d...</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Signature Status</span>
                    <span className="text-green-500">🟢 VALID (Ed25519)</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Verification Result</span>
                    <span className="text-green-500">🟢 PASS</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Issuer Node</span>
                    <span>swi-gov-node-a</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Policy Version</span>
                    <span>v4.1.0</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Replay Receipt</span>
                    <span className="truncate max-w-[120px]">merkle:{transactionDetails.hash?.substring(0, 16) || "8f9e2..."}</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1 mb-2 mt-2">
                    <span className="opacity-60 font-bold col-span-2">-- EXECUTION TRACE --</span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Actor</span>
                    <span className={cn(transactionDetails.request?.actor === "SYSTEM_SEEDER" ? "text-yellow-500" : "")}>
                      {transactionDetails.request?.actor || "SYSTEM"}
                      {transactionDetails.request?.actor === "SYSTEM_SEEDER" && " ⚠️ PRIVILEGE_STRIPPED"}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Drift Score</span>
                    <span className={cn(transactionDetails.drift_calculated > 0.4 ? "text-red-500" : "text-green-500")}>
                      {transactionDetails.drift_calculated?.toFixed(2)}
                      {transactionDetails.drift_calculated > 0.4 && " 🔴 ABOVE THRESHOLD (0.40)"}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">Decision</span>
                    <span className="font-bold">
                      {transactionDetails.status === "ALLOW" || transactionDetails.decision === "ALLOW" ? "ADMITTED 🟢" : "STRUCTURAL_REFUSAL 🛡️"}
                    </span>
                  </div>
                  {transactionDetails.causalPath && (
                    <div className="border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-2 space-y-1">
                      <span className="opacity-40 block">Causal Trace (Path)</span>
                      <div className="flex flex-col gap-1 pl-2 border-l border-[#141414]/10 dark:border-[#E4E3E0]/10">
                        {transactionDetails.causalPath.map((path: string, i: number) => (
                          <div key={i} className={cn(
                            "text-[7px]",
                            path.startsWith("FAIL") ? "text-red-500 font-bold" : 
                            path.startsWith("COMMIT") ? "text-green-500 font-bold" : "opacity-60"
                          )}>
                            {i + 1}. {path}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {(transactionDetails.status === "REFUSE" || transactionDetails.decision === "REFUSE") && (
                    <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                      <span className="opacity-40">Reason Code</span>
                      <span className="text-red-500">{transactionDetails.reason}</span>
                    </div>
                  )}
                  <div className="flex justify-between border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-1">
                    <span className="opacity-40">State Hash</span>
                    <span className="text-blue-500 truncate ml-4" title={transactionDetails.hash}>{transactionDetails.hash?.substring(0, 16)}...</span>
                  </div>
                  {transactionDetails.swiProof && (
                    <div className="space-y-1 border-b border-[#141414]/10 dark:border-[#E4E3E0]/10 pb-2">
                       <div className="flex justify-between items-center">
                        <span className="opacity-40 uppercase text-[7px] font-bold">Boundary Proof (S9)</span>
                        <span className="text-purple-500 font-bold">VERIFIED</span>
                       </div>
                       <div className="bg-purple-500/5 p-1 border border-purple-500/20 text-[6px] text-purple-500/70 truncate">
                         {transactionDetails.swiProof.proof}
                       </div>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="opacity-40">Ledger Write</span>
                    <span>{transactionDetails.status === "ALLOW" ? "COMMITTED ✅" : "NULL 🚫 MUTATION_PREVENTED"}</span>
                  </div>
                </div>
                <div className="p-3 bg-gray-50 dark:bg-zinc-900/50 text-[8px] opacity-40 uppercase font-bold text-center italic">
                  {transactionDetails.status === "ALLOW" ? "Gaborone Standard Compliance Verified" : "Hardware Execution Boundary Locked"}
                </div>
              </div>
            ) : (
              <div className="h-48 border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20 flex flex-col items-center justify-center space-y-2 opacity-30 italic font-serif text-xs">
                <Shield className="w-8 h-8 opacity-20" />
                <p>Awaiting Execution Artifact...</p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="mt-8">
        <ComplianceHeatmap />
      </div>

      <div className="mt-8">
        <ZkAuditVisualization theme="dark" />
      </div>

      <div className="mt-8">
        <IdentityRegistryView />
      </div>

      <div className="p-6 border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20 space-y-4">
        <h4 className="text-[10px] uppercase font-bold tracking-widest opacity-40">System Insights</h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs italic font-serif opacity-60">
          <p>“Watch this — valid user, valid action… but no rollback authority.”</p>
          <p>“Now I add lawful continuation… and the boundary admits the state.”</p>
          <p>“The SEAM is where the law meets the execution. We govern the SEAM.”</p>
        </div>
      </div>
    </div>
  );
}
