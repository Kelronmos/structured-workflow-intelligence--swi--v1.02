import React, { useState, useEffect } from "react";
import {
  Network,
  Database,
  FileCheck2,
  GitCommit,
  GitBranch,
  ShieldCheck,
  Server,
  ArrowRight,
  Fingerprint,
  RefreshCw,
  Search,
  CheckCircle2,
  Lock,
  Loader2,
  AlertOctagon
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

type NodeStatus = "IDLE" | "ACTIVE" | "VERIFIED" | "REJECTED" | "SYNCING";

interface GraphNode {
  id: string;
  label: string;
  type: "ORIGIN" | "SIGNATURE" | "EXPORT" | "DOWNLOAD" | "REHYDRATE" | "VERIFY";
  nodeName: string;
  hash: string;
  status: NodeStatus;
}

export default function ProvenanceGraphEngineView() {
  const [simulationState, setSimulationState] = useState<"IDLE" | "RUNNING" | "COMPLETE" | "FAILED">("IDLE");
  const [activeStep, setActiveStep] = useState(0);

  const [graphNodes, setGraphNodes] = useState<GraphNode[]>([
    { id: "gen", label: "Genesis Generation", type: "ORIGIN", nodeName: "swi-gov-node-a", hash: "sha256:4ea8f1...", status: "IDLE" },
    { id: "sig", label: "Cryptographic Signing", type: "SIGNATURE", nodeName: "swi-gov-node-a", hash: "ed25519:a7b8c...", status: "IDLE" },
    { id: "exp", label: "PDF Export & Ledger Commit", type: "EXPORT", nodeName: "swi-gov-node-a", hash: "merkle:8f9e2...", status: "IDLE" },
    { id: "dwn", label: "External Download", type: "DOWNLOAD", nodeName: "client-system", hash: "sha256:4ea8f1...", status: "IDLE" },
    { id: "reh", label: "Provenance Rehydration", type: "REHYDRATE", nodeName: "swi-gov-node-b", hash: "ledger://SWI/chain/881A", status: "IDLE" },
    { id: "ver", label: "DAG Verification & Consensus", type: "VERIFY", nodeName: "swi-gov-node-b", hash: "state:VALID", status: "IDLE" },
  ]);

  const updateNodeStatus = (index: number, status: NodeStatus) => {
    setGraphNodes(prev => prev.map((node, i) => i === index ? { ...node, status } : node));
  };

  const runSimulation = (simulateAttack: boolean = false) => {
    setSimulationState("RUNNING");
    setActiveStep(0);
    setGraphNodes(prev => prev.map(n => ({ ...n, status: "IDLE" })));

    let step = 0;
    const interval = setInterval(() => {
      if (step >= graphNodes.length) {
        clearInterval(interval);
        setSimulationState(simulateAttack ? "FAILED" : "COMPLETE");
        return;
      }

      if (simulateAttack && step === 3) {
        // Tamper during download
        setGraphNodes(prev => prev.map((node, i) => i === step ? { ...node, status: "ACTIVE", hash: "sha256:TAMPERED..." } : node));
      } else {
        updateNodeStatus(step, "ACTIVE");
      }
      
      setActiveStep(step);

      setTimeout(() => {
        if (simulateAttack && step >= 4) {
             updateNodeStatus(step, "REJECTED");
        } else {
             updateNodeStatus(step, "VERIFIED");
        }
      }, 800);

      step++;
    }, 1500);
  };

  const getNodeIcon = (type: string) => {
    switch (type) {
      case "ORIGIN": return <FileCheck2 className="w-4 h-4" />;
      case "SIGNATURE": return <Lock className="w-4 h-4" />;
      case "EXPORT": return <Database className="w-4 h-4" />;
      case "DOWNLOAD": return <GitBranch className="w-4 h-4" />;
      case "REHYDRATE": return <RefreshCw className="w-4 h-4" />;
      case "VERIFY": return <ShieldCheck className="w-4 h-4" />;
      default: return <GitCommit className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[100px] pointer-events-none"></div>
         <div className="space-y-3 relative z-10 w-full flex justify-between items-start">
            <div className="space-y-2">
               <div className="flex items-center gap-3">
                  <Network className="w-5 h-5 text-indigo-400" />
                  <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
                     SWI Provenance Graph Engine
                  </h2>
               </div>
               <p className="text-[10px] font-mono opacity-80 max-w-2xl text-indigo-100/70 border-l-2 border-indigo-500/50 pl-3">
                  Distributed DAG-based lineage system. Cross-cluster reconciliation of document identity using cryptographic graphs rather than localized file histories.
               </p>
            </div>
            <div className="flex gap-2">
               <button
                  onClick={() => runSimulation(false)}
                  disabled={simulationState === "RUNNING"}
                  className="px-4 py-2 uppercase font-bold text-[9px] transition-all border bg-indigo-500/10 text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
               >
                  Trace Valid Life-Cycle
               </button>
               <button
                  onClick={() => runSimulation(true)}
                  disabled={simulationState === "RUNNING"}
                  className="px-4 py-2 uppercase font-bold text-[9px] transition-all border bg-red-500/10 text-red-400 border-red-500/30 hover:bg-red-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
               >
                  Simulate Path Forgery
               </button>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

         {/* DAG Visualization */}
         <div className="lg:col-span-2 bg-[#141414] border border-white/10 p-6 relative overflow-hidden flex flex-col">
            <h3 className="text-[11px] font-bold text-white/40 uppercase tracking-widest mb-6 flex items-center gap-2">
               <GitBranch className="w-4 h-4" /> Directed Acyclic Graph (DAG) Traversal
            </h3>
            
            <div className="flex-1 flex flex-col justify-center gap-2 relative z-10">
               {graphNodes.map((node, i) => (
                  <div key={node.id} className="flex items-center gap-4 group">
                     {/* Node Info */}
                     <div className={cn(
                        "w-full flex items-center justify-between p-3 border transition-all duration-500",
                        node.status === "ACTIVE" ? "bg-indigo-500/20 border-indigo-500/50 shadow-[0_0_15px_rgba(99,102,241,0.2)]" :
                        node.status === "VERIFIED" ? "bg-emerald-500/10 border-emerald-500/30" :
                        node.status === "REJECTED" ? "bg-red-500/10 border-red-500/30" :
                        "bg-black/50 border-white/5 opacity-50"
                     )}>
                        <div className="flex items-center gap-4">
                           <div className={cn(
                              "p-2 rounded border",
                              node.status === "VERIFIED" ? "text-emerald-400 border-emerald-500/30" :
                              node.status === "REJECTED" ? "text-red-400 border-red-500/30" :
                              node.status === "ACTIVE" ? "text-indigo-400 border-indigo-500/50" :
                              "text-white/30 border-white/10"
                           )}>
                              {getNodeIcon(node.type)}
                           </div>
                           <div>
                              <div className={cn("text-[10px] font-bold uppercase", node.status === "REJECTED" ? "text-red-400" : node.status === "VERIFIED" ? "text-emerald-400" : "text-white")}>{node.label}</div>
                              <div className="text-[8px] font-mono text-white/40 flex items-center gap-2">
                                 <Server className="w-3 h-3 inline" /> {node.nodeName}
                              </div>
                           </div>
                        </div>

                        <div className="flex items-center gap-3">
                           <div className="text-[9px] font-mono max-w-[120px] truncate text-white/50 text-right">
                              {node.hash}
                           </div>
                           <div className="w-6 h-6 flex justify-center items-center">
                              {node.status === "ACTIVE" && <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />}
                              {node.status === "VERIFIED" && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                              {node.status === "REJECTED" && <AlertOctagon className="w-4 h-4 text-red-500" />}
                           </div>
                        </div>
                     </div>
                  </div>
               ))}
            </div>

            {/* Connecting lines rendered using CSS pseudo-elements implicitly via flex gap, keeping it clean */}
         </div>

         {/* Sidebar Data */}
         <div className="space-y-6">
            <div className="bg-[#141414] border border-white/10 p-5 space-y-4 h-full flex flex-col">
               <h3 className="text-[11px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
                  <Database className="w-4 h-4" /> Event Sourcing Ledger
               </h3>

               <div className="flex-1 space-y-3 overflow-y-auto pr-2 custom-scrollbar">
                  {graphNodes.filter(n => n.status !== "IDLE").map((node, i) => (
                     <div key={i} className="bg-black/50 border border-white/5 p-3 text-[9px] font-mono relative animate-in slide-in-from-right-2">
                        <div className="flex justify-between items-start mb-2">
                           <span className={cn(
                              "px-1.5 py-0.5 uppercase tracking-wider font-bold",
                              node.status === "REJECTED" ? "bg-red-500/20 text-red-400" : "bg-white/10 text-white/70"
                           )}>{node.type}</span>
                           <span className="text-white/30 truncate max-w-[80px]">{node.id}_{i}</span>
                        </div>
                        <div className="text-white/50 break-all space-y-1">
                           <div><span className="opacity-50">NODE:</span> {node.nodeName}</div>
                           <div><span className="opacity-50">HASH:</span> <span className={node.status === "REJECTED" ? "text-red-400 font-bold" : ""}>{node.hash}</span></div>
                           {node.status === "VERIFIED" && <div className="text-emerald-400 mt-2">→ Linked to parent block</div>}
                           {node.status === "REJECTED" && <div className="text-red-400 mt-2">→ Parent-Child Hash Divergence</div>}
                        </div>
                     </div>
                  ))}

                  {simulationState === "IDLE" && (
                     <div className="text-[9px] font-mono text-white/30 text-center py-10 uppercase">
                        Awaiting graph traversal...
                     </div>
                  )}
               </div>

               {simulationState === "COMPLETE" && (
                  <div className="mt-4 p-3 border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold uppercase flex items-center justify-center gap-2 animate-pulse">
                     <CheckCircle2 className="w-4 h-4" /> Graph Intact & Recept Verified
                  </div>
               )}
               {simulationState === "FAILED" && (
                  <div className="mt-4 p-3 border border-red-500/30 bg-red-500/10 text-red-500 text-[10px] font-bold uppercase flex items-center justify-center gap-2 animate-pulse">
                     <AlertOctagon className="w-4 h-4" /> Graph Fracture Detected
                  </div>
               )}
            </div>
         </div>
      </div>

      {simulationState === "COMPLETE" && (
         <div className="bg-[#141414] p-6 border border-emerald-500/30 mt-6 flex justify-center animate-in fade-in duration-500">
         <ProofArtifacts
            id="provenance-graph"
            title="Distributed Provenance DAG Extracted"
            data={{
               doc_origin_id: "SWI-ORIGIN-8f3a91",
               chain_depth: "6",
               distributed_nodes: "swi-gov-node-a, swi-gov-node-b",
               reconciliation_status: "SUCCESS_VERIFIED"
            }}
            variant="always-dark"
         />
         </div>
      )}
    </div>
  );
}
