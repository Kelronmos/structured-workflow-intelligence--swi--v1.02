import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { ExecutionBoundaryState } from '@/swi-core/kernel/engines/types';

interface ManifoldTopologyProps {
  standing: ExecutionBoundaryState | null;
}

export default function ManifoldTopology({ standing }: ManifoldTopologyProps) {
  if (!standing) return (
    <div className="h-64 flex items-center justify-center border border-dashed border-white/10 rounded-xl bg-black/20">
      <p className="text-[10px] uppercase tracking-widest opacity-30">Waiting for standing attestation...</p>
    </div>
  );

  const accuracy = (1 - standing.drift) * standing.viability * Math.sqrt(standing.authority);

  const data = [
    { subject: 'Authority', A: standing.authority * 100, fullMark: 100 },
    { subject: 'Capacity', A: standing.capacity * 100, fullMark: 100 },
    { subject: 'Viability', A: standing.viability * 100, fullMark: 100 },
    { subject: 'Continuity', A: (standing.continuity / 5000) * 100, fullMark: 100 },
    { subject: 'Policy', A: 100, fullMark: 100 },
    { subject: 'Drift', A: (1 - standing.drift) * 100, fullMark: 100 },
    { subject: 'Burden', A: (1 - standing.burden) * 100, fullMark: 100 },
  ];

  return (
    <div className="h-64 w-full bg-black/40 rounded-xl border border-white/5 p-4 flex flex-col relative overflow-hidden group">
      <div className="flex justify-between items-start mb-2 relative z-10">
        <div>
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-blue-500">Standing Manifold</h3>
          <p className="text-[8px] opacity-40 uppercase">High-Dimensional Logic Preservation</p>
        </div>
        <div className="px-2 py-1 bg-blue-500/10 border border-blue-500/20 rounded text-[7px] font-mono text-blue-400">
          RT_TOPOLOGY_v4
        </div>
      </div>

      <div className="flex-1 w-full mt-[-20px]">
        <ResponsiveContainer width="100%" height="100%">
          <RadarChart cx="50%" cy="50%" outerRadius="70%" data={data}>
            <PolarGrid stroke="#FFFFFF" strokeOpacity={0.05} />
            <PolarAngleAxis 
              dataKey="subject" 
              tick={{ fill: '#FFFFFF', fontSize: 6, opacity: 0.3, fontWeight: 'bold' }} 
            />
            <Radar
              name="Standing"
              dataKey="A"
              stroke="#3B82F6"
              fill="#3B82F6"
              fillOpacity={0.4}
              strokeWidth={1}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-2 flex items-center justify-between px-2 bg-white/5 rounded-lg p-2 border border-white/5">
         <div className="space-y-1">
            <span className="text-[6px] uppercase font-bold opacity-30 block">Execution Accuracy (A)</span>
            <div className="text-xs font-mono font-bold text-blue-400">{(accuracy * 100).toFixed(2)}%</div>
         </div>
         <div className="text-right">
            <span className="text-[6px] uppercase font-bold opacity-30 block">Formula Model</span>
            <div className="text-[7px] font-mono opacity-40 italic">(1-δ) * ν * √α</div>
         </div>
      </div>

      <div className="absolute bottom-4 left-4 right-4 flex justify-between text-[7px] font-mono opacity-20 uppercase">
        <span>Geometry: R^10</span>
        <span>Stability: Consensus_Verified</span>
      </div>
      
      {/* Visual Glitch/Scanner Line */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-10">
         <div className="w-full h-1 bg-blue-500 absolute top-0 animate-[scan_3s_linear_infinite]" />
      </div>
    </div>
  );
}
