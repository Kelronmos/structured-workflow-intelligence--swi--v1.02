// src/components/AuthorityTokenView.tsx
import React, { useState, useEffect } from 'react';
import { Key, Clock, ShieldCheck, TrendingDown, ExternalLink, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import { AuthorityToken } from '@/swi-core/kernel/UniverseTypes';

interface AuthorityTokenViewProps {
    tokens?: AuthorityToken[];
}

export default function AuthorityTokenView({ tokens: propTokens }: AuthorityTokenViewProps) {
    const [tokens, setTokens] = useState<AuthorityToken[]>(propTokens || []);

    const fetchTokens = async () => {
        try {
            const res = await fetch('/api/v4/authority/tokens');
            const data = await res.json();
            setTokens(data);
        } catch (e) {
            console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e);
        }
    };

    useEffect(() => {
        if (!propTokens) {
            const interval = setInterval(fetchTokens, 3000);
            const timeout = setTimeout(() => {
                fetchTokens().catch(e => console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, e));
            }, 0);
            return () => {
                clearInterval(interval);
                clearTimeout(timeout);
            };
        }
    }, [propTokens]);

    return (
        <div className="bg-white/5 border border-white/10 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-500/20 rounded-lg">
                        <Key className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                        <h3 className="text-xs font-black uppercase tracking-widest text-white/90">Sovereign Authority Mesh</h3>
                        <p className="text-[8px] font-bold text-white/30 uppercase tracking-widest">Active Scoped Tokens</p>
                    </div>
                </div>
                <div className="px-3 py-1 bg-white/5 border border-white/10 rounded-full">
                    <span className="text-[9px] font-mono text-white/50">{tokens.length} ACTIVE</span>
                </div>
            </div>

            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                <AnimatePresence mode="popLayout">
                    {tokens.length === 0 ? (
                        <div className="p-8 text-center border-2 border-dashed border-white/5 rounded-2xl">
                             <ShieldAlert className="w-8 h-8 text-white/10 mx-auto mb-2" />
                             <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">No active tokens in mesh</p>
                        </div>
                    ) : tokens.map((token) => (
                        <motion.div
                            key={token.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="bg-black/40 border border-white/5 rounded-2xl p-4 hover:border-blue-500/30 transition-all group"
                        >
                            <div className="flex justify-between items-start mb-3">
                                <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                        <span className="text-[10px] font-mono font-bold text-blue-400">{token.id}</span>
                                        <span className={cn(
                                            "text-[8px] font-black uppercase px-2 py-0.5 rounded-md",
                                            token.confidence > 0.8 ? "bg-green-500/10 text-green-500" : "bg-yellow-500/10 text-yellow-500"
                                        )}>
                                            Conf: {(token.confidence * 100).toFixed(1)}%
                                        </span>
                                    </div>
                                    <p className="text-[8px] font-mono text-white/20 truncate w-32">{token.identityHash}</p>
                                </div>
                                <div className={cn(
                                    "p-1.5 rounded-lg border transition-all",
                                    token.confidence > 0.8 ? "border-green-500/20 bg-green-500/5 text-green-500" : "border-yellow-500/20 bg-yellow-500/5 text-yellow-500"
                                )}>
                                    <ShieldCheck className="w-4 h-4" />
                                </div>
                            </div>

                            <div className="flex flex-wrap gap-1.5 mb-4">
                                {token.scope.map((s, i) => (
                                    <span key={i} className="text-[7px] font-black uppercase tracking-widest px-2 py-0.5 bg-white/5 border border-white/5 rounded-md text-white/60">
                                        {s}
                                    </span>
                                ))}
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <div className="flex items-center gap-1.5 text-white/30">
                                        <Clock className="w-3 h-3" />
                                        <span className="text-[8px] font-bold uppercase tracking-widest">Expiration</span>
                                    </div>
                                    <p className="text-[9px] font-mono text-white/60">
                                        {new Date(token.expiration).toLocaleTimeString()}
                                    </p>
                                </div>
                                <div className="space-y-1">
                                    <div className="flex items-center gap-1.5 text-white/30">
                                        <TrendingDown className="w-3 h-3" />
                                        <span className="text-[8px] font-bold uppercase tracking-widest">Trust Decay</span>
                                    </div>
                                    <p className="text-[9px] font-mono text-blue-400/80">
                                        λ 0.042/Anomaly
                                    </p>
                                </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between group-hover:border-blue-500/20">
                                <span className="text-[7px] text-white/20 font-bold uppercase tracking-[0.2em]">{token.jurisdiction} JURISDICTION</span>
                                <button className="opacity-0 group-hover:opacity-100 transition-all flex items-center gap-1 text-[8px] font-bold uppercase text-blue-400">
                                    Audit Replay <ExternalLink className="w-2.5 h-2.5" />
                                </button>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </div>
    );
}
