import React, { useState, useEffect, useRef } from "react";
import {
  Download,
  Terminal,
  Server,
  ShieldCheck,
  CheckCircle2,
  HardDrive,
  Cpu,
  Loader2,
  PackageCheck,
  Binary,
  Play,
  RefreshCw,
  Layers,
  ShieldAlert,
  Code,
  Copy,
  Check,
  AlertTriangle,
  FolderLock,
  Boxes,
  Database,
  Key,
  FileSignature,
  Activity,
  UserCheck,
  Radio,
  Network,
  Trash,
  XCircle,
  Clock,
  Unlock,
  Lock,
  Compass,
  FileText,
  AlertOctagon,
  HeartPulse,
  Eye,
  Info
} from "lucide-react";
import { cn } from "../lib/utils";
import {
  DEAMON_SCRIPTS,
  PKISCRIPT_COLLECTION,
  SOVEREIGN_OS_SCRIPTS,
  INNO_SETUP_SCRIPT,
  DaemonVersion,
  PKIScript,
  SovereignOSScript
} from "./SWIScripts";

interface OSNode {
  id: string;
  name: string;
  type: "Windows" | "Docker" | "Cloud" | "Human";
  trust: number;
  signed: boolean;
  healthy: boolean;
  ip: string;
  lastSeen: string;
}

interface SignedArtifact {
  id: string;
  fileName: string;
  fileHash: string;
  signature: string;
  timestamp: string;
  ownerSubject: string;
  revoked: boolean;
}

export default function SWISetupInstallerView() {
  const [activeTab, setActiveTab] = useState<"sovereign_os" | "daemons" | "pki" | "installer">("sovereign_os");

  // Selection state within code viewers
  const [selectedDaemonId, setSelectedDaemonId] = useState<"v1" | "v2" | "v3" | "v4">("v3");
  const [selectedPkiCodeId, setSelectedPkiCodeId] = useState<string>("root_ca");
  const [selectedOsCodeId, setSelectedOsCodeId] = useState<string>("byzantine_consensus");

  // State copied notifications
  const [isCopied, setIsCopied] = useState(false);

  // LOG SCROLLS
  const logTerminalEndRef = useRef<HTMLDivElement>(null);
  const pkiTerminalEndRef = useRef<HTMLDivElement>(null);
  const osTerminalEndRef = useRef<HTMLDivElement>(null);
  const installerTerminalEndRef = useRef<HTMLDivElement>(null);

  // ==========================================
  // TAB 1: Sovereign Cloud OS & Byzantine Mesh
  // ==========================================
  const [nodes, setNodes] = useState<OSNode[]>([
    { id: "node-win", name: "swi-host-win", type: "Windows", trust: 94, signed: true, healthy: true, ip: "10.0.12.44", lastSeen: "Active" },
    { id: "node-dock", name: "swi-container-mesh", type: "Docker", trust: 91, signed: true, healthy: true, ip: "172.18.0.2", lastSeen: "Active" },
    { id: "node-cloud", name: "swi-k8s-pod", type: "Cloud", trust: 97, signed: true, healthy: true, ip: "10.244.1.8", lastSeen: "Active" },
    { id: "node-human", name: "swi-gov-quorum", type: "Human", trust: 100, signed: true, healthy: true, ip: "External Secure Link", lastSeen: "Active" }
  ]);
  const [osLogs, setOsLogs] = useState<string[]>([
    "[SYSTEM] Sovereign Cloud OS (SCO v1.0) control plane initialized.",
    "[CONSENSUS] Initializing distributed Byzantine Trust Mesh verification loop...",
    "[CONSENSUS] All 4 active nodes evaluated in solid quorum. Global trust score: 95.5% (HEALTHY)."
  ]);
  const [osState, setOsState] = useState<"HEALTHY" | "DEGRADED" | "QUARANTINE">("HEALTHY");
  const [activeHealingNode, setActiveHealingNode] = useState<string | null>(null);

  // Compute live consensus score
  const avgTrust = Math.round(nodes.reduce((acc, n) => acc + n.trust, 0) / nodes.length);

  useEffect(() => {
    if (avgTrust < 70) {
      setOsState("QUARANTINE");
    } else if (avgTrust < 86) {
      setOsState("DEGRADED");
    } else {
      setOsState("HEALTHY");
    }
  }, [avgTrust]);

  useEffect(() => {
    if (osTerminalEndRef.current) {
      osTerminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [osLogs]);

  const injectOsLog = (msg: string) => {
    const ts = new Date().toISOString().substring(11, 19);
    setOsLogs(prev => [...prev, `[${ts}] ${msg}`]);
  };

  const runConsensusCheck = () => {
    injectOsLog("Consensus query broadcast to node mesh peers...");
    setTimeout(() => {
      let consensusDetails = nodes.map(n => `${n.name} (Trust: ${n.trust}%, Check: ${n.healthy ? "OK" : "CORRUPT"}, Signed: ${n.signed ? "YES" : "NO"})`).join(" | ");
      injectOsLog(`Trust Mesh Byzantine Vote Result: [Average: ${avgTrust}%] => Status: ${osState}`);
      injectOsLog(`Peer details: ${consensusDetails}`);
    }, 500);
  };

  const injectCorruptionScen = () => {
    // Corrupt Docker Node (B)
    injectOsLog("ALERTER: Injecting node file filesystem corruption inside swi-container-mesh...");
    setNodes(prev => prev.map(n => n.id === "node-dock" ? { ...n, healthy: false, trust: 28 } : n));
    
    setTimeout(() => {
      injectOsLog("[CRITICAL] Consensus state deviation discovered! swi-container-mesh reported broken.");
      injectOsLog(`[CONSENSUS] Average Trust score plummeted to 81% (${av_state_calc(1)} STATE).`);
    }, 800);

    // Auto healing kick-in after 2 secs
    setTimeout(() => {
      setActiveHealingNode("node-dock");
      injectOsLog("[AUTONOMIC-HEALING] Launching continuous restore kernel workflow...");
      injectOsLog("[AUTONOMIC-HEALING] Validating digital signatures of snapshot state...");
      injectOsLog("[AUTONOMIC-HEALING] Restoring pristine modules from '.swi_backups/' archive...");
    }, 2000);

    setTimeout(() => {
      setNodes(prev => prev.map(n => n.id === "node-dock" ? { ...n, healthy: true, trust: 92 } : n));
      setActiveHealingNode(null);
      injectOsLog("[AUTONOMIC-HEALING] Hot container restart completed via Docker runtime SIGTERM trigger.");
      injectOsLog("[CONSENSUS] State deviations cleared. Quorum re-stabilized. Global state: HEALTHY.");
    }, 4500);
  };

  const injectUnsignedScen = () => {
    injectOsLog("SECURITY-POLICIES: Simulating unauthenticated code deployment on 'swi-k8s-pod'...");
    setNodes(prev => prev.map(n => n.id === "node-cloud" ? { ...n, signed: false, trust: 0, healthy: false } : n));

    setTimeout(() => {
      injectOsLog("[DENIED] PKI strict validation failed. Unsigned binaries detected on Cloud node.");
      injectOsLog("[POLICY-ENGINE] Rule evaluation matching policy root: allow_unsigned_code = FALSE. Securing environment...");
      injectOsLog("[SECURE-LOCKDOWN] Moving container process swi-k8s-pod to isolation directory /.swi_quarantine/ !");
    }, 800);
  };

  const repairCloudNode = () => {
    if (nodes.find(n => n.id === "node-cloud")?.signed) return;
    injectOsLog("[PKI-AGENT] Attaching valid signature payload to swi-k8s-pod metadata...");
    
    setTimeout(() => {
      setNodes(prev => prev.map(n => n.id === "node-cloud" ? { ...n, signed: true, healthy: true, trust: 96 } : n));
      injectOsLog("[SECURE-LOCKDOWN] Sandbox constraint unlocked for swi-k8s-pod.");
      injectOsLog("[CONSENSUS] Core node mesh has approved signature authenticity. State restored.");
    }, 1200);
  };

  const av_state_calc = (sub: number) => {
    let raw = Math.round(nodes.reduce((acc, n) => acc + (n.id === "node-dock" ? 28 : n.trust), 0) / nodes.length);
    if (raw < 70) return "QUARANTINE";
    if (raw < 86) return "DEGRADED";
    return "HEALTHY";
  };


  // ==========================================
  // TAB 2: Interacting with PKI & Signatures
  // ==========================================
  const [rootCACert, setRootCACert] = useState<any>(null);
  const [interCACert, setInterCACert] = useState<any>(null);
  const [signedArtifacts, setSignedArtifacts] = useState<SignedArtifact[]>([
    { id: "sa-1", fileName: "swi_daemon.exe", fileHash: "f1da984e03fb892cf4de6a1d8bc98ad3482a0efc8f3bc29aa24fb89cf91f1852", signature: "3082010A02820101009DF8B3ACF4E119EFD...", timestamp: "2026-05-25T14:22:00Z", ownerSubject: "SWI Operational Intermediate CA", revoked: false },
    { id: "sa-2", fileName: "policy.manifest", fileHash: "88db82efb89091cac1e5509ba249cfba98eaefca28ef3c87e88924bcf89ad92c", signature: "48EB1A9D4EAA83CA7F1A9D439DF284C8F8A...", timestamp: "2026-05-25T18:10:00Z", ownerSubject: "SWI Operational Intermediate CA", revoked: false }
  ]);
  const [pkiLogs, setPkiLogs] = useState<string[]>([
    "PKI Authority Console initialized. Offline Root CA is currently UNINITIALIZED."
  ]);
  const [customSignFile, setCustomSignFile] = useState("install_setup.exe");
  const [revocationList, setRevocationList] = useState<string[]>([]);
  const [isSignState, setIsSignState] = useState<"IDLE" | "GENERATING" | "SIGNING" | "VERIFYING">("IDLE");
  const [bootTestResult, setBootTestResult] = useState<{ status: "NONE" | "PASS" | "WARN" | "FAIL", details: string }>({ status: "NONE", details: "" });

  useEffect(() => {
    if (pkiTerminalEndRef.current) {
      pkiTerminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [pkiLogs]);

  const addPkiLog = (msg: string) => {
    const ts = new Date().toISOString().substring(11, 19);
    setPkiLogs(prev => [...prev, `[${ts}] ${msg}`]);
  };

  const createRootCA = () => {
    setIsSignState("GENERATING");
    addPkiLog("Initializing Root CA Generation Algorithm...");
    setTimeout(() => {
      addPkiLog("Generating standard offline 4096-bit RSA asymmetric private critical parameters...");
    }, 600);
    setTimeout(() => {
      addPkiLog("Applying self-signed X509 Name Metadata: Subject=CN=SWI ROOT CA, O=SWI Root Authority, C=BW");
      setRootCACert({
        subject: "CN=SWI ROOT CA, O=SWI Root Authority, C=BW",
        issuer: "CN=SWI ROOT CA, O=SWI Root Authority, C=BW",
        serial: "0x" + Math.floor(Math.random() * 9999999).toString(16).toUpperCase(),
        keySize: 4096,
        validity: "10 Years (2036)",
        pem: `-----BEGIN CERTIFICATE-----\nMIIFdzCCBF+gAwIBAgIUHTY5OGFm... [SWI OFFLINE ROOT CA KEY BLOCK] ...\n-----END CERTIFICATE-----`
      });
      setIsSignState("IDLE");
      addPkiLog("[SUCCESS] Offline Root CA securely created. Private key moved to offline vault.");
    }, 1800);
  };

  const createIntermediateCA = () => {
    if (!rootCACert) {
      addPkiLog("[ERROR] Root CA must be created before delegating authority to Intermediate CA.");
      return;
    }
    setIsSignState("GENERATING");
    addPkiLog("Issuing Operational Intermediate Certificate Request...");
    setTimeout(() => {
      addPkiLog("Root CA authorization signature verified. Generating Intermediate 4096-bit cryptoservices.");
    }, 600);
    setTimeout(() => {
      setInterCACert({
        subject: "CN=SWI Operational Intermediate CA, O=SWI Governance Authority",
        issuer: rootCACert.subject,
        serial: "0x8DF1A4B" + Math.floor(Math.random() * 9999).toString(16).toUpperCase(),
        validity: "5 Years (2031)",
        pem: `-----BEGIN CERTIFICATE-----\nMIIEZDCCAsygAwIBAgIUIDM0ZmI0... [SWI INTERMEDIATE OPERATIONAL CA KEY] ...\n-----END CERTIFICATE-----`
      });
      setIsSignState("IDLE");
      addPkiLog("[SUCCESS] Intermediate Operational Cert generated. Approved for active code-signing operations.");
    }, 1500);
  };

  const signNewFile = () => {
    if (!interCACert) {
      addPkiLog("[ERROR] Operational Intermediate Cert needed to perform active digital signing.");
      return;
    }
    if (!customSignFile.trim()) return;

    setIsSignState("SIGNING");
    addPkiLog(`Hashing binary targets of ${customSignFile} with SHA-256...`);

    setTimeout(() => {
      const computedHash = "sha256_" + Math.random().toString(36).substring(2, 10).toUpperCase() + "e34f81cfaedb...";
      const mockSig = "3082010A0282" + Math.random().toString(16).substring(2, 10).toUpperCase() + "E4FA9D31B..." + Math.random().toString(16).substring(2, 6).toUpperCase();
      const newArtifact: SignedArtifact = {
        id: "sa-" + Date.now(),
        fileName: customSignFile,
        fileHash: computedHash,
        signature: mockSig,
        timestamp: new Date().toISOString(),
        ownerSubject: interCACert.subject,
        revoked: false
      };
      setSignedArtifacts(prev => [...prev, newArtifact]);
      addPkiLog(`[OK] Intermediate signs certificate hash context. Encrypting signatures.`);
      setIsSignState("IDLE");
      addPkiLog(`[SUCCESS] Detached binary signature generated at: ${customSignFile}.sig`);
    }, 1200);
  };

  const revokeArtifact = (id: string, fileName: string) => {
    addPkiLog(`[REVOCATION] Initiating revocation command for ${fileName}...`);
    setSignedArtifacts(prev => prev.map(sa => sa.id === id ? { ...sa, revoked: true } : sa));
    setRevocationList(prev => [...prev, fileName]);
    addPkiLog(`[CRL] Certificate file hash added of ${fileName} added to crl list revocation ledger.`);
  };

  const verifyChainAndBoot = (artifact: SignedArtifact) => {
    setIsSignState("VERIFYING");
    addPkiLog(`Executing anti-tamper boot validator on target: ${artifact.fileName}`);

    setTimeout(() => {
      // Step 1: Check CRL
      if (revocationList.includes(artifact.fileName) || artifact.revoked) {
        setBootTestResult({
          status: "FAIL",
          details: `HALT_BOOT - Cryptographic validation halted! Certificate or binary has been revoked in the active CRL list.`
        });
        addPkiLog("[CRITICAL] Anti-Tamper signature validation failed! Node booted locked.");
        setIsSignState("IDLE");
        return;
      }

      // Step 2: Check active signing chain
      if (!interCACert) {
        setBootTestResult({
          status: "WARN",
          details: `LIMITED_MODE - Chain of trust is partial. Root signature verified, but intermediate delegated signer not fully initialized in local runtime instance.`
        });
        addPkiLog("[WARN] Boot validation warning: partial authority path found.");
        setIsSignState("IDLE");
        return;
      }

      // Step 3: Success
      setBootTestResult({
        status: "PASS",
        details: `FULL_TRUST_BOOT - Clean boot verified! SHA-256 Hash matches exactly, PKI validation path checked, chain trusted.`
      });
      addPkiLog("[SUCCESS] Authentic signature confirmed. Launching boot daemon securely.");
      setIsSignState("IDLE");
    }, 1200);
  };


  // ==========================================
  // TAB 3: Legacy Daemons (Classic View Upgrade)
  // ==========================================
  const [daemonSimulatorLogs, setDaemonSimulatorLogs] = useState<string[]>([
    "System standby. Choose a daemon version and trigger a simulated event loop scenario below."
  ]);
  const [daemonSimState, setDaemonSimState] = useState<"IDLE" | "MONITORING" | "REPAIRING" | "QUARANTINING" | "CRITICAL">("IDLE");
  const [quarantinedFiles, setQuarantinedFiles] = useState<string[]>([]);
  const [backupsCreated, setBackupsCreated] = useState<string[]>([]);

  useEffect(() => {
    if (logTerminalEndRef.current) {
      logTerminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [daemonSimulatorLogs]);

  const activeDaemon = DEAMON_SCRIPTS.find(s => s.id === selectedDaemonId) || DEAMON_SCRIPTS[1];

  const simulateDaemonTask = (scenario: "normal" | "malware" | "deleted_modules" | "script_failure" | "test_failure") => {
    setDaemonSimState("MONITORING");
    setDaemonSimulatorLogs([
      `[SIMULATOR] Spawning daemon background thread containing script context: ${activeDaemon.name}`,
      `[SYSTEM] Watching workspace directory structure at: /app`,
      `[HEALTH-CHECK] Inspecting active modules...`
    ]);

    setTimeout(() => {
      if (scenario === "normal") {
        setDaemonSimulatorLogs(prev => [
          ...prev,
          `[OK] Manifest verification complete: package.json is fully sound.`,
          `[OK] Standard directories verified. node_modules loaded cleanly.`,
          `[GOVERNANCE] Evaluating active dependencies: ["react", "express", "lodash", "lucide-react"]`,
          `[GOVERNANCE] Integrity check: APPROVED. Signed compliant assemblies secure in container.`
        ]);
        setDaemonSimState("IDLE");
      }

      else if (scenario === "deleted_modules") {
        setDaemonSimulatorLogs(prev => [
          ...prev,
          `[ALERT] Warning: node_modules container directory deleted or modified outside of normal runtime channels!`,
          `[STATUS] Node mesh flagged state deviation.`
        ]);

        setTimeout(() => {
          if (selectedDaemonId === "v1") {
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[V1-LEGACY-REBUILD] Restoring legacy node_modules via direct npm install command...`
            ]);
            setTimeout(() => {
              setDaemonSimulatorLogs(prev => [...prev, `[SUCCESS] V1 executed basic repair. State restored.`]);
              setDaemonSimState("IDLE");
            }, 1000);
          } else {
            setDaemonSimState("REPAIRING");
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[SECURITY-GATE] Verifying whitelisted dependencies of package.json...`,
              `[GOVERNANCE] Whitelist check: OK. All packages approved by policy criteria.`
            ]);

            if (selectedDaemonId === "v3" || selectedDaemonId === "v4") {
              const currentTimestamp = Math.floor(Date.now() / 1000);
              const backupName = `backup_modules_v${selectedDaemonId}_${currentTimestamp}`;
              setBackupsCreated(old => [...old, backupName]);
              setDaemonSimulatorLogs(prev => [...prev, `[SNAPSHOT] Registered gold-standard build state: ${backupName}`]);
            }

            setTimeout(() => {
              setDaemonSimulatorLogs(prev => [
                ...prev,
                `[EXEC] Executing safe_npm_install under policy control...`,
                `[SUCCESS] Node modules restored. Core digital validation hash assigned.`
              ]);
              setDaemonSimState("IDLE");
            }, 1200);
          }
        }, 1200);
      }

      else if (scenario === "malware") {
        setDaemonSimulatorLogs(prev => [
          ...prev,
          `[ALERT] File integrity breach! Unregistered dependency update request located in manifest: "backdoor-payload"`,
          `[GOVERNANCE] Validating license scoring admissibility...`,
          `[GOVERNANCE] Action: DENIED. Package marked on security blacklist.`
        ]);

        setTimeout(() => {
          if (selectedDaemonId === "v1") {
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[V1-CRITICAL-LIMITATION] Warning: Legacy V1 model has zero admission gate rules!`,
              `[EXEC] V1 triggers basic installation: npm install`,
              `[CRITICAL_FAIL] Vulnerable packages active inside standard framework! Security status compromised.`
            ]);
            setDaemonSimState("CRITICAL");
          } else {
            setDaemonSimState("QUARANTINING");
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[GATED-INSTALL] Isolating unapproved package files immediately...`,
              `[ISOLATION] Writing blocker manifest under /.swi_quarantine/backdoor-payload.blocked`
            ]);
            const timestamp = new Date().toISOString().substring(14, 19);
            setQuarantinedFiles(prev => [...prev, `backdoor-payload_${timestamp}.blocked`]);

            setTimeout(() => {
              setDaemonSimulatorLogs(prev => [
                ...prev,
                `[GOVERNANCE] Threat neutralized. State preserved perfectly without corrupting node_modules.`,
                `[LEDGER] Logged event and reported metrics to security operations console.`
              ]);
              setDaemonSimState("IDLE");
            }, 1000);
          }
        }, 1200);
      }

      else if (scenario === "script_failure") {
        setDaemonSimulatorLogs(prev => [
          ...prev,
          `[ALERT] Custom source changes noticed. Triggering compiler sanity verification checks...`,
          `[EXEC] Running build task 'npm run build'`
        ]);

        setTimeout(() => {
          setDaemonSimulatorLogs(prev => [
            ...prev,
            `[COMPILE_ERROR] Syntax error compiled internally on /src/App.tsx line 440: Unexpected token ';'`,
            `[FAILURE-DETECTOR] Reading compiler log trace...`
          ]);

          if (selectedDaemonId === "v4") {
            setDaemonSimState("REPAIRING");
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[CI/CD-ENGINE] Classifier caught error. Categorization: BUILD_FAILURE.`,
              `[CI/CD-ENGINE] Automated repair authorized. Resolving workspace syntax inconsistencies...`,
              `[REPAIR] Restoring uncompiled templates and compiling with correct state machines...`,
              `[EXEC] Re-running build task 'npm run build' (Attempt #2)`
            ]);

            setTimeout(() => {
              setDaemonSimulatorLogs(prev => [
                ...prev,
                `[OK] Build compiled cleanly.`,
                `[SUCCESS] CI/CD pipeline restored state to green.`
              ]);
              setDaemonSimState("IDLE");
            }, 1200);
          } else {
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[FATAL] Compilation failed. Active daemon version ${activeDaemon.id} has no autonomic rebuild repair logic. System is locked in broken build state.`
            ]);
            setDaemonSimState("CRITICAL");
          }
        }, 1200);
      }

      else if (scenario === "test_failure") {
        setDaemonSimulatorLogs(prev => [
          ...prev,
          `[CI/CD] Booting full autonomic build suite stages...`,
          `[STAGES] Stage 1 (Install verify): APPROVED`,
          `[STAGES] Stage 2 (Compile Build verify): APPROVED`,
          `[STAGES] Stage 3 (Test execution): RUNNING 'npm run test'`
        ]);

        setTimeout(() => {
          setDaemonSimulatorLogs(prev => [
            ...prev,
            `[TEST-RESULT] Fail - assertion mismatch on student wellbeing index. Expected: baseline > 0.70, Found: 0.55`,
            `[CI/CD] Failure classified: TEST_FAILURE`
          ]);

          if (selectedDaemonId === "v4") {
            setDaemonSimState("QUARANTINING");
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[GOVERNANCE-RULE] Policy alert: Machine self-healing is FORBIDDEN from bypassing failing assertions!`,
              `[REASON] Safeguards prevent agents from generating artificial compliance statistics without real resolution.`,
              `[LOCKOUT] Commencing containment lockout of target commit to block deployment releases...`,
              `[QUARANTINE] Saving commit file descriptors inside /.swi_quarantine/failed_commit.json`
            ]);
            setQuarantinedFiles(prev => [...prev, `failed_wellbeing_commit_${new Date().toISOString().substring(14, 19)}.json`]);
            setDaemonSimState("IDLE");
          } else {
            setDaemonSimulatorLogs(prev => [
              ...prev,
              `[FATAL] Test suites failing. Legacy engines do not halt deployment for unit test failures. State remains vulnerable.`
            ]);
            setDaemonSimState("CRITICAL");
          }
        }, 1500);
      }
    }, 1200);
  };


  // ==========================================
  // TAB 4: Inno Setup Compiler / Installer ISS
  // ==========================================
  const [installerState, setInstallerState] = useState<"IDLE" | "COMPILING" | "PACKAGING" | "READY" | "DOWNLOADING">("IDLE");
  const [compilerProgress, setCompilerProgress] = useState(0);
  const [installerLogs, setInstallerLogs] = useState<string[]>([]);

  useEffect(() => {
    if (installerTerminalEndRef.current) {
      installerTerminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [installerLogs]);

  const compileInnoSetup = () => {
    setInstallerState("COMPILING");
    setInstallerLogs(["[INNO COMPILER] Initializing Inno Setup Compiler v6.2.2 Engine..."]);
    setCompilerProgress(5);

    setTimeout(() => {
      setInstallerLogs(prev => [...prev, "[INNO COMPILER] Preprocessing configuration rules from install.iss..."]);
      setCompilerProgress(20);
    }, 600);

    setTimeout(() => {
      setInstallerLogs(prev => [
        ...prev,
        "[INNO COMPILER] Packing file tree sources into installer assembly payload:",
        "  -> Source: {app}/swi-core/swi.exe (4.8MB Packed LZMA2)",
        "  -> Source: {app}/governance/policy.manifest (120KB Signed SHA-256)",
        "  -> Source: {app}/signature.sig (512B RSA)"
      ]);
      setCompilerProgress(45);
    }, 1500);

    setTimeout(() => {
      setInstallerLogs(prev => [...prev, "[INNO COMPILER] Embedding SWI policy validation hooks [CheckSystemRequirements, ValidateSWIPolicy, VerifyIntegrity]..."]);
      setCompilerProgress(65);
    }, 2400);

    setTimeout(() => {
      setInstallerLogs(prev => [
        ...prev,
        "[INNO COMPILER] Generating rollback system parameters directory under: {pf}/SWI_Sovereign/rollback",
        "[INNO COMPILER] Registering background system service [RegisterSWIService]..."
      ]);
      setCompilerProgress(80);
    }, 3200);

    setTimeout(() => {
      setInstallerState("PACKAGING");
      setInstallerLogs(prev => [...prev, "[INNO COMPILER] Performing Solid compression (LZMA2 Ultra) on whole package..."]);
      setCompilerProgress(95);
    }, 4000);

    setTimeout(() => {
      setInstallerState("READY");
      setInstallerLogs(prev => [...prev, "[SUCCESS] Inno Setup finished compilations. Output built: deploy/install.exe successfully."]);
      setCompilerProgress(100);
    }, 5000);
  };

  const handleDownloadIss = () => {
    const blob = new Blob([INNO_SETUP_SCRIPT], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "install.iss";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadSetupExe = () => {
    setInstallerState("DOWNLOADING");
    setInstallerLogs(prev => [...prev, "[DOWNLOAD] Transferring compiled setup binary swi_installer.exe to browser..."]);
    
    setTimeout(() => {
      const content = `MZ\\x90\\x00\\x03\\x00\\x00\\x00\\x04... SWI Sovereign Inno Setup Release 4.5. Signed with trusted CA keys. Approved: Botswana Quorum Protocol`;
      const blob = new Blob([content], { type: "application/x-msdownload" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "swi_installer.exe";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setInstallerLogs(prev => [...prev, "[SUCCESS] Download of swi_installer.exe finished."]);
      setInstallerState("READY");
    }, 1200);
  };


  // ==========================================
  // GENERAL HELPERS
  // ==========================================
  const activeDaemonScript = DEAMON_SCRIPTS.find(s => s.id === selectedDaemonId) || DEAMON_SCRIPTS[2];
  const activePkiScript = PKISCRIPT_COLLECTION.find(s => s.id === selectedPkiCodeId) || PKISCRIPT_COLLECTION[0];
  const activeOsScript = SOVEREIGN_OS_SCRIPTS.find(s => s.id === selectedOsCodeId) || SOVEREIGN_OS_SCRIPTS[0];

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const activeCodeViewerCode = () => {
    if (activeTab === "daemons") return activeDaemonScript.code;
    if (activeTab === "pki") return activePkiScript.code;
    if (activeTab === "sovereign_os") return activeOsScript.code;
    return INNO_SETUP_SCRIPT;
  };

  const activeCodeViewerTitle = () => {
    if (activeTab === "daemons") return `Daemon Code: ${activeDaemonScript.name}`;
    if (activeTab === "pki") return `PKI Authority Code: ${activePkiScript.name}`;
    if (activeTab === "sovereign_os") return `Governance & Assurance Module: ${activeOsScript.name}`;
    return "Inno Setup Script: install.iss";
  };

  const handleDownloadCodeFile = () => {
    const code = activeCodeViewerCode();
    const name = activeTab === "daemons" ? `swi_daemon_${activeDaemonScript.id}.py` :
                 activeTab === "pki" ? activePkiScript.name :
                 activeTab === "sovereign_os" ? activeOsScript.name : "install.iss";
    const blob = new Blob([code], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="swi-sculpted-installer-wrapper" className="space-y-6 animate-in fade-in duration-300 max-w-7xl mx-auto p-4 md:p-6 bg-black text-[#e4e3e0]">
      
      {/* HEADER SECTION */}
      <div className="bg-[#0a0a0c] border border-white/10 p-6 md:p-8 relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6 rounded-sm">
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-indigo-500/10 blur-[120px] pointer-events-none"></div>
        <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-emerald-500/5 blur-[120px] pointer-events-none"></div>

        <div className="space-y-2 relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 text-indigo-400 font-mono text-[10px] uppercase tracking-widest font-bold">
            <span className="flex h-2 w-2 rounded-full bg-indigo-500 animate-pulse" />
            SWI Sovereignty Orchestration Command
          </div>
          <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tight text-white font-serif">
            Governance & Assurance Kernels
          </h2>
          <p className="text-xs text-white/60 leading-relaxed font-sans mt-1">
            Build, audit, and deploy production-grade self-healing systems. 
            Enforce the core security premise: <span className="text-indigo-400 font-mono">install !== execution</span>. 
            Sign and execute cryptographically verifiable builds across distributed Byzantine Trust Meshes.
          </p>
        </div>

        {/* NAVIGATION TABS */}
        <div className="flex flex-wrap gap-1.5 relative z-10 bg-black/80 p-1 border border-white/10 rounded-sm">
          <button
            onClick={() => setActiveTab("sovereign_os")}
            className={cn(
              "px-3.5 py-1.5 text-[9.5px] uppercase font-bold transition-all flex items-center gap-1.5",
              activeTab === "sovereign_os"
                ? "bg-indigo-600 text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            )}
          >
            <Layers className="w-3.5 h-3.5" />
            Sovereign Cloud OS
          </button>
          <button
            onClick={() => setActiveTab("pki")}
            className={cn(
              "px-3.5 py-1.5 text-[9.5px] uppercase font-bold transition-all flex items-center gap-1.5",
              activeTab === "pki"
                ? "bg-indigo-600 text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            )}
          >
            <Key className="w-3.5 h-3.5" />
            PKI Authority
          </button>
          <button
            onClick={() => setActiveTab("daemons")}
            className={cn(
              "px-3.5 py-1.5 text-[9.5px] uppercase font-bold transition-all flex items-center gap-1.5",
              activeTab === "daemons"
                ? "bg-indigo-600 text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            )}
          >
            <Cpu className="w-3.5 h-3.5" />
            Autonomic Daemons
          </button>
          <button
            onClick={() => setActiveTab("installer")}
            className={cn(
              "px-3.5 py-1.5 text-[9.5px] uppercase font-bold transition-all flex items-center gap-1.5",
              activeTab === "installer"
                ? "bg-indigo-600 text-white"
                : "text-white/50 hover:text-white hover:bg-white/5"
            )}
          >
            <Binary className="w-3.5 h-3.5" />
            Inno Setup Compiler
          </button>
        </div>
      </div>

      {/* RENDER VIEW ACCORDING TO ACTIVE TAB */}
      
      {/* 2.1 TAB: SOVEREIGN CLOUD OS CONTROL PLANE */}
      {activeTab === "sovereign_os" && (
        <div id="sovereign-os-content" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-in fade-in duration-200">
          
          {/* Left panel is the live trust mesh graph (col-span-12 or 5 on desktop) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Visual Byzantine Node Network */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm space-y-4">
              <div className="flex justify-between items-center border-b border-white/5 pb-2">
                <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2">
                  <Network className="w-4 h-4 text-indigo-400 animate-pulse" />
                  Distributed Trust Mesh Graph
                </h3>
                <span className={cn(
                  "px-2 py-0.5 rounded text-[8px] font-mono tracking-wider font-bold border",
                  osState === "HEALTHY" ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/30" :
                  osState === "DEGRADED" ? "text-amber-400 bg-amber-400/10 border-amber-400/30" :
                  "text-red-500 bg-red-500/10 border-red-500/30 animate-pulse"
                )}>
                  {osState}
                </span>
              </div>

              {/* Graphical representation of the 4 Byzantine nodes */}
              <div className="relative bg-[#020202] border border-white/5 rounded-sm h-64 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-radial-gradient from-indigo-500/5 to-transparent pointer-events-none" />
                
                {/* Visual Connector lines */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ minHeight: "100%" }}>
                  {/* Nodes connect to each other */}
                  <line x1="25%" y1="25%" x2="75%" y2="25%" stroke="rgba(99, 102, 241, 0.2)" strokeWidth="1.5" strokeDasharray="4 2" />
                  <line x1="25%" y1="25%" x2="25%" y2="75%" stroke="rgba(99, 102, 241, 0.2)" strokeWidth="1.5" />
                  <line x1="75%" y1="25%" x2="75%" y2="75%" stroke="rgba(99, 102, 241, 0.2)" strokeWidth="1.5" />
                  <line x1="25%" y1="75%" x2="75%" y2="75%" stroke="rgba(99, 102, 241, 0.2)" strokeWidth="1.5" strokeDasharray="4 2" />
                  <line x1="25%" y1="25%" x2="75%" y2="75%" stroke="rgba(99, 102, 241, 0.15)" strokeWidth="1" />
                  <line x1="75%" y1="25%" x2="25%" y2="75%" stroke="rgba(99, 102, 241, 0.15)" strokeWidth="1" />
                </svg>

                {/* Nodes layout grid positioning */}
                <div className="absolute top-8 left-12 flex flex-col items-center">
                  <div className={cn(
                    "h-10 w-10 rounded-full border flex items-center justify-center transition-all bg-black",
                    nodes[0].healthy ? "border-emerald-500 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)]" : "border-red-500 text-red-500"
                  )}>
                    <HardDrive className="w-5 h-5" />
                  </div>
                  <span className="text-[8px] font-mono mt-1 text-white/50">{nodes[0].name}</span>
                  <span className="text-[7.5px] font-mono font-bold text-indigo-400">{nodes[0].trust}% Trust</span>
                </div>

                <div className="absolute top-8 right-12 flex flex-col items-center">
                  <div className={cn(
                    "h-10 w-10 rounded-full border flex items-center justify-center transition-all bg-black",
                    nodes[1].healthy ? "border-emerald-500 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)]" : "border-red-500 text-red-500 animate-pulse"
                  )}>
                    <Boxes className="w-5 h-5" />
                  </div>
                  <span className="text-[8px] font-mono mt-1 text-white/50">{nodes[1].name}</span>
                  <span className="text-[7.5px] font-mono font-bold text-indigo-400">{nodes[1].trust}% Trust</span>
                </div>

                <div className="absolute bottom-8 left-12 flex flex-col items-center">
                  <div className={cn(
                    "h-10 w-10 rounded-full border flex items-center justify-center transition-all bg-black",
                    nodes[2].healthy ? "border-emerald-500 text-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.2)]" : "border-amber-500 text-amber-500 animate-ping"
                  )}>
                    <Server className="w-5 h-5" />
                  </div>
                  <span className="text-[8px] font-mono mt-1 text-white/50">{nodes[2].name}</span>
                  <span className="text-[7.5px] font-mono font-bold text-indigo-400">{nodes[2].trust}% Trust</span>
                </div>

                <div className="absolute bottom-8 right-12 flex flex-col items-center">
                  <div className="h-10 w-10 rounded-full border border-violet-500 text-violet-400 flex items-center justify-center bg-black shadow-[0_0_10px_rgba(168,85,247,0.2)]">
                    <UserCheck className="w-5 h-5" />
                  </div>
                  <span className="text-[8px] font-mono mt-1 text-white/50">{nodes[3].name}</span>
                  <span className="text-[7.5px] font-mono font-bold text-violet-400">QUORUM</span>
                </div>

                {/* Node Healing Animation overlay */}
                {activeHealingNode && (
                  <div className="absolute inset-x-0 bottom-4 bg-indigo-950/80 border border-indigo-500/40 py-2 px-3 mx-4 rounded flex items-center justify-between text-[10px] font-mono animate-pulse">
                    <span className="text-indigo-300 flex items-center gap-1.5 font-bold uppercase">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      Healing {activeHealingNode}...
                    </span>
                    <span className="text-[8.5px] text-indigo-400">Hot Swap Registry</span>
                  </div>
                )}
              </div>

              {/* Status metrics grid */}
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-white/5 border border-white/5 p-3 rounded-sm space-y-1">
                  <span className="text-[8px] uppercase tracking-wider text-white/40 block">Average Quorum Trust</span>
                  <span className="text-xl font-bold text-indigo-400 font-serif">{avgTrust}%</span>
                </div>
                <div className="bg-white/5 border border-white/5 p-3 rounded-sm space-y-1">
                  <span className="text-[8px] uppercase tracking-wider text-white/40 block">Control Laws</span>
                  <span className="text-sm font-semibold text-emerald-400 font-mono">require_pki=True</span>
                </div>
              </div>
            </div>

            {/* Simulated Event Injector Arena */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm space-y-4">
              <div className="border-b border-white/5 pb-2">
                <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-1.5">
                  <Play className="w-4 h-4 text-indigo-400 animate-pulse" />
                  Governance Event Injectors
                </h3>
                <p className="text-[10px] text-white/40 mt-0.5 leading-relaxed">
                  Trigger infrastructure compromises or authentication failures to simulate the Governance Byzantine trust and heal workflow.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 md:gap-3">
                <button
                  onClick={injectCorruptionScen}
                  disabled={!!activeHealingNode}
                  className={cn(
                    "p-3.5 bg-black border text-left flex flex-col justify-between font-mono text-[9px] font-bold transition-all rounded-sm",
                    activeHealingNode ? "opacity-30 cursor-not-allowed border-white/5" : "border-white/10 hover:border-red-500 text-white hover:bg-red-500/5"
                  )}
                >
                  <span className="text-red-400 uppercase tracking-widest block">Nuke Docker Node</span>
                  <span className="text-white/40 font-sans text-[8px] font-normal mt-1 leading-normal">
                    Fails safety checks. Triggers file correction + rollback & reboot automatically.
                  </span>
                </button>

                <button
                  onClick={injectUnsignedScen}
                  disabled={!nodes[2].signed}
                  className={cn(
                    "p-3.5 bg-black border text-left flex flex-col justify-between font-mono text-[9px] font-bold transition-all rounded-sm",
                    !nodes[2].signed ? "opacity-30 cursor-not-allowed border-white/5" : "border-white/10 hover:border-amber-500 text-white hover:bg-amber-500/5"
                  )}
                >
                  <span className="text-amber-400 uppercase tracking-widest block">Unsigned Code Deploy</span>
                  <span className="text-white/40 font-sans text-[8px] font-normal mt-1 leading-normal">
                    Deploy unsigned package onto Cloud Pod. Triggers policy secure lockdown.
                  </span>
                </button>

                {!nodes[2].signed && (
                  <button
                    onClick={repairCloudNode}
                    className="col-span-1 sm:col-span-2 p-3 bg-indigo-900/30 hover:bg-indigo-900/50 text-indigo-300 border border-indigo-500/40 text-center uppercase tracking-wider font-mono text-[9.5px] font-bold py-2.5 transition-all text-xs flex justify-center items-center gap-2 rounded-sm"
                  >
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    Sign Code & Release Lockdown
                  </button>
                )}

                <button
                  onClick={runConsensusCheck}
                  className="col-span-1 sm:col-span-2 p-2 bg-white/5 hover:bg-white/10 border border-white/10 text-center uppercase tracking-widest font-mono text-[8.5px] font-bold py-2 transition-all rounded-sm"
                >
                  Force Byzantine Consensus Evaluation
                </button>
              </div>
            </div>

          </div>

          {/* Right panel terminal logs */}
          <div className="lg:col-span-7 bg-[#020202] border border-white/10 flex flex-col justify-between rounded-sm min-h-[550px] overflow-hidden">
            
            {/* Logging header */}
            <div className="bg-white/5 px-4 py-3 border-b border-white/10 flex items-center justify-between">
              <span className="text-[10px] font-bold font-mono text-white/70 uppercase tracking-widest flex items-center gap-2">
                <Terminal className="text-indigo-400 w-4 h-4" />
                Governance Control Log Terminal
              </span>
              <button
                onClick={() => setOsLogs(["[SYSTEM] Governance Terminal audit loop cleared."])}
                className="text-[8px] uppercase tracking-wider font-bold text-white/30 hover:text-white transition-colors"
                title="Wipe logs"
              >
                Clear Terminal
              </button>
            </div>

            {/* Container log listing */}
            <div className="p-4 flex-1 font-mono text-[9.5px] leading-relaxed max-h-[350px] overflow-y-auto custom-scrollbar space-y-1.5 bg-black">
              {osLogs.map((log, i) => (
                <div key={i} className={cn(
                  "break-all border-l pr-2 pl-2.5",
                  log.includes("[SUCCESS]") || log.includes("(HEALTHY)") ? "text-emerald-400 border-emerald-500/40" :
                  log.includes("[CRITICAL]") || log.includes("[DENIED]") ? "text-red-400 border-red-500 font-bold" :
                  log.includes("ALERTER:") || log.includes("[WARN]") ? "text-amber-400 border-amber-500/40" :
                  log.includes("[POLICY-ENGINE]") || log.includes("[CONSENSUS]") ? "text-indigo-400 border-indigo-500/40" :
                  log.includes("[AUTONOMIC-HEALING]") ? "text-cyan-400 border-cyan-500/40 font-semibold" :
                  "text-white/60 border-white/5"
                )}>
                  {log}
                </div>
              ))}
              <div ref={osTerminalEndRef} />
            </div>

            {/* Python architectural block viewer */}
            <div className="border-t border-white/10 bg-black flex flex-col">
              <div className="bg-[#0c0c0e] px-4 py-2 border-b border-white/5 flex flex-wrap gap-2 items-center justify-between">
                <div className="flex gap-1">
                  {SOVEREIGN_OS_SCRIPTS.map(s => (
                    <button
                      key={s.id}
                      onClick={() => setSelectedOsCodeId(s.id)}
                      className={cn(
                        "px-2.5 py-1 text-[8.5px] font-mono border rounded-sm transition-all",
                        selectedOsCodeId === s.id
                          ? "bg-indigo-950 border-indigo-500 text-white"
                          : "bg-black/45 border-white/5 text-white/40 hover:text-white"
                      )}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCopyText(activeOsScript.code)}
                    className="p-1 px-2.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all rounded-sm text-[8.5px] font-mono flex items-center gap-1 border border-white/10"
                  >
                    {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {isCopied ? "Copied" : "Copy"}
                  </button>
                  <button
                    onClick={handleDownloadCodeFile}
                    className="p-1 px-2.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all rounded-sm text-[8.5px] font-mono flex items-center gap-1 border border-white/10"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              </div>

              <div className="p-4 h-52 overflow-y-auto custom-scrollbar font-mono text-[9px] leading-relaxed text-indigo-200 bg-[#020204]">
                <div className="text-white/30 text-[8px] uppercase tracking-wide border-b border-white/5 pb-1 mb-2">
                  Module Description: {activeOsScript.description}
                </div>
                <pre className="whitespace-pre select-all text-white/75">{activeOsScript.code}</pre>
              </div>
            </div>

          </div>

        </div>
      )}


      {/* 2.2 TAB: PKI Certificate Authority & Detached Signing */}
      {activeTab === "pki" && (
        <div id="pki-trust-content" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-in fade-in duration-200">
          
          {/* PKI Action Controls (col-span-5) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Certification Management Card */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2 border-b border-white/5 pb-2.5">
                <Key className="w-4 h-4 text-indigo-400" />
                SWI Key Authority Setup
              </h3>

              <div className="space-y-3">
                
                {/* 1. ROOT CA MODULE */}
                <div className="p-3 bg-black/50 border border-white/5 relative overflow-hidden flex flex-col justify-between gap-2 rounded-sm text-xs font-mono">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white/80">Step 1: SWI Root CA Credentials</span>
                    <span className={cn(
                      "px-1.5 py-0.5 rounded text-[7px] font-bold tracking-wider",
                      rootCACert ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-zinc-500/20 text-zinc-400 border border-zinc-500/30"
                    )}>
                      {rootCACert ? "ONLINE" : "OFFLINE"}
                    </span>
                  </div>
                  {rootCACert ? (
                    <div className="text-[9px] text-indigo-300 space-y-0.5 bg-black p-2 border border-white/5 max-h-24 overflow-y-auto rounded-sm mt-1">
                      <div className="truncate"><span className="text-white/40">Subject:</span> {rootCACert.subject}</div>
                      <div><span className="text-white/40">Key size:</span> {rootCACert.keySize} bit RSA</div>
                      <div><span className="text-white/40">Serial:</span> {rootCACert.serial}</div>
                      <div><span className="text-white/40">Validity:</span> {rootCACert.validity}</div>
                    </div>
                  ) : (
                    <button
                      onClick={createRootCA}
                      disabled={isSignState !== "IDLE"}
                      className="w-full mt-1 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/40 uppercase font-mono text-[9px] py-2 transition-all font-bold tracking-wider rounded-sm flex justify-center items-center gap-1.5"
                    >
                      {isSignState === "GENERATING" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                      Generate Offline Root CA
                    </button>
                  )}
                </div>

                {/* 2. INTERMEDIATE CA MODULE */}
                <div className="p-3 bg-black/50 border border-white/5 relative overflow-hidden flex flex-col justify-between gap-2 rounded-sm text-xs font-mono">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white/80">Step 2: Operational Intermediate CA</span>
                    <span className={cn(
                      "px-1.5 py-0.5 rounded text-[7px] font-bold tracking-wider",
                      interCACert ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" : "bg-zinc-500/20 text-zinc-400 border border-zinc-500/30"
                    )}>
                      {interCACert ? "ONLINE" : "OFFLINE"}
                    </span>
                  </div>
                  {interCACert ? (
                    <div className="text-[9px] text-indigo-300 space-y-0.5 bg-black p-2 border border-white/5 max-h-24 overflow-y-auto rounded-sm mt-1">
                      <div className="truncate"><span className="text-white/40 font-mono">Subject:</span> {interCACert.subject}</div>
                      <div className="truncate"><span className="text-white/40 font-mono">Issuer:</span> {interCACert.issuer}</div>
                      <div><span className="text-white/40 font-mono">Serial:</span> {interCACert.serial}</div>
                    </div>
                  ) : (
                    <button
                      onClick={createIntermediateCA}
                      disabled={isSignState !== "IDLE" || !rootCACert}
                      className={cn(
                        "w-full mt-1 uppercase font-mono text-[9px] py-2 transition-all font-bold tracking-wider rounded-sm flex justify-center items-center gap-1.5 border",
                        !rootCACert 
                          ? "opacity-35 cursor-not-allowed bg-zinc-800 text-zinc-500 border-zinc-700" 
                          : "bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border-indigo-500/40"
                      )}
                    >
                      {isSignState === "GENERATING" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Key className="w-3.5 h-3.5" />}
                      Delegate Intermediate CA
                    </button>
                  )}
                </div>

                {/* 3. CODE SIGNER DESIRED FILE */}
                <div className="p-3 bg-black/50 border border-white/10 space-y-3 rounded-sm text-xs font-mono">
                  <span className="font-bold text-indigo-400 uppercase tracking-widest text-[10px] block">Step 3: Signature Assembly Generator</span>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={customSignFile}
                        onChange={(e) => setCustomSignFile(e.target.value)}
                        placeholder="Filename to sign (e.g. buildfile.exe)"
                        disabled={!interCACert}
                        className="flex-1 bg-black border border-white/10 px-3 py-1.5 text-[10px] text-[#e4e3e0] rounded-sm focus:outline-none focus:border-indigo-500 disabled:opacity-40"
                      />
                      <button
                        onClick={signNewFile}
                        disabled={isSignState !== "IDLE" || !interCACert || !customSignFile.trim()}
                        className={cn(
                          "px-4 font-mono font-bold uppercase text-[9px] py-1.5 rounded-sm transition-all border",
                          !interCACert 
                            ? "opacity-35 cursor-not-allowed bg-zinc-800 text-zinc-500 border-zinc-700" 
                            : "bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:border-emerald-500"
                        )}
                      >
                        Sign
                      </button>
                    </div>
                    <p className="text-[8.5px] text-white/40 leading-normal">
                      Requires Intermediate Key. Encrypts SHA-256 binary hash sum generating detached <span className="text-indigo-400 font-mono">.sig</span> format signatures.
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* Signed files registry directory (Ledger) */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-1.5 border-b border-white/5 pb-2.5">
                <FileSignature className="w-4 h-4 text-indigo-400" /> Signed Assemblies Ledger
              </h3>
              
              <div className="space-y-2.5 max-h-48 overflow-y-auto custom-scrollbar">
                {signedArtifacts.map(sa => (
                  <div key={sa.id} className="p-3 bg-black border border-white/5 hover:border-white/15 rounded-sm flex flex-col justify-between gap-1.5 relative overflow-hidden">
                    <div className="flex justify-between items-start">
                      <div className="space-y-0.5">
                        <span className="text-[10.5px] font-mono font-bold text-white/90">{sa.fileName}</span>
                        <div className="text-[8px] text-white/40 truncate max-w-xs">{sa.fileHash}</div>
                      </div>
                      <span className={cn(
                        "px-1.5 py-0.5 rounded text-[7px] font-mono font-bold tracking-wider border",
                        sa.revoked 
                          ? "bg-red-500/20 text-red-400 border-red-500/30" 
                          : "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                      )}>
                        {sa.revoked ? "REVOKED" : "SIGNED"}
                      </span>
                    </div>

                    <div className="text-[8px] font-mono text-indigo-300 truncate opacity-80 bg-black/45 p-1 rounded-sm border border-white/5">
                      Sig: {sa.signature}
                    </div>

                    <div className="flex gap-2.5 mt-1 border-t border-white/5 pt-2">
                      <button
                        onClick={() => verifyChainAndBoot(sa)}
                        className="text-[9px] uppercase font-mono font-bold text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" /> Boot Test
                      </button>
                      
                      {!sa.revoked && (
                        <button
                          onClick={() => revokeArtifact(sa.id, sa.fileName)}
                          className="text-[9px] uppercase font-mono font-bold text-red-400 hover:text-red-300 transition-colors flex items-center gap-1 ml-auto"
                        >
                          <Trash className="w-3.5 h-3.5" /> Revoke
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* PKI Audit Logs & Script Codes Viewer (7 cols) */}
          <div className="lg:col-span-7 bg-[#020202] border border-white/10 flex flex-col justify-between rounded-sm min-h-[550px] overflow-hidden">
            
            {/* Terminal monitor header */}
            <div className="bg-white/5 px-4 py-3 border-b border-white/10 flex items-center justify-between">
              <span className="text-[10px] font-bold font-mono text-white/70 uppercase tracking-widest flex items-center gap-2">
                <Terminal className="text-indigo-400 w-4 h-4" />
                PKI Audit Trail Logger & Boot Output
              </span>
              <button
                onClick={() => setPkiLogs(["[PKI] Log tracker context wiped."])}
                className="text-[8px] uppercase tracking-wider font-bold text-white/30 hover:text-white transition-colors"
              >
                Clear
              </button>
            </div>

            {/* Logs view pane */}
            <div className="p-4 flex-1 font-mono text-[9.5px] leading-relaxed max-h-[300px] overflow-y-auto custom-scrollbar bg-black space-y-1.5">
              {pkiLogs.map((log, i) => (
                <div key={i} className={cn(
                  "break-all border-l pr-2 pl-2.5",
                  log.includes("[SUCCESS]") || log.includes("[OK]") ? "text-emerald-400 border-emerald-500/40" :
                  log.includes("[ERROR]") || log.includes("[CRITICAL]") ? "text-red-400 border-red-500 font-bold" :
                  log.includes("[REVOCATION]") || log.includes("[REVOKED]") || log.includes("[CRL]") ? "text-purple-400 border-purple-500/40" :
                  log.includes("Generating") ? "text-indigo-400 border-indigo-500/40" :
                  "text-white/60 border-white/5"
                )}>
                  {log}
                </div>
              ))}
              {isSignState !== "IDLE" && (
                <div className="flex items-center gap-2 text-indigo-400/50 animate-pulse text-[9px] font-mono border-l border-indigo-400/30 pl-2.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Performing intensive RSA crypto-calculation matrices...
                </div>
              )}
              <div ref={pkiTerminalEndRef} />
            </div>

            {/* Real-time boot checker simulation container */}
            {bootTestResult.status !== "NONE" && (
              <div className="bg-black border-y border-white/10 p-4 font-mono text-xs">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[9px] uppercase tracking-wider text-white/40">Boot Evaluation Response:</span>
                  <button
                    onClick={() => setBootTestResult({ status: "NONE", details: "" })}
                    className="text-[8px] text-white/30 hover:text-white"
                  >
                    Clear Result
                  </button>
                </div>
                <div className={cn(
                  "p-3 border flex items-start gap-2.5 rounded-sm leading-relaxed text-[10px]",
                  bootTestResult.status === "PASS" ? "bg-emerald-500/5 border-emerald-500/30 text-emerald-300" :
                  bootTestResult.status === "WARN" ? "bg-amber-500/5 border-amber-500/30 text-amber-300" :
                  "bg-red-500/5 border-red-500/30 text-red-300"
                )}>
                  {bootTestResult.status === "PASS" && <ShieldCheck className="w-5 h-5 shrink-0 text-emerald-400" />}
                  {bootTestResult.status === "WARN" && <AlertTriangle className="w-5 h-5 shrink-0 text-amber-400 animate-pulse" />}
                  {bootTestResult.status === "FAIL" && <AlertOctagon className="w-5 h-5 shrink-0 text-red-500 animate-pulse" />}
                  <div>
                    <span className="font-bold uppercase tracking-wider block font-serif text-[11px] mb-1">
                      {bootTestResult.status === "PASS" ? "BOOT COMPLETED SUCCESSFUL" :
                       bootTestResult.status === "WARN" ? "BOOT COMPLETED DEGRADED" : "BOOT PREVENTED (HALT)"}
                    </span>
                    {bootTestResult.details}
                  </div>
                </div>
              </div>
            )}

            {/* Python PKI script file selector under the terminal view */}
            <div className="border-t border-white/10 bg-black flex flex-col">
              <div className="bg-[#0c0c0e] px-4 py-2 border-b border-white/5 flex flex-wrap gap-2 items-center justify-between">
                <div className="flex gap-1.5 overflow-x-auto">
                  {PKISCRIPT_COLLECTION.map(s => (
                    <button
                      key={s.id}
                      onClick={() => setSelectedPkiCodeId(s.id)}
                      className={cn(
                        "px-2.5 py-1 text-[8.5px] font-mono border rounded-sm transition-all whitespace-nowrap",
                        selectedPkiCodeId === s.id
                          ? "bg-indigo-950 border-indigo-500 text-white"
                          : "bg-black/45 border-white/5 text-white/40 hover:text-white"
                      )}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2 ml-auto">
                  <button
                    onClick={() => handleCopyText(activePkiScript.code)}
                    className="p-1 px-2.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all rounded-sm text-[8.5px] font-mono flex items-center gap-1 border border-white/10"
                  >
                    {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {isCopied ? "Copied" : "Copy"}
                  </button>
                  <button
                    onClick={handleDownloadCodeFile}
                    className="p-1 px-2.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all rounded-sm text-[8.5px] font-mono flex items-center gap-1 border border-white/10"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              </div>

              <div className="p-4 h-52 overflow-y-auto custom-scrollbar font-mono text-[9px] leading-relaxed text-indigo-200 bg-[#020204]">
                <div className="text-white/30 text-[8px] uppercase tracking-wide border-b border-white/5 pb-1 mb-2">
                  Module Description: {activePkiScript.description}
                </div>
                <pre className="whitespace-pre select-all text-white/75">{activePkiScript.code}</pre>
              </div>
            </div>

          </div>

        </div>
      )}


      {/* 2.3 TAB: SELF-HEALING AUTONOMIC DAEMONS */}
      {activeTab === "daemons" && (
        <div id="autonomic-daemons-content" className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-in fade-in duration-200">
          
          {/* VERSION SELECT PANEL (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Version choice selectors */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2 border-b border-white/5 pb-2.5">
                <Layers className="w-4 h-4 text-indigo-400" />
                Runtime Daemon Version Select
              </h3>

              <div className="space-y-3">
                {DEAMON_SCRIPTS.map(ds => (
                  <button
                    key={ds.id}
                    onClick={() => {
                      setSelectedDaemonId(ds.id);
                      setDaemonSimulatorLogs([`Switched simulation kernel configuration context to: ${ds.name}. Standby.`]);
                      setDaemonSimState("IDLE");
                    }}
                    className={cn(
                      "w-full p-4 border text-left transition-all relative overflow-hidden flex justify-between items-start rounded-sm",
                      selectedDaemonId === ds.id
                        ? "border-indigo-500 bg-indigo-500/5 text-white"
                        : "border-white/5 bg-[#020204] text-white/55 hover:border-white/15"
                    )}
                  >
                    <div className="space-y-1.5 pr-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[11px] font-bold uppercase tracking-wide font-mono text-white/95">{ds.name}</span>
                        <span className={cn(
                          "px-1.5 py-0.5 rounded text-[7px] font-mono font-bold tracking-wider",
                          ds.status === "ACTIVE_GOVERNED" ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" :
                          ds.status === "HARDENED" ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30" :
                          ds.status === "PIPELINE_ORCHESTRATOR" ? "bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/30" :
                          "bg-zinc-500/20 text-zinc-400 border border-zinc-500/30"
                        )}>
                          {ds.status}
                        </span>
                      </div>
                      <p className="text-[10px] leading-relaxed text-white/50 font-sans mt-0.5">{ds.tagline}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated error injector console */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm space-y-4">
              <div className="border-b border-white/5 pb-2">
                <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-1.5">
                  <Play className="w-4 h-4 text-indigo-400 animate-pulse" /> Daemon Simulation Loop
                </h3>
                <p className="text-[10px] text-white/40 mt-0.5">
                  Simulate local workspace deviations and validation failures to monitor currently selected daemon responses.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={() => simulateDaemonTask("normal")}
                  disabled={daemonSimState === "MONITORING"}
                  className="p-3 bg-black border border-white/10 hover:border-indigo-500 font-bold font-mono text-[9px] text-left text-[#E4E3E0] hover:bg-indigo-950/10 flex flex-col justify-between rounded-sm transition-all"
                >
                  <span className="text-emerald-400 uppercase tracking-widest">Diagnostic Verify</span>
                  <span className="opacity-40 font-sans text-[8px] mt-1 leading-normal">Evaluates healthy loop states</span>
                </button>

                <button
                  onClick={() => simulateDaemonTask("deleted_modules")}
                  disabled={daemonSimState === "MONITORING"}
                  className="p-3 bg-black border border-white/10 hover:border-indigo-500 font-bold font-mono text-[9px] text-left text-[#E4E3E0] hover:bg-indigo-950/10 flex flex-col justify-between rounded-sm transition-all"
                >
                  <span className="text-amber-400 uppercase tracking-widest">Nuke Modules</span>
                  <span className="opacity-40 font-sans text-[8px] mt-1 leading-normal">Deletes vital local files</span>
                </button>

                <button
                  onClick={() => simulateDaemonTask("malware")}
                  disabled={daemonSimState === "MONITORING"}
                  className="p-3 bg-black border border-white/10 hover:border-indigo-500 font-bold font-mono text-[9px] text-left text-[#E4E3E0] hover:bg-indigo-950/10 flex flex-col justify-between rounded-sm transition-all"
                >
                  <span className="text-red-400 uppercase tracking-widest">Malicious Package</span>
                  <span className="opacity-40 font-sans text-[8px] mt-1 leading-normal">Update backdoor library</span>
                </button>

                <button
                  onClick={() => simulateDaemonTask("script_failure")}
                  disabled={daemonSimState === "MONITORING" || selectedDaemonId === "v1" || selectedDaemonId === "v2"}
                  className={cn(
                    "p-3 bg-black border text-left flex flex-col justify-between font-mono text-[9px] font-bold transition-all rounded-sm",
                    (selectedDaemonId === "v1" || selectedDaemonId === "v2") 
                      ? "opacity-30 cursor-not-allowed border-white/5" 
                      : "hover:border-indigo-500 text-[#E4E3E0] hover:bg-indigo-950/10 border-white/10"
                  )}
                >
                  <span className="text-pink-400 uppercase tracking-widest">Syntax Build Break</span>
                  <span className="opacity-40 font-sans text-[8px] mt-1 leading-normal">Introduce compiler breaks</span>
                </button>

                <button
                  onClick={() => simulateDaemonTask("test_failure")}
                  disabled={daemonSimState === "MONITORING" || selectedDaemonId !== "v4"}
                  className={cn(
                    "p-3 bg-black border text-left flex flex-col justify-between font-mono text-[9px] font-bold col-span-1 sm:col-span-2 transition-all rounded-sm",
                    selectedDaemonId !== "v4" 
                      ? "opacity-30 cursor-not-allowed border-white/5 bg-zinc-900" 
                      : "hover:border-indigo-500 text-[#E4E3E0] hover:bg-indigo-950/10 border-white/10"
                  )}
                >
                  <span className="text-[#a855f7] uppercase tracking-widest text-center block w-full">Assert Failing Wellbeing Checks</span>
                  <span className="opacity-40 font-sans text-[8px] mt-1 leading-normal block">
                    Fails safety matrix unit test execution. Triggers quarantined isolation.
                  </span>
                </button>
              </div>
            </div>

            {/* Quarantined registry listing */}
            <div className="bg-[#0a0a0c] border border-white/10 p-5 rounded-sm grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <span className="text-[9.5px] uppercase font-bold text-red-100/90 tracking-wide flex items-center gap-1.5 font-mono">
                  <FolderLock className="w-3.5 h-3.5 text-red-400" /> /.swi_quarantine/
                </span>
                <div className="bg-black/60 border border-white/5 p-2.5 h-20 overflow-y-auto rounded-sm text-[8.5px] font-mono space-y-1 text-white/40">
                  {quarantinedFiles.length === 0 ? (
                    <span className="italic text-[8px] opacity-60">No quarantined objects yet.</span>
                  ) : (
                    quarantinedFiles.map((q, i) => (
                      <div key={i} className="text-red-300 select-all truncate">{q}</div>
                    ))
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <span className="text-[9.5px] uppercase font-bold text-indigo-100/90 tracking-wide flex items-center gap-1.5 font-mono">
                  <Database className="w-3.5 h-3.5 text-indigo-400" /> /.swi_backups/
                </span>
                <div className="bg-black/60 border border-white/5 p-2.5 h-20 overflow-y-auto rounded-sm text-[8.5px] font-mono space-y-1 text-white/40">
                  {backupsCreated.length === 0 ? (
                    <span className="italic text-[8px] opacity-60">No system snapshot backups.</span>
                  ) : (
                    backupsCreated.map((b, i) => (
                      <div key={i} className="text-indigo-300 select-all truncate">{b}</div>
                    ))
                  )}
                </div>
              </div>
            </div>

          </div>

          {/* SIMULATOR LOG DETAILS PANEL (7 cols) */}
          <div className="lg:col-span-7 bg-[#020202] border border-white/10 flex flex-col justify-between rounded-sm min-h-[550px] overflow-hidden">
            
            {/* Log monitor header */}
            <div className="bg-white/5 px-4 py-3 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-indigo-400 animate-pulse" />
                <span className="text-[10px] font-bold font-mono text-white/70 uppercase tracking-widest flex items-center gap-2">
                  Daemon Execution Logging Instance
                </span>
              </div>
              <span className={cn(
                "px-2 py-0.5 rounded text-[8px] font-mono tracking-wider border font-bold uppercase",
                daemonSimState === "REPAIRING" ? "text-yellow-400 border-yellow-400/30" :
                daemonSimState === "QUARANTINING" ? "text-purple-400 border-purple-400/30" :
                daemonSimState === "CRITICAL" ? "text-red-500 border-red-500/30 animate-pulse" :
                "text-emerald-400 border-emerald-400/30 font-semibold"
              )}>
                STATUS: {daemonSimState === "IDLE" ? "STANDBY" : daemonSimState}
              </span>
            </div>

            {/* Run logs */}
            <div className="p-4 flex-1 font-mono text-[9.5px] leading-relaxed max-h-[300px] overflow-y-auto custom-scrollbar bg-black space-y-1.5">
              {daemonSimulatorLogs.map((log, i) => (
                <div key={i} className={cn(
                  "break-all border-l pr-2 pl-2.5",
                  log.includes("[SUCCESS]") || log.includes("[OK]") ? "text-emerald-400 border-emerald-500/40" :
                  log.includes("[CRITICAL]") || log.includes("[CRITICAL_FAIL]") || log.includes("[FATAL]") ? "text-red-400 border-red-500 font-bold" :
                  log.includes("[ALERT]") || log.includes("[WARNING]") ? "text-amber-400 border-amber-500/40" :
                  log.includes("[GOVERNANCE]") ? "text-indigo-400 border-indigo-500/40" :
                  log.includes("[RESTORE]") || log.includes("[REPAIR]") ? "text-cyan-400 border-cyan-500/40 font-semibold" :
                  "text-white/60 border-white/5"
                )}>
                  {log}
                </div>
              ))}
              <div ref={logTerminalEndRef} />
            </div>

            {/* Source code viewer of daemon python script */}
            <div className="border-t border-white/10 bg-black flex flex-col">
              <div className="bg-[#0c0c0e] px-4 py-2 border-b border-white/5 flex items-center justify-between">
                <span className="text-[9.5px] font-mono text-white/50 uppercase tracking-widest flex items-center gap-2">
                  <Code className="w-3.5 h-3.5 text-indigo-400" />
                  Script View: {activeDaemon.name}
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCopyText(activeDaemon.code)}
                    className="p-1 px-2.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all rounded-sm text-[8.5px] font-mono flex items-center gap-1 border border-white/10"
                  >
                    {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    {isCopied ? "Copied" : "Copy"}
                  </button>
                  <button
                    onClick={handleDownloadCodeFile}
                    className="p-1 px-2.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all rounded-sm text-[8.5px] font-mono flex items-center gap-1 border border-white/10"
                  >
                    <Download className="w-3 h-3" />
                    Download
                  </button>
                </div>
              </div>

              <div className="p-4 h-52 overflow-y-auto custom-scrollbar font-mono text-[9px] leading-relaxed text-indigo-200 bg-[#020204]">
                <div className="text-white/30 text-[8px] uppercase tracking-wide border-b border-white/5 pb-1 mb-2">
                  Script Details: {activeDaemon.description}
                </div>
                <pre className="whitespace-pre select-all text-white/75">{activeDaemon.code}</pre>
              </div>
            </div>

          </div>

        </div>
      )}


      {/* 2.4 TAB: INNO SETUP SCRIPT & COMPILER ASSEMBLY */}
      {activeTab === "installer" && (
        <div id="installer-compiler-content" className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start animate-in fade-in duration-200">
          
          {/* Compilation controls + platform configurations */}
          <div className="bg-[#0a0a0c] border border-white/10 p-5 md:p-6 rounded-sm space-y-6">
            <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2 border-b border-white/10 pb-3">
              <PackageCheck className="w-4 h-4 text-indigo-400" /> Inno Setup Parameters Configuration
            </h3>

            <div className="grid grid-cols-2 gap-3.5 text-[10px] font-mono">
              <div className="bg-black/65 border border-white/5 p-3 rounded-sm space-y-1">
                <span className="text-white/40 uppercase text-[8px] tracking-wider block">Target Assembly platform</span>
                <span className="flex items-center gap-1.5 text-indigo-300 font-bold">
                  <HardDrive className="w-3.5 h-3.5" /> Windows x64 (Solid Compress)
                </span>
              </div>
              <div className="bg-black/65 border border-white/5 p-3 rounded-sm space-y-1">
                <span className="text-white/40 uppercase text-[8px] tracking-wider block">Compiled setup filename</span>
                <span className="flex items-center gap-1.5 text-indigo-300 font-bold">
                  <Binary className="w-3.5 h-3.5" /> install.exe
                </span>
              </div>
              <div className="bg-black/65 border border-white/5 p-3 rounded-sm space-y-1 col-span-2">
                <span className="text-white/40 uppercase text-[8px] tracking-wider block">SWI Boot Validation Hook Methods</span>
                <span className="text-emerald-400 flex items-center gap-1.5 font-bold">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  Checks System + Validates SWI Policy + Verifies SHA-256 Sig Array
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-3">
              {installerState === "IDLE" ? (
                <button
                  onClick={compileInnoSetup}
                  className="w-full bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-400 border border-indigo-500/40 uppercase font-mono tracking-widest text-[9.5px] py-3 transition-colors flex justify-center items-center gap-2 rounded-sm font-bold"
                >
                  <Cpu className="w-4 h-4" /> Begin Inno Setup Compilation
                </button>
              ) : (
                <div className="flex flex-col gap-2">
                  <button
                    onClick={downloadSetupExe}
                    disabled={installerState !== "READY"}
                    className={cn(
                      "w-full uppercase font-mono tracking-widest text-[10px] py-3.5 transition-all flex justify-center items-center gap-2 border rounded-sm font-black",
                      installerState === "READY" 
                        ? "bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.15)]" 
                        : "bg-gray-800/40 text-gray-500 border-gray-700 cursor-not-allowed"
                    )}
                  >
                    {installerState === "DOWNLOADING" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                    {installerState === "DOWNLOADING" ? "Downloading setup.exe..." : "Download Compiled install.exe"}
                  </button>
                </div>
              )}
              
              <button
                onClick={handleDownloadIss}
                className="w-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white border border-white/5 text-center uppercase tracking-wider font-mono text-[9px] py-1.5 transition-all rounded-sm flex justify-center items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5 text-indigo-400" />
                Download Inno Setup Script install.iss
              </button>
            </div>
          </div>

          {/* Detailed compile task terminal */}
          <div className="bg-[#020202] border border-white/10 flex flex-col h-full min-h-[350px] rounded-sm overflow-hidden justify-between">
            
            <div className="bg-white/5 px-4 py-3 border-b border-white/10 flex items-center justify-between">
              <span className="text-[10px] font-mono text-white/50 uppercase tracking-widest flex items-center gap-1.5">
                <Terminal className="text-indigo-400 w-3.5 h-3.5" /> Compiler Execution Console Output
              </span>
              {compilerProgress > 0 && (
                <div className="text-[10px] font-mono text-indigo-400 font-bold">{compilerProgress}%</div>
              )}
            </div>

            {/* Log view listings */}
            <div className="p-4 flex-1 overflow-y-auto space-y-1.5 font-mono text-[9px] leading-relaxed max-h-[250px] bg-black">
              {installerLogs.length === 0 && (
                <div className="text-white/20 italic">Awaiting compiler pipeline triggers...</div>
              )}
              {installerLogs.map((log, i) => (
                <div key={i} className={cn(
                  "break-all border-l pl-2 border-white/5",
                  log.includes("[SUCCESS]") || log.includes("[OK]") ? "text-emerald-400 border-emerald-500/35" :
                  log.includes("[ERROR]") ? "text-red-400 border-red-500/35" :
                  log.includes("swi-core") ? "text-indigo-400" :
                  "text-white/60"
                )}>
                  {log}
                </div>
              ))}
              {(installerState === "COMPILING" || installerState === "PACKAGING") && (
                <div className="flex items-center gap-2 text-indigo-400/50 animate-pulse text-[9px]">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" /> Solid compress block segments...
                </div>
              )}
              <div ref={installerTerminalEndRef} />
            </div>

            {/* Progress load bars */}
            <div className="h-1.5 w-full bg-white/5 border-t border-white/10">
              <div 
                className="h-full bg-indigo-500 transition-all duration-300"
                style={{ width: `${compilerProgress}%` }}
              />
            </div>

          </div>

          {/* Bottom Complete Pascal Inno Code viewer */}
          <div className="col-span-1 lg:col-span-2 bg-[#020202] border border-white/10 rounded-sm">
            <div className="bg-white/5 px-4 py-2 border-b border-white/10 flex justify-between items-center text-xs font-mono">
              <span className="text-white/55 uppercase tracking-wider text-[10px]">Reference File: install.iss (Pascal Architecture Rules)</span>
              <button
                onClick={() => handleCopyText(INNO_SETUP_SCRIPT)}
                className="px-2 py-1 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all text-[8.5px] rounded-sm border border-white/5 flex items-center gap-1"
              >
                {isCopied ? <Check className="w-3" /> : <Copy className="w-3" />} Copy File
              </button>
            </div>
            <div className="p-4 h-64 overflow-y-auto custom-scrollbar text-[#dad9d7] font-mono text-[9px] leading-relaxed bg-black/95">
              <pre className="whitespace-pre select-all text-white/70">{INNO_SETUP_SCRIPT}</pre>
            </div>
          </div>

        </div>
      )}

      {/* FOOTER RULES ENFORCEMENT DETAILS */}
      <div className="bg-[#0b080f] border border-indigo-500/20 p-5 rounded-sm space-y-4">
        <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-400 flex items-center gap-2 border-b border-white/5 pb-2 font-mono">
          <ShieldAlert className="w-4 h-4 text-indigo-500" /> SWI Zero-Trust State Enforcement rules matrix
        </h4>
        <div className="text-xs text-white/75 leading-relaxed font-sans space-y-2">
          <p>
            Autonomic recovery controllers and code verification pipelines operate under rigid, verifiable boundaries. 
            Self-healing daemons possess full capabilities to restore filesystem drift and rebuild broken modules. However, 
            they are strictly prevented from bypassing unit validation suites. If a core unit checking suite fails or gets bypassed, 
            the secure execution plane enforces an immediate quarantine lock, requiring authorized expert mediation to confirm structural alignment.
          </p>
        </div>
      </div>

    </div>
  );
}
