import React, { useState, useEffect } from "react";
import {
  HardDrive,
  Server,
  ShieldCheck,
  Key,
  Lock,
  Users,
  Clock,
  Usb,
  Cpu,
  FileCheck2,
  AlertCircle,
  ScanLine,
  Shield,
  Terminal,
  Database,
  FileText,
  CheckCircle2,
  Download,
  FileArchive,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface StateSignature {
  state: string;
  hash: string;
  timestamp: string;
}

export default function SecureExecutionPlatformView() {
  const [verificationScore, setVerificationScore] = useState(0);
  const [timer, setTimer] = useState(180);
  const [gateStatus, setGateStatus] = useState<
    "BOOT" | "VERIFYING" | "WAITING_HUMAN" | "APPROVED" | "BLOCKED"
  >("BOOT");
  const [quorum, setQuorum] = useState<string[]>([]);
  const requiredQuorum = 2; // 2-of-3 required
  const [lineage, setLineage] = useState<StateSignature[]>([]);

  const addSignature = (state: string) => {
    setLineage(prev => [...prev, {
      state,
      hash: "sig_" + Math.random().toString(36).substring(2, 10).toUpperCase(),
      timestamp: new Date().toISOString().split("T")[1].substring(0, 8)
    }]);
  };

  useEffect(() => {
    if (gateStatus === "BOOT") {
      addSignature("INIT");
      const timeout = setTimeout(() => {
        setGateStatus("VERIFYING");
        addSignature("VERIFY");
      }, 1500);
      return () => clearTimeout(timeout);
    }
    if (gateStatus === "VERIFYING") {
      const interval = setInterval(() => {
        setVerificationScore((prev) => {
          const next = prev + Math.random() * 5;
          if (next >= 99.9) {
            clearInterval(interval);
            setGateStatus("WAITING_HUMAN");
            addSignature("WAITING_HUMAN");
            return 99.9;
          }
          return next;
        });
      }, 100);
      return () => clearInterval(interval);
    }
  }, [gateStatus]);

  useEffect(() => {
    if (gateStatus === "WAITING_HUMAN" && timer > 0) {
      const interval = setInterval(() => setTimer((t) => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [gateStatus, timer]);

  const handleApprove = (voterId: string) => {
    if (gateStatus !== "WAITING_HUMAN") return;
    if (quorum.includes(voterId)) return;
    
    const newQuorum = [...quorum, voterId];
    setQuorum(newQuorum);
    
    if (newQuorum.length >= requiredQuorum) {
      setGateStatus("APPROVED");
      addSignature("APPROVED");
      setTimeout(() => addSignature("EXECUTING_SIM"), 500);
    }
  };

  const handleReject = () => {
    if (gateStatus !== "WAITING_HUMAN") return;
    setGateStatus("BLOCKED");
    addSignature("REJECTED");
  };

  const layers = [
    {
      title: "L1: Immutable Boot",
      icon: HardDrive,
      desc: "UEFI Secure Boot, signed kernel, dm-verity, TPM PCR. Read-only squashfs.",
    },
    {
      title: "L2: Identity & Presence",
      icon: Key,
      desc: "TPM 2.0 / FIDO2 presence. SPIFFE/SPIRE identity certificates.",
    },
    {
      title: "L3: Policy Runtime",
      icon: FileCheck2,
      desc: "OPA/Rego signed policies. No execution unverified. Simulation required.",
    },
    {
      title: "L4: Verification Engine",
      icon: ShieldCheck,
      desc: "Cert validity (20), Runtime integrity (20), Policy compliance (20), Audit (15), Consensus (15), Human (10).",
    },
    {
      title: "L5: Append-Only Audit",
      icon: Database,
      desc: "Immudb hash-chained Merkle continuum. RFC3161 timestamps.",
    },
    {
      title: "L6: Human Gate",
      icon: Users,
      desc: "Irreversible execution requires manual quorum. 3-minute review window.",
    },
    {
      title: "L7: Simulation-Only",
      icon: Terminal,
      desc: "No real-world infrastructure control. Reproducible deterministic replay.",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              SWI Secure Execution Platform (SSEP)
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            A research-oriented secure verification and simulation runtime with hardware-backed attestation, signed policy enforcement, append-only auditability, and human-gated execution review.
          </p>
        </div>
      </div>

      {/* Trust Chain & Verification */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4 lg:col-span-1 flex flex-col">
          <div className="flex items-center gap-2 text-emerald-400 mb-2">
            <Lock className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              SSEP Trust Chain
            </h3>
          </div>
          <div className="border-l-2 border-emerald-500/30 pl-4 space-y-3 font-mono text-[10px] text-white/80 py-2 relative flex-1">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 absolute -left-[5px]"></div>{" "}
              SWI Root CA
            </div>
            <div className="flex items-center gap-2 text-white/60">
              <div className="w-2 h-2 rounded-full bg-emerald-500/50 absolute -left-[5px]"></div>{" "}
              Hardware Identity (TPM/FIDO2)
            </div>
            <div className="flex items-center gap-2 text-white/60">
              <div className="w-2 h-2 rounded-full bg-emerald-500/50 absolute -left-[5px]"></div>{" "}
              Device Certificate
            </div>
            <div className="flex items-center gap-2 text-white/60">
              <div className="w-2 h-2 rounded-full bg-emerald-500/50 absolute -left-[5px]"></div>{" "}
              Runtime Certificate
            </div>
            <div className="flex items-center gap-2 text-white/60">
              <div className="w-2 h-2 rounded-full bg-emerald-500/50 absolute -left-[5px]"></div>{" "}
              Session Attestation Token
            </div>
            <div className="flex items-center gap-2 text-emerald-400 font-bold">
              <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)] absolute -left-[5px]"></div>{" "}
              Human Approval Gate ({quorum.length}/{requiredQuorum})
            </div>
            <div className="flex items-center gap-2 text-white/40">
              <div className="w-2 h-2 rounded-full bg-white/20 absolute -left-[5px]"></div>{" "}
              Controlled Execution
            </div>
          </div>
          <div className="text-[9px] font-mono text-white/40 border-t border-white/10 pt-3 italic">
            "Execution is not trusted because software says so. Execution is
            trusted because verification chains hold."
          </div>
        </div>

        {/* Phase 1 Verification Flow */}
        <div className="bg-[#141414] border border-white/10 p-5 space-y-4 lg:col-span-2 flex flex-col">
          <div className="flex items-center gap-2 text-blue-400 mb-2">
            <ScanLine className="w-4 h-4" />
            <h3 className="text-xs font-bold uppercase tracking-widest">
              Live Verification & Execution Lineage
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-1">
            <div>
              <div className="text-[10px] font-mono text-white/50 mb-2">
                Verification Score:{" "}
                <span className="text-blue-400">
                  {verificationScore.toFixed(2)}
                </span>{" "}
                / 100.00
              </div>
              <div className="h-1.5 w-full bg-white/10 overflow-hidden mb-4 rounded-full">
                <div
                  className="h-full bg-blue-500 transition-all duration-75"
                  style={{ width: `${Math.min(100, verificationScore)}%` }}
                ></div>
              </div>

              <div className="space-y-2 text-[9px] font-mono">
                <div className="flex justify-between items-center text-white/50">
                  <span>Certificate validity</span>
                  <span>20/20</span>
                </div>
                <div className="flex justify-between items-center text-white/50">
                  <span>Runtime integrity</span>
                  <span>20/20</span>
                </div>
                <div className="flex justify-between items-center text-white/50">
                  <span>Policy compliance</span>
                  <span>20/20</span>
                </div>
                <div className="flex justify-between items-center text-white/50">
                  <span>Audit continuity</span>
                  <span>15/15</span>
                </div>
                <div className="flex justify-between items-center text-white/50">
                  <span>Consensus verification</span>
                  <span>15/15</span>
                </div>
                <div className="flex justify-between items-center text-white/50">
                  <span>Human authorization</span>
                  <span
                    className={
                      gateStatus === "APPROVED"
                        ? "text-green-400"
                        : "text-amber-500/50"
                    }
                  >
                    {gateStatus === "APPROVED" ? "10/10" : `${(quorum.length / requiredQuorum) * 10}/10`}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col bg-black/40 border border-white/5 p-4 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500/0 via-blue-500/50 to-blue-500/0 opacity-50"></div>
              <h4 className="text-[10px] uppercase font-bold text-white/40 mb-3 tracking-widest text-center">
                Quorum Gate & State Signatures
              </h4>

              <div className="flex-1 flex flex-col justify-between">
                {/* Signatures */}
                <div className="space-y-1 mb-4 h-24 overflow-y-auto">
                   {lineage.map((sig, i) => (
                      <div key={i} className="text-[9px] font-mono flex items-center justify-between border-b border-white/5 pb-1">
                         <span className="text-emerald-400">{sig.state}.sig</span>
                         <span className="text-white/30">{sig.hash}</span>
                      </div>
                   ))}
                </div>

                {/* Quorum Controls */}
                {gateStatus === "WAITING_HUMAN" && (
                  <div className="text-center bg-red-950/20 border border-red-500/20 p-3 rounded-sm">
                    <div className="text-red-400 font-bold text-[10px] tracking-widest uppercase mb-2 flex items-center justify-center gap-2">
                       <Clock className="w-3 h-3" />
                       WAITING HUMAN QUORUM ({quorum.length}/{requiredQuorum})
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 mt-3">
                      <button
                        onClick={() => handleApprove("operator-01")}
                        disabled={quorum.includes("operator-01")}
                        className="bg-emerald-500/10 hover:bg-emerald-500/30 border border-emerald-500/50 text-emerald-400 text-[9px] uppercase font-bold px-2 py-1.5 transition-all disabled:opacity-30 disabled:hover:bg-emerald-500/10"
                      >
                        Sign (Op 1)
                      </button>
                      <button
                        onClick={() => handleApprove("operator-02")}
                        disabled={quorum.includes("operator-02")}
                        className="bg-emerald-500/10 hover:bg-emerald-500/30 border border-emerald-500/50 text-emerald-400 text-[9px] uppercase font-bold px-2 py-1.5 transition-all disabled:opacity-30 disabled:hover:bg-emerald-500/10"
                      >
                        Sign (Op 2)
                      </button>
                      <button
                        onClick={handleReject}
                        className="bg-red-500/10 hover:bg-red-500/30 border border-red-500/50 text-red-400 text-[9px] uppercase font-bold px-2 py-1.5 transition-all col-span-2"
                      >
                        Halt & Reject
                      </button>
                    </div>
                  </div>
                )}
                
                {gateStatus === "APPROVED" && (
                  <div className="text-emerald-400 font-mono font-bold text-[10px] bg-emerald-500/10 border border-emerald-500/20 p-3 flex flex-col items-center justify-center gap-2">
                    <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> QUORUM REACHED</div>
                    <div className="text-white/50 font-normal">EXECUTING_SIM (Deterministic Replay Enabled)</div>
                  </div>
                )}
                {gateStatus === "BLOCKED" && (
                  <div className="text-red-500 font-mono font-bold text-[10px] bg-red-500/10 border border-red-500/20 p-3 flex flex-col items-center justify-center gap-2">
                    <div className="flex items-center gap-2"><AlertCircle className="w-4 h-4" /> EXECUTION ABORTED</div>
                    <div className="text-white/50 font-normal">Sealed rejection audit trail preserved.</div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Runtime Layers & Bundle Export */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {layers.slice(0, 3).map((layer, idx) => (
          <div
            key={idx}
            className="bg-[#141414] border border-white/5 p-4 hover:border-white/10 transition-colors"
          >
            <div className="flex items-center gap-2 text-white/70 mb-2">
              <layer.icon className="w-4 h-4" />
              <h3 className="text-[10px] font-bold uppercase tracking-widest">
                {layer.title}
              </h3>
            </div>
            <p className="text-[9px] font-mono text-white/40 leading-relaxed">
              {layer.desc}
            </p>
          </div>
        ))}
        {/* Verification Bundle Export */}
        <div className="bg-[#0A0A0A] border border-blue-500/20 p-4 hover:border-blue-500/40 transition-colors flex flex-col justify-between">
          <div>
              <div className="flex items-center gap-2 text-blue-400 mb-2">
                <FileArchive className="w-4 h-4" />
                <h3 className="text-[10px] font-bold uppercase tracking-widest">
                  Signed Bundle
                </h3>
              </div>
              <div className="text-[8px] font-mono text-white/40 mb-3 space-y-1">
                  <div>runtime.hash</div>
                  <div>attest.jwt</div>
                  <div>policy.sig</div>
                  <div>audit.chain</div>
                  <div>replay.proof</div>
              </div>
          </div>
          <button className="w-full bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[9px] uppercase font-bold py-2 flex items-center justify-center gap-2 transition-all">
             <Download className="w-3 h-3" /> verification_bundle.tar
          </button>
        </div>
      </div>

      {/* Proof Artifacts Footer */}
      <div className="bg-[#141414] p-6 border border-white/10 mt-6 flex flex-col items-center text-center">
        <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#E4E3E0] mb-2">
          Cryptographic Artifact Lineage
        </h3>
        <p className="text-[9px] font-mono text-white/40 max-w-xl mx-auto mb-6">
          Every state transition is signed. Deterministic replay allows exact reconstruction of policy evaluation, runtime verification, and audit generation.
        </p>
        <div className="w-full text-left">
          <ProofArtifacts
            id="ssep-lineage"
            title="SSEP Execution Lineage Proofs"
            data={{
              score: verificationScore.toFixed(2),
              gate: gateStatus,
              quorum: quorum,
              lineage: lineage,
            }}
            variant="always-dark"
          />
        </div>
      </div>
    </div>
  );
}

