import React, { useState, useEffect } from "react";
import {
  Network,
  Server,
  Shield,
  Cpu,
  Activity,
  CheckCircle2,
  Zap,
  Terminal,
  Code2,
  Database,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface Milestone {
  id: string;
  title: string;
  category: string;
  description: string;
  icon: React.ElementType;
  status: "RESEARCH" | "PROTOTYPE" | "ACTIVE" | "PLANNED";
  logs: string[];
  syntaxModel: string;
}

export default function FormalExecutionRuntimeView() {
  const [milestones] = useState<Milestone[]>([
    {
      id: "tla-plus",
      title: "TLA+ Model Checking",
      category: "Formal Distributed-State Proofs",
      description:
        "Machine-checkable protocol definitions. Provably absent of deadlock, livelock, and Byzantine faults. Currently in planning and architectural modeling phase.",
      icon: Code2,
      status: "PLANNED",
      logs: [
        "[TLA+] Architectural model defined.",
        "[TLA+] Model checker integration pending valid TLC specifications.",
        "[TLA+] Awaiting resolution of undefined vars and invariant scope issues."
      ],
      syntaxModel:
        '---- MODULE SWI_Core ----\n\\* Model checking planned but currently incomplete\nVARIABLES state, quorum\nInvariant == (state = "EXECUTE") => (quorum >= 2/3)\n====',
    },
    {
      id: "hotstuff-raft",
      title: "Real HotStuff / Raft Cluster",
      category: "Replicated State Machine",
      description:
        "Actual cluster runtime implementing BFT cryptographic quorum consensus.",
      icon: Server,
      status: "ACTIVE",
      logs: [
        "[RAFT] Node 0x9f.. elected as leader.",
        "[HOTSTUFF] Block #944 proposed.",
        "[BFT] 2f+1 signatures collected. State transition finalized.",
      ],
      syntaxModel:
        "fn handle_proposal(block) {\n  if verify_signatures(block) && check_fsm_transition(block) {\n    broadcast_vote();\n  }\n}",
    },
    {
      id: "event-sourced",
      title: "Deterministic Event Engine",
      category: "CQRS + Append-Only Storage",
      description:
        "Replay-safe distributed scheduler. Event queues, delta cycles, and deterministic FSM progression.",
      icon: Database,
      status: "PROTOTYPE",
      logs: [
        "[EVENT_Q] Tick 4001: Pushing SYS_UPDATE_GOV.",
        "[CQRS] Append operation 0xad3f to immutable log.",
        "[REPLAY] Replaying sequence 0-4001... State match 100%.",
      ],
      syntaxModel:
        "type SWI_Event = \n  | GovernanceTick\n  | ConsensusTick\n  | AuditTick\n\nmatch event {\n  GovernanceTick => advance_fsm(),\n}",
    },
    {
      id: "bytecode-vm",
      title: "Real Bytecode VM",
      category: "Registers, Memory Model",
      description:
        "Fully defined, mathematical VM semantics (SWI-HDL) executing smart contracts inside the governance loop.",
      icon: Terminal,
      status: "PROTOTYPE",
      logs: [
        "[VM] Loading SWI bytecode... 128 ops.",
        "[VM] Executing instruction 0x01 (ASSERT_TRUST)",
        "[VM] Execution halted safely. Cost: 42 gas.",
      ],
      syntaxModel:
        "entity TRUST_TRANSFER {\n  input:\n    trust_score\n  assert:\n    trust_score > 80\n  execute:\n    transfer(A, B, 50)\n}",
    },
    {
      id: "fpga-accel",
      title: "FPGA Hardware Acceleration",
      category: "Accelerated Verification Pipeline",
      description:
        "Mapping the VM pipeline and cryptographic validation directly into FPGA fabric for ultra-low latency.",
      icon: Cpu,
      status: "RESEARCH",
      logs: [
        "[FPGA] Flashing bitstream SWI_BFT_ACCEL_v2.",
        "[FPGA] SNARK pair-check accelerated by 400x.",
        "[HW] Validating consensus payload... 14ns latency.",
      ],
      syntaxModel:
        "`timescale 1ns / 1ps\nmodule snark_verify(input clk, input [255:0] proof, output valid);\n  // Elliptic curve hardware acceleration\nendmodule",
    },
    {
      id: "self-healing",
      title: "Self-Healing Cluster Control",
      category: "Autonomous Recovery Rules",
      description:
        "Autonomous recovery with bounded policy rules. Automatic node isolation and leader rotation under stress.",
      icon: Shield,
      status: "ACTIVE",
      logs: [
        "[HEAL] Partition detected on Node C.",
        "[HEAL] Bounded recovery policy activated. Fencing Node C.",
        "[HEAL] Bootstrapping Node F as replacement. Cluster healthy.",
      ],
      syntaxModel:
        "rule Self_Heal {\n  when node.drift > MAX_TOLERANCE\n  then isolate(node) && spin_up(replica)\n}",
    },
  ]);

  const [activeMilestoneId, setActiveMilestoneId] = useState(milestones[0].id);
  const activeMilestone =
    milestones.find((m) => m.id === activeMilestoneId) || milestones[0];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-[#141414] text-white p-6 border border-white/10">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <Network className="w-5 h-5 text-purple-400" />
            <h2 className="text-sm font-black uppercase tracking-widest text-[#E4E3E0]">
              Formal Execution Runtime
            </h2>
          </div>
          <p className="text-[10px] font-mono opacity-60 max-w-2xl">
            A research-oriented distributed execution and verification platform.
            Utilizing Hardware Description Style (SWI-HDL), FSM semantics,
            determinism, and TLA+ model checking.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 border border-white/10 bg-[#141414] p-2 space-y-2 max-h-[600px] overflow-y-auto">
          <div className="text-[10px] text-white/50 font-bold uppercase tracking-widest p-2">
            Architectural Milestones
          </div>
          {milestones.map((m) => (
            <button
              key={m.id}
              onClick={() => setActiveMilestoneId(m.id)}
              className={cn(
                "w-full text-left p-4 border transition-all relative overflow-hidden group",
                activeMilestoneId === m.id
                  ? "bg-black text-white border-purple-500"
                  : "bg-[#141414] text-white border-white/5 hover:border-white/20",
              )}
            >
              <div className="flex items-center gap-3 mb-2">
                <m.icon
                  className={cn(
                    "w-4 h-4",
                    activeMilestoneId === m.id
                      ? "text-purple-400"
                      : "text-white/40",
                  )}
                />
                <h3 className="text-[11px] font-bold uppercase tracking-widest">
                  {m.title}
                </h3>
              </div>
              <div className="text-[9px] font-mono opacity-60">
                {m.category}
              </div>

              {activeMilestoneId === m.id && (
                <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-purple-500/10 to-transparent pointer-events-none" />
              )}
            </button>
          ))}
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#141414] border border-white/10 p-6 relative">
            <div className="absolute top-0 right-0 p-4">
              <span
                className={cn(
                  "text-[9px] font-bold px-2 py-0.5 rounded-full border uppercase",
                  activeMilestone.status === "ACTIVE"
                    ? "border-green-500 text-green-500"
                    : activeMilestone.status === "PROTOTYPE"
                      ? "border-yellow-500 text-yellow-500"
                      : "border-blue-500 text-blue-500",
                )}
              >
                {activeMilestone.status}
              </span>
            </div>
            <div className="flex items-center gap-3 mb-4 text-purple-400">
              <activeMilestone.icon className="w-6 h-6" />
              <h2 className="text-sm font-black uppercase tracking-widest">
                {activeMilestone.title}
              </h2>
            </div>
            <p className="text-[11px] font-mono text-white/70 mb-6 leading-relaxed">
              {activeMilestone.description}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-black/50 border border-white/5 rounded-sm p-4 font-mono text-[10px] overflow-y-auto min-h-[160px]">
                <div className="flex items-center gap-2 text-white/40 mb-3 border-b border-white/10 pb-2">
                  <Terminal className="w-3 h-3" />
                  <span>RUNTIME_EXECUTION_LOG</span>
                </div>
                {activeMilestone.logs.map((log, idx) => (
                  <div
                    key={idx}
                    className="text-green-400/80 mb-1 leading-relaxed"
                  >
                    {log}
                  </div>
                ))}
              </div>
              <div className="bg-[#0D0D0D] border border-indigo-500/20 rounded-sm p-4 font-mono text-[10px] overflow-y-auto min-h-[160px] relative">
                <div className="flex items-center gap-2 text-indigo-400/60 mb-3 border-b border-indigo-500/20 pb-2">
                  <Code2 className="w-3 h-3" />
                  <span>SWI_HDL_SPECIFICATION</span>
                </div>
                <pre className="text-indigo-300 whitespace-pre-wrap">
                  {activeMilestone.syntaxModel}
                </pre>
              </div>
            </div>
          </div>

          <ProofArtifacts
            id={`formal-proof-${activeMilestone.id}`}
            title={`${activeMilestone.title} Verified Proof`}
            logs={activeMilestone.logs}
            data={{
              component: activeMilestone.title,
              spec: activeMilestone.syntaxModel,
            }}
            variant="always-dark"
          />
        </div>
      </div>
    </div>
  );
}
