import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface Node extends d3.SimulationNodeDatum {
  id: string;
  group: number;
  trustScore: number;
}

interface Link extends d3.SimulationLinkDatum<Node> {
  source: string;
  target: string;
  value: number;
}

interface SecurityMazeGraphProps {
  theme: 'light' | 'dark';
  currentDrift?: number;
}

export default function SecurityMazeGraph({ theme, currentDrift = 0 }: SecurityMazeGraphProps) {
  const d3Container = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!d3Container.current) return;

    // Clear previous
    d3.select(d3Container.current).selectAll("*").remove();

    const width = d3Container.current.clientWidth;
    const height = 300;

    // Generate dynamic nodes based on drift
    const nodes: Node[] = [
      { id: "SWI_KERNEL", group: 1, trustScore: 100 - currentDrift * 10 },
      { id: "S9_MONITOR", group: 2, trustScore: 95 },
      { id: "POLICY_ENFORCER", group: 2, trustScore: 90 - currentDrift * 5 },
      { id: "BEHAVIOR_ANALYZER", group: 2, trustScore: 85 - currentDrift * 15 },
      { id: "EXECUTION_GATE", group: 3, trustScore: 98 },
      { id: "USER_PROXY", group: 4, trustScore: 70 - currentDrift * 20 },
    ];

    const links: Link[] = [
      { source: "USER_PROXY", target: "EXECUTION_GATE", value: 1 },
      { source: "EXECUTION_GATE", target: "POLICY_ENFORCER", value: 5 },
      { source: "POLICY_ENFORCER", target: "SWI_KERNEL", value: 10 },
      { source: "BEHAVIOR_ANALYZER", target: "SWI_KERNEL", value: 8 },
      { source: "S9_MONITOR", target: "SWI_KERNEL", value: 10 },
      { source: "S9_MONITOR", target: "POLICY_ENFORCER", value: 5 },
      { source: "USER_PROXY", target: "BEHAVIOR_ANALYZER", value: 2 },
    ];

    const svg = d3.select(d3Container.current)
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", [0, 0, width, height]);

    const simulation = d3.forceSimulation<Node, Link>(nodes)
      .force("link", d3.forceLink<Node, Link>(links).id(d => d.id).distance(60))
      .force("charge", d3.forceManyBody().strength(-200))
      .force("center", d3.forceCenter(width / 2, height / 2));

    const link = svg.append("g")
      .attr("stroke", theme === 'light' ? "#00000020" : "#ffffff20")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke-width", d => Math.sqrt(d.value));

    const nodeGroup = (svg.append("g")
      .selectAll("g")
      .data(nodes)
      .join("g") as any)
      .call(d3.drag<SVGGElement, Node>()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended));

    nodeGroup.append("circle")
      .attr("r", (d: Node) => 8 + (d.trustScore / 10))
      .attr("fill", (d: Node) => {
        if (d.trustScore < 60) return "#ef4444"; // red
        if (d.trustScore < 85) return "#eab308"; // yellow
        return "#22c55e"; // green
      })
      .attr("stroke", theme === 'light' ? "#fff" : "#141414")
      .attr("stroke-width", 1.5);

    nodeGroup.append("text")
      .text((d: Node) => `${d.id} (${d.trustScore.toFixed(0)})`)
      .attr("x", 12)
      .attr("y", 3)
      .style("font-size", "10px")
      .style("font-family", "monospace")
      .style("text-transform", "uppercase")
      .style("fill", theme === 'light' ? "#666" : "#aaa");

    simulation.on("tick", () => {
      link
        .attr("x1", d => ((d.source as unknown) as Node).x!)
        .attr("y1", d => ((d.source as unknown) as Node).y!)
        .attr("x2", d => ((d.target as unknown) as Node).x!)
        .attr("y2", d => ((d.target as unknown) as Node).y!);

      nodeGroup.attr("transform", (d: Node) => `translate(${d.x},${d.y})`);
    });

    function dragstarted(event: d3.D3DragEvent<SVGGElement, Node, Node>) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: d3.D3DragEvent<SVGGElement, Node, Node>) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: d3.D3DragEvent<SVGGElement, Node, Node>) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    return () => {
      simulation.stop();
    };
  }, [theme, currentDrift]);

  return <div ref={d3Container} className="w-full" />;
}
