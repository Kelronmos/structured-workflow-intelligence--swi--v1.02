import React, { useState } from "react";
import {
  HeartHandshake,
  CheckCircle2,
  ShieldCheck,
  FileCheck2,
  Lock,
  ArrowRight,
  Activity,
  Banknote,
  GraduationCap,
  Users,
  MapPin,
  Clock,
  Landmark
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";

type TrancheStatus = "DISBURSED" | "VERIFYING" | "PENDING_PROOF" | "LOCKED";

interface FundingTranche {
  id: string;
  phase: string;
  amount: number;
  description: string;
  requirements: string[];
  status: TrancheStatus;
  hash?: string;
}

export default function SAMHFundingView() {
  const [tranches, setTranches] = useState<FundingTranche[]>([
    {
      id: "TR-001",
      phase: "Phase 1: Pre-program & SWI Network Setup",
      amount: 500000,
      description: "Identify global community groups, establish CNCF SWI cloud nodes, integrate zero-trust IAM with accountability.",
      requirements: ["Community_MoU_Signed", "SWI_Node_Provisioned", "Promotional_Assets_Hashed"],
      status: "DISBURSED",
      hash: "0x8f3a...991c"
    },
    {
      id: "TR-002",
      phase: "Phase 2: Training Sessions & Cryptographic Ledger Sync",
      amount: 850000,
      description: "Modules: Children's Mental Health Basics, Advocacy Skills. Map participation to Immutable Ledger.",
      requirements: ["Attendance_Cryptographic_Roll", "Module_Completion_Certificates"],
      status: "PENDING_PROOF"
    },
    {
      id: "TR-003",
      phase: "Phase 3: Global Program Launch & Workflow Trace",
      amount: 1150000,
      description: "Implement SAMH initiatives to protect women and the girl child. Monitor via distributed graph engine.",
      requirements: ["Event_Execution_Proofs", "Global_Network_Ledger_Entry", "Effectiveness_Survey_Results"],
      status: "LOCKED"
    }
  ]);

  const [simulating, setSimulating] = useState(false);
  const [logs, setLogs] = useState<string[]>([
    "[SYSTEM] SWI Smart Grant initialized for Trusts Motion.",
    "[LEDGER] Total Budget Reserved: $2,500,000 USD (Escrowed).",
    "[VERIFIER] Phase 1 Proofs validated. Signature: Gaborone_Auth_01.",
    "[DISBURSE] Tranche TR-001 ($500,000) released to Trusts Motion."
  ]);

  const handleVerifyTranche = (index: number) => {
    setSimulating(true);
    const updated = [...tranches];
    updated[index].status = "VERIFYING";
    setTranches(updated);

    const addLog = (msg: string, delay: number) => {
      setTimeout(() => setLogs(prev => [...prev, msg]), delay);
    };

    addLog(`[API] Ingesting proof artifacts for ${updated[index].id}...`, 500);
    addLog(`[VERIFIER] Canonical hash generated for Training Attendance Records.`, 1500);
    addLog(`[POLICY] OPA Engine: evaluating SAMH_Tranche_Release_Rules...`, 2500);
    
    setTimeout(() => {
      addLog(`[DECISION] Requirements met. Cryptographic signatures match.`, 3500);
      addLog(`[DISBURSE] ${updated[index].id} ($${updated[index].amount.toLocaleString()}) unlocked and routed.`, 4000);
      
      const finalized = [...tranches];
      finalized[index].status = "DISBURSED";
      finalized[index].hash = `0x${Math.random().toString(16).substr(2, 12)}...`;
      
      if (finalized[index + 1]) {
        finalized[index + 1].status = "PENDING_PROOF";
      }
      
      setTranches(finalized);
      setSimulating(false);
    }, 4500);
  };

  const getStatusColor = (status: TrancheStatus) => {
    switch (status) {
      case "DISBURSED": return "text-emerald-400 bg-emerald-400/10 border-emerald-400/30";
      case "VERIFYING": return "text-indigo-400 bg-indigo-400/10 border-indigo-400/30";
      case "PENDING_PROOF": return "text-amber-400 bg-amber-400/10 border-amber-400/30";
      case "LOCKED": return "text-gray-500 bg-gray-500/10 border-gray-500/30";
    }
  };

  const totalDisbursed = tranches.filter(t => t.status === "DISBURSED").reduce((acc, curr) => acc + curr.amount, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      
      {/* Header */}
      <div className="bg-[#0a0a0a] border border-white/10 p-6 relative overflow-hidden flex flex-col md:flex-row gap-6 justify-between items-start">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-orange-500/10 blur-[100px] pointer-events-none"></div>
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-blue-500/10 blur-[100px] pointer-events-none"></div>
        
        <div className="relative z-10 space-y-4 max-w-2xl">
          <div className="flex items-center gap-3">
             <div className="p-3 bg-gradient-to-br from-orange-500/20 to-blue-500/20 border border-white/10 rounded-xl">
                <HeartHandshake className="w-6 h-6 text-orange-400" />
             </div>
             <div>
                <h2 className="text-xl font-black uppercase tracking-widest text-white flex items-center gap-2">
                   SWI Autonomous Grant Management
                </h2>
                <div className="text-xs font-mono text-white/50 flex items-center gap-4 mt-1">
                   <span className="flex items-center gap-1"><Landmark className="w-3 h-3" /> Beneficiary: Trusts Motion</span>
                   <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> P.O Box 4079, Gaborone, Botswana</span>
                </div>
             </div>
          </div>
          
          <div className="p-4 border border-white/5 bg-white/5 rounded-lg space-y-2">
            <h3 className="text-sm font-bold text-blue-400 uppercase tracking-widest">Student Advocates for Mental Health (SAMH)</h3>
            <p className="text-xs text-white/70 leading-relaxed font-serif">
              Empowering communities and transforming lives globally. SWI retains knowledge with accountability to be shared 
              with community groups globally, supporting children's mental health, and protecting women and the girl child 
              by eradicating stigma and providing comprehensive advocacy skills.
            </p>
          </div>
        </div>

        <div className="relative z-10 bg-black/50 border border-white/10 p-4 rounded-xl min-w-[250px]">
           <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-1">Total Cryptographic Escrow</div>
           <div className="text-3xl font-black text-emerald-400">$2,500,000</div>
           
           <div className="mt-4 space-y-2">
             <div className="flex justify-between text-xs font-mono">
               <span className="text-white/50">Disbursed</span>
               <span className="text-emerald-400">${totalDisbursed.toLocaleString()}</span>
             </div>
             <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
               <div className="bg-emerald-400 h-full transition-all duration-1000" style={{ width: `${(totalDisbursed / 2500000) * 100}%`}}></div>
             </div>
           </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Verification Timeline */}
        <div className="lg:col-span-2 space-y-4">
           <h3 className="text-[11px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
              <ShieldCheck className="w-4 h-4" /> Cryptographic Tranche Disbursement
           </h3>
           
           <div className="space-y-4">
             {tranches.map((tranche, i) => (
                <div key={tranche.id} className={cn("p-5 border bg-[#0a0a0a] transition-all", getStatusColor(tranche.status))}>
                   <div className="flex justify-between items-start mb-3">
                     <div>
                       <div className="text-xs font-black uppercase tracking-widest flex items-center gap-2">
                         {tranche.status === "DISBURSED" && <CheckCircle2 className="w-4 h-4" />}
                         {tranche.status === "VERIFYING" && <Activity className="w-4 h-4 animate-spin" />}
                         {tranche.status === "PENDING_PROOF" && <FileCheck2 className="w-4 h-4" />}
                         {tranche.status === "LOCKED" && <Lock className="w-4 h-4" />}
                         {tranche.phase}
                       </div>
                       <div className="text-[10px] font-mono text-white/50 mt-1">{tranche.id} • {tranche.description}</div>
                     </div>
                     <div className="text-xl font-bold font-mono">
                        ${tranche.amount.toLocaleString()}
                     </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-inherit">
                      <div>
                        <div className="text-[9px] font-bold uppercase tracking-widest opacity-60 mb-2">Required Proofs from Trusts Motion:</div>
                        <ul className="space-y-1">
                          {tranche.requirements.map((req, j) => (
                            <li key={j} className="text-[10px] font-mono flex items-center gap-2 opacity-80">
                               <div className={cn("w-1.5 h-1.5 rounded-full", tranche.status === "DISBURSED" ? "bg-emerald-400" : "bg-white/30")}></div>
                               {req}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="flex flex-col justify-end items-end gap-2">
                         {tranche.hash && (
                           <div className="text-[9px] font-mono opacity-60 bg-black/20 p-1.5 rounded border border-inherit">
                             TX: {tranche.hash}
                           </div>
                         )}
                         {tranche.status === "PENDING_PROOF" && (
                           <button 
                             onClick={() => handleVerifyTranche(i)}
                             disabled={simulating}
                             className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-bold uppercase tracking-widest transition-colors disabled:opacity-50"
                           >
                             Verify Proofs & Release Funds
                           </button>
                         )}
                      </div>
                   </div>
                </div>
             ))}
           </div>
        </div>

        {/* Ledger & Governance Context */}
        <div className="space-y-6">
           <div className="bg-[#0a0a0a] border border-white/10 p-5 space-y-4">
              <h3 className="text-[11px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-2 border-b border-white/10 pb-2">
                <Clock className="w-4 h-4" /> SWI Audit Trail
              </h3>
              <div className="h-64 overflow-y-auto space-y-2 custom-scrollbar font-mono text-[9px]">
                 {logs.map((log, i) => (
                    <div key={i} className={cn(
                      "p-2 border border-white/5 rounded",
                      log.includes("[DISBURSE]") ? "text-emerald-400 bg-emerald-400/5 border-emerald-400/20 font-bold" :
                      log.includes("[VERIFIER]") ? "text-blue-400" :
                      log.includes("[POLICY]") ? "text-fuchsia-400" :
                      "text-white/60"
                    )}>
                      {log}
                    </div>
                 ))}
                 {simulating && (
                    <div className="p-2 text-white/40 flex items-center gap-2">
                       <Activity className="w-3 h-3 animate-spin" /> Awaiting oracle confirmation...
                    </div>
                 )}
              </div>
           </div>

           <div className="bg-black/80 border border-fuchsia-500/20 p-5 space-y-3 relative overflow-hidden">
             <div className="absolute top-0 right-0 p-2 opacity-10"><ShieldCheck className="w-16 h-16" /></div>
             <div className="relative z-10 text-[10px] font-mono text-fuchsia-300/80 leading-relaxed">
               <strong className="text-fuchsia-400 uppercase tracking-widest mb-2 block border-b border-fuchsia-500/30 pb-1">SWI Smart Policy Enforcement</strong>
               <p className="mb-2">Governance rules engine tied directly to the SAMH curriculum overview:</p>
               <div className="bg-fuchsia-950/30 p-2 border border-fuchsia-500/20 rounded text-[9px] space-y-1">
                 <div className="opacity-50">package swi.grants.trustsmotion</div>
                 <div className="mt-2 text-emerald-400">allow_disbursement {'{'}</div>
                 <div className="ml-4">input.grant_id == "SAMH_2024"</div>
                 <div className="ml-4">validate_signatures(input.school_mou, "ED25519")</div>
                 <div className="ml-4">verify_curriculum_coverage(input.modules, ["advocacy", "leadership"])</div>
                 <div className="text-emerald-400">{'}'}</div>
               </div>
             </div>
           </div>
        </div>
      </div>

       <div className="flex justify-end pt-4">
          <ProofArtifacts
              id="samh-grant-manifest"
              title="SWI x Trusts Motion Grant Ledger"
              data={{
                  beneficiary: "Trusts Motion (Gaborone) & Global Community Groups",
                  program: "SAMH (Children's Mental Health & Protecting Women/Girl Child)",
                  total_budget: "$2,500,000",
                  verified_disbursements: `$${totalDisbursed.toLocaleString()}`,
                  smart_contract_status: totalDisbursed >= 2500000 ? "CLOSED_SUCCESS" : "ACTIVE"
              }}
              logs={logs}
              variant="default"
          />
       </div>

    </div>
  );
}
