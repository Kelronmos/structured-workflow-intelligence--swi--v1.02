import React, { useEffect, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, GitCompare } from "lucide-react";
import CryptoJS from "crypto-js";

// Mock baseline hash for evaluation determinism
const KNOWN_GOOD_BASELINE_HASH = CryptoJS.SHA256(JSON.stringify({ x: 1, _deterministic: true })).toString(CryptoJS.enc.Hex);

export function DeterminismMonitor() {
  const [divergenceDetected, setDivergenceDetected] = useState(false);
  const [lastCheckedHash, setLastCheckedHash] = useState<string>("");
  const [checks, setChecks] = useState(0);

  useEffect(() => {
    // Monitor continuously
    const interval = setInterval(() => {
      // Periodic check against baseline (simulate node drift calculation)
      const executionPayload = { x: 1, _deterministic: true };
      const currentHash = CryptoJS.SHA256(JSON.stringify(executionPayload)).toString(CryptoJS.enc.Hex);
      
      setLastCheckedHash(currentHash.substring(0, 16) + '...');
      setChecks(c => c + 1);

      if (currentHash !== KNOWN_GOOD_BASELINE_HASH) {
        setDivergenceDetected(true);
      } else {
        // Occasionally simulate a cluster node divergence (about 5% chance)
        if (Math.random() > 0.95) {
            setDivergenceDetected(true);
            setTimeout(() => setDivergenceDetected(false), 8000); // recover after 8 secs
        }
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-[#1A1A1A] border border-[#333] rounded p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2 text-gray-300">
          <GitCompare className="w-4 h-4 text-purple-400" />
          Determinism Monitor Utility
        </h3>
        <div className="text-[10px] text-gray-500 flex items-center gap-1">
          <Activity className="w-3 h-3" />
          Checks Counter: {checks}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-black/50 border border-[#333] p-3 rounded">
          <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">Known Good Baseline (KGB)</p>
          <p className="text-xs font-mono text-blue-400 truncate">{KNOWN_GOOD_BASELINE_HASH.substring(0, 16)}...</p>
        </div>
        <div className="bg-black/50 border border-[#333] p-3 rounded">
          <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">Recent Execution Hash</p>
          <p className="text-xs font-mono text-purple-400 truncate">{lastCheckedHash}</p>
        </div>
      </div>

      <div className="mt-4 flex items-center gap-3">
        {divergenceDetected ? (
          <div className="flex-1 bg-red-500/10 border border-red-500/30 p-2 rounded flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-xs text-red-400 font-bold uppercase">Cluster Node Divergence Detected</p>
              <p className="text-[10px] text-red-400/80 mt-1">State transition hashes do not match known-good baseline. PBFT consensus failure risk.</p>
            </div>
          </div>
        ) : (
          <div className="flex-1 bg-emerald-500/10 border border-emerald-500/30 p-2 rounded flex items-center gap-2 text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-xs font-bold uppercase">Determinism Verified Node-Wide</span>
          </div>
        )}
      </div>
    </div>
  );
}
