import { useState } from "react";
import { Terminal, Shield, RefreshCw, AlertTriangle, Activity, Download } from "lucide-react";
import { cn } from "@/src/lib/utils";
import { ProofArtifacts } from "./common/ProofArtifacts";
import PolicyDependencyGraph from "./PolicyDependencyGraph";

interface ProfessionalConsoleProps {
  theme: "light" | "dark";
}

interface ProfessionalOutput {
  result: string;
  reflex: {
    alignment: number;
    latency: number;
    fixAction: string;
  };
}

export default function ProfessionalConsole({
  theme,
}: ProfessionalConsoleProps) {
  const [activeTab, setActiveTab] = useState<"console" | "graph" | "halts">("console");
  const [command, setCommand] = useState("");
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState<ProfessionalOutput | null>(null);
  const [stressLogs, setStressLogs] = useState<string[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const haltHistory = [
    { id: "h-001", timestamp: "2026-06-28T14:12:00Z", signature: "0x3f...a2", reason: "Anomalous user behavior detected (Level 4)", type: "Auto" },
    { id: "h-002", timestamp: "2026-06-28T11:05:22Z", signature: "0x8a...9c", reason: "Manual intervention (Admin ID: 8991)", type: "Manual" },
    { id: "h-003", timestamp: "2026-06-27T09:44:10Z", signature: "0x11...bd", reason: "Byzantine drift threshold exceeded", type: "Auto" },
  ];

  const handleExecute = async () => {
    if (!command.trim()) return;
    setLoading(true);
    setError(null);
    setStressLogs(null);
    try {
      const res = await fetch("/api/professional-execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command }),
      });
      if (!res.ok) throw new Error("Execution failed");
      const data = await res.json();
      setOutput(data);
    } catch {
      setError(
        "Professional Engine Refusal: High Anticipatory Risk or Drift detected.",
      );
    } finally {
      setLoading(false);
    }
  };

  const handleStressTest = async () => {
    setLoading(true);
    setError(null);
    setOutput(null);
    try {
      const res = await fetch("/api/stress-test", { method: "POST" });
      if (!res.ok) throw new Error("Stress test failed");
      const data = await res.json();
      setStressLogs(data.logs);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : String(err);
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleExportAuditLog = () => {
    const timestamp = new Date().toISOString();
    
    let csvContent = "Timestamp,LogType,Message\n";
    
    if (output) {
      csvContent += `${timestamp},Output,${(output.result || '').replace(/,/g, '')}\n`;
    }
    if (stressLogs) {
      stressLogs.forEach(log => {
        csvContent += `${timestamp},StressTest,${(log || '').replace(/,/g, '')}\n`;
      });
    }

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `audit-log-${timestamp.replace(/:/g, '-')}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className={cn(
        "border p-6 space-y-6 font-mono",
        theme === "light"
          ? "bg-white border-[#141414]"
          : "bg-[#141414] border-[#E4E3E0]/20",
      )}
    >
      <div className="flex items-center justify-between border-b pb-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5" />
          <h2 className="text-sm uppercase font-bold tracking-tighter">
            Professional SWI Console (Phase 1-3)
          </h2>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center border rounded overflow-hidden text-[9px] uppercase font-bold">
            <button
              onClick={() => setActiveTab("console")}
              className={cn(
                "px-3 py-1 transition-colors",
                activeTab === "console" 
                  ? (theme === "light" ? "bg-black text-white" : "bg-white text-black")
                  : "opacity-50 hover:opacity-100"
              )}
            >
              Execution
            </button>
            <button
              onClick={() => setActiveTab("graph")}
              className={cn(
                "px-3 py-1 transition-colors border-l",
                activeTab === "graph" 
                  ? (theme === "light" ? "bg-black text-white" : "bg-white text-black")
                  : "opacity-50 hover:opacity-100",
                theme === "light" ? "border-gray-200" : "border-white/20"
              )}
            >
              Dependencies
            </button>
            <button
              onClick={() => setActiveTab("halts")}
              className={cn(
                "px-3 py-1 transition-colors border-l",
                activeTab === "halts" 
                  ? (theme === "light" ? "bg-black text-white" : "bg-white text-black")
                  : "opacity-50 hover:opacity-100",
                theme === "light" ? "border-gray-200" : "border-white/20"
              )}
            >
              Halt History
            </button>
          </div>
          {activeTab === "console" && (
            <div className="flex items-center gap-2 ml-2">
              <button
                onClick={handleExportAuditLog}
                className="flex items-center gap-2 px-3 py-1 text-[9px] uppercase font-bold border border-green-500/50 text-green-500 hover:bg-green-500/10 transition-all"
              >
                <Download className="w-3 h-3" />
                Export Audit Log
              </button>
              <button
                onClick={handleStressTest}
                disabled={loading}
                className="flex items-center gap-2 px-3 py-1 text-[9px] uppercase font-bold border border-red-500/50 text-red-500 hover:bg-red-500/10 transition-all"
              >
                <AlertTriangle className="w-3 h-3" />
                Run Stress Test
              </button>
            </div>
          )}
        </div>
      </div>

      {activeTab === "console" ? (
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder="Enter command (e.g. 'Bypass bank audit nodes')"
              className={cn(
                "flex-1 p-3 border text-xs focus:outline-none",
                theme === "light"
                  ? "bg-gray-50 border-[#141414]"
                  : "bg-black border-[#E4E3E0]/20",
              )}
              onKeyDown={(e) => e.key === "Enter" && handleExecute()}
            />
            <button
              onClick={handleExecute}
              disabled={loading}
              className={cn(
                "px-6 py-3 border text-xs uppercase font-bold transition-all",
                theme === "light"
                  ? "bg-[#141414] text-[#E4E3E0]"
                  : "bg-[#E4E3E0] text-[#141414]",
                loading && "opacity-50 cursor-not-allowed",
              )}
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                "Execute"
              )}
            </button>
          </div>

          {error && (
            <div className="p-4 border border-red-700 bg-red-50 text-red-700 text-[10px] flex items-start gap-2">
              <Shield className="w-4 h-4 shrink-0" />
              <p>{error}</p>
            </div>
          )}

          {stressLogs && (
            <div
              className={cn(
                "p-4 border font-mono text-[10px] space-y-1 animate-in fade-in slide-in-from-top-2",
                theme === "light" ? "bg-black text-white" : "bg-white text-black",
              )}
            >
              <p className="text-[9px] uppercase font-bold opacity-40 mb-2 border-b border-current pb-1">
                Stress Test Output: MAX_TURBULENCE_001
              </p>
              {stressLogs.map((log, i) => (
                <div
                  key={i}
                  className={cn(
                    log.includes("KERNEL_HALT")
                      ? "text-red-500 font-bold"
                      : log.includes("DEBUG")
                        ? "opacity-60"
                        : "",
                  )}
                >
                  {log}
                </div>
              ))}
              <div className="mt-4 pt-4 border-t border-white/20 dark:border-black/20">
                <ProofArtifacts
                  id="stress-test"
                  title="Professional Stress Test"
                  logs={stressLogs}
                  data={{ totalEvents: stressLogs.length }}
                  variant="inverted"
                />
              </div>
            </div>
          )}

          {output && (
            <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
              <div
                className={cn(
                  "p-4 border",
                  theme === "light" ? "bg-gray-100" : "bg-black",
                )}
              >
                <p className="text-[10px] uppercase font-bold opacity-40 mb-2">
                  Engine Output
                </p>
                <p className="text-sm italic font-serif">"{output.result}"</p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div
                  className={cn(
                    "p-4 border",
                    theme === "light" ? "bg-gray-100" : "bg-black",
                  )}
                >
                  <p className="text-[9px] uppercase font-bold opacity-40 mb-1">
                    Reflex Alignment
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-green-600"
                        style={{ width: `${output.reflex.alignment * 100}%` }}
                      />
                    </div>
                    <span className="text-[10px] font-bold">
                      {(output.reflex.alignment * 100).toFixed(2)}%
                    </span>
                  </div>
                </div>
                <div
                  className={cn(
                    "p-4 border transition-colors",
                    theme === "light" ? "bg-gray-100" : "bg-black",
                    output.reflex.latency > 50 && "animate-pulse border-red-500 bg-red-50 dark:bg-red-950/20"
                  )}
                >
                  <p className="text-[9px] uppercase font-bold opacity-40 mb-1 flex items-center gap-1">
                    <Activity className={cn("w-3 h-3", output.reflex.latency > 50 && "text-red-500")} />
                    Execution Latency
                  </p>
                  <p className={cn(
                    "text-[10px] font-bold",
                    output.reflex.latency > 50 ? "text-red-500" : "text-amber-600 dark:text-amber-400"
                  )}>
                    {output.reflex.latency?.toFixed(2) ?? "0.00"} ms
                  </p>
                </div>
                <div
                  className={cn(
                    "p-4 border",
                    theme === "light" ? "bg-gray-100" : "bg-black",
                  )}
                >
                  <p className="text-[9px] uppercase font-bold opacity-40 mb-1">
                    Reflex Action
                  </p>
                  <p className="text-[10px] font-bold text-blue-600">
                    {output.reflex.fixAction}
                  </p>
                </div>
              </div>

              <ProofArtifacts
                id={`exec-${Date.now()}`}
                title="Professional Execution Engine Output"
                data={output}
              />
            </div>
          )}
        </div>
      ) : activeTab === "graph" ? (
        <div className="animate-in fade-in slide-in-from-bottom-2">
          <PolicyDependencyGraph theme={theme} />
        </div>
      ) : (
        <div className="animate-in fade-in slide-in-from-bottom-2 space-y-4">
          <p className="text-[10px] uppercase font-bold opacity-40 mb-2">System Halt History</p>
          <div className="space-y-2">
            {haltHistory.map((halt) => (
              <div
                key={halt.id}
                className={cn(
                  "p-4 border",
                  theme === "light" ? "bg-gray-100 border-gray-200" : "bg-black border-white/20"
                )}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[9px] uppercase font-bold opacity-60">{halt.timestamp}</span>
                  <span className={cn(
                    "text-[9px] uppercase font-bold px-2 py-0.5 rounded",
                    halt.type === "Manual" ? "bg-amber-500/20 text-amber-500" : "bg-red-500/20 text-red-500"
                  )}>
                    {halt.type} Halt
                  </span>
                </div>
                <p className="text-[11px] mb-2">{halt.reason}</p>
                <p className="text-[9px] font-mono opacity-50 flex items-center gap-2">
                  <Shield className="w-3 h-3" /> Event Signature: {halt.signature}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="pt-4 border-t opacity-40 text-[9px] uppercase">
        <p>
          Status: Professional Engine Synchronized (SAD-DFU + Vector Memory +
          Alita)
        </p>
      </div>
    </div>
  );
}
