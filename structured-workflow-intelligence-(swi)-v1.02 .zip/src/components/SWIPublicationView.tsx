// src/components/SWIPublicationView.tsx
import React, { useState } from 'react';
import { BookOpen, Award, Download, ChevronRight, Hash } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { IEEE_PAPER_CONTENT } from '@/swi-core/kernel/IEEE_Paper';

type TabId = 'PAPER' | 'STANDARD' | 'ISA' | 'ROADMAP';

export default function SWIPublicationView() {
    const [activeTab, setActiveTab] = useState<TabId>('PAPER');

    const tabs = [
        { id: 'PAPER' as TabId, label: 'IEEE Publication', icon: BookOpen },
        { id: 'STANDARD' as TabId, label: 'v6.0 Execution Std', icon: Award },
        { id: 'ISA' as TabId, label: 'SWI-ISA v1.0 Spec', icon: Hash },
        { id: 'ROADMAP' as TabId, label: 'v6.0 Roadmap', icon: ChevronRight }
    ];

    return (
        <div className="bg-[#FAF9F6] text-[#141414] min-h-screen p-8 font-sans">
            <div className="max-w-4xl mx-auto space-y-12">
                {/* Header */}
                <div className="border-b-4 border-black pb-8 flex justify-between items-end">
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <span className="px-3 py-1 bg-black text-[#FAF9F6] text-[10px] font-black uppercase tracking-widest">Scientific Release v6.0</span>
                            <span className="text-[10px] font-bold text-black/40 uppercase tracking-widest">Docket ID: IEEE-SWI-2026-X</span>
                        </div>
                        <h1 className="text-5xl font-black tracking-tight leading-none uppercase">
                            The Proxima Standard
                        </h1>
                    </div>
                </div>

                {/* Tabs */}
                <div className="flex gap-4">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={cn(
                                "flex items-center gap-2 px-6 py-3 border-2 transition-all font-black text-xs uppercase tracking-widest",
                                activeTab === tab.id 
                                    ? "bg-black text-white border-black" 
                                    : "bg-transparent text-black/40 border-black/10 hover:border-black/30"
                            )}
                        >
                            <tab.icon className="w-4 h-4" />
                            {tab.label}
                        </button>
                    ))}
                </div>

                {/* Content */}
                <div className="bg-white border-b-8 border-black shadow-2xl p-12 space-y-8 animate-in fade-in duration-700">
                    {activeTab === 'PAPER' && (
                        <div className="space-y-8">
                            <div className="space-y-2">
                                <h2 className="text-3xl font-black uppercase tracking-tight">
                                    Deterministic Governance in High-Stakes Autonomous Systems
                                </h2>
                                <p className="text-sm font-bold text-black/60 italic uppercase tracking-widest">
                                    Authored by SWI Kernel Architecture Group
                                </p>
                            </div>

                            <div className="bg-black/5 p-6 border-l-4 border-black italic">
                                <h3 className="text-[10px] font-black uppercase tracking-widest mb-2">Abstract</h3>
                                <p className="text-sm leading-relaxed text-black/80">{IEEE_PAPER_CONTENT.abstract}</p>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 pt-8">
                                <div className="space-y-4">
                                    <h3 className="text-xs font-black uppercase tracking-widest border-b border-black/10 pb-2">Methodology</h3>
                                    <ul className="space-y-4">
                                        {IEEE_PAPER_CONTENT.methodology.map((m, i) => (
                                            <li key={i} className="flex gap-4 text-sm">
                                                <span className="font-black opacity-20">0{i+1}</span>
                                                <span className="text-black/70">{m}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                                <div className="space-y-4">
                                    <h3 className="text-xs font-black uppercase tracking-widest border-b border-black/10 pb-2">Experimental Results</h3>
                                    <ul className="space-y-4">
                                        {IEEE_PAPER_CONTENT.results.map((r, i) => (
                                            <li key={i} className="flex gap-4 text-sm font-bold">
                                                <ChevronRight className="w-4 h-4 text-black/20" />
                                                <span className="text-black/80">{r}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>

                            <div className="pt-8 border-t border-black/5 flex justify-between items-center">
                                <div className="flex gap-4">
                                    {IEEE_PAPER_CONTENT.keywords.map(kw => (
                                        <span key={kw} className="text-[9px] font-black text-black/40 uppercase">#{kw.replace(' ', '_')}</span>
                                    ))}
                                </div>
                                <button className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] px-4 py-2 bg-black text-white hover:scale-105 active:scale-95 transition-all">
                                    <Download className="w-3 h-3" /> Cite Paper
                                </button>
                            </div>
                        </div>
                    )}

                    {activeTab === 'STANDARD' && (
                        <div className="space-y-8">
                            <div className="flex justify-between items-start">
                                <h2 className="text-3xl font-black uppercase tracking-tight">SWI Execution Standard v6.0</h2>
                                <div className="bg-black text-white px-4 py-2 font-black text-xs">PROXIMA_APPROVED</div>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-6">
                                {[
                                    { title: 'Traceability', value: '1.0', desc: 'Bit-for-bit record' },
                                    { title: 'Determinism', value: '0.998', desc: 'State reproducibility' },
                                    { title: 'Transparency', value: 'Vτ-Stable', desc: 'Direct logic visibility' }
                                ].map(metric => (
                                    <div key={metric.title} className="p-4 border-2 border-black/5 hover:border-black transition-all group">
                                        <h4 className="text-[10px] font-black text-black/40 uppercase mb-1">{metric.title}</h4>
                                        <div className="text-2xl font-black group-hover:text-blue-600 transition-colors">{metric.value}</div>
                                        <p className="text-[9px] font-bold text-black/40 mt-1">{metric.desc}</p>
                                    </div>
                                ))}
                            </div>

                            <div className="space-y-4 pt-4">
                                <p className="text-sm leading-relaxed text-black/70">
                                    The v6.0 Standard (Proxima) establishes that governance is not an "add-on" but a primitive of computation. 
                                    By utilizing the SWI-ISA, we enforce the **Sovereign Interlock**—a state where no instruction can complete 
                                    unless it is formally verified against the dual-engine (Law & Ethics) stack.
                                </p>
                                <div className="p-6 bg-black text-white rounded-xl">
                                    <h4 className="text-[10px] font-black uppercase tracking-widest mb-4 opacity-50">Standard Compliance Matrix</h4>
                                    <div className="space-y-2 font-mono text-[10px]">
                                        <div className="flex justify-between border-b border-white/10 pb-1">
                                            <span>S9_STATE_HASH</span>
                                            <span className="text-green-400">PASSED</span>
                                        </div>
                                        <div className="flex justify-between border-b border-white/10 pb-1">
                                            <span>MERKLE_TRACE_INTEGRITY</span>
                                            <span className="text-green-400">VERIFIED</span>
                                        </div>
                                        <div className="flex justify-between border-b border-white/10 pb-1">
                                            <span>C1_MET_COHERENCE</span>
                                            <span className="text-green-400">ACTIVE</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {activeTab === 'ISA' && (
                        <div className="space-y-8">
                            <h2 className="text-3xl font-black uppercase tracking-tight">SWI-ISA v1.0 Specification</h2>
                            <p className="text-sm text-black/60">Low-level operational primitives for deterministic governance. The machine language of Digital Sovereignty.</p>
                            
                            <div className="space-y-4">
                                {[
                                    { code: '0x01', mnemonic: 'SWI_LOAD_BOUND', type: 'Administrative', desc: 'Pre-execution constraint load' },
                                    { code: '0x0A', mnemonic: 'SWI_CHECK_ETHIC', type: 'Audit', desc: 'Hardware-level ethical interrupt' },
                                    { code: '0xC1', mnemonic: 'SWI_SEAL_TRACE', type: 'Immunity', desc: 'Atomic Merkle commitment' },
                                    { code: '0xFF', mnemonic: 'SWI_TRAP_DIV', type: 'Safety', desc: 'Dynamic drift isolation' }
                                ].map(op => (
                                    <div key={op.code} className="flex items-center gap-6 p-4 border-b border-black/5 hover:bg-black/5 transition-all">
                                        <span className="font-mono text-xs font-black bg-black text-white px-3 py-1">{op.code}</span>
                                        <div className="flex-1">
                                            <div className="flex items-center gap-3">
                                                <span className="text-sm font-black uppercase tracking-widest">{op.mnemonic}</span>
                                                <span className="text-[10px] text-black/40 uppercase font-bold">[{op.type}]</span>
                                            </div>
                                            <p className="text-xs text-black/60 font-medium">{op.desc}</p>
                                        </div>
                                        <div className="w-12 h-1 bg-black/10 rounded-full overflow-hidden">
                                            <div className="h-full bg-black w-[80%]" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {activeTab === 'ROADMAP' && (
                        <div className="space-y-12">
                            <h2 className="text-3xl font-black uppercase tracking-tight">v6.0 Proxima: Multi-Plane Architecture</h2>
                            
                            <div className="space-y-8">
                                <h3 className="text-xs font-black uppercase tracking-widest border-l-4 border-black pl-4">The 3-Plane Foundation</h3>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    {[
                                        { title: 'Control Plane', desc: 'Fail-closed decision logic. Policy enforcement and coherence checking.' },
                                        { title: 'Execution Plane', desc: 'Secure, sandboxed task environment. Hardware-level instruction gating.' },
                                        { title: 'Audit Plane', desc: 'Immutable, cryptographically hashed registry. Absolute event traceability.' }
                                    ].map(plane => (
                                        <div key={plane.title} className="p-6 bg-black/[0.02] border-2 border-black/5 space-y-2">
                                            <h4 className="text-sm font-black uppercase">{plane.title}</h4>
                                            <p className="text-[10px] text-black/60 font-medium leading-relaxed">{plane.desc}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-8">
                                <h3 className="text-xs font-black uppercase tracking-widest border-l-4 border-black pl-4">Operational Module Segregation (46-Module Mesh)</h3>
                                <div className="space-y-4">
                                    {[
                                        { cat: 'Bio-Reflex (Response)', mods: 'SAFE_001, SAFE_002', desc: 'Hardware-synced latency testing and stimuli integrity.' },
                                        { cat: 'Compliance (Governance)', mods: 'GOV_003, LAW_001', desc: 'Real-time auditing against Gaborone Protocol & EU AI Act.' },
                                        { cat: 'Shadow Trajectory (Security)', mods: 'SEC_001, SEC_002', desc: 'Counter-drift node interlinks and prompt trajectory auditing.' }
                                    ].map(cat => (
                                        <div key={cat.cat} className="flex flex-col md:flex-row gap-6 p-6 border-b border-black/5 hover:bg-black/[0.01] transition-all">
                                            <div className="w-48">
                                                <div className="text-[10px] font-black uppercase tracking-widest">{cat.cat}</div>
                                                <div className="text-[9px] font-mono text-black/40 mt-1">{cat.mods}</div>
                                            </div>
                                            <p className="flex-1 text-[11px] text-black/60 font-serif italic italic">{cat.desc}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="p-8 bg-black text-white rounded-2xl relative overflow-hidden">
                                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
                                    <div className="space-y-2">
                                        <h4 className="text-sm font-black uppercase tracking-widest">Scientific Commitment: The 3-Minute Fix</h4>
                                        <p className="text-[10px] text-white/50 max-w-sm">Every SWI-certified process must maintain data quality and allow for human SME biometric handshakes (SAFE_004).</p>
                                    </div>
                                    <div className="bg-white/10 px-6 py-3 border border-white/20 rounded-full text-[10px] uppercase font-black tracking-widest">
                                        HARDCODE_GOVERNANCE_ACTIVE
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer Footer */}
                <div className="flex justify-between items-center opacity-30 text-[10px] font-black uppercase tracking-[0.3em]">
                    <span>Sovereign Intelligence Group © 2026</span>
                    <span>All Rights Reserved - SWI Runtime Environment</span>
                </div>
            </div>
        </div>
    );
}
