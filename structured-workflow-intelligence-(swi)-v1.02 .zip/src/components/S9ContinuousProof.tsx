import React, { useState, useEffect } from 'react';
import { Shield, Zap, RefreshCw, AlertTriangle, CheckCircle2, History, Database, Fingerprint, Lock, Unlock, ArrowRight, Download, Upload, FileText } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

interface S9Receipt {
  timestamp: string;
  prior_state: {
    ethical_weight: number;
    risk_band: string;
  };
  trigger_condition: string;
  governing_rule: string;
  resulting_action: string;
  rollback_plan_id: string | null;
  merkle_root: string;
  firefly_pin: string;
}

interface S9DashboardMetrics {
  total_actions: number;
  bound_actions: number;
  refused_actions: number;
  bound_percentage: number;
  refused_percentage: number;
  latest_pin: string;
  latest_merkle: string;
}

export default function S9ContinuousProof() {
  const [metrics, setMetrics] = useState<S9DashboardMetrics | null>(null);
  const [ledger, setLedger] = useState<S9Receipt[]>([]);
  const [loading, setLoading] = useState(true);
  const [ethicalWeight, setEthicalWeight] = useState(82);
  const [riskBand, setRiskBand] = useState(2); // MEDIUM
  const [rollbackBound, setRollbackBound] = useState(false);
  const [lastReceipt, setLastReceipt] = useState<S9Receipt | null>(null);
  const [importResult, setImportResult] = useState<{ success: boolean; notes: string; importedEvents?: number } | null>(null);

  const fetchDashboard = async () => {
    const res = await fetch('/api/s9/dashboard');
    const data = await res.json();
    setMetrics(data);
  };

  const fetchLedger = async () => {
    const res = await fetch('/api/s9/ledger');
    const data = await res.json();
    setLedger(data.reverse());
  };

  useEffect(() => {
    let isMounted = true;
    const init = async () => {
      await Promise.all([fetchDashboard(), fetchLedger()]);
      if (isMounted) setLoading(false);
    };
    init();
    const interval = setInterval(fetchDashboard, 5000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const handleUpdate = async () => {
    const res = await fetch('/api/s9/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ethical_weight: ethicalWeight, risk_band: riskBand })
    });
    const receipt = await res.json();
    setLastReceipt(receipt);
    fetchDashboard();
    fetchLedger();
  };

  const bindRollback = async () => {
    await fetch('/api/s9/rollback/bind', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        plan_id: "RP-" + Math.random().toString(36).substring(7).toUpperCase(),
        owner: "StandingAuthority",
        steps: ["Step 1: Halt Execution", "Step 2: Revert State", "Step 3: Notify SME"]
      })
    });
    setRollbackBound(true);
    fetchDashboard();
  };

  const exportJson = async (count: number = 100) => {
    const res = await fetch(`/api/proof/export/json?count=${count}`);
    const data = await res.json();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `swi_proof_${count}_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportPdf = async (count: number = 100) => {
    const res = await fetch(`/api/proof/export/pdf?count=${count}`);
    const { url, fileName } = await res.json();
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const proof = JSON.parse(event.target?.result as string);
        const res = await fetch('/api/proof/import', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(proof)
        });
        const result = await res.json();
        setImportResult(result);
        if (result.success) {
           // Optionally flash a success message for a few seconds
           setTimeout(() => setImportResult(null), 10000);
        }
      } catch {
        setImportResult({ success: false, notes: "Failed to parse proof JSON." });
      }
    };
    reader.readAsText(file);
    // Clear input
    e.target.value = '';
  };

  if (loading || !metrics) return <div className="p-8 text-center animate-pulse font-mono text-xs uppercase tracking-widest">Initializing Continuous Proof Pipeline...</div>;

  const chartData = [
    { name: 'Bound', value: metrics.bound_actions, color: '#22c55e' },
    { name: 'Refused', value: metrics.refused_actions, color: '#ef4444' }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8 p-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-black/10 dark:border-white/10 pb-6 gap-4">
        <div>
          <h2 className="text-3xl font-bold uppercase tracking-tighter flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-500" />
            SWI Runtime Environment
          </h2>
          <p className="text-xs opacity-50 uppercase tracking-[0.2em]">Execution Trace Enabled | Policy Gate: ACTIVE</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="flex gap-2">
            <button 
              onClick={() => exportJson(100)}
              className="flex items-center gap-2 px-3 py-2 border border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5 text-[10px] uppercase font-bold tracking-widest transition-colors"
            >
              <Download className="w-3 h-3" /> JSON
            </button>
            <button 
              onClick={() => exportPdf(100)}
              className="flex items-center gap-2 px-3 py-2 border border-black/10 dark:border-white/10 hover:bg-black/5 dark:hover:bg-white/5 text-[10px] uppercase font-bold tracking-widest transition-colors"
            >
              <FileText className="w-3 h-3" /> PDF
            </button>
            <div className="w-px bg-black/10 dark:bg-white/10 mx-1"></div>
            <button 
              onClick={() => exportJson(10000)}
              className="flex items-center gap-2 px-3 py-2 border border-blue-500/30 text-blue-600 dark:text-blue-400 hover:bg-blue-500/10 text-[10px] uppercase font-bold tracking-widest transition-colors"
            >
              <Download className="w-3 h-3" /> 10K JSON
            </button>
            <button 
              onClick={() => exportPdf(10000)}
              className="flex items-center gap-2 px-3 py-2 border border-blue-500/30 text-blue-600 dark:text-blue-400 hover:bg-blue-500/10 text-[10px] uppercase font-bold tracking-widest transition-colors"
            >
              <FileText className="w-3 h-3" /> 10K PDF
            </button>
          </div>
          <label className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-[10px] uppercase font-bold tracking-widest transition-colors cursor-pointer group">
            <Upload className="w-3 h-3 group-hover:animate-bounce" /> 
            <span>IMPORT</span>
            <input type="file" className="hidden" onChange={handleImport} accept=".json" />
          </label>
        </div>
      </div>

      {importResult && (
        <motion.div 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          className={cn(
            "p-4 border text-[10px] font-bold uppercase tracking-widest flex items-center justify-between",
            importResult.success ? "border-green-500/50 bg-green-500/5 text-green-600" : "border-red-500/50 bg-red-500/5 text-red-600"
          )}
        >
          <div className="flex items-center gap-3">
            <Fingerprint className="w-4 h-4" />
            <span>{importResult.success ? "Proof Verified" : "Verification Failed"}: {importResult.notes}</span>
            {importResult.importedEvents && <span className="opacity-50">({importResult.importedEvents} events parsed)</span>}
          </div>
          <button onClick={() => setImportResult(null)} className="opacity-50 hover:opacity-100">✕</button>
        </motion.div>
      )}

      <div className="flex gap-4">
        <div className={cn(
          "px-4 py-2 border flex items-center gap-3 transition-all",
          rollbackBound ? "border-green-500 bg-green-500/10 text-green-600" : "border-red-500 bg-red-500/10 text-red-600"
        )}>
          {rollbackBound ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4 animate-pulse" />}
          <span className="text-[10px] font-bold uppercase tracking-widest">
            Rollback Plan: {rollbackBound ? "BOUND" : "UNBOUND"}
          </span>
        </div>
        {!rollbackBound && (
          <button 
            onClick={bindRollback}
            className="px-4 py-2 bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] text-[10px] font-bold uppercase tracking-widest hover:opacity-90 transition-opacity"
          >
            Bind Rollback Plan
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Control & Metrics */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white dark:bg-[#1A1A1A] border border-black/10 dark:border-white/10 p-6 space-y-6">
            <h3 className="text-xs font-bold uppercase tracking-widest opacity-40">State Simulation</h3>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase font-bold">
                  <span>Ethical Weight</span>
                  <span className={cn(ethicalWeight < 75 ? "text-red-500" : "text-blue-500")}>{ethicalWeight}</span>
                </div>
                <input 
                  type="range" min="0" max="100" value={ethicalWeight} 
                  onChange={(e) => setEthicalWeight(parseInt(e.target.value))}
                  className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-bold opacity-40">Risk Band</label>
                <select 
                  value={riskBand} 
                  onChange={(e) => setRiskBand(parseInt(e.target.value))}
                  className="w-full bg-transparent border border-black/10 dark:border-white/10 p-2 text-xs font-bold uppercase"
                >
                  <option value={1}>Low Risk</option>
                  <option value={2}>Medium Risk</option>
                  <option value={3}>High Risk</option>
                </select>
              </div>

              <button 
                onClick={handleUpdate}
                className="w-full py-3 bg-[#141414] dark:bg-[#E4E3E0] text-[#E4E3E0] dark:text-[#141414] text-xs font-bold uppercase tracking-widest hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                Update State & Sign
              </button>
            </div>
          </div>

          <div className="bg-white dark:bg-[#1A1A1A] border border-black/10 dark:border-white/10 p-6 space-y-6">
            <h3 className="text-xs font-bold uppercase tracking-widest opacity-40">Action Distribution</h3>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ left: -20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="rgba(0,0,0,0.05)" />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" hide />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    contentStyle={{ backgroundColor: '#141414', border: 'none', borderRadius: '0', fontSize: '10px', color: '#fff' }}
                  />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="p-3 bg-green-500/5 border border-green-500/20">
                <div className="text-2xl font-bold text-green-500">{metrics.bound_actions}</div>
                <div className="text-[8px] uppercase font-bold opacity-40">Bound</div>
              </div>
              <div className="p-3 bg-red-500/5 border border-red-500/20">
                <div className="text-2xl font-bold text-red-500">{metrics.refused_actions}</div>
                <div className="text-[8px] uppercase font-bold opacity-40">Refused</div>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Cryptographic Chain */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-[#141414] text-[#E4E3E0] p-8 border border-white/10 space-y-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Fingerprint className="w-48 h-48" />
            </div>

            <div className="space-y-6 relative z-10">
              <div className="flex items-center gap-3 text-blue-400">
                <Database className="w-5 h-5" />
                <h3 className="text-sm font-bold uppercase tracking-[0.2em]">Latest Firefly Pin</h3>
              </div>
              <div className="bg-white/5 p-4 font-mono text-xs break-all border border-white/10 select-all">
                {metrics.latest_pin}
              </div>

              <div className="flex items-center gap-3 text-yellow-400">
                <RefreshCw className="w-5 h-5" />
                <h3 className="text-sm font-bold uppercase tracking-[0.2em]">Latest Merkle Root</h3>
              </div>
              <div className="bg-white/5 p-4 font-mono text-xs break-all border border-white/10 select-all">
                {metrics.latest_merkle}
              </div>
            </div>

            <div className="pt-8 border-t border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-bold uppercase tracking-widest opacity-60">Ledger Status: Active</span>
                </div>
                <span className="text-[10px] font-mono opacity-40">TOTAL RECEIPTS: {metrics.total_actions}</span>
              </div>
            </div>
          </div>

          {/* Last Receipt Notification */}
          <AnimatePresence>
            {lastReceipt && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={cn(
                  "p-6 border flex items-start gap-6",
                  lastReceipt.resulting_action === 'Refused' ? "border-red-500 bg-red-500/5" : "border-green-500 bg-green-500/5"
                )}
              >
                <div className={cn(
                  "p-3 rounded-full",
                  lastReceipt.resulting_action === 'Refused' ? "bg-red-500/10 text-red-500" : "bg-green-500/10 text-green-500"
                )}>
                  {lastReceipt.resulting_action === 'Refused' ? <AlertTriangle className="w-6 h-6" /> : <CheckCircle2 className="w-6 h-6" />}
                </div>
                <div className="space-y-2 flex-1">
                  <div className="flex justify-between items-center">
                    <h4 className="text-sm font-bold uppercase tracking-widest">
                      Action: {lastReceipt.resulting_action}
                    </h4>
                    <span className="text-[8px] font-mono opacity-40">{lastReceipt.timestamp}</span>
                  </div>
                  <p className="text-xs opacity-70 italic">"{lastReceipt.trigger_condition}"</p>
                  <div className="flex items-center gap-2 text-[10px] font-bold uppercase opacity-60">
                    <ArrowRight className="w-3 h-3" />
                    {lastReceipt.governing_rule}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Ledger Table */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-widest opacity-40 flex items-center gap-2">
                <History className="w-4 h-4" />
                Governance Ledger
              </h3>
              <button 
                onClick={fetchLedger}
                className="text-[10px] font-bold uppercase opacity-40 hover:opacity-100 transition-opacity"
              >
                Refresh Ledger
              </button>
            </div>
            <div className="border border-black/10 dark:border-white/10 overflow-hidden">
              <div className="max-h-[400px] overflow-y-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-black/5 dark:bg-white/5 sticky top-0 z-10">
                    <tr>
                      <th className="p-3 text-[10px] font-bold uppercase opacity-60 border-b border-black/10 dark:border-white/10">Timestamp</th>
                      <th className="p-3 text-[10px] font-bold uppercase opacity-60 border-b border-black/10 dark:border-white/10">Action</th>
                      <th className="p-3 text-[10px] font-bold uppercase opacity-60 border-b border-black/10 dark:border-white/10">Merkle Root</th>
                      <th className="p-3 text-[10px] font-bold uppercase opacity-60 border-b border-black/10 dark:border-white/10">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-black/5 dark:divide-white/5">
                    {ledger.map((receipt, idx) => (
                      <tr key={idx} className="hover:bg-black/5 dark:hover:bg-white/5 transition-colors group">
                        <td className="p-3 text-[10px] font-mono opacity-60">{new Date(receipt.timestamp).toLocaleTimeString()}</td>
                        <td className="p-3 text-[10px] font-bold uppercase tracking-tighter">{receipt.resulting_action}</td>
                        <td className="p-3 text-[10px] font-mono opacity-40 group-hover:opacity-100 transition-opacity">
                          {receipt.merkle_root.substring(0, 16)}...
                        </td>
                        <td className="p-3">
                          <span className={cn(
                            "text-[8px] font-bold uppercase px-1.5 py-0.5 border",
                            receipt.resulting_action === 'Refused' ? "border-red-500 text-red-500" : "border-green-500 text-green-500"
                          )}>
                            {receipt.resulting_action === 'Refused' ? "REFUSED" : "BOUND"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
