import { useState, useEffect } from "react";
import {
  Shield,
  Users,
  FileText,
  Download,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Activity,
  Layers,
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import LiveGovernanceGraph from "./LiveGovernanceGraph";
import { ProofArtifacts } from "./common/ProofArtifacts";

interface NodeConfig {
  name: string;
  authorityValid: boolean;
  integrityStatus: "VALID" | "COMPROMISED";
}

interface AuditEntry {
  hash: string;
  timestamp: string;
  prev_hash?: string;
  previousHash?: string;
  final_decision?: string;
  status?: string;
  consensus?: {
    result: string;
    strength: string;
    node_votes?: Record<string, unknown>[];
  };
  node_votes?: Record<string, unknown>[];
  reputations?: Record<string, number>;
  quarantine?: string[];
  type?: string;
}

export default function ConsensusView({ theme }: { theme: "light" | "dark" }) {
  const [burden, setBurden] = useState(39.6);
  const [nodeConfigs, setNodeConfigs] = useState<NodeConfig[]>([
    { name: "Node-A", authorityValid: true, integrityStatus: "VALID" },
    { name: "Node-B", authorityValid: false, integrityStatus: "VALID" },
    { name: "Node-C", authorityValid: true, integrityStatus: "VALID" },
  ]);
  const [result, setResult] = useState<AuditEntry | null>(null);
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<AuditEntry[]>([]);

  const fetchLogs = async () => {
    try {
      const res = await fetch("/api/system-events");
      const data = await res.json();
      setLogs(data.reverse());
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Failed to fetch system events", e);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const runConsensus = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/consensus-execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          burden,
          payload: { action: "DISTRIBUTED_TRANSFER", amount: 1000 },
          nodeConfigs: nodeConfigs,
        }),
      });
      const data = await res.json();
      setResult(data);
      fetchLogs();
    } catch (e) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, "Consensus failed", e);
    } finally {
      setLoading(false);
    }
  };

  const toggleNodeAuthority = (index: number) => {
    const newConfigs = [...nodeConfigs];
    newConfigs[index].authorityValid = !newConfigs[index].authorityValid;
    setNodeConfigs(newConfigs);
  };

  const toggleNodeIntegrity = (index: number) => {
    const newConfigs = [...nodeConfigs];
    newConfigs[index].integrityStatus =
      newConfigs[index].integrityStatus === "VALID" ? "COMPROMISED" : "VALID";
    setNodeConfigs(newConfigs);
  };

  const [selectedBlock, setSelectedBlock] = useState<number | null>(null);

  const getLiveConsensus = () => {
    const approved = nodeConfigs.filter(
      (n) => n.authorityValid && n.integrityStatus === "VALID",
    ).length;
    const rejected = nodeConfigs.filter(
      (n) => !n.authorityValid || n.integrityStatus !== "VALID",
    ).length;
    const quorum = Math.ceil(nodeConfigs.length * 0.66);

    let result: "APPROVED" | "REJECTED" | "PENDING" = "PENDING";
    if (approved >= quorum) result = "APPROVED";
    else if (rejected >= quorum) result = "REJECTED";

    return { approved, rejected, quorum, result };
  };

  const liveConsensus = getLiveConsensus();

  const displayedResult =
    selectedBlock !== null ? logs[logs.length - 1 - selectedBlock] : result;

  const graphNodes = nodeConfigs.map((n) => ({
    id: n.name,
    status: result?.quarantine?.includes(n.name)
      ? ("QUARANTINED" as const)
      : n.authorityValid && n.integrityStatus === "VALID"
        ? ("VALID" as const)
        : ("INVALID" as const),
    reputation: result?.reputations?.[n.name] ?? 1.0,
  }));

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <h2 className="text-3xl font-bold tracking-tighter uppercase font-serif italic">
            🔐 Distributed SWI Execution Boundary
          </h2>
          <p className="text-sm opacity-60 max-w-2xl">
            Distributed governance with real-time quorum detection and Byzantine
            fault isolation.
          </p>
        </div>
        <div className="flex gap-2">
          {selectedBlock !== null && (
            <button
              onClick={() => setSelectedBlock(null)}
              className="flex items-center gap-2 px-4 py-2 text-[10px] font-bold uppercase border border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white transition-all"
            >
              <RefreshCw className="w-3 h-3" />
              Exit Time Travel
            </button>
          )}
          <button
            onClick={() => {
              const link = document.createElement("a");
              link.href = "/api/export-audit";
              link.download = "SWI_Audit_Report.pdf";
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            }}
            className={cn(
              "flex items-center gap-2 px-4 py-2 text-[10px] font-bold uppercase border transition-all",
              theme === "light"
                ? "bg-[#141414] text-[#E4E3E0] hover:bg-black/90"
                : "bg-[#E4E3E0] text-[#141414] hover:bg-white/90",
            )}
          >
            <Download className="w-3 h-3" />
            Audit PDF
          </button>
          <button
            onClick={() => {
              const blob = new Blob([JSON.stringify(logs, null, 2)], {
                type: "application/json",
              });
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = `SWI_Audit_Ledger_${new Date().toISOString()}.json`;
              a.click();
            }}
            className={cn(
              "flex items-center gap-2 px-4 py-2 text-[10px] font-bold uppercase border transition-all shadow-sm",
              theme === "light"
                ? "bg-white text-[#141414] border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0]"
                : "bg-[#141414] text-[#E4E3E0] border-[#E4E3E0] hover:bg-[#E4E3E0] hover:text-[#141414]",
            )}
          >
            <FileText className="w-3 h-3" />
            Audit JSON
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Node Configuration */}
        <div className="lg:col-span-1 space-y-6">
          {/* Live Governance Graph */}
          <div className="p-4 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-3">
            <h3 className="text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 opacity-60">
              <Layers className="w-3 h-3" />
              Real-time Governance Graph
            </h3>
            <LiveGovernanceGraph
              nodes={graphNodes}
              decision={
                (displayedResult?.consensus?.result || liveConsensus.result) as
                  | "APPROVED"
                  | "REJECTED"
                  | "PENDING"
              }
              strength={
                (displayedResult?.consensus?.strength || "STRONG") as
                  | "STRONG"
                  | "WEAK"
              }
            />
          </div>

          {/* Temporal Execution Scrubber */}
          <div className="p-4 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 opacity-60">
                <RefreshCw className="w-3 h-3" />
                Temporal Execution Scrubber
              </h3>
              {selectedBlock !== null && (
                <span className="text-[8px] bg-blue-500 text-white px-2 py-0.5 font-bold uppercase">
                  Time Travel: Block #{logs.length - selectedBlock}
                </span>
              )}
            </div>
            <input
              type="range"
              min="0"
              max={Math.max(0, logs.length - 1)}
              step="1"
              value={selectedBlock === null ? logs.length : selectedBlock}
              onChange={(e) => {
                const val = parseInt(e.target.value);
                if (val === logs.length) setSelectedBlock(null);
                else setSelectedBlock(val);
              }}
              className="w-full h-1 bg-blue-500/20 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-[7px] font-bold uppercase opacity-40">
              <span>Genesis</span>
              <span>
                {selectedBlock === null
                  ? "Live"
                  : `Block ${logs.length - selectedBlock}`}
              </span>
            </div>
          </div>

          <div className="p-6 border border-[#141414] dark:border-[#E4E3E0]/20 bg-white dark:bg-[#141414] space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                Validator Cluster
                {liveConsensus.result !== "PENDING" && (
                  <div className="flex items-center gap-2 ml-2">
                    <span
                      className={cn(
                        "text-[8px] px-2 py-0.5 rounded-full border animate-pulse",
                        liveConsensus.result === "APPROVED"
                          ? "border-green-500 text-green-500 bg-green-500/5"
                          : "border-red-500 text-red-500 bg-red-500/5",
                      )}
                    >
                      {liveConsensus.result}
                    </span>
                    <span className="text-[7px] opacity-40 font-mono">
                      (QUORUM: {liveConsensus.approved}/{liveConsensus.quorum})
                    </span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                {result?.consensus?.strength && (
                  <span
                    className={cn(
                      "text-[7px] px-1.5 py-0.5 border font-mono font-bold",
                      result.consensus.strength === "STRONG"
                        ? "border-blue-500 text-blue-500"
                        : result.consensus.strength === "DISPUTED"
                          ? "border-red-500 text-red-500"
                          : "border-yellow-500 text-yellow-500",
                    )}
                  >
                    STRENGTH: {result.consensus.strength}
                  </span>
                )}
              </div>
            </h3>

            <div className="space-y-4">
              {nodeConfigs.map((node, i) => {
                const reputation = result?.reputations?.[node.name] ?? 1.0;
                const isQuarantined = result?.quarantine?.includes(node.name);

                return (
                  <div
                    key={node.name}
                    className={cn(
                      "p-3 border border-dashed space-y-2 transition-all",
                      isQuarantined
                        ? "opacity-40 grayscale border-red-500/50 bg-red-500/5"
                        : "border-[#141414]/20 dark:border-[#E4E3E0]/20",
                    )}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase">
                        {node.name}
                      </span>
                      <div className="flex items-center gap-2">
                        {isQuarantined && (
                          <span className="text-[7px] bg-red-500 text-white px-1 py-0.5 rounded-full font-bold uppercase animate-pulse">
                            Quarantined
                          </span>
                        )}
                        <span
                          className={cn(
                            "text-[8px] font-mono",
                            reputation > 0.8
                              ? "text-green-500"
                              : reputation > 0.5
                                ? "text-yellow-500"
                                : "text-red-500",
                          )}
                        >
                          REP: {reputation.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => toggleNodeAuthority(i)}
                        className={cn(
                          "flex-1 py-1 text-[8px] font-bold uppercase border transition-all",
                          node.authorityValid
                            ? "bg-green-500/10 text-green-600 border-green-500/30"
                            : "bg-red-500/10 text-red-600 border-red-500/30",
                        )}
                      >
                        Auth: {node.authorityValid ? "VALID" : "INVALID"}
                      </button>
                      <button
                        onClick={() => toggleNodeIntegrity(i)}
                        className={cn(
                          "flex-1 py-1 text-[8px] font-bold uppercase border transition-all",
                          node.integrityStatus === "VALID"
                            ? "border-[#141414]/20 hover:bg-red-500/10"
                            : "bg-red-600 text-white border-red-600",
                        )}
                      >
                        {node.integrityStatus === "VALID"
                          ? "Compromise"
                          : "Restore"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="space-y-2 pt-4 border-t border-[#141414]/10 dark:border-[#E4E3E0]/10">
              <div className="flex justify-between text-[10px] font-bold uppercase">
                <span className="opacity-40">Burden (Risk Factor)</span>
                <span>{burden.toFixed(1)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="0.1"
                value={burden}
                onChange={(e) => setBurden(parseFloat(e.target.value))}
                className="w-full h-1 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#141414] dark:accent-[#E4E3E0]"
              />
            </div>

            <button
              onClick={runConsensus}
              disabled={loading}
              className="w-full py-3 bg-[#141414] text-white dark:bg-[#E4E3E0] dark:text-[#141414] font-bold uppercase text-xs flex items-center justify-center gap-2"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Shield className="w-4 h-4" />
              )}
              Run Consensus
            </button>
          </div>
        </div>

        {/* Execution Result */}
        <div className="lg:col-span-2 space-y-6">
          {displayedResult ? (
            <div
              className={cn(
                "p-6 border animate-in slide-in-from-right-4 relative overflow-hidden",
                selectedBlock !== null
                  ? "border-blue-500 bg-blue-500/5 shadow-[0_0_20px_rgba(59,130,246,0.1)]"
                  : displayedResult.final_decision === "REFUSE" ||
                      displayedResult.consensus?.result === "REJECTED"
                    ? "border-red-500 bg-red-500/5"
                    : displayedResult.final_decision === "ESCALATE"
                      ? "border-orange-500 bg-orange-500/5"
                      : "border-green-500 bg-green-500/5",
              )}
            >
              {selectedBlock !== null && (
                <div className="absolute top-0 right-0 p-1 bg-blue-500 text-white text-[7px] font-bold uppercase tracking-widest z-50">
                  Historical Record #{logs.length - selectedBlock}
                </div>
              )}
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold uppercase tracking-tighter flex items-center gap-2">
                  {displayedResult.final_decision === "REFUSE" ||
                  displayedResult.consensus?.result === "REJECTED" ? (
                    <AlertTriangle className="text-red-500" />
                  ) : (
                    <CheckCircle2 className="text-green-500" />
                  )}
                  Final Decision:{" "}
                  {
                    (displayedResult.final_decision ||
                      displayedResult.consensus?.result) as string
                  }
                </h3>
                <span className="text-[10px] font-mono opacity-40">
                  Consensus Hash: {displayedResult.hash.substring(0, 16)}...
                </span>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                {(
                  displayedResult.node_votes ||
                  (displayedResult.consensus?.node_votes as Record<
                    string,
                    unknown
                  >[]) ||
                  []
                ).map((vote: Record<string, unknown>) => (
                  <div
                    key={vote.nodeName as string}
                    className="p-3 border border-[#141414]/10 dark:border-[#E4E3E0]/10 bg-white/50 dark:bg-black/50"
                  >
                    <p className="text-[8px] font-bold uppercase opacity-40 mb-1">
                      {vote.nodeName as string}
                    </p>
                    <p
                      className={cn(
                        "text-[10px] font-bold uppercase",
                        vote.decision === "REFUSE" ||
                          vote.decision === "REJECTED"
                          ? "text-red-500"
                          : "text-green-500",
                      )}
                    >
                      {vote.decision as string}
                    </p>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase font-bold opacity-40">
                  Consensus Receipt (Ledger Block)
                </label>
                <div className="relative group">
                  <pre className="p-4 bg-black text-green-500 font-mono text-[10px] overflow-x-auto border border-white/10 max-h-[300px]">
                    {JSON.stringify(displayedResult, null, 2)}
                  </pre>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(
                        JSON.stringify(displayedResult, null, 2),
                      );
                    }}
                    className="absolute top-2 right-2 p-1 bg-white/10 hover:bg-white/20 text-white text-[8px] font-bold uppercase transition-all opacity-0 group-hover:opacity-100"
                  >
                    Copy Block
                  </button>
                </div>
              </div>

              {/* AI Court Formal Verdict Section */}
              <div className="pt-6 border-t border-[#141414]/10 dark:border-white/10 space-y-4">
                <div className="flex items-center gap-2 text-blue-500">
                  <Shield className="w-5 h-5" />
                  <h4 className="text-sm font-bold uppercase tracking-widest font-serif italic underline">
                    Formal AI Court Verdict
                  </h4>
                </div>
                <div className="p-6 bg-white dark:bg-[#0A0A0A] border-4 border-double border-[#141414] dark:border-white/40 font-serif space-y-4">
                  <div className="flex justify-between text-[10px] font-bold italic border-b border-black/10 pb-2">
                    <span>
                      Case ID:{" "}
                      {displayedResult.hash.substring(0, 12).toUpperCase()}
                    </span>
                    <span>Issued: {displayedResult.timestamp}</span>
                  </div>
                  <p className="text-xs leading-relaxed opacity-80">
                    "The S9 Kernel, acting as the primary orchestrator of the
                    Sovereign Intelligence Engine, hereby issues a binding{" "}
                    {displayedResult.final_decision ||
                      displayedResult.consensus?.result}{" "}
                    for the requested execution pattern. This decision is backed
                    by a {displayedResult.consensus?.strength || "STRONG"}{" "}
                    consensus quorum across all active validation clusters."
                  </p>
                  <div className="pt-2">
                    <p className="text-[10px] font-bold uppercase underline">
                      Governance Proof:
                    </p>
                    <p className="text-[9px] font-mono break-all opacity-60">
                      ROOT_{displayedResult.hash}
                    </p>
                  </div>
                  <div className="flex justify-end pt-4 grayscale">
                    <div className="text-right">
                      <p className="text-[8px] font-bold uppercase">
                        Authorized Representative
                      </p>
                      <p className="text-[10px] font-serif italic">
                        SWI-v4 Governance Core
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <ProofArtifacts
                id={displayedResult.hash || "consensus"}
                title="Consensus Quorum Validated"
                data={displayedResult}
              />
            </div>
          ) : (
            <div className="h-full border border-dashed border-[#141414]/20 dark:border-[#E4E3E0]/20 flex flex-col items-center justify-center opacity-20 py-20">
              <Activity className="w-16 h-16 mb-4" />
              <p className="uppercase tracking-widest text-sm font-bold">
                Awaiting Consensus Execution
              </p>
            </div>
          )}

          {/* Audit Ledger */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Audit Ledger (Tamper-Proof Chain)
            </h3>
            <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
              {logs.map((log, i) => (
                <div
                  key={log.hash as string}
                  onClick={() => setSelectedBlock(i)}
                  className={cn(
                    "p-3 border transition-all cursor-pointer group",
                    selectedBlock === i
                      ? "border-blue-500 bg-blue-500/10 scale-[1.02]"
                      : "border-[#141414]/10 dark:border-[#E4E3E0]/10 bg-white dark:bg-[#1A1A1A] hover:border-[#141414] dark:hover:border-[#E4E3E0]",
                  )}
                >
                  <div className="text-[10px] font-mono flex flex-col gap-1">
                    <div className="flex justify-between">
                      <span
                        className={cn(
                          "font-bold",
                          selectedBlock === i ? "text-blue-500" : "opacity-60",
                        )}
                      >
                        BLOCK #{logs.length - i}
                      </span>
                      <span className="opacity-40">
                        {log.timestamp as string}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="opacity-60">
                        PREV_HASH:{" "}
                        {(
                          (log.prev_hash as string) ||
                          (log.previousHash as string) ||
                          ""
                        ).substring(0, 12)}
                        ...
                      </span>
                      <span className="font-bold">
                        HASH: {(log.hash as string).substring(0, 12)}...
                      </span>
                    </div>
                    <div className="mt-1 p-2 bg-black/5 dark:bg-white/5 flex justify-between items-center group-hover:bg-black/10 dark:group-hover:bg-white/10 transition-colors">
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            "font-bold uppercase",
                            log.final_decision === "REFUSE" ||
                              log.status === "REFUSE" ||
                              log.consensus?.result === "REJECTED"
                              ? "text-red-500"
                              : "text-green-500",
                          )}
                        >
                          {log.final_decision ||
                            log.status ||
                            log.consensus?.result}
                        </span>
                        {log.consensus?.strength === "WEAK" && (
                          <span className="text-[7px] text-yellow-600 bg-yellow-500/10 px-1 border border-yellow-500/20 font-bold uppercase">
                            Weak Consensus
                          </span>
                        )}
                      </div>
                      <span className="opacity-40">
                        {(log.type as string) || "CONSENSUS_EVENT"}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
