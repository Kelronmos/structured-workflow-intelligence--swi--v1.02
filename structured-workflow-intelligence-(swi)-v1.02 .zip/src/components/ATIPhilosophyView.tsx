import React, { useEffect, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Shield, BookOpen, Quote, Target, Users, Scale, Heart } from "lucide-react";
import { cn } from "../lib/utils";

export default function ATIPhilosophyView() {
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);

  return (
    <div className="max-w-4xl mx-auto space-y-16 pb-24 animate-in fade-in duration-1000 selection:bg-purple-900/30">
      
      {/* Article Header */}
      <motion.header 
        style={{ opacity, scale }}
        className="pt-24 pb-12 border-b border-white/5 space-y-6 relative"
      >
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[120px] pointer-events-none mix-blend-screen" />
        
        <div className="flex items-center gap-3 text-purple-400 font-mono text-[10px] uppercase tracking-widest font-bold">
          <Shield className="w-4 h-4" />
          <span>Governance Policy / Ethical Foundation</span>
          <span className="opacity-50 mx-2">•</span>
          <span>Drafted 2025</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-white font-sans leading-[1.1]">
          The A.T.I Philosophy:
          <br className="hidden md:block"/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-emerald-400">
            {" "}Voice, Identity, and the Responsibility to Build
          </span>
        </h1>

        <div className="flex items-center gap-4 text-xs font-mono text-white/50 pt-6">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Ground Ethics of Joe Build
          </div>
          <div>Ronald Mosidila & Late A.T.I</div>
        </div>
      </motion.header>

      {/* Article Content */}
      <article className="prose prose-invert prose-p:text-white/70 prose-p:leading-relaxed prose-h2:font-sans prose-h2:text-2xl prose-h2:text-white prose-h2:tracking-tight max-w-none space-y-12">
        
        <section className="space-y-6">
          <h2 className="flex items-center gap-3">
            <BookOpen className="w-5 h-5 text-purple-400" />
            Introduction
          </h2>
          <p className="text-lg text-white/80 leading-relaxed font-serif italic border-l-2 border-purple-500/30 pl-4 py-1">
            Few artists become larger than their music. Some create songs that dominate radio stations for a season and then fade into memory. Others become symbols of an era, carrying the aspirations, frustrations, and hopes of a generation. In Botswana, A.T.I emerged as more than a musician. He became a cultural voice, a storyteller, an advocate, and a reminder that success has meaning only when it remains connected to the people.
          </p>
          <p>
            The philosophy presented here is not a collection of direct quotations. Rather, it is an interpretation inspired by the themes consistently reflected in A.T.I's public life, artistic work, community engagement, and social advocacy. At its core, this philosophy rests on one simple belief:
          </p>
          <blockquote className="bg-white/5 border border-white/10 rounded-lg p-6 my-8">
            <Quote className="w-8 h-8 text-purple-400/50 mb-3" />
            <p className="text-xl font-bold text-white leading-snug">
              A person must never become so successful that they forget where they came from, nor so comfortable that they stop building for those who come after them.
            </p>
          </blockquote>
          <p>
            This idea appears repeatedly throughout the journey of many influential African artists. Yet in the case of A.T.I, it carried a distinctly Botswana identity. His work demonstrated that one could be modern without abandoning culture, ambitious without abandoning community, and influential without abandoning humanity.
          </p>
        </section>

        <section className="grid md:grid-cols-2 gap-8 my-16">
          <div className="bg-black/40 border border-white/5 rounded-lg p-6 space-y-4 hover:border-purple-500/20 transition-colors">
            <Target className="w-6 h-6 text-emerald-400" />
            <h3 className="text-lg font-bold text-white m-0">The Philosophy of Authentic Identity</h3>
            <p className="text-sm">
              Modern society often pressures people to imitate others. Social media rewards trends, popularity, and conformity. 
              The philosophy inspired by A.T.I rejects this approach. It argues that true influence begins when individuals stop performing for others and start expressing who they genuinely are.
              Authenticity is not simply honesty. It is courage.
            </p>
          </div>
          
          <div className="bg-black/40 border border-white/5 rounded-lg p-6 space-y-4 hover:border-emerald-500/20 transition-colors">
            <Users className="w-6 h-6 text-purple-400" />
            <h3 className="text-lg font-bold text-white m-0">The Philosophy of Representation</h3>
            <p className="text-sm">
              Representation matters because people cannot aspire to what they never see.
              The philosophy associated with A.T.I demonstrates that international standards of excellence can emerge from local communities.
              Representation is therefore not about fame. It is about possibility. When one person succeeds visibly, they expand the imagination of countless others.
            </p>
          </div>
        </section>

        <section className="space-y-6">
          <h2 className="flex items-center gap-3">
            <Scale className="w-5 h-5 text-emerald-400" />
            Service and Mental Strength
          </h2>
          <p>
            Success without service eventually becomes hollow. The deepest satisfaction often comes from contribution rather than accumulation. Every platform should serve a purpose. Every achievement should create opportunities.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-8">
            <div className="text-center p-4 bg-white/5 rounded border border-white/5">
              <span className="block text-xs uppercase tracking-widest text-white/50 mb-1">Question</span>
              <span className="font-bold font-serif italic">"What can I gain?"</span>
            </div>
            <div className="flex items-center justify-center text-white/20">
              changes to
            </div>
            <div className="text-center p-4 bg-purple-500/10 rounded border border-purple-500/20">
               <span className="block text-xs uppercase tracking-widest text-purple-400 mb-1">Question</span>
               <span className="font-bold text-white font-serif italic">"What can I build?"</span>
            </div>
          </div>
          <p>
            Life presents setbacks to everyone. The difference lies in response. Resilience is not pretending that pain does not exist. Resilience is continuing despite pain. A resilient individual accepts difficulty without surrendering identity.
          </p>
          <ul className="text-sm font-mono space-y-2 text-white/60 bg-black/50 p-6 rounded border border-white/5">
            <li><span className="text-emerald-400">→</span> Challenges become teachers.</li>
            <li><span className="text-emerald-400">→</span> Obstacles become training grounds.</li>
            <li><span className="text-emerald-400">→</span> Criticism becomes information.</li>
            <li><span className="text-emerald-400">→</span> Failure becomes education.</li>
          </ul>
        </section>

        <section className="space-y-6">
          <h2>Community & Cultural Confidence</h2>
          <p>
            Individual achievement has limits. Community achievement multiplies impact. No artist succeeds entirely alone. The philosophy inspired by A.T.I recognizes this reality. Community is not merely a social structure. Community is an ecosystem.
          </p>
          <p>
            One of Africa's greatest resources is culture. Language. History. Music. Storytelling. Values. Traditions. These are not relics of the past. They are strategic assets for the future. Cultural confidence is the ability to participate in a global world without losing local identity.
          </p>
        </section>
        
        <section className="space-y-6 bg-gradient-to-br from-purple-900/10 to-transparent p-8 rounded-xl border border-purple-500/10">
          <h2 className="flex items-center gap-3 text-purple-400 m-0 pb-4">
            <Heart className="w-5 h-5" />
            Youth Empowerment & Legacy
          </h2>
          <p className="text-white/80">
            Every generation inherits unfinished work. Young people are not merely recipients of the future. They are creators of it. Potential must be developed. Talent must be disciplined. Dreams must be executed. Empowerment without responsibility creates entitlement. Responsibility without empowerment creates frustration. Real progress requires both.
          </p>
          <p className="text-white/80">
            Legacy is often misunderstood. Many people believe legacy means being remembered. A deeper perspective suggests that legacy means remaining useful after you are gone. 
          </p>
          
          <div className="font-mono text-xs text-white/50 space-y-3 pt-6 border-t border-purple-500/20">
            <p className="font-bold text-purple-300 uppercase tracking-widest">Ask Yourself:</p>
            <p>1. What am I building that will outlive me?</p>
            <p>2. What problem am I solving for future generations?</p>
            <p>3. What knowledge am I preserving?</p>
            <p>4. What opportunities am I creating?</p>
          </div>
        </section>

        <section className="pt-12 text-center space-y-6">
          <div className="w-16 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent mx-auto" />
          <h2 className="text-3xl font-bold font-serif italic text-white/90">Conclusion</h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto leading-relaxed">
            The philosophy associated with A.T.I can ultimately be summarized through a commitment to authenticity, service, resilience, community, culture, youth development, and legacy. It is a philosophy that encourages individuals to remain grounded while pursuing excellence.
          </p>
          
          <div className="py-8 space-y-4">
            <p className="text-xl font-bold text-white">
              The greatest achievement is not becoming successful.
              <br />
              <span className="text-emerald-400">The greatest achievement is becoming useful.</span>
            </p>
            <p className="text-xl font-bold text-white">
              And the greatest legacy is not being remembered.
              <br />
              <span className="text-purple-400">It is leaving behind a world that is better because you were here.</span>
            </p>
          </div>
        </section>

      </article>

      <div className="flex justify-center pt-16 opacity-50">
        <div className="font-mono text-[10px] uppercase tracking-widest text-center">
          <p>End of Document</p>
          <p>Authoritative Policy — SWI v3.6</p>
        </div>
      </div>
    </div>
  );
}
