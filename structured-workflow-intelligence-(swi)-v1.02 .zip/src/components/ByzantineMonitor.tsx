import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, ShieldCheck, ZapOff, Activity, ShieldAlert } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export interface FaultReport {
  nodeName: string;
  type: "OSCILLATION" | "DIVERGENCE" | "HASH_INTEGRITY" | "TIMING_ANOMALY";
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  timestamp: number;
}

interface ByzantineMonitorProps {
  faults: FaultReport[];
  quarantinedNodes: string[];
}

export default function ByzantineMonitor({ faults, quarantinedNodes }: ByzantineMonitorProps) {
  return (
    <div className="bg-white dark:bg-[#0A0A0A] border border-[#141414] dark:border-[#E4E3E0]/20 p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div className="space-y-1">
          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] flex items-center gap-2 opacity-60">
            <ShieldAlert className="w-3 h-3" />
            Byzantine Isolation Layer
          </h3>
          <p className="text-sm font-bold tracking-tight">Active Fault Monitoring</p>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-black/5 dark:bg-white/5 border border-white/10">
            <Activity className="w-3 h-3 text-blue-500" />
            <span className="text-[9px] font-mono font-bold">{faults.length} Warnings</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-red-500/10 border border-red-500/20">
            <ZapOff className="w-3 h-3 text-red-500" />
            <span className="text-[9px] font-mono font-bold text-red-500 uppercase">{quarantinedNodes.length} Isolated</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {faults.length === 0 && quarantinedNodes.length === 0 ? (
          <div className="py-8 flex flex-col items-center justify-center opacity-20 space-y-2 border border-dashed border-white/10">
            <ShieldCheck className="w-8 h-8" />
            <p className="text-[10px] uppercase tracking-widest font-bold font-mono">Network Symmetrical</p>
          </div>
        ) : (
          <>
            {/* Isolated Nodes */}
            <div className="space-y-2">
              <p className="text-[8px] uppercase font-bold opacity-40 tracking-wider">Isolated Execution Units</p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                <AnimatePresence>
                  {quarantinedNodes.map(node => (
                    <motion.div
                      key={node}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="p-2 border border-red-500/30 bg-red-500/5 flex items-center justify-between group"
                    >
                      <span className="text-[9px] font-mono font-bold text-red-500 truncate mr-2">{node}</span>
                      <ZapOff className="w-3 h-3 text-red-500 opacity-50 group-hover:opacity-100 transition-opacity" />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

            {/* Fault LOG */}
            <div className="space-y-2">
              <p className="text-[8px] uppercase font-bold opacity-40 tracking-wider">Telemetry Alerts</p>
              <div className="space-y-1 max-h-[200px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-white/10">
                {faults.slice().reverse().map((fault, i) => (
                  <motion.div
                    key={`${fault.nodeName}-${i}`}
                    initial={{ x: -10, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    className={cn(
                      "p-3 border flex items-start gap-3 transition-colors",
                      fault.severity === 'CRITICAL' ? "bg-red-500/10 border-red-500/20" :
                      fault.severity === 'HIGH' ? "bg-orange-500/10 border-orange-500/20" :
                      "bg-yellow-500/5 border-yellow-500/10"
                    )}
                  >
                    <AlertTriangle className={cn(
                      "w-4 h-4 mt-0.5",
                      fault.severity === 'CRITICAL' || fault.severity === 'HIGH' ? "text-red-500" : "text-yellow-500"
                    )} />
                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold font-mono">{fault.nodeName}</span>
                        <span className="text-[7px] opacity-40">{new Date(fault.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-[9px] font-bold uppercase tracking-wide">
                        {fault.type.replace('_', ' ')} <span className="opacity-40 italic">detected</span>
                      </p>
                      <div className="flex gap-2">
                        <span className={cn(
                          "px-1 text-[7px] font-bold uppercase",
                          fault.severity === 'CRITICAL' ? "bg-red-500 text-white" : "bg-white/10"
                        )}>
                          {fault.severity}
                        </span>
                        <span className="text-[7px] opacity-40 font-mono">AUTOMATED_ISOLATION_TRIGGERED</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      <div className="pt-4 border-t border-[#141414]/10 dark:border-[#E4E3E0]/10 flex justify-between items-center opacity-40">
        <span className="text-[7px] font-mono">LAYER_BYZANTINE v4.1.0</span>
        <span className="text-[7px] font-mono">MTBF: 428.4hrs</span>
      </div>
    </div>
  );
}
