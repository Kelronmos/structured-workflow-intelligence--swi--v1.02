export class ByzantineModel {
  isMalicious(nodeId: string): boolean {
    // placeholder adversarial model
    return nodeId.includes("bad");
  }

  filter(nodes: string[]) {
    return nodes.filter(n => !this.isMalicious(n));
  }
}
