import { ZKProof } from "../zk/proof";

export interface ExecutionBlock {
  height: number;
  prevHash: string;

  proposer: string;

  stateRoot: string;
  trapRoot: string;
  executionRoot: string;

  zkProof: ZKProof;

  signature: string;
}
