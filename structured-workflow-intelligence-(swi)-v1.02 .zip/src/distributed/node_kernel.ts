import { Kernel } from "../kernel/kernel";
import { ConsensusEngine } from "./consensus";
import { hash } from "../kernel/crypto";
import { Prover } from "../zk/prover";

export class DistributedKernelNode {
  private prover = new Prover();

  constructor(
    public id: string,
    private kernel: Kernel,
    private consensus: ConsensusEngine
  ) {}

  step(syscalls: Map<number, any>) {
    const result = this.kernel.step(undefined, syscalls);

    this.consensus.submit({
      height: Date.now(),
      prevHash: this.consensus.head()?.executionRoot ?? "GENESIS",

      proposer: this.id,

      stateRoot: this.stateHash(),
      trapRoot: this.trapHash(),
      executionRoot: this.executionHash(),

      zkProof: this.prover.generate({
        height: Date.now(),
        preState: "A",
        postState: this.stateHash(),
        exec: this.executionHash(),
        traps: this.trapHash()
      }),

      signature: this.sign()
    }, ["nodeA", "nodeB"]);

    return result;
  }

  stateHash() {
    return hash(JSON.stringify(Array.from(this.kernel.state.processes.entries())));
  }

  trapHash() {
    return hash(JSON.stringify(this.kernel.traps?.peek?.() ?? []));
  }

  executionHash() {
    return hash("execution");
  }

  sign() {
    return hash(this.id + this.stateHash());
  }
}
