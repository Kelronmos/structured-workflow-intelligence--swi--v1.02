export interface Node {
  id: string;
  publicKey: string;
  stake: number;
}
