import { ExecutionBlock } from "./block";
import { Verifier } from "../zk/verifier";

export class ConsensusEngine {
  private blocks: ExecutionBlock[] = [];
  private verifier = new Verifier();

  submit(block: ExecutionBlock, approvals: string[]): boolean {
    const valid = this.verify(block);

    const quorum = approvals.length >= this.requiredQuorum();

    if (!valid || !quorum) return false;

    this.blocks.push(block);
    return true;
  }

  requiredQuorum(): number {
    return Math.max(1, Math.floor(this.blocks.length * 0.66));
  }

  verify(block: ExecutionBlock): boolean {
    const proofValid = this.verifier.verify(block.zkProof);

    const structureValid =
      !!block.stateRoot && !!block.executionRoot && !!block.trapRoot;

    return proofValid && structureValid;
  }

  head(): ExecutionBlock | null {
    return this.blocks.length
      ? this.blocks[this.blocks.length - 1]
      : null;
  }
}
