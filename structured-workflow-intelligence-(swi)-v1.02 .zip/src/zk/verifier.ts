import { ZKProof } from "./proof";
import { hash } from "../kernel/crypto";

export class Verifier {
  verify(proof: ZKProof): boolean {
    const recomputed = hash(
      proof.preStateRoot +
        proof.postStateRoot +
        proof.executionRoot +
        proof.trapRoot +
        proof.blockHeight,
    );

    return recomputed === proof.proofHash && proof.validity === true;
  }
}
