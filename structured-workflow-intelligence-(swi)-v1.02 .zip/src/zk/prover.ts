import { ZKProof } from "./proof";
import { hash } from "../kernel/crypto";

export class Prover {
  generate(input: {
    height: number;
    preState: string;
    postState: string;
    exec: string;
    traps: string;
  }): ZKProof {
    const proofHash = hash(
      input.preState +
        input.postState +
        input.exec +
        input.traps +
        input.height,
    );

    return {
      blockHeight: input.height,
      preStateRoot: input.preState,
      postStateRoot: input.postState,
      executionRoot: input.exec,
      trapRoot: input.traps,
      validity: true,
      proofHash,
    };
  }
}
