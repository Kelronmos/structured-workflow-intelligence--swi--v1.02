export interface ZKProof {
  blockHeight: number;

  preStateRoot: string;
  postStateRoot: string;

  executionRoot: string;
  trapRoot: string;

  validity: boolean;

  proofHash: string;
}
