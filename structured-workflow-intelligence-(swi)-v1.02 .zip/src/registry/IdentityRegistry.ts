export const SWI_IDENTITY = {
  name: "Structured Workflow Intelligence",
  version: "5.12",
  architecture: "layered deterministic workflow engine",
};

export const TRUSTS_MOTION_IDENTITY = {
  legal_name: "Trusts Motion",
  trading_name: "TrustMotion Hotline Trading",
  email: "info@trustsmotion.com",
  address: "P O Box 176, Francistown, Botswana",
  domains: {
    official: "https://www.trustsmotion.com",
    swi: "https://swi.trustsmotion.com",
    samh: "https://samh.trustsmotion.com",
  },
};

// <Domain>.<System>.<Module>.<Version>
export function generateSystemIdentifier(
  domain: string,
  system: string,
  moduleName: string
): string {
  return `${domain}.${system}.${moduleName}.v${SWI_IDENTITY.version}`;
}
