export async function executeSWI(payload: Record<string, unknown>) {
  const res = await fetch("/api/execute", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  return await res.json();
}

export async function rateAIInteraction(interactionId: string, rating: "thumb_up" | "thumb_down", comments?: string) {
  const res = await fetch("/api/rate-ai-interaction", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ interactionId, rating, comments })
  });
  if (!res.ok) {
    throw new Error("Failed to send rating");
  }
  return await res.json();
}
