export interface SWIModuleContract {
  name: string;
  version: string;

  init(): Promise<void>;
  execute(input: unknown): Promise<unknown>;

  verify?(): Promise<boolean>;

  executionMode: "REAL" | "SIMULATED" | "HYBRID";
}
