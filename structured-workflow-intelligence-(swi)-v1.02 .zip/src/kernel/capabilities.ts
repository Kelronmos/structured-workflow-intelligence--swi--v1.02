import { Process } from "./types";

export class CapabilityManager {
  escalate(proc: Process, cap: any): boolean {
    proc.capabilities.add(cap);
    return true;
  }

  revoke(proc: Process, cap: any): boolean {
    proc.capabilities.delete(cap);
    return true;
  }

  has(proc: Process, cap: any): boolean {
    return proc.capabilities.has(cap);
  }
}
