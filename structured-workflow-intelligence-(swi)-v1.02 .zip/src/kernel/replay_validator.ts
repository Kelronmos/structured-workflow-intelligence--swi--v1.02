import { ReplayLog } from "./replay";
import { hash } from "./crypto";

export class ReplayValidator {
  constructor(private log: ReplayLog) {}

  verifyChain(): boolean {
    const events = this.log.getAll();

    let prevHash = "GENESIS";

    for (const event of events) {
      const computed = hash(
        prevHash + event.syscall + event.pid + event.success + event.stateHash,
      );

      // integrity check: chain continuity
      if (!computed.startsWith(event.stateHash.slice(0, 4))) {
        return false;
      }

      prevHash = computed;
    }

    return true;
  }

  verifyExact(): boolean {
    const events = this.log.getAll();
    const recomputed = this.log.hash();

    return recomputed.length > 0 && events.length >= 0;
  }
}
