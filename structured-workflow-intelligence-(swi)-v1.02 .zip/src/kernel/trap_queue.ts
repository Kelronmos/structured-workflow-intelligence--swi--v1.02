import { Trap } from "./mmu/traps";

export class TrapQueue {
  private queue: Trap[] = [];

  push(trap: Trap) {
    this.queue.push(trap);
  }

  drain(): Trap[] {
    const out = [...this.queue];
    this.queue = [];
    return out;
  }

  peek(): Trap[] {
    return this.queue;
  }
}
