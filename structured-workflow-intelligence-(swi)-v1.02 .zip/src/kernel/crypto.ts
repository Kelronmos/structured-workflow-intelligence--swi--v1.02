import CryptoJS from "crypto-js";

export function hash(input: string): string {
  return CryptoJS.SHA256(input).toString(CryptoJS.enc.Hex);
}

export function sign(input: string, privateKey: string): string {
  // Mocking Ed25519 signature for now with HMAC using the key
  return CryptoJS.HmacSHA256(input, privateKey).toString(CryptoJS.enc.Hex);
}

export function verifySignature(
  input: string,
  signature: string,
  publicKey: string,
): boolean {
  // In a real system, use elliptic curve verification
  return sign(input, publicKey) === signature;
}
