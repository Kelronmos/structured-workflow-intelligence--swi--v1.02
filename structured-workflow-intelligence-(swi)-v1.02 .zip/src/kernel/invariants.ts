import { Kernel } from "./kernel";

export class InvariantEngine {
  constructor(private kernel: Kernel) {}

  check(): boolean {
    const processes = this.kernel.state.processes;

    for (const [pid, proc] of processes) {
      if (!(proc as any).pageTable || (proc as any).pageTable.size < 0) {
        return false;
      }

      if (proc.capabilities.has("UNDEFINED" as any)) {
        return false;
      }
    }

    return true;
  }
}
