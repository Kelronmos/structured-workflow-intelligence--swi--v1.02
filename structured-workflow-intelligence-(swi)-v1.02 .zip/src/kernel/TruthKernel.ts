import CryptoJS from "crypto-js";
import { signEvent, verifySignature, KeyPair } from "../crypto/signature";
import { AuditEvent } from "./types";

export class TruthKernel {
  private chain: AuditEvent[] = [];
  private lastHash: string = "GENESIS";
  private keyPair: KeyPair;

  constructor(keyPair: KeyPair) {
    this.keyPair = keyPair;
  }

  private hash(data: string): string {
    return CryptoJS.SHA256(data).toString(CryptoJS.enc.Hex);
  }

  public execute(eventType: string, payload: any) {
    const timestamp = new Date().toISOString();

    const raw = JSON.stringify({
      eventType,
      payload,
      timestamp,
      prev: this.lastHash,
    });

    const hash = this.hash(raw);
    const signature = signEvent(hash, this.keyPair.privateKey);

    const event: AuditEvent = {
      eventType,
      payload,
      timestamp,
      prevHash: this.lastHash,
      hash,
      signature,
    };

    this.chain.push(event);
    this.lastHash = hash;

    return event;
  }

  public verifyChain(): boolean {
    let prev = "GENESIS";

    for (const event of this.chain) {
      const raw = JSON.stringify({
        eventType: event.eventType,
        payload: event.payload,
        timestamp: event.timestamp,
        prev: prev,
      });

      const recalculated = this.hash(raw);

      if (recalculated !== event.hash) return false;
      if (!verifySignature(event.hash, event.signature, this.keyPair.publicKey))
        return false;

      prev = event.hash;
    }

    return true;
  }

  public exportChain() {
    return this.chain;
  }
}
