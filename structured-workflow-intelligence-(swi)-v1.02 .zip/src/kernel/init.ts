import { Kernel } from "./kernel";

export function createKernel(): Kernel {
  const kernel = new Kernel({
    runningPid: 1,
    halted: false,
    processes: new Map([
      [
        1,
        {
          pid: 1,
          memoryRoot: new Map(),
          capabilities: new Set([
            "MEMORY_READ",
            "MEMORY_WRITE",
            "SPAWN",
            "HALT",
          ]),
        },
      ],
    ]),
  });

  return kernel;
}
