import { z } from "zod";
import { SWICoreOrchestrator } from "./CoreOrchestrator";

// Policy Domain Specific Language
export interface PolicyRule {
  rule_id: string;
  condition: (input: any) => boolean;
  action: {
    require_review: boolean;
    block_execution: boolean;
  };
  confidence_threshold: number;
}

export interface PolicyDecision {
  ruleTriggered: string | null;
  blocked: boolean;
  requiresReview: boolean;
  confidence: number;
}

export class PolicyEngine {
  private rules: PolicyRule[] = [];
  private orchestrator = SWICoreOrchestrator.getInstance();

  public loadRules(rules: PolicyRule[]) {
    this.rules = rules;
  }

  public evaluate(input: any): PolicyDecision {
    const DecisionSchema = z.any();

    const decisionResult = this.orchestrator.executeDeterministically(
      "AI_COURT_POLICY_ENGINE",
      DecisionSchema,
      input,
      "REAL", // Deterministic cryptographically verified policy rule set
      (parsedInput) => {
        let blocked = false;
        let requiresReview = false;
        let triggeredRule = null;
        let finalConfidence = 1.0;

        for (const rule of this.rules) {
          if (rule.condition(parsedInput)) {
            triggeredRule = rule.rule_id;
            requiresReview = rule.action.require_review;
            blocked = rule.action.block_execution;
            finalConfidence = rule.confidence_threshold;
            break; // take first match
          }
        }

        return {
          ruleTriggered: triggeredRule,
          blocked,
          requiresReview,
          confidence: finalConfidence,
        };
      },
    );

    return decisionResult.data;
  }
}
