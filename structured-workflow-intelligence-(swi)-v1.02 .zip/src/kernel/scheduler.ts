import { Kernel } from "./kernel";

export class Scheduler {
  private queue: number[] = [];
  private index = 0;

  constructor(private kernel: Kernel) {}

  addProcess(pid: number) {
    if (!this.queue.includes(pid)) {
      this.queue.push(pid);
    }
  }

  next(): number | null {
    if (this.queue.length === 0) return null;

    const pid = this.queue[this.index % this.queue.length];
    this.index++;

    return pid;
  }

  remove(pid: number) {
    this.queue = this.queue.filter((p) => p !== pid);
  }
}
