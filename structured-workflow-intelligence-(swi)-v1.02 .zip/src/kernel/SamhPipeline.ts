import { z } from "zod";
import { SWICoreOrchestrator } from "./CoreOrchestrator";
import { PolicyEngine } from "./PolicyEngine";

// Event Sourced Logs
type SamhEvent = {
  eventId: string;
  type: "REGISTER_PARTICIPANT" | "RISK_SCREENING" | "CASE_ROUTED";
  payload: any;
  timestamp: string;
};

const samhEventLog: SamhEvent[] = [];

// Schemas
export const ParticipantSchema = z.object({
  participant_id: z.string(),
  first_name: z.string(),
  last_name: z.string(),
  gender: z.string(),
  age: z.number().min(0),
  district: z.string(),
  consent_status: z.enum(["Approved", "Pending", "Denied"]),
});

export const ScreeningSchema = z.object({
  participant_id: z.string(),
  depression_score: z.number().min(0).max(100),
  anxiety_score: z.number().min(0).max(100),
});

export class SamhDataPipeline {
  private orchestrator = SWICoreOrchestrator.getInstance();
  private policyEngine = new PolicyEngine();

  constructor() {
    this.policyEngine.loadRules([
      {
        rule_id: "SAMH_RISK_CRITICAL",
        condition: (input) =>
          input.depression_score >= 80 || input.anxiety_score >= 85,
        action: { require_review: true, block_execution: false },
        confidence_threshold: 0.95,
      },
    ]);
  }

  public registerParticipant(data: unknown) {
    const res = this.orchestrator.executeDeterministically(
      "SAMH_INTAKE",
      ParticipantSchema,
      data,
      "REAL", // Now REAL cryptographically verified enforcement
      (parsed) => {
        samhEventLog.push({
          eventId: `evt_${Date.now()}`,
          type: "REGISTER_PARTICIPANT",
          payload: parsed,
          timestamp: new Date().toISOString(),
        });
        return { status: "ACTIVE", next_step: "SCREENING" };
      },
    );
    return res;
  }

  public processScreening(data: unknown) {
    const res = this.orchestrator.executeDeterministically(
      "SAMH_SCREENING",
      ScreeningSchema,
      data,
      "REAL",
      (parsed) => {
        // Evaluate through AI Court Policy DSL
        const decision = this.policyEngine.evaluate(parsed);

        let targetRisk: "LOW" | "MODERATE" | "HIGH" | "CRITICAL" = "LOW";
        if (decision.ruleTriggered === "SAMH_RISK_CRITICAL")
          targetRisk = "CRITICAL";
        else if (parsed.depression_score > 60 || parsed.anxiety_score > 60)
          targetRisk = "HIGH";
        else if (parsed.depression_score > 40) targetRisk = "MODERATE";

        samhEventLog.push({
          eventId: `evt_${Date.now()}`,
          type: "RISK_SCREENING",
          payload: { ...parsed, risk_level: targetRisk },
          timestamp: new Date().toISOString(),
        });

        // Case Routing based on decision
        if (decision.requiresReview) {
          samhEventLog.push({
            eventId: `evt_${Date.now()}_route`,
            type: "CASE_ROUTED",
            payload: {
              participant_id: parsed.participant_id,
              target: "CRISIS_TEAM",
            },
            timestamp: new Date().toISOString(),
          });
        }

        return {
          risk_level: targetRisk,
          requires_review: decision.requiresReview,
        };
      },
    );
    return res;
  }

  public getEventHistory() {
    return samhEventLog;
  }
}
