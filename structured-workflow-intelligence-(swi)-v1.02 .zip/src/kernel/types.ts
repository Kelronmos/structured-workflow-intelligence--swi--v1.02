export type PID = number;

export type Capability = "MEMORY_WRITE" | "MEMORY_READ" | "SPAWN" | "HALT";

export interface Process {
  pid: PID;

  // TRUE isolation: per-process address space
  memoryRoot: Map<number, number>;
  capabilities: Set<Capability>;
}

export interface KernelState {
  runningPid: PID | null;
  processes: Map<PID, Process>;
  halted: boolean;
}

export type Syscall =
  | { type: "memory_write"; pid: PID; addr: number; value: number }
  | { type: "memory_read"; pid: PID; addr: number }
  | { type: "spawn"; pid: PID }
  | { type: "halt"; pid: PID; reason: string };

export type AuditEvent = {
  eventType: string;
  payload: any;
  timestamp: string;
  prevHash: string;
  hash: string;
  signature: string;
};
