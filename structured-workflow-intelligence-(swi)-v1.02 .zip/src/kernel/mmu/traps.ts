export type TrapType =
  | "PAGE_FAULT"
  | "SEGMENTATION_FAULT"
  | "PROTECTION_FAULT";

export interface Trap {
  type: TrapType;
  pid: number;
  addr: number;
  instructionPointer?: number;
  reason: string;
}
