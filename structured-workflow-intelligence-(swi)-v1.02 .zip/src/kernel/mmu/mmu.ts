import { TrapQueue } from "../trap_queue";
import { PhysicalMemory } from "./physical_memory";
import { Process } from "../types";
import { TrapReplayLog } from "../trap_replay_log";

export class MMU {
  constructor(
    private memory: PhysicalMemory,
    private traps: TrapQueue,
    private replay: TrapReplayLog
  ) {}

  translateWrite(proc: Process, addr: number, value: number, pid: number): boolean {
    const page = Math.floor(addr / 4096);
    const offset = addr % 4096;

    const entry = (proc as any).pageTable?.get(page);

    if (!entry || !entry.present) {
      const trap = {
        type: "PAGE_FAULT" as const,
        pid,
        addr,
        reason: "Page not present"
      };
      this.traps.push(trap);
      this.replay.append(trap);
      return false;
    }

    if (!entry.writable) {
      const trap = {
        type: "PROTECTION_FAULT" as const,
        pid,
        addr,
        reason: "Write denied"
      };
      this.traps.push(trap);
      this.replay.append(trap);
      return false;
    }

    this.memory.write(entry.frame * 4096 + offset, value);
    return true;
  }

  translateRead(proc: Process, addr: number, pid: number): number | null {
    const page = Math.floor(addr / 4096);
    const offset = addr % 4096;

    const entry = (proc as any).pageTable?.get(page);

    if (!entry || !entry.present) {
      const trap = {
        type: "PAGE_FAULT" as const,
        pid,
        addr,
        reason: "Page not present"
      };
      this.traps.push(trap);
      this.replay.append(trap);
      return null;
    }

    if (!entry.readable) {
      const trap = {
        type: "PROTECTION_FAULT" as const,
        pid,
        addr,
        reason: "Read denied"
      };
      this.traps.push(trap);
      this.replay.append(trap);
      return null;
    }

    return this.memory.read(entry.frame * 4096 + offset) ?? null;
  }
}
