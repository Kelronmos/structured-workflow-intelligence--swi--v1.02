export class PhysicalMemory {
  private memory = new Map<number, number>();

  write(addr: number, value: number) {
    this.memory.set(addr, value);
  }

  read(addr: number): number | undefined {
    return this.memory.get(addr);
  }
}
