import { hash, sign } from "./crypto";

export interface ReplayEvent {
  index: number;
  syscall: string;
  pid: number;
  success: boolean;
  stateHash: string;
  previous_hash: string;
  hash: string;
  signature: string;
  timestamp: string;
  execution_mode: "REAL" | "HYBRID" | "SIMULATED";
  verification_strength: number;
}

const SYSTEM_PRIVATE_KEY = "kernel_private_key_v1";

export class ReplayLog {
  private log: ReplayEvent[] = [];
  private currentHash: string =
    "0000000000000000000000000000000000000000000000000000000000000000";

  append(
    eventPartial: Omit<
      ReplayEvent,
      | "previous_hash"
      | "hash"
      | "signature"
      | "timestamp"
      | "execution_mode"
      | "verification_strength"
    >,
  ) {
    const timestamp = String(this.log.length);
    const eventPayload = `${eventPartial.syscall}:${eventPartial.pid}:${eventPartial.success}:${eventPartial.stateHash}`;

    const previous_hash = this.currentHash;
    const newHash = hash(eventPayload + previous_hash + timestamp);
    const signature = sign(newHash, SYSTEM_PRIVATE_KEY);

    const event: ReplayEvent = {
      ...eventPartial,
      previous_hash,
      hash: newHash,
      signature,
      timestamp,
      execution_mode: "REAL",
      verification_strength: 1.0,
    };

    this.currentHash = newHash;
    this.log.push(event);
  }

  getAll() {
    return [...this.log];
  }

  hash(): string {
    return this.currentHash;
  }
}
