export interface Context {
  pid: number;
  instructionPointer: number;
  registers: Map<string, number>;
}
