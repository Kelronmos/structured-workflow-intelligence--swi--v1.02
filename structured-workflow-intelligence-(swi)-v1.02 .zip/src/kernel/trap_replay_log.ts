import { Trap } from "./mmu/traps";
import { hash } from "./crypto";

export interface TrapRecord extends Trap {
  index: number;
  prevHash: string;
  recordHash: string;
}

export class TrapReplayLog {
  private log: TrapRecord[] = [];

  append(trap: Trap) {
    const prev = this.log.length ? this.log[this.log.length - 1] : null;

    const prevHash = prev ? prev.recordHash : "GENESIS";

    const recordHash = hash(
      prevHash + trap.type + trap.pid + trap.addr + trap.reason,
    );

    this.log.push({
      ...trap,
      index: this.log.length,
      prevHash,
      recordHash,
    });
  }

  getAll() {
    return [...this.log];
  }
}
