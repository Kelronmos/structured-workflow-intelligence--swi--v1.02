import { TrapQueue } from "./trap_queue";

export class TrapHandler {
  constructor(private traps: TrapQueue) {}

  handleAll() {
    const events = this.traps.drain();

    for (const t of events) {
      switch (t.type) {
        case "PAGE_FAULT":
          this.handlePageFault(t);
          break;

        case "PROTECTION_FAULT":
          this.handleProtectionFault(t);
          break;

        case "SEGMENTATION_FAULT":
          this.handleSegFault(t);
          break;
      }
    }
  }

  private handlePageFault(t: any) {
    console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, `[PAGE FAULT] pid=${t.pid} addr=${t.addr}`);
  }

  private handleProtectionFault(t: any) {
    console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, `[PROTECTION FAULT] pid=${t.pid} addr=${t.addr}`);
  }

  private handleSegFault(t: any) {
    console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, `[SEGFAULT] pid=${t.pid}`);
  }
}
