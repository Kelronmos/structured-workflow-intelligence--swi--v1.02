import { KernelState, Syscall } from "./types";
import { ReplayLog } from "./replay";
import { hash } from "./crypto";

export class SyscallGate {
  constructor(
    private state: KernelState,
    private log: ReplayLog,
  ) {}

  execute(call: Syscall): boolean {
    const process = this.state.processes.get(call.pid);

    if (!process) return this.reject(call.pid, call.type);

    let success = false;

    switch (call.type) {
      case "memory_write": {
        if (!process.capabilities.has("MEMORY_WRITE")) break;

        // TRUE per-process memory isolation
        process.memoryRoot.set(call.addr, call.value);
        success = true;
        break;
      }

      case "memory_read": {
        success = process.capabilities.has("MEMORY_READ");
        break;
      }

      case "spawn": {
        const newPid = this.state.processes.size + 1;

        this.state.processes.set(newPid, {
          pid: newPid,
          memoryRoot: new Map(),
          capabilities: new Set(["MEMORY_READ"]),
        });

        success = true;
        break;
      }

      case "halt": {
        this.state.halted = true;
        success = true;
        break;
      }
    }

    this.log.append({
      index: this.log.getAll().length,
      syscall: call.type,
      pid: call.pid,
      success,
      stateHash: hash(JSON.stringify([...this.state.processes])),
    });

    return success;
  }

  private reject(pid: number, syscall: string) {
    this.log.append({
      index: this.log.getAll().length,
      syscall,
      pid,
      success: false,
      stateHash: "reject",
    });

    return false;
  }
}
