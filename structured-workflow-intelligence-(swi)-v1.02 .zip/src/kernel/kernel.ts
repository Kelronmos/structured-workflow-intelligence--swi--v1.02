import { KernelState, Syscall } from "./types";
import { SyscallGate } from "./syscall_gate";
import { ReplayLog } from "./replay";
import { Scheduler } from "./scheduler";
import { TrapHandler } from "./trap_handler";

export class Kernel {
  state: KernelState;
  gate: SyscallGate;
  log: ReplayLog;

  // Added MMU, traps, handler, and scheduler for distributed kernel updates
  mmu: any;
  traps: any;
  handler: TrapHandler;
  scheduler: Scheduler;

  constructor(
    initial: KernelState,
    mmu?: any,
    traps?: any,
    handler?: TrapHandler,
    scheduler?: Scheduler,
  ) {
    this.state = initial;
    this.log = new ReplayLog();
    this.gate = new SyscallGate(this.state, this.log);

    this.mmu = mmu || {};
    this.traps = traps || { peek: () => [] };
    this.handler =
      handler ||
      new TrapHandler({
        drain: () => [],
        push: () => {},
        peek: () => [],
      } as any);
    this.scheduler = scheduler || new Scheduler(this);
  }

  step(call?: Syscall, syscalls?: Map<number, any>): boolean | undefined {
    if (syscalls) {
      const pid = this.scheduler.next();
      if (pid === null) return;
      const syscallObj = syscalls.get(pid);
      if (!syscallObj) return;
      const result = syscallObj.execute();
      this.handler.handleAll();
      return result;
    }

    if (!call) return;
    if (this.state.halted) return false;
    const result = this.gate.execute(call);
    this.handler.handleAll();
    return result;
  }

  replay() {
    return this.log.getAll();
  }

  integrityHash() {
    return this.log.hash();
  }
}
