import { z } from "zod";
import { hash, sign } from "./crypto";

export type ExecutionMode = "REAL" | "HYBRID" | "SIMULATED";

export interface ExecutionContext {
  mode: ExecutionMode;
  strength: number;
}

export interface OrchestrationResult<T> {
  data: T;
  auditTrail: {
    txId: string;
    hash: string;
    signature: string;
    timestamp: string;
    context: ExecutionContext;
  };
}

const SYSTEM_PRIVATE_KEY = "fsk_v2_private_key_production";
let globalHashChain =
  "0000000000000000000000000000000000000000000000000000000000000000";

export class SWICoreOrchestrator {
  private static instance: SWICoreOrchestrator;
  private constructor() {}

  static getInstance() {
    if (!this.instance) {
      this.instance = new SWICoreOrchestrator();
    }
    return this.instance;
  }

  public executeDeterministically<T, S extends z.ZodTypeAny>(
    moduleName: string,
    schema: S,
    input: unknown,
    executionMode: ExecutionMode,
    operation: (parsedInput: z.infer<S>) => T,
  ): OrchestrationResult<T> {
    // 1. Zod Validation phase
    const parsed = schema.parse(input);

    // 2. Determine verification strength based on mode
    let strength = 0;
    if (executionMode === "REAL") strength = 1.0;
    else if (executionMode === "HYBRID") strength = 0.5;
    else strength = 0.1;

    // 3. Execute
    const output = operation(parsed);

    // 4. Trace & Commit to Chain
    const timestamp = new Date().toISOString();
    const payload = JSON.stringify({
      moduleName,
      input: parsed,
      output,
      timestamp,
    });

    globalHashChain = hash(payload + globalHashChain);
    const signature = sign(globalHashChain, SYSTEM_PRIVATE_KEY);

    return {
      data: output,
      auditTrail: {
        txId: `tx_${hash(timestamp).substring(0, 8)}`,
        hash: globalHashChain,
        signature,
        timestamp,
        context: {
          mode: executionMode,
          strength,
        },
      },
    };
  }
}
