export type PolicyRule = {
  id: string;
  priority: number;
  condition: (input: any) => boolean;
  action: "ALLOW" | "BLOCK" | "REVIEW";
};

export type Decision = {
  allowed: boolean;
  action: string;
  triggeredRules: string[];
};

export class AICourtEngine {
  private rules: PolicyRule[] = [];

  addRule(rule: PolicyRule) {
    this.rules.push(rule);
    this.rules.sort((a, b) => b.priority - a.priority);
  }

  evaluate(input: any): Decision {
    const triggered: string[] = [];

    for (const rule of this.rules) {
      if (rule.condition(input)) {
        triggered.push(rule.id);

        if (rule.action === "BLOCK") {
          return {
            allowed: false,
            action: "BLOCK",
            triggeredRules: triggered,
          };
        }

        if (rule.action === "REVIEW") {
          return {
            allowed: true,
            action: "REVIEW",
            triggeredRules: triggered,
          };
        }
      }
    }

    return {
      allowed: true,
      action: "ALLOW",
      triggeredRules: triggered,
    };
  }
}
