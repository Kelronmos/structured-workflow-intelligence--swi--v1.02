import { PolicyRule } from "./types";

export function normalizeRule(rule: PolicyRule): PolicyRule {
  return {
    ...rule,
    priority: rule.priority ?? 0,
    conditions: rule.conditions ?? {},
  };
}
