import { PolicyRule } from "./types";

export function detectConflicts(rules: PolicyRule[]) {
  const conflicts = [];

  for (let i = 0; i < rules.length; i++) {
    for (let j = i + 1; j < rules.length; j++) {
      if (
        rules[i].effect !== rules[j].effect &&
        rules[i].priority === rules[j].priority
      ) {
        conflicts.push([rules[i], rules[j]]);
      }
    }
  }

  return conflicts;
}
