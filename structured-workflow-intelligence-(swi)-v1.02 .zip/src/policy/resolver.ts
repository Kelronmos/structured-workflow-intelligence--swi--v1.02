import { PolicyRule, PolicyEffect } from "./types";
import { appendEvent } from "../audit/ledger";

const severityRank: Record<PolicyEffect, number> = {
  DENY: 4,
  REQUIRE_HUMAN: 3,
  REVIEW: 2,
  ALLOW: 1,
};

export async function resolvePolicies(
  rules: PolicyRule[],
  context: any
): Promise<PolicyEffect> {
  let selected: PolicyRule | null = null;

  for (const rule of rules) {
    const match = evaluate(rule, context);

    if (!match) continue;

    if (
      !selected ||
      rule.priority > selected.priority ||
      (rule.priority === selected.priority &&
        severityRank[rule.effect] > severityRank[selected.effect])
    ) {
      selected = rule;
    }
  }

  const result = selected?.effect ?? "REVIEW";

  await appendEvent({
    id: crypto.randomUUID(),
    type: "POLICY_APPLIED",
    timestamp: Date.now(),
    actor: "SYSTEM",
    refId: "policy-resolver",
    payload: {
      result,
      selectedRule: selected,
      context,
    },
  });

  return result;
}

function evaluate(rule: PolicyRule, context: any): boolean {
  const c = rule.conditions;

  if (c.riskScore) {
    if (c.riskScore.gte && context.riskScore < c.riskScore.gte) return false;
    if (c.riskScore.lte && context.riskScore > c.riskScore.lte) return false;
  }

  if (c.confidence) {
    if (c.confidence.gte && context.confidence < c.confidence.gte) return false;
    if (c.confidence.lte && context.confidence > c.confidence.lte) return false;
  }

  if (c.stateMatch && !c.stateMatch.includes(context.state)) {
    return false;
  }

  if (c.metricsMatch && context.metrics) {
    const hasMetric = c.metricsMatch.some((m: string) => context.metrics.includes(m));
    if (!hasMetric) return false;
  }

  return true;
}
