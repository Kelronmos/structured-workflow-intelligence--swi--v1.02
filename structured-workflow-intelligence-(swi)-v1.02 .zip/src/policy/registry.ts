import { PolicyRule } from "./types";

export const policyRegistry: PolicyRule[] = [
  {
    id: "deny-behavioral-drift",
    priority: 15,
    effect: "DENY",
    conditions: {
      metricsMatch: ["BEHAVIORAL_DRIFT_DETECTED", "ENVIRONMENTAL_DRIFT_DETECTED"],
    },
    source: "SYSTEM",
  },
  {
    id: "deny-high-risk",
    priority: 10,
    effect: "DENY",
    conditions: {
      riskScore: { gte: 0.85 },
    },
    source: "SYSTEM",
  },
  {
    id: "human-required-low-confidence",
    priority: 8,
    effect: "REQUIRE_HUMAN",
    conditions: {
      confidence: { lte: 0.4 },
    },
    source: "SYSTEM",
  },
  {
    id: "review-medium-risk",
    priority: 5,
    effect: "REVIEW",
    conditions: {
      riskScore: { gte: 0.5, lte: 0.84 },
    },
    source: "SYSTEM",
  },
  {
    id: "default-allow",
    priority: 1,
    effect: "ALLOW",
    conditions: {},
    source: "SYSTEM",
  },
];
