export interface ApiResponse<T> {
  success: boolean;
  timestamp: number;
  requestId: string;
  data: T | null;
  errors: ApiError[];
}

export interface ApiError {
  code: string;
  message: string;
  details?: any;
}

export function createResponse<T>(data: T, requestId: string = 'REQ-DEFAULT'): ApiResponse<T> {
  return {
    success: true,
    timestamp: Math.floor(Date.now() / 1000),
    requestId,
    data,
    errors: [],
  };
}

export function createErrorResponse(message: string, code: string = 'INTERNAL_ERROR', requestId: string = 'REQ-DEFAULT'): ApiResponse<null> {
  return {
    success: false,
    timestamp: Math.floor(Date.now() / 1000),
    requestId,
    data: null,
    errors: [{ code, message }],
  };
}
