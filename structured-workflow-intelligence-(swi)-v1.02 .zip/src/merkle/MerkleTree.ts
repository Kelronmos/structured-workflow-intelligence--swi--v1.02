import CryptoJS from "crypto-js";

export class MerkleTree {
  leaves: string[];

  constructor(leaves: string[]) {
    this.leaves = leaves;
  }

  private hash(data: string): string {
    return CryptoJS.SHA256(data).toString(CryptoJS.enc.Hex);
  }

  buildTree(): string {
    if (this.leaves.length === 0) return "";

    let level = this.leaves.map((l) => this.hash(l));

    while (level.length > 1) {
      const next: string[] = [];

      for (let i = 0; i < level.length; i += 2) {
        const left = level[i];
        const right = level[i + 1] || left;

        next.push(this.hash(left + right));
      }

      level = next;
    }

    return level[0];
  }
}
