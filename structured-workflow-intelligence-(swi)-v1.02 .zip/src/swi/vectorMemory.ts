import { GoogleGenAI } from "@google/genai";
import { cosineSimilarity } from './vectors';
import fs from 'fs';
import path from 'path';

const SCARS_FILE = path.join(process.cwd(), 'scars.json');

interface Scar {
  id: string;
  description: string;
  embedding: number[];
  severity: string;
  severityLevel: number;
  severityColor: string;
  fixAction: string;
  timestamp: number;
}

/**
 * Phase 2: Vector Memory & The Architecture of Immunity
 * The "Hard Drive" for the AI's conscience.
 */
export class SWIVectorMemory {
  private scars: Scar[] = [];
  private ai: GoogleGenAI | null = null;

  constructor() {
    const apiKey = (import.meta as any).env ? (import.meta as any).env.VITE_GEMINI_API_KEY : process.env.VITE_GEMINI_API_KEY;
    if (apiKey && apiKey !== "demo_mode") {
      this.ai = new GoogleGenAI({ apiKey });
    }
    this.loadScars();
  }

  private loadScars() {
    if (typeof process === "undefined" || !fs) return;
    if (fs.existsSync(SCARS_FILE)) {
      try {
        this.scars = JSON.parse(fs.readFileSync(SCARS_FILE, 'utf8'));
      } catch {
        this.scars = [];
      }
    }
  }

  private saveScars() {
    if (typeof process === "undefined" || !fs) return;
    fs.writeFileSync(SCARS_FILE, JSON.stringify(this.scars, null, 2));
  }

  async getEmbedding(text: string): Promise<number[]> {
    if (!text || text.trim() === '') {
      throw new Error("CRYPTO_BACKEND_UNAVAILABLE: Admissible execution aborted. Empty request.");
    }

    const apiKey = (import.meta as any).env ? (import.meta as any).env.VITE_GEMINI_API_KEY : process.env.VITE_GEMINI_API_KEY;
    if (!apiKey || apiKey === "demo_mode") {
      return Array(768).fill(0.1); // Mock embedding
    }
    
    try {
      const aiAny = this.ai as unknown as { 
        models: { 
          embedContent: (params: { model: string; contents: string }) => Promise<{ embeddings: { values: number[] }[] }> 
        } 
      };
      const result = await aiAny.models.embedContent({
        model: 'gemini-embedding-2-preview',
        contents: text,
      });
      return result.embeddings[0].values || [];
    } catch (error: any) {
      throw new Error("CRYPTO_BACKEND_UNAVAILABLE: Admissible execution aborted. " + error.message);
    }
  }

  async recordScar(description: string, severity: string, fixAction: string) {
    const embedding = await this.getEmbedding(description);
    
    let severityLevel = 1;
    let severityColor = '#4CAF50';

    if (severity === 'HIGH') {
      severityLevel = 3;
      severityColor = '#F44336';
    } else if (severity === 'MEDIUM') {
      severityLevel = 2;
      severityColor = '#FFC107';
    }

    const scar: Scar = {
      id: Math.random().toString(36).substring(7),
      description,
      embedding,
      severity,
      severityLevel,
      severityColor,
      fixAction,
      timestamp: Date.now()
    };
    this.scars.push(scar);
    this.saveScars();
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Phase 2] Permanent Scar Recorded: ${severity} severity (Level ${severityLevel}).`);
  }

  /**
   * Checks if current thought is near a historical failure.
   */
  async proactiveSearch(currentIntent: string): Promise<{ found: boolean; scar?: Scar; similarity: number; severity?: string }> {
    if (this.scars.length === 0) return { found: false, similarity: 0 };

    const queryEmbedding = await this.getEmbedding(currentIntent);
    
    let bestMatch: Scar | null = null;
    let maxSimilarity = -1;

    for (const scar of this.scars) {
      const sim = cosineSimilarity(queryEmbedding, scar.embedding);
      if (sim > maxSimilarity) {
        maxSimilarity = sim;
        bestMatch = scar;
      }
    }

    // If similarity is high, the 'thought' is too close to a past mistake
    // Threshold 0.85 (or 0.4 distance as per PDF)
    if (maxSimilarity > 0.85) {
      return { 
        found: true, 
        scar: bestMatch!, 
        similarity: maxSimilarity,
        severity: bestMatch!.severity
      };
    }

    return { found: false, similarity: maxSimilarity };
  }
}
