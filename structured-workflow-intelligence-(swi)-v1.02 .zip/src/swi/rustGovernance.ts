import { v4 as uuidv4 } from 'uuid';

export type RustState = 
  | 'Active'
  | 'Stable'
  | 'Dormant'
  | 'Rusting'
  | 'Rust'
  | 'Archived'
  | 'Reactivated';

export interface GovernanceHistoryEntry {
  timestamp: Date;
  previousState: RustState;
  newState: RustState;
  reason: string;
}

export interface KnowledgeObject {
  id: string;
  content: string;
  confidence: number;
  evidence_score: number;
  governance_score: number;
  importance_score: number;
  usage_frequency: number;
  last_used: Date;
  last_validated: Date;
  rust_factor: number;
  patina_factor: number;
  state: RustState;
  history: GovernanceHistoryEntry[];
}

export interface GovernanceDecision {
  previousState: RustState;
  newState: RustState;
  rustDelta: number;
  patinaDelta: number;
  reason: string;
}

export interface RustGovernance {
  evaluate(object: KnowledgeObject): GovernanceDecision;
  rust(id: string): void;
  reactivate(id: string, newEvidenceScore: number): void;
  archive(id: string): void;
  validate(id: string, evidenceStrength: number): void;
  forceState(id: string, newState: RustState, reason: string): void;
  getObject(id: string): KnowledgeObject | undefined;
  getAllObjects(): KnowledgeObject[];
}

export class RustGovernanceEngine implements RustGovernance {
  private memoryStore: Map<string, KnowledgeObject> = new Map();

  // Rust = (Time - Evidence - Usage - Governance Priority - Current Relevance)
  // Patina increases when knowledge is consistently validated over long periods across contexts.

  constructor() {
    this.seedInitialKnowledge();
  }

  private seedInitialKnowledge() {
    const now = new Date();
    const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixMonthsAgo = new Date(now.getTime() - 180 * 24 * 60 * 60 * 1000);
    const oneYearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);

    this.addKnowledge({
      content: "Human safety override protocols are inviolable.",
      last_validated: now,
      last_used: now,
      evidence_score: 0.99,
      governance_score: 1.0,
      importance_score: 1.0,
      usage_frequency: 1500,
      rust_factor: 0,
      patina_factor: 0.85,
      state: 'Stable'
    });

    this.addKnowledge({
      content: "Initial testing parameters for Alpha framework",
      last_validated: sixMonthsAgo,
      last_used: sixMonthsAgo,
      evidence_score: 0.4,
      governance_score: 0.2,
      importance_score: 0.3,
      usage_frequency: 5,
      rust_factor: 0.6,
      patina_factor: 0.05,
      state: 'Rusting'
    });

    this.addKnowledge({
      content: "Legacy network topology configuration v1.2",
      last_validated: oneYearAgo,
      last_used: oneYearAgo,
      evidence_score: 0.1,
      governance_score: 0.1,
      importance_score: 0.1,
      usage_frequency: 1,
      rust_factor: 0.95,
      patina_factor: 0,
      state: 'Rust'
    });

    this.addKnowledge({
      content: "Deprecated consensus algorithm (Replaced by BFT-2)",
      last_validated: oneYearAgo,
      last_used: oneYearAgo,
      evidence_score: 0.2,
      governance_score: 0.0,
      importance_score: 0.0,
      usage_frequency: 0,
      rust_factor: 1.0,
      patina_factor: 0,
      state: 'Archived'
    });

    this.addKnowledge({
      content: "Foundational Principle: Structural Reality Binding",
      last_validated: oneMonthAgo,
      last_used: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000),
      evidence_score: 0.95,
      governance_score: 0.9,
      importance_score: 0.95,
      usage_frequency: 850,
      rust_factor: 0.02,
      patina_factor: 0.6,
      state: 'Active'
    });
  }

  private addKnowledge(partial: Omit<KnowledgeObject, 'id' | 'confidence' | 'history'>) {
    const id = uuidv4();
    this.memoryStore.set(id, {
      id,
      confidence: (partial.evidence_score + partial.governance_score) / 2,
      ...partial,
      history: [{
        timestamp: new Date(),
        previousState: partial.state,
        newState: partial.state,
        reason: 'Initial object creation and seeding.'
      }]
    });
  }

  evaluate(object: KnowledgeObject): GovernanceDecision {
    const previousState = object.state;
    const now = new Date();
    
    // Calculate Time factor (Days since last validation)
    const daysSinceValidation = (now.getTime() - object.last_validated.getTime()) / (1000 * 60 * 60 * 24);
    const timeDecay = Math.min(daysSinceValidation / 365, 1.0); // Normalize to 1 year max
    
    // Rust Equation: Rust = (Time - Evidence - Usage - Governance Priority - Current Relevance)
    // We normalize usage to a 0-1 scale. Assuming 100 uses is "high".
    const usageFactor = Math.min(object.usage_frequency / 100, 1.0);
    
    const rawRust = timeDecay - (object.evidence_score * 0.3) - (usageFactor * 0.2) - (object.governance_score * 0.3) - (object.importance_score * 0.2);
    
    // Ensure rust is between 0 and 1
    const newRustFactor = Math.max(0, Math.min(1, object.rust_factor + rawRust * 0.1)); // Apply incrementally
    const rustDelta = newRustFactor - object.rust_factor;
    
    // Calculate Patina (Increases with continuous high validation and usage over time)
    let newPatinaFactor = object.patina_factor;
    let patinaDelta = 0;
    
    if (object.evidence_score > 0.8 && object.governance_score > 0.8 && daysSinceValidation < 30) {
        newPatinaFactor = Math.min(1.0, object.patina_factor + 0.05); // Grow patina
    } else if (daysSinceValidation > 90) {
        newPatinaFactor = Math.max(0, object.patina_factor - 0.02); // Slowly lose patina if not validated
    }
    patinaDelta = newPatinaFactor - object.patina_factor;

    // Determine new state based on Rust and Patina
    let newState = previousState;
    
    if (previousState === 'Archived') {
        // Stays archived unless explicitly reactivated
        newState = 'Archived';
    } else if (newRustFactor >= 0.9) {
        newState = 'Rust';
    } else if (newRustFactor >= 0.6) {
        newState = 'Rusting';
    } else if (newRustFactor >= 0.3 && usageFactor < 0.2) {
        newState = 'Dormant';
    } else if (newPatinaFactor > 0.5 && newRustFactor < 0.2) {
        newState = 'Stable';
    } else if (newRustFactor < 0.3 && usageFactor >= 0.2) {
        newState = 'Active';
    } else if (previousState === 'Reactivated' && newRustFactor < 0.3) {
         // keep it reactivated to show the history until it becomes stable
        if (newPatinaFactor > 0.3) {
            newState = 'Stable';
        }
    }

    object.rust_factor = newRustFactor;
    object.patina_factor = newPatinaFactor;
    object.state = newState;
    object.confidence = (object.evidence_score + object.governance_score) / 2 + (newPatinaFactor * 0.2) - (newRustFactor * 0.2);
    object.confidence = Math.max(0, Math.min(1, object.confidence));
    
    const reason = `Evaluated at T+${daysSinceValidation.toFixed(1)} days. Rust delta: ${rustDelta.toFixed(3)}, Patina delta: ${patinaDelta.toFixed(3)}.`;
    
    if (newState !== previousState) {
        if (!object.history) object.history = [];
        object.history.unshift({
            timestamp: now,
            previousState,
            newState,
            reason
        });
    }

    this.memoryStore.set(object.id, object);

    return {
      previousState,
      newState,
      rustDelta,
      patinaDelta,
      reason
    };
  }

  tickGovernanceCycle() {
      const results: {id: string, decision: GovernanceDecision}[] = [];
      this.memoryStore.forEach((obj) => {
          if (obj.state !== 'Archived') {
             const decision = this.evaluate(obj);
             if (decision.previousState !== decision.newState || Math.abs(decision.rustDelta) > 0.01) {
                 results.push({ id: obj.id, decision });
             }
          }
      });
      return results;
  }

  rust(id: string): void {
    const obj = this.memoryStore.get(id);
    if (obj) {
      obj.rust_factor = Math.min(1.0, obj.rust_factor + 0.2);
      this.evaluate(obj);
    }
  }

  reactivate(id: string, newEvidenceScore: number): void {
    const obj = this.memoryStore.get(id);
    if (obj) {
      const previousState = obj.state;
      obj.evidence_score = newEvidenceScore;
      obj.last_validated = new Date();
      obj.rust_factor = Math.max(0, obj.rust_factor - 0.5); // Remove significant rust
      obj.state = 'Reactivated';
      obj.usage_frequency += 1;
      
      if (previousState !== 'Reactivated') {
        if (!obj.history) obj.history = [];
        obj.history.unshift({
          timestamp: new Date(),
          previousState,
          newState: 'Reactivated',
          reason: 'Manual reactivation from evidence alert.'
        });
      }

      this.evaluate(obj);
    }
  }

  archive(id: string): void {
    const obj = this.memoryStore.get(id);
    if (obj) {
      const previousState = obj.state;
      if (previousState !== 'Archived') {
        obj.state = 'Archived';
        if (!obj.history) obj.history = [];
        obj.history.unshift({
          timestamp: new Date(),
          previousState,
          newState: 'Archived',
          reason: 'Manual archival.'
        });
        this.memoryStore.set(id, obj);
      }
    }
  }

  validate(id: string, evidenceStrength: number): void {
     const obj = this.memoryStore.get(id);
     if (obj) {
        obj.evidence_score = Math.min(1.0, obj.evidence_score + evidenceStrength);
        obj.last_validated = new Date();
        obj.usage_frequency += 1;
        this.evaluate(obj);
     }
  }

  forceState(id: string, newState: RustState, reason: string): void {
    const obj = this.memoryStore.get(id);
    if (obj) {
      const previousState = obj.state;
      obj.state = newState;
      if (newState === 'Rust') obj.rust_factor = Math.max(obj.rust_factor, 0.9);
      if (newState === 'Rusting') obj.rust_factor = Math.max(obj.rust_factor, 0.6);
      if (newState === 'Archived') obj.rust_factor = 1.0;
      if (newState === 'Active') obj.rust_factor = Math.min(obj.rust_factor, 0.2);
      if (newState === 'Stable') {
          obj.rust_factor = 0;
          obj.patina_factor = Math.max(obj.patina_factor, 0.6);
      }
      
      if (previousState !== newState) {
        if (!obj.history) obj.history = [];
        obj.history.unshift({
          timestamp: new Date(),
          previousState,
          newState,
          reason: `Forced State Transition: ${reason}`
        });
      }

      this.memoryStore.set(id, obj);
      
      console.log(`[Governance Audit] Object ${id} forced to state ${newState}. Reason: ${reason}`);
    }
  }

  getObject(id: string): KnowledgeObject | undefined {
    return this.memoryStore.get(id);
  }

  getAllObjects(): KnowledgeObject[] {
    return Array.from(this.memoryStore.values());
  }
}

export const rustGovernanceEngine = new RustGovernanceEngine();
