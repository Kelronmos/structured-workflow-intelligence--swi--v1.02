import crypto from "crypto";
import { silentReboot, logEvent, generateReport, getLiveReport, resetS9 } from "./s9";
import { validateAgainstExternalPolicy } from "./policyAnchor";
import { securityCheck, evaluateMaze } from "./securityCheck";
import { hasSeen, store, mutateContext } from "./scenarioMemory";
import { learn } from "./commonsenseEngine";

const MAX_COUNTDOWN = 100;
const SIMULATION_RANGE = { min: -70, max: 70 };

function sign(data: unknown) {
  return crypto.createHash("sha256").update(JSON.stringify(data)).digest("hex");
}

function evaluateRisk(value: number) {
  if (value < -30) return "HIGH";
  if (value < 0) return "MEDIUM";
  return "LOW";
}

function simulateOutcomes() {
  const outcomes = [];
  for (let i = SIMULATION_RANGE.min; i <= SIMULATION_RANGE.max; i += 10) {
    const risk = evaluateRisk(i);
    outcomes.push({ value: i, risk });
  }
  return outcomes;
}

// Removed unused autoFixDiagnosis

function processHumanInput(input: { value: number }, attempts: number) {
  const risk = evaluateRisk(input.value);
  if (risk === "HIGH" && attempts < 3) {
    return {
      accepted: false,
      retry: true,
      message: `Risk too high. Attempts left: ${3 - attempts}`
    };
  }
  return { accepted: true, input };
}

// --- MEMORY STORE (Scarmatic Layer) ---
export const ScarmaticMemory = {
  history: [] as { selected: { risk: string } }[],
  patterns: {} as Record<string, number>,

  store(entry: { selected: { risk: string } }) {
    this.history.push(entry);

    // Learn simple pattern: risk frequency
    const key = entry.selected.risk;
    this.patterns[key] = (this.patterns[key] || 0) + 1;
  },

  getInsights() {
    return this.patterns;
  },

  reset() {
    this.history = [];
    this.patterns = {};
  }
};

// --- LEARNING ENGINE ---
function learnFromCycle(cycleData: { selected: { risk: string } }) {
  ScarmaticMemory.store(cycleData);
  return ScarmaticMemory.getInsights();
}

// --- FUTURE SIMULATION BUILDER ---
function buildFutureScenarios(currentState: { value?: number }) {
  const scenarios = [];

  // Predict based on learned risk distribution
  for (let i = 0; i < 5; i++) {
    const predictedValue = (currentState.value || 0) + (Math.random() * 40 - 20);

    scenarios.push({
      predictedValue,
      predictedRisk: evaluateRisk(predictedValue),
    });
  }

  return scenarios;
}

// --- CONTINUOUS ADAPTIVE SIMULATION ---
function adaptiveSimulation(state: { value?: number }) {
  const scenarios = buildFutureScenarios(state);

  // Choose best predicted scenario
  const best = scenarios.find(s => s.predictedRisk === "LOW") || scenarios[0];

  return { best, scenarios };
}

export interface MazeArtifact {
  countdown: number;
  state: SWIInput;
  selected: { value: number; risk: string; generated?: boolean };
  signature: string;
  event?: string;
  humanInput?: { accepted: boolean; input?: { value: number }; retry?: boolean; message?: string } | null;
  fix?: { fixed: boolean; reboot?: boolean; note?: string };
  outcomes?: { value: number; risk: string }[];
  insights?: Record<string, number>;
  futureScenarios?: { predictedValue: number; predictedRisk: string }[];
  predictedDecision?: { predictedValue: number; predictedRisk: string };
  s9?: { active: boolean; rebooting: boolean; totalLogs: number };
  reportFile?: string;
  simulationCount?: number;
  mazeHash?: string;
  riskScore?: number;
}

import { SWIInput, Trace } from './types';

export async function* runSecurityMaze(initialInput: SWIInput) {
  // 🔐 1) HARDENED SECURITY MAZE (MULTI-LAYER VALIDATION)
  const maze = securityCheck(initialInput);
  if (!evaluateMaze(maze)) {
    yield {
      countdown: MAX_COUNTDOWN,
      state: initialInput,
      selected: { risk: maze.risk, value: 0 },
      signature: "ERROR",
      event: `SECURITY_VIOLATION: Security Maze rejection | FAILED: ${maze.failed.join(", ")}`,
      mazeHash: maze.hash,
      riskScore: maze.riskScore
    };
    return;
  }

  // 🔁 3) NON-REPEATING SCENARIO ENGINE
  if (hasSeen(maze.hash)) {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "🔁 Pattern repeated in Maze. Mutating context...");
    mutateContext(initialInput);
  }
  store(maze.hash);

  ScarmaticMemory.reset();
  resetS9();
  let state: SWIInput = { ...initialInput };
  let countdown = MAX_COUNTDOWN;
  let attempts = 0;
  let simulationCount = 0;
  const TARGET_SIMULATIONS = 18000000;

  while (true) {
    let event: string | undefined;
    let reportFile: string | undefined;
    
    // --- S9: SILENT REBOOT + INNOVATION (NO PAUSE) ---
    if (Math.random() < 0.15 || simulationCount % 1000000 === 0) {
      // Innovation: Mutate state based on learned insights during reboot
      const insights = ScarmaticMemory.getInsights();
      const innovation = {
        type: "INNOVATION",
        basis: insights,
        mutation: Math.random() > 0.5 ? "ADAPTIVE_EXPANSION" : "RISK_MITIGATION"
      };
      
      silentReboot({ ...state, innovation });
      event = `S9_SILENT_REBOOT_WITH_INNOVATION_${innovation.mutation}`;
      
      // Apply immediate innovation to current state
      if (state.value !== undefined) {
        state.value += (Math.random() * 20 - 10);
      }
    }

    // --- HIGH-SCALE SIMULATION STEP ---
    // We simulate a batch of simulations to reach the 18M target efficiently
    const batchSize = Math.floor(Math.random() * 50000) + 10000;
    simulationCount += batchSize;
    if (simulationCount >= TARGET_SIMULATIONS) {
      simulationCount = 0;
      event = event ? `${event} | TARGET_18M_REACHED_RESTARTING` : "TARGET_18M_REACHED_RESTARTING";
    }

    // --- SIMULATION ---
    const outcomes = simulateOutcomes();
    
    // --- EXTERNAL POLICY FILTER ---
    const filteredOutcomes = outcomes.map(o => {
      const policyCheck = validateAgainstExternalPolicy(o);
      if (!policyCheck.valid) {
        return { ...o, risk: "HIGH", policyViolation: policyCheck.reason };
      }
      return o;
    });

    const highRiskOnly = filteredOutcomes.every(o => o.risk === "HIGH");

    // --- CREATE THIRD OPTION IF ALL BAD ---
    let selected;
    if (highRiskOnly) {
      selected = { value: 10, risk: "LOW", generated: true };
      event = event ? `${event} | FALLBACK_GENERATED` : "FALLBACK_GENERATED";
    } else {
      selected = filteredOutcomes.find(o => o.risk === "LOW") || filteredOutcomes[0];
    }

    // --- HUMAN INTERVENTION WINDOW ---
    let humanInputResult: { accepted: boolean; input?: { value: number }; retry?: boolean; message?: string } | null = null;
    if (countdown % 20 === 0) {
      const simulatedHumanInput = { value: Math.floor(Math.random() * 100) - 50 };
      humanInputResult = processHumanInput(simulatedHumanInput, attempts);

      if (!humanInputResult.accepted) {
        attempts++;
      } else if (humanInputResult && humanInputResult.input) {
        state = { ...state, value: humanInputResult.input.value };
      }
    }

    // --- LEARNING STEP ---
    const cycleData = { countdown, state, selected };
    const insights = learnFromCycle(cycleData);

    // 🧠 4) COMMONSENSE ENGINE
    learn({
      decision: selected.risk === "HIGH" ? "REFUSE" : "ALLOW",
      artifactId: `MAZE-${Date.now()}`,
      timestamp: Date.now(),
      signature: "MAZE_SIG",
      provenance: "SWI_MAZE_V1",
      drift: { score: selected.risk === "HIGH" ? 0.8 : 0.2, degraded: selected.risk === "HIGH" },
      reason: `Cycle ${countdown} execution`
    } as unknown as Trace);

    // --- S9: LOG EVENT CONTINUOUSLY ---
    logEvent({
      type: "CYCLE",
      countdown,
      state,
      selected,
      insights
    });

    // --- S9: GENERATE REPORT SNAPSHOT ---
    if (countdown % 30 === 0) {
      const report = generateReport();
      reportFile = report.fileName;
      event = event ? `${event} | S9_REPORT_GENERATED` : "S9_REPORT_GENERATED";
    }

    // --- FUTURE SIMULATION ---
    const { best: futureDecision, scenarios: futureScenarios } = adaptiveSimulation(state);

    // --- LOG ARTIFACT ---
    const artifact: MazeArtifact = {
      countdown,
      state,
      selected,
      signature: sign({ countdown, state, selected }),
      event,
      humanInput: humanInputResult,
      outcomes,
      insights: { ...insights },
      futureScenarios,
      predictedDecision: futureDecision,
      s9: getLiveReport(),
      reportFile,
      simulationCount
    };

    yield artifact;

    // Update system direction without stopping runtime (Predictive Adaptation)
    state = {
      ...state,
      value: futureDecision.predictedValue
    };

    // --- ADAPTIVE SPEED (AGENCY CONTROL) ---
    // Slow down for high risk events to allow for visualization/analysis
    const speed = selected.risk === "HIGH" ? 800 : selected.risk === "MEDIUM" ? 300 : 100;
    await new Promise(res => setTimeout(res, speed));

    countdown--;
    // Prevent countdown from becoming too negative
    if (countdown < -1000000) countdown = MAX_COUNTDOWN;
  }
}
