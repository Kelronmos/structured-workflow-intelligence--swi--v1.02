import crypto from 'crypto';

export interface Block {
  index: number;
  timestamp: string;
  payload: unknown;
  burden: number;
  metadata: Record<string, unknown>;
  previousHash: string;
  hash: string;
}

const ledger: Block[] = [];

export function calculateHash(block: Omit<Block, 'hash'>): string {
  const data = block.index + block.timestamp + JSON.stringify(block.payload) + block.burden + JSON.stringify(block.metadata) + block.previousHash;
  return crypto.createHash('sha256').update(data).digest('hex');
}

export function mint_block(payload: unknown, burden: number, metadata: Record<string, unknown>): Block {
  const previousBlock = ledger[ledger.length - 1];
  const previousHash = previousBlock ? previousBlock.hash : '0';
  const index = ledger.length;
  const timestamp = new Date().toISOString();

  const newBlock: Omit<Block, 'hash'> = {
    index,
    timestamp,
    payload,
    burden,
    metadata,
    previousHash,
  };

  const hash = calculateHash(newBlock);
  const block: Block = { ...newBlock, hash };

  ledger.push(block);
  console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[LEDGER] [STREAM-B] Minted block ${block.index}: ${block.hash} (Burden: ${burden.toFixed(2)})`);
  return block;
}

export function getLedger(): Block[] {
  return [...ledger];
}
