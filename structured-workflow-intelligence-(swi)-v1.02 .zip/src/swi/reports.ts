import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';

export async function generatePDF(reportData: Record<string, unknown>, filename: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const reportsDir = path.join(process.cwd(), 'reports');
    if (!fs.existsSync(reportsDir)) {
      fs.mkdirSync(reportsDir);
    }

    const filePath = path.join(reportsDir, filename);
    const doc = new PDFDocument();
    const stream = fs.createWriteStream(filePath);

    doc.pipe(stream);

    doc.fontSize(20).text('SWI Execution Audit Report', { align: 'center' });
    doc.moveDown();

    doc.fontSize(12).text(`Generated on: ${new Date().toISOString()}`);
    doc.moveDown();

    for (const [key, value] of Object.entries(reportData)) {
      doc.fontSize(10).font('Helvetica-Bold').text(`${key}: `, { continued: true })
         .font('Helvetica').text(typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value));
      doc.moveDown(0.5);
    }

    doc.end();

    stream.on('finish', () => {
      resolve(filePath);
    });

    stream.on('error', (err) => {
      reject(err);
    });
  });
}
