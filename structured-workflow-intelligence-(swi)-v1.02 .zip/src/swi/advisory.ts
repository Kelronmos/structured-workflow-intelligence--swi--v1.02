import { SWIInput, ExecutionKernelResult, AdvisoryResult } from './types';

export class AdvisoryEngine {
  challenge(request: SWIInput, kernelResult: ExecutionKernelResult): AdvisoryResult {
    const concerns: string[] = [];

    if ((request.amount || 0) > 800) {
      concerns.push("High-value transaction — verify intent");
    }

    if (!request.user_verified) {
      concerns.push("User not verified — potential identity risk");
    }

    if (kernelResult.status === "ALLOW" && concerns.length > 0) {
      return {
        advisory: true,
        concerns,
        resolutionCertainty: "LOW"
      };
    }

    return {
      advisory: false,
      concerns: [],
      resolutionCertainty: "HIGH"
    };
  }
}
