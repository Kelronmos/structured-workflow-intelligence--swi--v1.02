import { AuditBlock, NodeState } from './AuditTypes';
import { ProofOfContinuationEngine } from './ProofOfContinuationEngine';
import { AuditValidator } from './AuditValidator';

export class SWIAuditLedger {
  private chain: AuditBlock[] = [];
  private engine: ProofOfContinuationEngine;

  constructor(nodeIds: string[]) {
    this.engine = new ProofOfContinuationEngine(nodeIds);
  }

  tryCommit(event: { id: string; type: string; sourceNode?: string; payload?: unknown }, nodes: NodeState[]) {
    // 1. compute consensus
    const result = this.engine.decide(nodes);

    // 2. BLOCK if not final
    if (result === "PENDING") {
      return {
        status: "WAITING_CONSENSUS",
        chain: this.chain
      };
    }

    // 3. build immutable block ONLY on finality
    const prev = this.chain[this.chain.length - 1];

    const block: Partial<AuditBlock> = {
      index: prev ? prev.index + 1 : 0,
      timestamp: Date.now(),

      eventId: event.id,
      eventType: event.type,

      sourceNode: event.sourceNode || "SYSTEM",

      payloadHash: this.hash(event.payload || event),
      previousHash: prev?.hash || "GENESIS",
      stateRoot: this.computeStateRoot(event),

      blsSignature: this.aggregateBLS(nodes),

      consensus: {
        approved: nodes.filter(n => n.auth === "VALID").length,
        rejected: nodes.filter(n => n.auth === "INVALID").length,
        quorum: Math.ceil(nodes.length * 0.66),
        result: result as "APPROVED" | "REJECTED"
      },

      nonce: Math.floor(Math.random() * 1e6),
    };

    // Compute hash for indexing
    block.hash = this.hash(block);

    // Validate strictly before pushing
    try {
      const validatedBlock = AuditValidator.validate(block);
      
      // Final integrity check
      if (!this.isValid(validatedBlock)) {
        throw new Error("BLOCK_REJECTED: integrity failure (previous hash mismatch)");
      }

      this.chain.push(validatedBlock);

      return {
        status: "COMMITTED",
        block: validatedBlock,
        chain: this.chain
      };
    } catch (err) {
      return {
        status: "REJECTED",
        error: (err as Error).message,
        chain: this.chain
      };
    }
  }

  private hash(data: unknown) {
    const str = JSON.stringify(data);
    let h = 0;

    for (let i = 0; i < str.length; i++) {
      h = (h << 5) - h + str.charCodeAt(i);
      h |= 0;
    }

    return h.toString(16);
  }

  private computeStateRoot(event: unknown) {
    return this.hash({ event, timestamp: Date.now(), version: "1.0.0" });
  }

  private aggregateBLS(nodes: NodeState[]) {
    return `BLS(${nodes.map(n => n.auth).join("|")})`;
  }

  private isValid(block: AuditBlock): boolean {
    if (this.chain.length === 0) return block.previousHash === "GENESIS";

    const prev = this.chain[this.chain.length - 1];

    return (
      block.previousHash === prev.hash &&
      block.index === prev.index + 1
    );
  }

  getChain() {
    return this.chain;
  }

  getEngine() {
    return this.engine;
  }
}
