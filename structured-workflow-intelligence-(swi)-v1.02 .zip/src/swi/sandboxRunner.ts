import { evaluateContinuation } from "./engine";
import { buildFireflyArtifact } from "./fireflyStore";
import { learn } from "./commonsenseEngine";
import { signRoot } from "./swiCA";

import { SWIInput, Trace } from "./types";
import { SimulationParams } from "../types";

/**
 * Sandbox Engine - Hidden and continuous.
 * Runs new scenarios, evolves drift, and learns from results.
 */

export function runSandboxScenario(input: SWIInput): Trace {
  // 1. Evaluate continuation (the core logic)
  const result = evaluateContinuation(input) as unknown as Trace;

  // 2. Build Merkle artifact
  const artifact = buildFireflyArtifact(result);

  // 3. Sign the Merkle root
  const signature = signRoot(artifact.rootHash);

  // 4. Learning happens here only
  learn(result as unknown as Trace);

  return {
    decision: result.decision,
    artifactId: artifact.rootHash,
    timestamp: new Date().toISOString(),
    signature: signature,
    provenance: 'SANDBOX_SWI_V1',
    reason: result.reason,
    violation_type: result.violation_type,
    input: input as unknown as SimulationParams,
    action: input.action,
    tokenValid: result.tokenValid,
    locallyValid: result.locallyValid,
    drift: result.drift,
    context: result.context,
    metadata: result.metadata,
    modules: result.modules
  };
}
