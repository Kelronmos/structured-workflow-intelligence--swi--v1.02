import fs from 'fs';
import path from 'path';

import { Trace } from '../types';

const FILE = path.join(process.cwd(), 'commonsense.json');

interface CommonsensePattern {
  drift: number;
  decision: string;
  reason: string;
  timestamp: string;
}

export function load(): CommonsensePattern[] {
  if (!fs.existsSync(FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return [];
  }
}

export function save(data: CommonsensePattern[]) {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2));
}

export function shouldLearn(result: Trace) {
  return result.decision === "REFUSE" && (result.drift?.score || 0) > 0.6;
}

export function learn(result: Trace) {
  if (!shouldLearn(result)) return;

  const data = load();

  const pattern: CommonsensePattern = {
    drift: result.drift?.score || 0,
    decision: result.decision,
    reason: result.reason,
    timestamp: new Date().toISOString()
  };

  data.push(pattern);
  save(data);
}

export function analyze() {
  const data = load();

  const refuseCases = data.filter((d: CommonsensePattern) => d.decision === "REFUSE");

  const avgDrift =
    refuseCases.reduce((sum: number, d: CommonsensePattern) => sum + d.drift, 0) /
    (refuseCases.length || 1);

  return {
    totalCases: data.length,
    refusalRate: refuseCases.length / (data.length || 1),
    avgRefusalDrift: avgDrift
  };
}
