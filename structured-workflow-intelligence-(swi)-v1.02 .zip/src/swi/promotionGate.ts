import { verifyRoot } from "./swiCA";
import { Trace } from "./types";


/**
 * Promotion Gate - Prevents chaos by ensuring only verified states move to the display layer.
 */

export function promote(candidate: { artifact: { rootHash: string }; result: Trace; signature: string }) {
  const { artifact, result, signature } = candidate;

  // Verify signature of the Merkle root
  const isSignatureValid = verifyRoot(artifact.rootHash, signature);

  // Verify drift and decision
  const isDriftSafe = (result.drift?.score || 0) < 0.7;
  const isDecisionStable = result.decision !== "REFUSE";

  const valid = isSignatureValid && isDriftSafe && isDecisionStable;

  if (!valid) {
    return { promoted: false };
  }

  return {
    promoted: true,
    state: {
      ...result,
      verificationState: "SIMULATED",
      rootHash: artifact.rootHash,
      signature: signature
    }
  };
}

function cryptographicallyVerify(signature: string, hash: string): boolean {
  return verifyRoot(hash, signature);
}
