/**
 * Chapter 5: The 46 Modules
 */

export class PreModuleP1 {
  status: string = "Inactive";
  heartbeat: number = 0.0;
  patches: string[] = [];

  bootstrap() {
    this.status = "Active";
    this.heartbeat = 1.0;
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "P1 initialized: heartbeat =", this.heartbeat);
  }

  loadPatch(patchName: string) {
    this.patches.push(patchName);
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `Patch ${patchName} loaded into P1`);
  }
}

export class PreModuleP2 {
  status: string = "Inactive";
  policyPatches: Record<string, { rules: string[]; weights: number[] }> = {};

  initialize() {
    this.status = "Active";
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "P2 initialized");
  }

  loadPolicyPatch(policyName: string, rules: string[], weights: number[]) {
    this.policyPatches[policyName] = { rules, weights };
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `Policy ${policyName} loaded with weights ${weights}`);
  }

  evaluateAction(policyName: string): string {
    const policy = this.policyPatches[policyName];
    if (!policy) return "Policy not found";

    const score = policy.weights.reduce((sum, w) => sum + w, 0) / policy.rules.length;
    return score >= 0.5 ? "Action approved" : "Action blocked";
  }
}

export class SecurityModuleS1 {
  errors: string[] = [];
  heartbeat: number = 0.0;
  maxErrors: number = 10;

  initialize() {
    this.heartbeat = 1.0;
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "S1 Security Monitor initialized");
  }

  logError(error: string) {
    this.errors.push(error);
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `Error logged: ${error}`);
  }

  integrityScore(): number {
    return 1 - this.errors.length / this.maxErrors;
  }
}

export class SecurityModuleS2 {
  private submodules: (PreModuleP1 | PreModuleP2 | SecurityModuleS1)[];

  constructor(submodules: (PreModuleP1 | PreModuleP2 | SecurityModuleS1)[]) {
    this.submodules = submodules;
  }

  checkIntegrity(): number {
    const weights = [0.2, 0.3, 0.5]; // Example weights
    const scores = this.submodules.map(sm => {
      if ('status' in sm) {
        return (sm as { status: string }).status === "Active" ? 1 : 0;
      }
      if ('heartbeat' in sm) {
        return (sm as { heartbeat: number }).heartbeat > 0 ? 1 : 0;
      }
      return 0;
    });
    const integrity = scores.reduce((sum: number, s, i) => sum + (weights[i] || 0.1) * s, 0);
    return integrity;
  }
}
