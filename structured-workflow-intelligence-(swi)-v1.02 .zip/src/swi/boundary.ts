import { Continuation } from './continuation';

export class RuntimeHooks {
  preExecution(continuation: Continuation) {
    if (continuation.kernel_result.status !== "ALLOW") {
      throw new Error("Blocked at pre-execution");
    }
  }

  midExecution(continuation: Continuation) {
    // simulate checkpoint validation
    if (!continuation.request.user_verified) {
      throw new Error("Mid-execution failure");
    }
  }

  postExecution(result: string) {
    return `[VALIDATED OUTPUT]: ${result}`;
  }
}

export class ExecutionBoundary {
  private hooks: RuntimeHooks;

  constructor() {
    this.hooks = new RuntimeHooks();
  }

  execute(continuation: Continuation, signature: string, func: () => string): string {
    if (!Continuation.verify(continuation, signature)) {
      throw new Error("Signature mismatch");
    }

    // Commit-bound enforcement: function name must match
    if (continuation.constraints.function !== func.name) {
       throw new Error(`Function mismatch: expected ${continuation.constraints.function}, got ${func.name}`);
    }

    this.hooks.preExecution(continuation);
    this.hooks.midExecution(continuation);

    const result = func();

    return this.hooks.postExecution(result);
  }
}
