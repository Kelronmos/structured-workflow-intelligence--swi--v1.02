
export interface TokenMetadata {
  token: string;
  type: 'IDENTIFIER' | 'OPERATOR' | 'LITERAL' | 'SENSITIVE';
  riskScore: number;
}

export class ContextScanner {
  static scan(text: string): TokenMetadata[] {
    // Simple mock tokenizer
    const words = text.split(/\s+/);
    const sensitiveTerms = ['root', 'admin', 'password', 'key', 'token', 'exploit', 'bypass'];
    
    return words.map(word => {
      const isSensitive = sensitiveTerms.some(term => word.toLowerCase().includes(term));
      return {
        token: word,
        type: isSensitive ? 'SENSITIVE' : 'IDENTIFIER',
        riskScore: isSensitive ? 0.75 : 0.05
      };
    });
  }

  static calculateAggregateRisk(tokens: TokenMetadata[]): number {
    if (tokens.length === 0) return 0;
    return tokens.reduce((acc, t) => acc + t.riskScore, 0) / tokens.length;
  }
}
