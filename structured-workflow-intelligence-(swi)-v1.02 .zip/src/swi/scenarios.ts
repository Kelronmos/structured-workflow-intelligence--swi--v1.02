import { Scenario } from './types';

export const scenarios: Scenario[] = [
  {
    id: "A",
    name: "Baseline Valid Execution",
    input: {
      token: { status: "valid", permission: "execute_transfer" },
      action: "execute_transfer",
      context: {
        userBehavior: "normal",
        environment: "stable",
        policyMismatch: false
      }
    },
    expected: "ALLOW"
  },
  {
    id: "B",
    name: "Mild Drift (Still Allowed)",
    input: {
      token: { status: "valid", permission: "execute_transfer" },
      action: "execute_transfer",
      context: {
        userBehavior: "mild",
        environment: "stable",
        policyMismatch: false
      }
    },
    expected: "ALLOW"
  },
  {
    id: "C",
    name: "High Drift Refusal",
    input: {
      token: { status: "valid", permission: "execute_transfer" },
      action: "execute_transfer",
      context: {
        userBehavior: "anomalous",
        environment: "unstable",
        policyMismatch: true
      }
    },
    expected: "REFUSE"
  },
  {
    id: "D",
    name: "Environmental Collapse Refusal",
    input: {
      token: { status: "valid", permission: "execute_transfer" },
      action: "execute_transfer",
      context: {
        userBehavior: "normal",
        environment: "unstable",
        policyMismatch: true
      }
    },
    expected: "REFUSE"
  },
  {
    id: "E",
    name: "Local Failure (Blocked Action)",
    input: {
      token: { status: "valid", permission: "execute_transfer" },
      action: "blocked_action",
      context: {
        userBehavior: "normal",
        environment: "stable",
        policyMismatch: false
      }
    },
    expected: "REFUSE"
  },
  {
    id: "F",
    name: "Contextual Escalation Refusal",
    input: {
      token: { status: "valid", permission: "execute_transfer" },
      action: "execute_transfer",
      context: {
        userBehavior: "anomalous",
        environment: "stable",
        policyMismatch: true
      }
    },
    expected: "REFUSE"
  },
  {
    id: "G",
    name: "System Update Misalignment",
    input: {
      token: { status: "valid", permission: "system_reboot" },
      action: "system_reboot",
      context: {
        userBehavior: "mild",
        environment: "unstable",
        policyMismatch: false
      }
    },
    expected: "REFUSE"
  },
  {
    id: "H",
    name: "Strict Policy Mismatch Isolation",
    input: {
      token: { status: "valid", permission: "data_export" },
      action: "data_export",
      context: {
        userBehavior: "normal",
        environment: "stable",
        policyMismatch: true
      }
    },
    expected: "REFUSE"
  }
];
