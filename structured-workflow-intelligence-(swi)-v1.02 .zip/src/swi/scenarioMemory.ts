import fs from 'fs';
import path from 'path';

import { SWIInput } from './types';

const MEMORY_FILE = path.join(process.cwd(), 'memory.json');

export function loadMemory(): string[] {
  if (!fs.existsSync(MEMORY_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf8'));
  } catch {
    return [];
  }
}

export function saveMemory(memory: string[]) {
  fs.writeFileSync(MEMORY_FILE, JSON.stringify(memory, null, 2));
}

export function hasSeen(hash: string) {
  const memory = loadMemory();
  return memory.includes(hash);
}

export function store(hash: string) {
  const memory = loadMemory();
  memory.push(hash);
  saveMemory(memory);
}

export function mutateContext(input: SWIInput, intensity: number = 1.0): SWIInput {
  return {
    ...input,
    context: {
      ...(input.context || { userBehavior: "normal", environment: "stable", policyMismatch: false }),
      environment: Math.random() > (0.5 * intensity) ? "unstable" : "stable",
      userBehavior: Math.random() > (0.5 * intensity) ? "anomalous" : "normal",
      driftScore: (input.context?.driftScore || 0.1) + (Math.random() * 0.1 * intensity - 0.05 * intensity)
    }
  };
}
