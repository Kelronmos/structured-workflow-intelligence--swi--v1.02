import crypto from "crypto";

export function normalizeContext(context: { userBehavior?: string; environment?: string; driftScore?: number } | undefined) {
  return {
    userBehavior: context?.userBehavior || "normal",
    environment: context?.environment || "stable",
    driftScore: typeof context?.driftScore === "number" ? context.driftScore : 0
  };
}

export function hashInput(input: unknown) {
  return crypto.createHash('sha256')
    .update(JSON.stringify(input))
    .digest('hex');
}

import { SWIInput } from './types';

export function securityCheck(input: SWIInput) {
  const context = normalizeContext(input.context);
  const checks = {
    inputIntegrity: !!input && typeof input === "object",
    behavioralCheck: context.userBehavior !== "hostile",
    environmentCheck: context.environment !== "compromised",
    driftCheck: context.driftScore < 0.7,
    schemaCheck: ["userBehavior", "environment", "driftScore"].every(k => k in context)
  };

  // Deterministic scoring vector (weights)
  const weights: Record<string, number> = {
    inputIntegrity: 0.3,
    behavioralCheck: 0.25,
    environmentCheck: 0.3,
    driftCheck: 0.1,
    schemaCheck: 0.05
  };

  const failed = Object.entries(checks).filter(([, v]) => v === false);
  
  // Vector sum: score = Σ(weight_i * violation_i)
  const riskScore = failed.reduce((sum, [k]) => sum + (weights[k] || 0), 0);

  const risk =
    riskScore === 0 ? "LOW" :
    riskScore < 0.4 ? "MEDIUM" :
    "HIGH";

  return {
    checks,
    failed: failed.map(([k]) => k),
    risk,
    riskScore,
    hash: hashInput({ ...input, context })
  };
}

export function evaluateMaze(maze: { risk: string }) {
  return maze.risk !== "HIGH";
}
