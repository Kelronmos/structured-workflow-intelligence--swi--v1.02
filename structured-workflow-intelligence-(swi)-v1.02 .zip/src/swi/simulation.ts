import crypto from "crypto";
import { SWIConfig } from "./types";

// Utility: cryptographic hash for artifact signing
function signArtifact(data: unknown) {
  return crypto.createHash("sha256").update(JSON.stringify(data)).digest("hex");
}

// Base Module Class
export class SWIModule {
  id: string;
  name: string;
  type: string;
  description: string;
  active: boolean;
  artifacts: Record<string, unknown>[];

  constructor(id: string, name: string, type: string, description: string) {
    this.id = id;
    this.name = name;
    this.type = type;
    this.description = description;
    this.active = false;
    this.artifacts = [];
  }

  // Activate module
  activate() {
    this.active = true;
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `Activated Module: [${this.id}] - [${this.name}] ([${this.type}]) - [${this.description}]`);
  }

  // Emit artifact with cryptographic signature
  emitArtifact(signal: unknown, context?: { inputSignal?: unknown, previousOutput?: unknown }) {
    const timestamp = Date.now();
    const artifact = {
      moduleId: this.id,
      moduleName: this.name,
      moduleType: this.type,
      moduleDescription: this.description,
      timestamp,
      signal,
      context: {
        inputSignal: context?.inputSignal,
        // Only include a subset of previous output for brevity
        previousOutput: context?.previousOutput && Array.isArray(context.previousOutput) ? context.previousOutput.slice(0, 5) : context?.previousOutput
      },
      signature: signArtifact({ moduleId: this.id, timestamp, signal, context }),
    };
    this.artifacts.push(artifact);
    return artifact;
  }

  // Placeholder process function (to override)
  process(input: unknown, previousOutput?: unknown): unknown {
    return this.emitArtifact({ status: "processed", input }, { inputSignal: input, previousOutput });
  }
}

export function createSWIModules(config?: SWIConfig) {
  const modules: SWIModule[] = [];

  const shouldInclude = (id: string, type: string) => {
    if (config?.deactivatedTypes?.includes(type)) return false;
    if (config?.deactivatedIds?.includes(id)) return false;
    return true;
  };

  // 1. Premodules P1-P10
  for (let i = 1; i <= 10; i++) {
    const id = `P${i}`;
    const type = "premodule";
    if (shouldInclude(id, type)) {
      modules.push(new SWIModule(id, `Premodule ${i}`, type, `Foundational input and context parsing for stage ${i}`));
    }
  }

  // 2. Security maze S1-S9
  for (let i = 1; i <= 9; i++) {
    const id = `S${i}`;
    const type = "security";
    if (shouldInclude(id, type)) {
      const mod = new SWIModule(id, `Security Maze ${i}`, type, `Execution boundary control and anomaly detection for layer ${i}`);
      mod.process = function (input: unknown, prev: unknown) {
        const anomaly = Math.random() < 0.1; // 10% chance
        const signal = { anomalyDetected: anomaly, input: "Context verified" };
        return this.emitArtifact(signal, { inputSignal: input, previousOutput: prev });
      };
      modules.push(mod);
    }
  }

  // 3. Ethics E1-E7
  for (let i = 1; i <= 7; i++) {
    const id = `E${i}`;
    const type = "ethics";
    if (shouldInclude(id, type)) {
      const mod = new SWIModule(id, `Ethics ${i}`, type, `Behavioral alignment and ethical evaluation for module ${i}`);
      mod.process = function (input: unknown, prev: unknown) {
        const ethicalScore = parseFloat(Math.random().toFixed(2));
        const signal = { ethicalScore, input: "Behavioral alignment checked" };
        return this.emitArtifact(signal, { inputSignal: input, previousOutput: prev });
      };
      modules.push(mod);
    }
  }

  // 4. Governance G1-G7
  for (let i = 1; i <= 7; i++) {
    const id = `G${i}`;
    const type = "governance";
    if (shouldInclude(id, type)) {
      const mod = new SWIModule(id, `Governance ${i}`, type, `Policy adherence and authority chain tracking for unit ${i}`);
      mod.process = function (input: unknown, prev: unknown) {
        const authorityChange = Math.random() < 0.2; // 20% chance
        const signal = { authorityChange, input: "Authority chain validated" };
        return this.emitArtifact(signal, { inputSignal: input, previousOutput: prev });
      };
      modules.push(mod);
    }
  }

  // 5. Law & Policy L1-L6
  for (let i = 1; i <= 6; i++) {
    const id = `L${i}`;
    const type = "law";
    if (shouldInclude(id, type)) {
      const mod = new SWIModule(id, `Law & Policy ${i}`, type, `Compliance monitoring and regulatory validation for tier ${i}`);
      mod.process = function (input: unknown, prev: unknown) {
        const compliance = Math.random() < 0.95; // mostly compliant
        const signal = { compliance, input: "Regulatory check complete" };
        return this.emitArtifact(signal, { inputSignal: input, previousOutput: prev });
      };
      modules.push(mod);
    }
  }

  // 6. Human Safety H1-H7
  for (let i = 1; i <= 7; i++) {
    const id = `H${i}`;
    const type = "safety";
    if (shouldInclude(id, type)) {
      const mod = new SWIModule(id, `Human Safety ${i}`, type, `Protective boundary enforcement and safety verification for zone ${i}`);
      mod.process = function (input: unknown, prev: unknown) {
        const riskScore = parseFloat(Math.random().toFixed(2));
        const signal = { riskScore, input: "Safety boundary verified" };
        return this.emitArtifact(signal, { inputSignal: input, previousOutput: prev });
      };
      modules.push(mod);
    }
  }

  // 7. Observability/Ops O1-O3
  for (let i = 1; i <= 3; i++) {
    const id = `O${i}`;
    const type = "ops";
    if (shouldInclude(id, type)) {
      const mod = new SWIModule(id, `Observability ${i}`, type, `Telemetry capture and operational verification for node ${i}`);
      mod.process = function (input, prev) {
        const logEntry = { status: "observed", input: "Telemetry captured" };
        return this.emitArtifact(logEntry, { inputSignal: input, previousOutput: prev });
      };
      modules.push(mod);
    }
  }

  return modules;
}

export function runSWISimulation(inputData: unknown, swiConfig?: SWIConfig) {
  const modules = createSWIModules(swiConfig);
  let currentData = inputData as Record<string, unknown>;
  const globalArtifacts: unknown[] = [];

  modules.forEach((mod, index) => {
    mod.activate();
    try {
      const previousModuleId = index > 0 ? modules[index - 1].id : null;
      const previousOutput = previousModuleId ? currentData[previousModuleId] : null;

      console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Module ${mod.id}] Input Signal:`, currentData);
      const artifact = mod.process(currentData, previousOutput) as {
        moduleId: string;
        timestamp: number;
        signal: unknown;
        signature: string;
      };
      console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Module ${mod.id}] Output Signal:`, artifact.signal);
      console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Module ${mod.id}] Final Combined Artifact:`, {
        id: artifact.moduleId,
        timestamp: artifact.timestamp,
        signal: artifact.signal,
        signature: artifact.signature
      });
      globalArtifacts.push({ ...artifact, success: true });
      // Propagate artifact to next module as input (simplified propagation)
      currentData = { ...currentData, [mod.id]: artifact.signal };
    } catch (error) {
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Module ${mod.id}] Error during processing:`, error);
      console.error(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Module ${mod.id}] Input Data at failure:`, currentData);
      const errorArtifact = {
        moduleId: mod.id,
        moduleName: mod.name,
        moduleType: mod.type,
        moduleDescription: mod.description,
        timestamp: Date.now(),
        signal: { status: "failed", error: error instanceof Error ? error.message : String(error) },
        context: { inputSignal: currentData }, // Reference original input signal at failure
        signature: "ERROR_SIG",
        success: false
      };
      globalArtifacts.push(errorArtifact);
    }
  });

  return globalArtifacts;
}
