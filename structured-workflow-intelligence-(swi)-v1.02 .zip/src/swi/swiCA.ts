import crypto from 'crypto';

const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding: {
    type: 'spki',
    format: 'pem'
  },
  privateKeyEncoding: {
    type: 'pkcs8',
    format: 'pem'
  }
});

export function signRoot(rootHash: string) {
  const sign = crypto.createSign('SHA256');
  sign.update(rootHash);
  sign.end();

  return sign.sign(privateKey, 'hex');
}

export function verifyRoot(rootHash: string, signature: string) {
  const verify = crypto.createVerify('SHA256');
  verify.update(rootHash);
  verify.end();

  return verify.verify(publicKey, signature, 'hex');
}

export function getCAPublicKey() {
  return publicKey;
}
