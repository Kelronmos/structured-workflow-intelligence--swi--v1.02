
/**
 * SWI Mathematical Core
 * Definitions for CEK (Context Evaluation Kernel)
 */

export interface SWIWeights {
  alpha: number; // Ethical alignment
  beta: number;  // Environmental stability
  gamma: number; // Knowledge/Policy consistency
}

/**
 * Computes the raw CEK score.
 * CEK = (α * E + β * S + γ * K) / (1 + δ)
 * 
 * where:
 * E = Ethical Weight [0,1]
 * S = Stability [0,1]
 * K = Knowledge/Policy [0,1]
 * δ = Contextual Drift [0,∞)
 */
export function computeCEK(
  values: { ethics: number; stability: number; knowledge: number },
  drift: number,
  weights: SWIWeights = { alpha: 0.4, beta: 0.3, gamma: 0.3 }
): number {
  const numerator = (weights.alpha * values.ethics) + (weights.beta * values.stability) + (weights.gamma * values.knowledge);
  const denominator = 1 + drift;
  
  return numerator / denominator;
}

/**
 * Deterministic Admissibility Threshold (τ)
 * If CEK >= τ, the state is admitted.
 */
export const ADMISSIBILITY_THRESHOLD = 0.42;

export function isAdmissible(cek: number): boolean {
  return cek >= ADMISSIBILITY_THRESHOLD;
}
