import { Continuation } from './continuation';

export class DistributedState {
  private nodes: Record<string, Continuation> = {};

  store(continuation: Continuation) {
    for (const node of ["node_A", "node_B", "node_C"]) {
      this.nodes[node] = continuation;
    }
  }

  verifyGlobal(continuationId: string): boolean {
    const nodes = Object.values(this.nodes);
    if (nodes.length === 0) return false;
    return nodes.every(node => node.id === continuationId);
  }
}
