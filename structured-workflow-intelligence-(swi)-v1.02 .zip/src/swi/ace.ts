
import { Trace } from '../types';

export interface WeightTuning {
  previous: number;
  current: number;
  delta: number;
}

export interface ACEResult {
  tuning: {
    alpha: WeightTuning;
    beta: WeightTuning;
    gamma: WeightTuning;
  };
  recommendation: string;
}

export class ACE {
  // Adaptive Commonsense Engine (ACE)
  // Refines governance weights based on drift patterns and refusal incidents
  
  private static weights = {
    alpha: 0.4, // Ethics
    beta: 0.3,  // Environment
    gamma: 0.3  // Knowledge
  };

  static tune(history: Trace[]): ACEResult {
    const recentrefusals = history.filter(t => t.decision === 'REFUSE').slice(-5);
    const avgDrift = history.reduce((acc, t) => acc + (t.drift?.score || 0), 0) / (history.length || 1);
    
    const prevWeights = { ...this.weights };
    
    // Simple tuning logic: if many refusals due to environment, increase beta
    if (recentrefusals.some(r => r.violation_type === 'UNSTABLE_ENVIRONMENT')) {
      this.weights.beta += 0.05;
      this.weights.alpha -= 0.025;
      this.weights.gamma -= 0.025;
    }

    // Stabilize
    const total = this.weights.alpha + this.weights.beta + this.weights.gamma;
    this.weights.alpha /= total;
    this.weights.beta /= total;
    this.weights.gamma /= total;

    return {
      tuning: {
        alpha: { previous: prevWeights.alpha, current: this.weights.alpha, delta: this.weights.alpha - prevWeights.alpha },
        beta: { previous: prevWeights.beta, current: this.weights.beta, delta: this.weights.beta - prevWeights.beta },
        gamma: { previous: prevWeights.gamma, current: this.weights.gamma, delta: this.weights.gamma - prevWeights.gamma }
      },
      recommendation: avgDrift > 0.5 ? "S9_HARD_REBOOT_REQUIRED" : "CONTINUE_ADAPTIVE"
    };
  }

  static getWeights() {
    return this.weights;
  }
}
