import crypto from 'crypto';

// In a real system, these would be loaded from secure storage
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding: {
    type: 'spki',
    format: 'pem'
  },
  privateKeyEncoding: {
    type: 'pkcs8',
    format: 'pem'
  }
});

export function signArtifact(data: unknown) {
  const sign = crypto.createSign('SHA256');
  sign.update(JSON.stringify(data));
  sign.end();

  return sign.sign(privateKey, 'hex');
}

export function getPublicKey() {
  return publicKey;
}
