import { AuditBlock } from './AuditTypes';

export class AuditValidator {
  static validate(block: Partial<AuditBlock>): AuditBlock {
    const requiredFields: (keyof AuditBlock)[] = [
      "index",
      "timestamp",
      "eventId",
      "eventType",
      "sourceNode",
      "payloadHash",
      "previousHash",
      "stateRoot",
      "blsSignature",
      "nonce",
      "hash",
    ];

    for (const field of requiredFields) {
      const value = (block as Record<string, unknown>)[field];

      if (value === null || value === undefined || value === "") {
        throw new Error(`AUDIT_INVALID: missing ${field}`);
      }
    }

    return block as AuditBlock;
  }

  static sanitizeAuditInput(input: Record<string, unknown>) {
    return Object.fromEntries(
      Object.entries(input).filter(([, v]) =>
        v !== null &&
        v !== undefined &&
        v !== ""
      )
    );
  }
}
