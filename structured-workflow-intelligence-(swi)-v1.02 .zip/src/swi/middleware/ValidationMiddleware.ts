// src/swi/middleware/ValidationMiddleware.ts
import { z } from 'zod';
import { ProtocolManager } from '../protocol/ProtocolManager';
import { LogicalClock } from '../../../swi-core/kernel/LogicalClock';

export const EngineInputSchema = z.object({
  version: z.string().default('v1.0'),
  action: z.string().min(1),
  payload: z.record(z.string(), z.unknown()).optional(),
  timestamp: z.number().optional(),
  logicalTick: z.number().optional(), // Injected by middleware if missing
  requestorId: z.string().optional(),
  priority: z.enum(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']).default('MEDIUM'),
  integrityToken: z.string().optional()
}).passthrough();

export type ValidatedEngineInput = z.infer<typeof EngineInputSchema>;

export interface ContractDiagnostic {
  engineId: string;
  version: string;
  reliabilityIndex: number;
  violationCount: number;
  lastFailure?: {
    timestamp: number;
    error: string;
    payload: unknown;
  };
}

export class ValidationMiddleware {
  private static violationCounts: Map<string, number> = new Map();
  private static lastFailures: Map<string, { timestamp: number; error: string; payload: unknown }> = new Map();
  private static lastCleanup: number = Date.now();

  private static cleanup() {
    const now = Date.now();
    const dt = (now - this.lastCleanup) / 1000; // seconds
    if (dt > 10) {
      this.violationCounts.forEach((count, id) => {
        const decayed = Math.max(0, count - (dt * 0.1));
        this.violationCounts.set(id, decayed);
      });
      this.lastCleanup = now;
    }
  }

  public static validatePayload(payload: unknown, engineId: string): { success: true; data: ValidatedEngineInput } | { success: false; error: string; driftImpact: number } {
    this.cleanup();
    
    // Dynamically retrieve the current protocol schema
    const protocol = ProtocolManager.getCurrentProtocol();
    const result = protocol.schema.safeParse(payload);
    
    if (!result.success) {
      const currentCount = (this.violationCounts.get(engineId) || 0) + 1;
      this.violationCounts.set(engineId, currentCount);
      
      const errorStr = result.error.issues.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
      this.lastFailures.set(engineId, {
        timestamp: Date.now(),
        error: errorStr,
        payload
      });

      return {
        success: false,
        error: errorStr,
        driftImpact: Math.min(0.8, 0.1 * currentCount)
      };
    }

    // Inject Deterministic Logical Tick
    const validatedData = {
      ...result.data,
      logicalTick: result.data.logicalTick || LogicalClock.nextTick(),
      version: protocol.version
    } as ValidatedEngineInput;

    this.violationCounts.set(engineId, Math.max(0, (this.violationCounts.get(engineId) || 0) - 0.5));
    return { success: true, data: validatedData };
  }

  public static getReliabilityIndex(engineId: string): number {
    this.cleanup();
    const violations = this.violationCounts.get(engineId) || 0;
    return Math.max(0, 1 - (violations * 0.05));
  }

  public static getDiagnostic(engineId: string): ContractDiagnostic {
    return {
      engineId,
      version: 'v1.0',
      reliabilityIndex: this.getReliabilityIndex(engineId),
      violationCount: this.violationCounts.get(engineId) || 0,
      lastFailure: this.lastFailures.get(engineId)
    };
  }

  public static reset(engineId?: string) {
    if (engineId) {
      this.violationCounts.delete(engineId);
      this.lastFailures.delete(engineId);
    } else {
      this.violationCounts.clear();
      this.lastFailures.clear();
    }
    this.lastCleanup = Date.now();
  }
}
