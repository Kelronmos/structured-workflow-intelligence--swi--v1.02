import invariants from "./invariants.json";
import { CanonicalTrace } from "../services/RuntimeTraceService";

export interface InvariantEvaluation {
  invariantId: string;
  name: string;
  severity: string;
  status: "PASS" | "FAIL";
}

export interface AdmissibilityResult {
  traceId: string;
  evaluations: InvariantEvaluation[];
  overallStatus: "PASS" | "FAIL";
  signature?: string;
}

export class InvariantValidator {
  public static evaluateTrace(trace: CanonicalTrace): AdmissibilityResult {
    // Deterministic mock evaluation
    const evaluations: InvariantEvaluation[] = invariants.map((inv) => {
      // simulate realistic validation failures when tracing HALT logic
      const isFail = trace.decision === "HALT" && inv.severity === "CRITICAL" && trace.event_id.charCodeAt(0) % 2 === 0;
      return {
        invariantId: inv.id,
        name: inv.name,
        severity: inv.severity,
        status: isFail ? "FAIL" : "PASS",
      };
    });

    return {
      traceId: trace.event_id,
      evaluations,
      overallStatus: evaluations.some(e => e.status === "FAIL") ? "FAIL" : "PASS",
    };
  }

  public static getInvariants() {
    return invariants;
  }
}
