import { ConstitutionalState } from './types';

let STABILITY_STATE: ConstitutionalState = {
  currentStability: 1.0,
  pressure: 0.0,
  heartbeat: 60,
  params: {
    driftThreshold: 0.85,
    vigilanceFactor: 1.0,
    interlockEnabled: true
  },
  lastAdjustment: Date.now()
};

const HISTORY: number[] = [];

export function getStabilityState(): ConstitutionalState {
  return STABILITY_STATE;
}

export function pulseConstitutionalLoop(lastDrift: number): ConstitutionalState {
  HISTORY.push(lastDrift);
  if (HISTORY.length > 50) HISTORY.shift();

  const avgDrift = HISTORY.reduce((a, b) => a + b, 0) / HISTORY.length;
  const instability = lastDrift > 0.6 || avgDrift > 0.4 ? (lastDrift - 0.4) * 2 : 0;
  
  // Self-Stabilization Logic
  const newPressure = Math.min(1.0, STABILITY_STATE.pressure + instability * 0.1 - 0.01);
  const currentStability = Math.max(0, 1.0 - newPressure);
  
  // Adjust Parameters based on stability
  const driftThreshold = 0.85 - (newPressure * 0.2); // Tighten threshold under pressure
  const vigilanceFactor = 1.0 + (newPressure * 0.5); // Increase vigilance
  
  STABILITY_STATE = {
    ...STABILITY_STATE,
    currentStability,
    pressure: Math.max(0, newPressure),
    heartbeat: 60 - Math.floor(newPressure * 30), // Faster heartbeat under stress
    params: {
      driftThreshold,
      vigilanceFactor,
      interlockEnabled: currentStability > 0.2
    },
    lastAdjustment: Date.now()
  };

  return STABILITY_STATE;
}
