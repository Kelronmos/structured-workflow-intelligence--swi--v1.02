import { evaluateContinuation } from './engine';
import { SWIInput } from './types';

export function runMandatoryTest() {
  const input: SWIInput = {
    token: { status: "valid", permission: "TRANSFER_FUNDS" },
    action: "TRANSFER_FUNDS",
    context: {
      userBehavior: "normal",
      environment: "secure",
      policyMismatch: false
    },
    // Missing AHMR, Legal signature, TPM, GateToken
  };

  const result = evaluateContinuation(input);
  console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "Test Result:", result);
  if (result.decision === "REFUSE" && result.reason?.includes("NO_AUTHORITY")) {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "Test Passed: Authority check failed as expected.");
  } else {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "Test Failed: Authority check did not fail as expected.");
  }
}

runMandatoryTest();
