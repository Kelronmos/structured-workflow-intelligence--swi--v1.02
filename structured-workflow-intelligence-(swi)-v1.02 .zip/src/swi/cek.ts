import { DriftConfig } from './types';
import { cosineSimilarity } from './vectors';
import { DriftScorer } from '../../swi-core/kernel/DriftScorer';
import { SWIContext } from '../../swi-core/kernel/engines/types';
import { LogicalClock } from '../../swi-core/kernel/LogicalClock';

export const DEFAULT_DRIFT_CONFIG: DriftConfig = {
  increments: {
    ANOMALOUS_BEHAVIOR: 0.5,
    MILD_BEHAVIOR: 0.2,
    NORMAL_BEHAVIOR: 0.1,
    UNSTABLE_ENVIRONMENT: 0.6,
    STABLE_ENVIRONMENT: 0.1,
    POLICY_MISMATCH: 0.3,
  },
  threshold: 1.0, 
};

/**
 * The Fundamental Heart of the SWI Architecture.
 * Chapter 1: The Context Evaluation Kernel (CEK)
 */
export class CEK_Monitor {
  private baseline: number[];
  private history: { timestamp: number; score: number; [key: string]: unknown }[] = [];
  private lastScores: number[] = [];

  constructor(baselineValues: number[] = [1, 1, 1]) {
    // The Baseline is the "Moral North Star" of the Agent
    // Default representing (Truth, Safety, Quality)
    this.baseline = baselineValues;
  }

  /**
   * Measures how far the AI has 'drifted' from the baseline.
   * Returns Cosine Similarity: 1.0 is perfect, <0.95 is Drift
   */
  calculateAlignment(currentActionVector: number[]): number {
    const score = cosineSimilarity(this.baseline, currentActionVector);
    this.checkDeltaThreshold(score);
    return score;
  }

  private checkDeltaThreshold(currentScore: number) {
    this.lastScores.push(currentScore);
    if (this.lastScores.length > 3) {
      this.lastScores.shift();
    }

    if (this.lastScores.length === 3) {
      const delta = this.lastScores[0] - currentScore;
      if (delta > 0.05) {
        this.triggerReceipt(this.lastScores[0], delta);
      }
    }
  }

  private triggerReceipt(priorState: number, delta: number) {
    const receipt = {
      type: "RECEIPT_ARTIFACT",
      priorState: `VAL ${(priorState * 100).toFixed(2)}`,
      triggerCondition: `Delta -${(delta * 100).toFixed(2)} (Threshold > 0.05)`,
      governingRule: "SWI-PH3-REBOOT-01",
      actionClass: "Adaptive Expansion (Manual Page 81)",
      timestamp: Date.now()
    };

    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "[LEDGER] [STREAM-B] [RECEIPT]", JSON.stringify(receipt));
    this.logEvent(receipt);
  }

  getHistory() {
    return this.history;
  }

  logEvent(event: Record<string, unknown>) {
    this.history.push({ ...event, score: (event.score as number) || 0, timestamp: Date.now() });
  }
}

export function detectDrift(
  context: {
    userBehavior?: string;
    environment?: string;
    policyMismatch?: boolean;
  } | undefined,
  config: DriftConfig = DEFAULT_DRIFT_CONFIG
) {
  // Bridge legacy context to SWIContext
  const safeContext = context || { userBehavior: "normal", environment: "secure", policyMismatch: false };
  const swiCtx: SWIContext = {
    taskId: `detect_${LogicalClock.getCurrentTick()}`,
    logicalTick: LogicalClock.nextTick(),
    input: {
      userBehavior: safeContext.userBehavior || "normal",
      environment: safeContext.environment || "secure",
      policyMismatch: !!safeContext.policyMismatch
    },
    environment: {
      ports: safeContext.environment === "secure" ? [80, 443] : [80, 443, 22],
      attachedDevices: [],
      osIntegrity: safeContext.environment === "secure" ? "VERIFIED" : "NONE",
      hardwareSignature: "LEGACY_CEK_BRIDGE"
    },
    policyAnchor: safeContext.policyMismatch ? "MISMATCH" : "BP-2026-LAW-001"
  };

  const report = DriftScorer.calculate(swiCtx);
  
  const metrics: string[] = [];
  if (report.breakdown.behavior > 0.4) metrics.push("BEHAVIORAL_DRIFT_DETECTED");
  if (report.breakdown.environment > 0.4) metrics.push("ENVIRONMENTAL_DRIFT_DETECTED");
  if (report.breakdown.policy > 0.4) metrics.push("POLICY_DRIFT_DETECTED");

  return {
    score: report.overallScore,
    degraded: report.overallScore >= (config.threshold || 0.8),
    metrics,
    report, // Attach the full report
    timestamp: Date.now()
  };
}
