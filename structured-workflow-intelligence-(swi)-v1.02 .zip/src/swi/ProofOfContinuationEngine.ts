import { NodeState } from './AuditTypes';

export class ProofOfContinuationEngine {
  private nodeReputations: Record<string, number> = {};
  private quarantinedNodes: Set<string> = new Set();

  constructor(initialNodes: string[]) {
    initialNodes.forEach(id => {
      this.nodeReputations[id] = 1.0;
    });
  }

  decide(nodes: NodeState[]) {
    const activeNodes = nodes.filter(n => !this.quarantinedNodes.has(n.id));
    
    const approved = activeNodes.filter(n => n.auth === "VALID").length;
    const rejected = activeNodes.filter(n => n.auth === "INVALID").length;

    // Self-healing: if a node consistently disagrees with the majority, lower reputation
    this.auditNodes(activeNodes);

    // Dynamic Quorum: based on active, non-quarantined nodes
    const quorum = Math.ceil(activeNodes.length * 0.66);

    if (approved >= quorum) {
      return "APPROVED";
    }

    if (rejected >= quorum) {
      return "REJECTED";
    }

    return "PENDING";
  }

  private auditNodes(nodes: NodeState[]) {
    const validCount = nodes.filter(n => n.auth === "VALID").length;
    const invalidCount = nodes.filter(n => n.auth === "INVALID").length;
    const majorityAuth = validCount >= invalidCount ? "VALID" : "INVALID";

    nodes.forEach(node => {
      if (node.auth !== majorityAuth) {
        this.nodeReputations[node.id] = (this.nodeReputations[node.id] || 1.0) - 0.1;
      } else {
        this.nodeReputations[node.id] = Math.min(1.0, (this.nodeReputations[node.id] || 1.0) + 0.05);
      }

      // Byzantine Fault Detection: isolate nodes below reputation threshold
      if (this.nodeReputations[node.id] < 0.4) {
        this.quarantinedNodes.add(node.id);
        console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, `[BYZANTINE] Node ${node.id} isolated due to low reputation: ${this.nodeReputations[node.id].toFixed(2)}`);
      }
    });
  }

  getQuarantineList() {
    return Array.from(this.quarantinedNodes);
  }

  getReputations() {
    return { ...this.nodeReputations };
  }
}
