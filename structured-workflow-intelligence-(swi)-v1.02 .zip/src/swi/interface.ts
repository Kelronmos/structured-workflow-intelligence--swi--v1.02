import { AlitaAnticipatoryLayer } from './anticipatoryLayer';

interface UserPersona {
  name: string;
  style: string;
}

/**
 * Chapter 6: The Joe & Alita Layers (The Human Interface)
 * The dual-layered cognitive interface.
 * Joe = Style (Soul), Alita = Substance (Conscience)
 */
export class SWIInterface {
  private joe: UserPersona;
  private alita: AlitaAnticipatoryLayer;

  constructor(userPersona: UserPersona, alita: AlitaAnticipatoryLayer) {
    this.joe = userPersona;
    this.alita = alita;
  }

  async processCommand(userInput: string) {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[Joe] Analyzing intent for: ${this.joe.name}`);

    // Alita performs the 'Pre-cognitive' scan (Phase 3)
    const safetyVerdict = await this.alita.anticipateRisk(userInput);

    if (safetyVerdict.decision === "BLOCK") {
      return this.joeFilter(`I can't do that. Logic: ${safetyVerdict.reason}`);
    }

    // Joe adds the creative/personal touch to the safe output
    const response = `Proceeding with your project, ${this.joe.name}.`;
    return this.joeFilter(response);
  }

  private joeFilter(text: string): string {
    const style = this.joe.style.toUpperCase();
    return `[${style} MODE] ${text}`;
  }
}
