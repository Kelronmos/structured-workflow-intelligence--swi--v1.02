/**
 * Display Layer - Deterministic, never resets.
 * Only reflects verified changes from the sandbox.
 */

import { StableState } from '../types';

let currentState: StableState | null = null;

export function updateDisplay(newState: StableState) {
  // Only update if verification status matches
  if (newState.verificationState && newState.verificationState !== "UNVERIFIED") {
    currentState = newState;
  }
}

export function getDisplay(): StableState | null {
  return currentState;
}
