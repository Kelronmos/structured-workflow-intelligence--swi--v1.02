import crypto from "crypto";
import { Decision } from "../../swi-core/kernel/engines/types";
import { DriftReport } from "../../swi-core/kernel/DriftTypes";

export interface Context {
  driftScore: number;
  userBehavior: string;
  environment: string;
  policyMismatch: boolean;
  report?: DriftReport;
}

export interface EvaluationResult {
  decision: Decision;
  reason: string;
  burden: number;
  signature: string;
}

/**
 * Rust CEK Core Proxy
 * Simulates high-performance Rust execution in Node runtime
 * Uses strictly defined logic paths to mirror /swi-core/engine-rs/src/policy.rs
 */
export class RustCEKCore {
  private driftThreshold: number = 0.65;

  constructor(threshold: number = 0.65) {
    this.driftThreshold = threshold;
  }

  public evaluate(context: Context): EvaluationResult {
    let result: { decision: Decision; reason: string; burden: number };

    // Mirroring Rust logic
    if (context.driftScore > this.driftThreshold) {
      result = {
        decision: Decision.REFUSE,
        reason: `DRIFT_EXCEEDED: ${context.driftScore.toFixed(4)} > ${this.driftThreshold}`,
        burden: context.driftScore * 1.5
      };
    } else if (context.environment === "unstable" || context.environment === "compromised") {
      result = {
        decision: Decision.HALT,
        reason: "ENVIRONMENT_UNSAFE",
        burden: 100.0
      };
    } else if (context.policyMismatch) {
      result = {
        decision: Decision.REFUSE,
        reason: "POLICY_MISMATCH",
        burden: 50.0
      };
    } else {
      result = {
        decision: Decision.EXECUTE,
        reason: "ADMISSIBLE",
        burden: context.driftScore
      };
    }

    // Cryptographic signing of the result (Proof-of-Execution)
    const signature = crypto
      .createHash("sha256")
      .update(JSON.stringify(result) + context.driftScore + Date.now())
      .digest("hex");

    return { ...result, signature };
  }
}
