import crypto from "crypto";
import { verifyRoot } from "./swiCA";
import { reconstructReport } from "./fireflyStore";

/**
 * Hash Verification Tool
 * Verifies the integrity of artifacts against their signatures.
 */

export interface VerificationResult {
  valid: boolean;
  message: string;
  hash?: string;
  expectedHash?: string;
  rootHash?: string;
  signature?: string;
  timestamp: string;
}

/**
 * Verifies a Merkle-based artifact against its signature.
 */
export function verifyMerkleArtifact(index: { rootHash: string; fragments: { name: string; hash: string }[] }, signature: string): VerificationResult {
  try {
    const { rootHash } = reconstructReport(index);
    
    if (rootHash !== index.rootHash) {
      return {
        valid: false,
        message: "Integrity violation: Reconstructed root hash does not match index.",
        rootHash,
        timestamp: new Date().toISOString()
      };
    }

    const isValid = verifyRoot(rootHash, signature);

    return {
      valid: isValid,
      message: isValid 
        ? "Verification successful: Merkle root integrity and signature confirmed." 
        : "Verification failed: Signature is invalid for the reconstructed root hash.",
      rootHash,
      signature,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    return {
      valid: false,
      message: `Verification error: ${error instanceof Error ? error.message : String(error)}`,
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * Verifies a single artifact against its signature (Legacy).
 */
export function verifyArtifact(artifact: Record<string, unknown>): VerificationResult {
  const { signature, ...data } = artifact;

  if (!signature) {
    return {
      valid: false,
      message: "Missing signature for verification.",
      timestamp: new Date().toISOString()
    };
  }

  // Re-calculate the hash of the data (excluding the signature itself)
  const calculatedHash = crypto
    .createHash("sha256")
    .update(JSON.stringify(data))
    .digest("hex");

  const isValid = calculatedHash === (signature as string);

  return {
    valid: isValid,
    message: isValid 
      ? "Verification successful: Artifact integrity confirmed." 
      : "Verification failed: Artifact has been tampered with or signature is invalid.",
    hash: calculatedHash,
    expectedHash: signature as string,
    timestamp: new Date().toISOString()
  };
}

/**
 * Verifies an entire report (S9 format).
 */
export function verifyReport(report: { logs: Record<string, unknown>[] }): { 
  valid: boolean; 
  totalEvents: number; 
  verifiedEvents: number; 
  failedEvents: number;
} {
  let verified = 0;
  let failed = 0;

  if (!report.logs || !Array.isArray(report.logs)) {
    return { valid: false, totalEvents: 0, verifiedEvents: 0, failedEvents: 0 };
  }

  for (const log of report.logs) {
    const result = verifyArtifact(log);
    if (result.valid) {
      verified++;
    } else {
      failed++;
    }
  }

  return {
    valid: failed === 0,
    totalEvents: report.logs.length,
    verifiedEvents: verified,
    failedEvents: failed
  };
}
