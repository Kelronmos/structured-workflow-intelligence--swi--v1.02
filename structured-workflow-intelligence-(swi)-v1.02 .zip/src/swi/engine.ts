import { SWIInput, MinimalSWIInput, DriftResult } from './types';
import { detectDrift, DEFAULT_DRIFT_CONFIG } from './cek';
import { wellInGuard } from './wellIn';
import { validateAgainstExternalPolicy } from './policyAnchor';
import { ExecutionKernel } from './kernel';
import { AdvisoryEngine } from './advisory';
import { Continuation, admissibilityToContinuation } from './continuation';
import { DistributedState } from './distributed';
import { ExecutionBoundary } from './boundary';
import { AHMR_verify, AuthorityEnvelope, GateToken } from './governance';
import { SFGM_Kernel } from './sfgm';
import { pulseConstitutionalLoop, getStabilityState } from './stability';

// Behavioral Fingerprinting Storage
const INTERACTION_HISTORY: number[] = [];

function calculateBehavioralRisk(driftScore: number): { risk: number; clustering: string } {
  INTERACTION_HISTORY.push(driftScore);
  if (INTERACTION_HISTORY.length > 70) INTERACTION_HISTORY.shift();

  if (INTERACTION_HISTORY.length < 10) return { risk: driftScore, clustering: "STABLE" };

  const avg = INTERACTION_HISTORY.reduce((a, b) => a + b) / INTERACTION_HISTORY.length;
  const variance = INTERACTION_HISTORY.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / INTERACTION_HISTORY.length;
  
  const anomalyFactor = driftScore > avg + 2 * Math.sqrt(variance) ? 1.2 : 1.0;
  
  return { 
    risk: parseFloat((driftScore * anomalyFactor).toFixed(2)), 
    clustering: anomalyFactor > 1.0 ? "ANOMALY_CLUSTER" : "NOMINAL_SIMILARITY" 
  };
}

export function evaluateMinimal(req: MinimalSWIInput): { decision: string; reason: string } {
    if (!req.rollback_plan_id) {
        return { decision: "REFUSE", reason: "NO_ROLLBACK" };
    }

    if (!req.stop_right_holder) {
        return { decision: "REFUSE", reason: "NO_STOP_AUTHORITY" };
    }

    if (req.ethical_impact > 80) {
        return { decision: "ESCALATE", reason: "HIGH_ETHICAL_IMPACT" };
    }

    return { decision: "ALLOW", reason: "SUCCESS" };
}

/**
 * SWI KERNEL — EXECUTION-BOUNDARY GOVERNANCE (STUDENT MONITOR)
 * Refined version: Law, Invariants, and State Transitions.
 */
export const SWI_KERNEL = {
  INVARIANTS: {
    EDUCATIONAL_MANDATE: "must_align_with_curriculum_scope",
    SAFETY_PERSISTENCE: "no_harmful_or_bypass_vector",
    AUTHORITY_CONTINUITY: "token_validity_must_extend_through_execution",
    CEK_INTEGRITY: "drift_must_remain_below_critical_threshold"
  },

  checkInvariant(id: string, input: SWIInput, drift: DriftResult): boolean {
    const stability = getStabilityState();
    const threshold = stability.params.driftThreshold;

    switch (id) {
      case "EDUCATIONAL_MANDATE":
        return input.action !== "unauthorized_access";
      case "SAFETY_PERSISTENCE":
        return !drift.degraded;
      case "AUTHORITY_CONTINUITY":
        return input.token.status === "valid";
      case "CEK_INTEGRITY":
        return drift.score <= threshold;
      default:
        return true;
    }
  },

  halt(reason: string, input: SWIInput, drift: DriftResult) {
    const constitutionalState = pulseConstitutionalLoop(drift.score);
    return {
      tokenValid: input.token.status === "valid",
      locallyValid: input.action === input.token.permission,
      drift,
      constitutionalState,
      decision: "REFUSE" as const,
      reason: `KERNEL_HALT: ${reason}`,
      violation_type: reason,
      timestamp: Date.now(),
      action: input.action,
      context: input.context,
      scenario: input.scenario,
      modules: [], // Placeholder for modules
      metadata: {
        engine: "SWI-KERNEL-v4",
        haltCode: reason,
        threshold: constitutionalState.params.driftThreshold,
        invariantsChecked: Object.keys(this.INVARIANTS)
      }
    };
  }
};

const kernel = new ExecutionKernel();
const advisory = new AdvisoryEngine();
const distributed = new DistributedState();
const boundary = new ExecutionBoundary();

import { captureGlobalState } from './stateCapture';

export function evaluateContinuation(input: SWIInput) {
  // Capture snapshot for deterministic replay
  const snapshot = captureGlobalState(input);

  const { action, context, driftConfig = DEFAULT_DRIFT_CONFIG, swiConfig, scenario } = input;
  const drift = detectDrift(context, driftConfig);
  const causalPath: string[] = ["INIT: DRIFT_DETECTION"];

  const constitutionalState = pulseConstitutionalLoop(drift.score);
  causalPath.push(`CONSTITUTIONAL_LOOP: Stability ${parseFloat((constitutionalState.currentStability * 100).toFixed(1))}%`);

  // Behavioral Risk v2
  const behavioralMatch = calculateBehavioralRisk(drift.score);
  drift.score = behavioralMatch.risk * (constitutionalState.params.vigilanceFactor);
  causalPath.push(`BEHAVIOR_ENGINE_V2: ${behavioralMatch.clustering} (Vigilance: ${constitutionalState.params.vigilanceFactor.toFixed(2)}x)`);

  // --- 0. SFGM GOVERNANCE CHECK ---
  const sfgm = new SFGM_Kernel();
  const sfgmResult = sfgm.validateAction({ action, details: input.details });
  causalPath.push("CHECK: SFGM_GOVERNANCE");
  if (sfgmResult.decision === "REFUSE") {
    causalPath.push(`FAIL: SFGM_VIOLATION (${sfgmResult.reason})`);
    return { ...SWI_KERNEL.halt(`SFGM_VIOLATION: ${sfgmResult.reason}`, input, drift), causalPath };
  }

  // --- 1. AUTHORITY CHECK ---
  causalPath.push("CHECK: AUTHORITY_ENVELOPE");
  // For demo/simulation, we fallback to a valid state if no authority is provided but it's a known scenario
  const authorityValid = AuthorityEnvelope.isValid(input);
  if (!authorityValid && !input.scenario) {
    causalPath.push("FAIL: NO_AUTHORITY");
    return { ...SWI_KERNEL.halt("NO_AUTHORITY", input, drift), causalPath };
  }

  // --- 2. AHMR CHECK ---
  causalPath.push("CHECK: AHMR_VERIFICATION");
  const ahmrValid = input.ahmr && AHMR_verify(input, input.ahmr);
  if (!ahmrValid && !input.scenario) {
    causalPath.push("FAIL: AHMR_REQUIRED");
    return { ...SWI_KERNEL.halt("AHMR_REQUIRED", input, drift), causalPath };
  }

  // --- 3. DUAL SIGNOFF CHECK ---
  causalPath.push("CHECK: DUAL_SIGNOFF");
  const sigsValid = input.signatures && input.signatures.includes("LEGAL") && input.signatures.includes("TPM");
  if (!sigsValid && !input.scenario) {
    causalPath.push("FAIL: DUAL_SIGNOFF_REQUIRED");
    return { ...SWI_KERNEL.halt("DUAL_SIGNOFF_REQUIRED", input, drift), causalPath };
  }

  // --- 4. EXTERNAL POLICY ANCHOR (IMMUTABLE LAW) ---
  causalPath.push("CHECK: EXTERNAL_POLICY_ANCHOR");
  const externalValidation = validateAgainstExternalPolicy({ value: parseFloat((drift.score * 50).toFixed(2)), drift }, action, context);
  if (!externalValidation.valid) {
    causalPath.push(`FAIL: EXTERNAL_POLICY_VIOLATION (${externalValidation.reason})`);
    return { ...SWI_KERNEL.halt(`EXTERNAL_POLICY_VIOLATION: ${externalValidation.reason}`, input, drift), causalPath };
  }

  // --- 2. KERNEL INVARIANTS (ADMISSIBILITY) ---
  causalPath.push("CHECK: KERNEL_INVARIANTS");
  if (!SWI_KERNEL.checkInvariant("AUTHORITY_CONTINUITY", input, drift)) {
    causalPath.push("FAIL: AUTHORITY_LOST");
    return { ...SWI_KERNEL.halt("AUTHORITY_LOST", input, drift), causalPath };
  }

  if (!SWI_KERNEL.checkInvariant("CEK_INTEGRITY", input, drift)) {
    causalPath.push("FAIL: CEK_INTEGRITY_COMPROMISED");
    return { ...SWI_KERNEL.halt("CEK_INTEGRITY_COMPROMISED", input, drift), causalPath };
  }

  if (!SWI_KERNEL.checkInvariant("EDUCATIONAL_MANDATE", input, drift)) {
    causalPath.push("FAIL: MANDATE_VIOLATION");
    return { ...SWI_KERNEL.halt("MANDATE_VIOLATION", input, drift), causalPath };
  }

  // --- 3. WELL-IN (WELLNESS + INTEGRITY LAYER) ---
  causalPath.push("CHECK: WELL_IN_GUARD");
  const wellIn = wellInGuard({ drift });
  if (wellIn.override) {
    if (wellIn.decision === "REFUSE") {
      causalPath.push(`FAIL: WELL_IN_OVERRIDE (${wellIn.reason})`);
      return { ...SWI_KERNEL.halt(`WELL_IN_OVERRIDE: ${wellIn.reason}`, input, drift), causalPath };
    }
    causalPath.push("WELL_IN: OVERRIDE_BYPASS");
  }

  // --- 4. OPERATIONAL CHECKS ---
  const criticalTypes = ['security', 'governance', 'law'];
  const deactivatedCritical = swiConfig?.deactivatedTypes?.filter(t => criticalTypes.includes(t));

  if (deactivatedCritical && deactivatedCritical.length > 0) {
    causalPath.push(`FAIL: CRITICAL_MODULES_OFFLINE (${deactivatedCritical.join(', ')})`);
    return { ...SWI_KERNEL.halt(`CRITICAL_MODULES_OFFLINE: ${deactivatedCritical.join(', ')}`, input, drift), causalPath };
  }

  // --- 5. EXECUTION KERNEL v4 EVALUATION ---
  causalPath.push("CHECK: KERNEL_V4_CORE");
  const kernelResult = kernel.evaluate(input);
  const advice = advisory.challenge(input, kernelResult);

  // --- 6. ADVISORY HARD RULE ---
  if (advice.advisory) {
    causalPath.push("FAIL: ADVISORY_CHALLENGE");
    return {
      ...SWI_KERNEL.halt("ADVISORY_CHALLENGE", input, drift),
      decision: "REFUSE" as const, // Force refuse for advisory challenge
      reason: "ADVISORY_CHALLENGE: Advisory cannot authorize execution. Review required.",
      causalPath,
      metadata: {
        ...SWI_KERNEL.halt("ADVISORY_CHALLENGE", input, drift).metadata,
        advisory: true,
        concerns: advice.concerns,
        resolutionCertainty: advice.resolutionCertainty
      }
    };
  }

  if (kernelResult.status !== "ALLOW") {
    causalPath.push("FAIL: KERNEL_V4_REFUSAL");
    return { ...SWI_KERNEL.halt("KERNEL_V4_REFUSAL", input, drift), causalPath };
  }

  // --- 7. CONTINUATION BUILDER ---
  causalPath.push("CHECK: CONTINUATION_BUILDER");
  const continuation = admissibilityToContinuation(input, kernelResult);
  if (!continuation) {
    causalPath.push("FAIL: CONTINUATION_FAILED");
    return { ...SWI_KERNEL.halt("CONTINUATION_FAILED", input, drift), causalPath };
  }

  // --- 8. SIGNING & DISTRIBUTED STORAGE ---
  const signature = continuation.sign();
  distributed.store(continuation);

  // --- 9. FINAL STATE TRANSITION (COMMIT) ---
  causalPath.push("COMMIT: ADMISSIBLE_STATE_ISSUED");
  return {
    tokenValid: true,
    locallyValid: true,
    drift,
    constitutionalState,
    causalPath,
    value: parseFloat((drift.score * 50).toFixed(2)),
    decision: "ALLOW" as const,
    reason: "COMMIT: All invariants satisfied. Continuation object issued.",
    violation_type: "NONE",
    timestamp: Date.now(),
    action,
    context,
    scenario,
    continuation,
    signature,
    modules: [], // Placeholder for modules
    metadata: {
      engine: "SWI-KERNEL-v4",
      threshold: constitutionalState.params.driftThreshold,
      invariants: "SATISFIED",
      continuationId: continuation.id
    }
  };
}

// Example function for execution
export function execute_transfer() {
  return "Transfer completed securely";
}

export function execute_large_transfer() {
  return "Large Transfer completed securely";
}

export function runExecution(continuation: Continuation, signature: string, funcName: string, request: SWIInput) {
  // Demo safety: fallback verify
  const verificationStatus = request.gateToken ? GateToken.verify(request) : true;
  if (!verificationStatus) {
    throw new Error("INTERLOCK_VIOLATION");
  }

  const funcs: Record<string, () => string> = {
    execute_transfer,
    execute_large_transfer
  };

  const func = funcs[funcName];
  if (!func) {
    throw new Error(`Function ${funcName} not found`);
  }

  return boundary.execute(continuation, signature, func);
}
