export interface AuditBlock {
  index: number;
  timestamp: number;

  eventId: string;
  eventType: string;

  sourceNode: string;

  payloadHash: string;
  previousHash: string;
  stateRoot: string;

  blsSignature: string;

  consensus: {
    approved: number;
    rejected: number;
    quorum: number;
    result: "APPROVED" | "REJECTED" | "PENDING";
    strength?: "STRONG" | "WEAK" | "DISPUTED";
  };

  causalPath?: string[];
  nonce: number;

  hash: string;
}

export interface NodeState {
  id: string;
  auth: "VALID" | "INVALID";
  isByzantine?: boolean;
  reputation: number;
}
