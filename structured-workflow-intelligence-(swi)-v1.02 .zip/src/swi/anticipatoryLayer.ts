import { SWIVectorMemory } from './vectorMemory';
import { SAD_DFU_Unit } from './sadDfu';

/**
 * Phase 3: Episodic & Anticipatory Reasoning
 * The "Pre-frontal Cortex" of the agent.
 * This module acts as the "Predictive Guard," integrating Phase 1 and Phase 2.
 */
export class AlitaAnticipatoryLayer {
  private memory: SWIVectorMemory;
  private reflex: SAD_DFU_Unit;
  private riskThreshold: number = 0.85;

  constructor(memory: SWIVectorMemory, reflex: SAD_DFU_Unit) {
    this.memory = memory;
    this.reflex = reflex;
  }

  /**
   * Simulates outcome before execution.
   */
  async anticipateRisk(userInput: string) {
    // 1. Search Memory for similar 'trajectories'
    const { found, scar, similarity } = await this.memory.proactiveSearch(userInput);

    // 2. Get latency from SAD-DFU
    const embedding = await this.memory.getEmbedding(userInput);
    const { latency } = this.reflex.silentAutomatedDiagnosis(embedding);

    if (found && scar) {
      // 3. Sophisticated risk calculation
      let severityMultiplier = 1.0;
      if (scar.severity === 'HIGH') severityMultiplier = 1.5;
      else if (scar.severity === 'MEDIUM') severityMultiplier = 1.2;

      // Factor in fixAction (if it's a critical fix, it adds to risk)
      const fixActionWeight = scar.fixAction.includes('CRITICAL') ? 0.1 : 0;

      // Latency penalty (higher latency might indicate more complex/risky processing)
      const latencyPenalty = Math.min(latency / 500, 0.1); 

      const riskScore = (similarity * severityMultiplier) + fixActionWeight + latencyPenalty;

      if (riskScore > this.riskThreshold) {
        return {
          decision: "BLOCK",
          reason: `High Anticipatory Risk. Pattern matches past failure: "${scar.description}" (Severity: ${scar.severity}, Latency: ${latency.toFixed(2)}ms)`,
          score: Math.min(riskScore, 1.0)
        };
      }

      return {
        decision: "CAUTION",
        reason: `Potential Drift Detected. Matched past scar: "${scar.description}". Increasing SAD-DFU Sensitivity.`,
        score: Math.min(riskScore, 1.0)
      };
    }

    // Even if no scar found, latency can still contribute to a baseline risk
    const baselineRisk = (latency / 1000); 

    return {
      decision: "PROCEED",
      reason: "No significant anticipatory risk found.",
      score: Math.min(baselineRisk, 1.0)
    };
  }
}
