
export interface PolicyRule {
  id: string;
  name: string;
  description: string;
  condition: string; // e.g. "driftScore < 0.4 && tokenPermission == 'ADMIN'"
  action: 'ALLOW' | 'REFUSE' | 'ESCALATE';
}

export interface OrgPolicy {
  orgId: string;
  rules: PolicyRule[];
  defaultAction: 'ALLOW' | 'REFUSE';
}

export class PolicyEngine {
  static evaluate(policy: OrgPolicy, context: Record<string, unknown>): { decision: string; ruleId?: string } {
    for (const rule of policy.rules) {
      if (this.checkCondition(rule.condition, context)) {
        return { decision: rule.action, ruleId: rule.id };
      }
    }
    return { decision: policy.defaultAction };
  }

  private static checkCondition(condition: string, context: Record<string, unknown>): boolean {
    try {
      // Simplified safe evaluation for demo
      // In production, use a real parser (like jexl or expression-eval)
      // For this sandbox, we'll implement a very basic one
      const tokens = condition.split(' ');
      
      // Basic support for: driftScore < 0.4
      if (tokens.length === 3) {
        const [field, op, val] = tokens;
        const contextVal = context[field];
        
        switch (op) {
          case '<': {
            if (typeof contextVal !== 'number') return false;
            return contextVal < parseFloat(val);
          }
          case '>': {
            if (typeof contextVal !== 'number') return false;
            return contextVal > parseFloat(val);
          }
          case '==': {
            return String(contextVal) === val;
          }
          case '!=': {
            return String(contextVal) !== val;
          }
        }
      }
      
      return false;
    } catch {
      return false;
    }
  }
}

export const defaultPolicies: Record<string, OrgPolicy> = {
  "SWI_GLOBAL": {
    orgId: "global",
    defaultAction: "REFUSE",
    rules: [
      {
        id: "RULE_001",
        name: "Admin Override",
        description: "Admins skip basic drift checks if below critical threshold",
        condition: "tokenPermission == ADMIN", // Simplified tokens
        action: "ALLOW"
      },
      {
        id: "RULE_002",
        name: "Critical Drift",
        description: "Hard block on any drift above 0.8",
        condition: "driftScore > 0.8",
        action: "REFUSE"
      }
    ]
  }
};
