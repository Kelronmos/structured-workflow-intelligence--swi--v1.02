export type PrototypeClassification = 
  | "prototype_level_0" // Unknown: Insufficient evidence available.
  | "prototype_level_1" // Prototype: Update tested in isolated environment.
  | "prototype_level_2" // Verified: Update passed validation checks.
  | "prototype_level_3"; // Review Grade: Update independently reviewed.

export interface UpdateRecord {
  updateId: string;
  timestamp: number;
  previousVersion: string;
  newVersion: string;
  deploymentScope: "prototype_only";
  approvalAuthority: string;
  validationStatus: "prototype_unverified" | "prototype_verified";
  auditSignature: string;
  evidenceLinks: string[];
}

export interface LifecycleState {
  createdAt: string;
  lastModified: string;
  version: "prototype";
  status: "prototype";
  classification: PrototypeClassification;
}

export interface ClaimRecord {
  id: string;
  statement: string;
  evidence: string[];
  status: "prototype_unverified" | "prototype_verified";
}

export interface AuditOutput {
  status: "prototype";
  verification_level: PrototypeClassification;
  findings: string[];
  claims: ClaimRecord[];
  updates: UpdateRecord[];
}

export interface SwiCorePrototype {
  identity: Record<string, any>;
  authority: Record<string, any>;
  evidence: Record<string, any>;
  decisionBoundary: Record<string, any>;
  replay: Record<string, any>;
  audit: Record<string, any>;
  lifecycle: LifecycleState;
  risk: Record<string, any>;
  reporting: Record<string, any>;
  verification: Record<string, any>;
  classification: "prototype";
}
