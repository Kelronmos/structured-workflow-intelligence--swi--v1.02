import { UpdateRecord, ClaimRecord, AuditOutput, LifecycleState } from "./types";

export async function hashEvent(event: any) {
  const encoder = new TextEncoder();
  const data = encoder.encode(JSON.stringify(event));
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

export class LUGMEngine {
  private updates: UpdateRecord[] = [];
  private claims: ClaimRecord[] = [];
  private lifecycle: LifecycleState;

  constructor() {
    this.lifecycle = {
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString(),
      version: "prototype",
      status: "prototype",
      classification: "prototype_level_0"
    };
  }

  public registerClaim(id: string, statement: string, evidence: string[]) {
    this.claims.push({
      id,
      statement,
      evidence,
      status: evidence.length > 0 ? "prototype_verified" : "prototype_unverified"
    });
    this.updateClassification();
  }

  public async registerUpdate(previousVersion: string, newVersion: string, evidenceLinks: string[]) {
    const update: UpdateRecord = {
      updateId: crypto.randomUUID(),
      timestamp: Date.now(),
      previousVersion,
      newVersion,
      deploymentScope: "prototype_only",
      approvalAuthority: "PROTOTYPE_SYSTEM",
      validationStatus: evidenceLinks.length > 0 ? "prototype_verified" : "prototype_unverified",
      auditSignature: "",
      evidenceLinks
    };
    
    // Generate evidence signature
    const signaturePayload = { ...update, auditSignature: undefined };
    update.auditSignature = await hashEvent(signaturePayload);
    this.updates.push(update);
    
    this.lifecycle.lastModified = new Date().toISOString();
    this.updateClassification();
    return update;
  }

  private updateClassification() {
    const allClaimsVerified = this.claims.every(c => c.status === "prototype_verified") && this.claims.length > 0;
    const allUpdatesVerified = this.updates.every(u => u.validationStatus === "prototype_verified");

    if (this.claims.length === 0 && this.updates.length === 0) {
       this.lifecycle.classification = "prototype_level_0";
    } else if (allClaimsVerified && allUpdatesVerified) {
      this.lifecycle.classification = "prototype_level_2"; // Verified Prototype
    } else {
      this.lifecycle.classification = "prototype_level_1"; // Has unknown claims/updates
    }
  }

  public generateAuditReport(): AuditOutput {
    return {
      status: "prototype",
      verification_level: this.lifecycle.classification,
      findings: [
        "prototype system only",
        "no production validation",
        "no certification claims"
      ],
      claims: [...this.claims],
      updates: [...this.updates]
    };
  }
}

export const globalLugmEngine = new LUGMEngine();
