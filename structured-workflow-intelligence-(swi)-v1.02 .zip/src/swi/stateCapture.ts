import { SWIInput } from "./types";
import { LogicalClock } from "../../swi-core/kernel/LogicalClock";

export interface GlobalStateSnapshot {
    timestamp: number;
    logicalTick: number;
    cekDriftVector: {
        userBehavior: string;
        environment: string;
        policyMismatch: boolean;
        driftScore?: number;
    };
    policyState: any;
    inputParameters: any;
}

export const StateRegistry: GlobalStateSnapshot[] = [];

export function captureGlobalState(input: SWIInput, policyState: any = "SWI_VF_1.01"): GlobalStateSnapshot {
    const snapshot: GlobalStateSnapshot = {
        timestamp: Date.now(),
        logicalTick: LogicalClock.getCurrentTick(),
        cekDriftVector: {
            userBehavior: input.context?.userBehavior || "normal",
            environment: input.context?.environment || "secure",
            policyMismatch: input.context?.policyMismatch || false,
            driftScore: input.context?.driftScore
        },
        policyState,
        inputParameters: JSON.parse(JSON.stringify(input)) // deep copy
    };
    StateRegistry.push(snapshot);
    return snapshot;
}
