export interface ReplayPackage {
  contextHash: string;
  policyHash: string;
  evidenceHash: string;
  decisionHash: string;
}

export class GovernanceReplayEngine {
  public verifyReplay(replayPackage: ReplayPackage, storedDecisionHash: string): boolean {
    return replayPackage.decisionHash === storedDecisionHash;
  }
}
