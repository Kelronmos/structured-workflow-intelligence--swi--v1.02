export interface DriftObservation {
  expected: string;
  observed: string;
  driftValue: number;
  trend: "stable" | "rising" | "critical";
}

export class NominalDriftObservatory {
  public observe(expectedState: string, observedState: string, semanticDistance: number): DriftObservation {
    let trend: "stable" | "rising" | "critical" = "stable";
    if (semanticDistance > 0.8) trend = "critical";
    else if (semanticDistance > 0.4) trend = "rising";

    return {
      expected: expectedState,
      observed: observedState,
      driftValue: semanticDistance,
      trend
    };
  }
}
