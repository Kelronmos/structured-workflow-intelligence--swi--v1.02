export interface AuthorityRecord {
  authorityId: string;
  scope: string[];
  issuedAt: number;
  expiresAt: number;
  issuer: string;
  trustLevel: number;
}

export enum AuthorityStatus {
  VERIFIED = "Authority Verified",
  LIMITED = "Authority Limited",
  EXPIRED = "Authority Expired",
  REVOKED = "Authority Revoked"
}

export class AuthorityRegistryFramwork {
  private registry: Map<string, AuthorityRecord> = new Map();

  public register(record: AuthorityRecord) {
    this.registry.set(record.authorityId, record);
  }

  public verify(authorityId: string, requiredScope: string, currentTime: number): AuthorityStatus {
    const record = this.registry.get(authorityId);
    if (!record) return AuthorityStatus.REVOKED;

    if (currentTime > record.expiresAt) return AuthorityStatus.EXPIRED;
    
    if (!record.scope.includes(requiredScope) && !record.scope.includes("*")) {
      return AuthorityStatus.LIMITED;
    }

    return AuthorityStatus.VERIFIED;
  }
}
