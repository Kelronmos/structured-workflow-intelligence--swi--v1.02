export interface ExplainableDecision {
  decision: "ADMISSIBLE" | "REVIEW_REQUIRED" | "INADMISSIBLE";
  reason: string[];
}

export class GovernanceExplainabilityLayer {
  public explain(driftScore: number, policyTriggers: string[], evidenceConfidence: number): ExplainableDecision {
    const reasons: string[] = [];
    let decision: "ADMISSIBLE" | "REVIEW_REQUIRED" | "INADMISSIBLE" = "ADMISSIBLE";

    if (driftScore > 0.8) {
      reasons.push("Drift exceeded threshold");
      decision = "REVIEW_REQUIRED";
    }
    if (policyTriggers.length > 0) {
      reasons.push(`Policy ${policyTriggers.join(', ')} triggered`);
      decision = "REVIEW_REQUIRED";
    }
    if (evidenceConfidence < 0.75) {
      reasons.push("Evidence confidence below 0.75");
      decision = "REVIEW_REQUIRED";
    }
    
    if (driftScore > 0.95 || evidenceConfidence < 0.3) {
        decision = "INADMISSIBLE";
    }

    if (reasons.length === 0) {
        reasons.push("All governance indicators nominal");
    }

    return { decision, reason: reasons };
  }
}
