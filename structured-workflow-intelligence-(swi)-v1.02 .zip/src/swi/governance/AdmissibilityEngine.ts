export enum AdmissibilityState {
  ADMISSIBLE = "Admissible",
  CONDITIONALLY_ADMISSIBLE = "Conditionally Admissible",
  REQUIRES_REVIEW = "Requires Review",
  INADMISSIBLE = "Inadmissible"
}

export class AdmissibilityEngine {
  public evaluate(contextIntegrity: number, policyAlignment: number, trustScore: number, driftScore: number): AdmissibilityState {
    if (contextIntegrity < 0.5 || driftScore > 0.9) return AdmissibilityState.INADMISSIBLE;
    if (policyAlignment < 0.8 || trustScore < 0.7) return AdmissibilityState.REQUIRES_REVIEW;
    if (driftScore > 0.5) return AdmissibilityState.CONDITIONALLY_ADMISSIBLE;
    
    return AdmissibilityState.ADMISSIBLE;
  }
}
