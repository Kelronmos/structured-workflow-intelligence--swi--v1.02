import { createHash } from 'crypto';

export interface GovernanceDecisionInput {
  inputHash: string;
  policyVersion: string;
  evidenceHash: string;
}

export interface GovernanceAuditRecord {
  inputHash: string;
  policyVersion: string;
  evidenceHash: string;
  decisionHash: string;
  decisionState: string;
}

export class DeterministicGovernanceEngine {
  public evaluate(input: GovernanceDecisionInput, decisionState: string): GovernanceAuditRecord {
    const rawData = `${input.inputHash}|${input.policyVersion}|${input.evidenceHash}|${decisionState}`;
    const decisionHash = createHash('sha256').update(rawData).digest('hex');

    return {
      ...input,
      decisionState,
      decisionHash
    };
  }
}
