export interface TrustEvidence {
  sourceDomain: string;
  targetDomain: string;
  confidence: number;
  evidence: string[];
}

export class CrossDomainTrustEngine {
  public propagateTrust(sourceEvidence: TrustEvidence): TrustEvidence {
    // Trust should propagate. Authority should not automatically propagate.
    return {
      sourceDomain: sourceEvidence.sourceDomain,
      targetDomain: sourceEvidence.targetDomain,
      confidence: sourceEvidence.confidence * 0.9, // Slight degradation across domains without context
      evidence: [...sourceEvidence.evidence, "Cross-Domain Trust Evaluated"]
    };
  }
}
