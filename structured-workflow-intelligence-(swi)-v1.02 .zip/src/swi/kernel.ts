import { SWIInput, ExecutionKernelResult } from './types';

export class ExecutionKernel {
  evaluate(request: SWIInput): ExecutionKernelResult {
    const admissible = this.checkAdmissibility(request);
    const carryable = this.checkCarryability(request);
    const lawful = this.checkPersistence(request);

    return {
      admissible,
      carryable,
      lawful,
      status: (admissible && carryable && lawful) ? "ALLOW" : "REFUSE"
    };
  }

  private checkAdmissibility(request: SWIInput): boolean {
    // Basic rule: amount <= 1000
    return (request.amount || 0) <= 1000;
  }

  private checkCarryability(request: SWIInput): boolean {
    // Basic rule: function is not null
    return !!request.function;
  }

  private checkPersistence(request: SWIInput): boolean {
    // Basic rule: user verified
    return !!request.user_verified;
  }
}
