import { v4 as uuidv4 } from 'uuid';
import { createHash } from 'crypto';

export interface SFGMEnvelope {
  event_id?: string;
  action?: string;
  details?: {
    cost_owner?: string;
    rollback_owner?: string;
    rollback_plan?: string;
    [key: string]: unknown;
  };
}

export interface SFGMReceipt {
  event_id: string;
  timestamp: string;
  attempted_action: string;
  decision: "EXECUTE" | "REFUSE";
  reason_code: string;
  object_state: "PRESERVED_NOT_EXTRACTED" | "MODIFIED";
  state_hash: string;
}

export class SFGM_Kernel {
  state_stable: boolean;

  constructor() {
    this.state_stable = true;
  }

  validateAction(envelope: SFGMEnvelope): { decision: "EXECUTE" | "REFUSE"; reason: string; receipt: SFGMReceipt } {
    const requiredFields = ["cost_owner", "rollback_owner", "rollback_plan"];
    const presentedData = envelope.details || {};
    
    const missing = requiredFields.filter(f => !presentedData[f]);
    
    const decision = missing.length > 0 ? "REFUSE" : "EXECUTE";
    const reason = missing.length > 0 ? `MISSING_${missing.join('_').toUpperCase()}_BOUND` : "VALIDATED";
    
    const receipt = this.emitReceipt(envelope, decision, reason);
    
    return { decision, reason, receipt };
  }

  private emitReceipt(env: SFGMEnvelope, decision: "EXECUTE" | "REFUSE", reason: string): SFGMReceipt {
    const timestamp = new Date().toISOString();
    const stateHash = createHash('sha256').update(JSON.stringify(env)).digest('hex').substring(0, 16).toUpperCase();
    
    return {
      event_id: env.event_id || uuidv4(),
      timestamp,
      attempted_action: env.action || "UNKNOWN",
      decision,
      reason_code: reason,
      object_state: decision === "REFUSE" ? "PRESERVED_NOT_EXTRACTED" : "MODIFIED",
      state_hash: stateHash
    };
  }
}
