import { AdmissionLayer, AdmissionToken } from './AdmissionLayer';
import { ProtectedEffectGate, GateContext, GateDecision } from './ProtectedEffectGate';
import { ReceiptLayer, ProtectedReceipt } from './ReceiptLayer';
import { ConsequenceLedger, ProtectedConsequence } from './ConsequenceLedger';
import { ReplayGuard } from './ReplayGuard';
import { createHash } from 'crypto';
import { v4 as uuidv4 } from 'uuid';

export class ConsequenceBoundaryEngine {
  public admissionLayer = new AdmissionLayer();
  public effectGate = new ProtectedEffectGate();
  public receiptLayer = new ReceiptLayer();
  public ledger = new ConsequenceLedger();
  public replayGuard = new ReplayGuard();

  public attemptConsequence(
    token: AdmissionToken, 
    authorityChain: string[],
    consequenceType: string,
    statePayload: any
  ): ProtectedConsequence | null {
    const context: GateContext = {
      token,
      authorityIsValid: authorityChain.length > 0,
      replayGuard: this.replayGuard
    };

    const decision = this.effectGate.evaluate(context);

    if (decision === GateDecision.DENY) {
      console.warn(`[${new Date().toISOString().substring(0, 19)}Z]`, "ProtectedEffectGate blocked consequence formation.");
      return null;
    }

    // Mark nonce as used
    this.replayGuard.recordUsage(token);

    const executionHash = createHash('sha256').update(JSON.stringify(statePayload)).digest('hex');
    const consequenceHash = createHash('sha256').update(executionHash + token.boundarySignature).digest('hex');

    const receipt = this.receiptLayer.generateReceipt(
      token.proposalId,
      token.boundarySignature,
      authorityChain,
      executionHash,
      consequenceHash
    );

    const pcId = `PC-${uuidv4()}`;

    const consequence: ProtectedConsequence = {
      id: pcId,
      type: consequenceType,
      statePayload,
      receipt,
      status: "EXECUTED"
    };

    this.ledger.append(consequence);

    return consequence;
  }

  public rollbackConsequence(proposalId: string, consequenceId: string): void {
    this.replayGuard.invalidate(proposalId);
    this.ledger.updateStatus(consequenceId, "ROLLED_BACK");
  }
}
