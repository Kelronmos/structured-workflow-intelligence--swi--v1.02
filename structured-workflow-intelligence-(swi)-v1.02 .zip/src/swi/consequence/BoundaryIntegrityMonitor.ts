import { ConsequenceLedger, ProtectedConsequence } from './ConsequenceLedger';

export interface IntegrityReport {
  totalConsequences: number;
  validConsequences: number;
  invalidConsequences: number;
  coverageScore: number;
  gaps: IntegrityGap[];
}

export interface IntegrityGap {
  consequenceId: string;
  type: string; // e.g. "AUTHORITY GAP", "ADMISSION GAP", "RECEIPT GAP", "REPLAY GAP"
}

export class BoundaryIntegrityMonitor {
  private ledger: ConsequenceLedger;

  constructor(ledger: ConsequenceLedger) {
    this.ledger = ledger;
  }

  public detectGaps(): IntegrityReport {
    const consequences = this.ledger.getLedger();
    const gaps: IntegrityGap[] = [];

    for (const c of consequences) {
      if (!c.receipt) {
        gaps.push({ consequenceId: c.id, type: "RECEIPT GAP" });
        continue;
      }
      if (!c.receipt.admissionId) {
        gaps.push({ consequenceId: c.id, type: "ADMISSION GAP" });
        continue;
      }
      if (!c.receipt.authorityChain || c.receipt.authorityChain.length === 0) {
        gaps.push({ consequenceId: c.id, type: "AUTHORITY GAP" });
        continue;
      }
      // If a consequence is rolled back but generates trust, that would be a ROLLBACK GAP.
      // (This logic would be more sophisticated in reality).
    }

    const validCount = consequences.length - gaps.length;
    const coverageScore = consequences.length === 0 ? 1 : validCount / consequences.length;

    return {
      totalConsequences: consequences.length,
      validConsequences: validCount,
      invalidConsequences: gaps.length,
      coverageScore,
      gaps
    };
  }
}
