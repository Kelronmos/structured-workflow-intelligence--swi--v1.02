import { createHash } from 'crypto';

export interface AdmissionToken {
  proposalId: string;
  authorityHash: string;
  admissibilityHash: string;
  boundarySignature: string;
  timestamp: number;
  expiry: number;
  stateHash: string;
}

export class AdmissionLayer {
  public generateToken(
    proposalId: string,
    authorityHash: string,
    admissibilityHash: string,
    stateHash: string,
    signerPrivateKey: string // Mocked representation for signature
  ): AdmissionToken {
    const timestamp = Date.now();
    const expiry = timestamp + 1000 * 60 * 5; // 5 minute validity
    
    const payload = `${proposalId}:${authorityHash}:${admissibilityHash}:${stateHash}:${timestamp}:${expiry}`;
    const boundarySignature = createHash('sha256').update(payload + signerPrivateKey).digest('hex');

    return {
      proposalId,
      authorityHash,
      admissibilityHash,
      boundarySignature,
      timestamp,
      expiry,
      stateHash
    };
  }

  public verifyToken(token: AdmissionToken): boolean {
    if (!token) return false;
    if (Date.now() > token.expiry) return false;
    
    // In a real system we would verify the signature against the boundary's public key
    return !!token.boundarySignature;
  }
}
