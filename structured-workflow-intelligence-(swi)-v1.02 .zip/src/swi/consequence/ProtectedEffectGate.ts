import { AdmissionToken } from './AdmissionLayer';
import { ReplayGuard } from './ReplayGuard';

export interface GateContext {
  token: AdmissionToken;
  authorityIsValid: boolean;
  replayGuard: ReplayGuard;
}

export enum GateDecision {
  ALLOW = "ALLOW",
  DENY = "DENY"
}

export class ProtectedEffectGate {
  public evaluate(context: GateContext): GateDecision {
    // CB-01 No consequence without admission
    if (!context.token) return GateDecision.DENY;
    
    // CB-02 No consequence without authority
    if (!context.authorityIsValid) return GateDecision.DENY;
    
    // expiry and basic validation
    if (Date.now() > context.token.expiry) return GateDecision.DENY;

    // CB-05 No consequence through replay
    if (context.replayGuard.isReplay(context.token)) return GateDecision.DENY;

    // CB-04 No consequence after rejection / CB-06 Rollback reuse
    if (context.replayGuard.isInvalidated(context.token.proposalId)) return GateDecision.DENY;

    return GateDecision.ALLOW;
  }
}
