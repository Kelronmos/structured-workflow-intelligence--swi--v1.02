import { AdmissionToken } from './AdmissionLayer';

export class ReplayGuard {
  private usedNonces: Set<string> = new Set();
  private invalidatedProposals: Set<string> = new Set();

  public isReplay(token: AdmissionToken): boolean {
    const signature = token.boundarySignature;
    if (this.usedNonces.has(signature)) {
      return true; // Replay detected
    }
    return false;
  }

  public recordUsage(token: AdmissionToken): void {
    this.usedNonces.add(token.boundarySignature);
  }

  public invalidate(proposalId: string): void {
    this.invalidatedProposals.add(proposalId);
  }

  public isInvalidated(proposalId: string): boolean {
    return this.invalidatedProposals.has(proposalId);
  }
}
