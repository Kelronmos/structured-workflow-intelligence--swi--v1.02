import { ProtectedReceipt } from './ReceiptLayer';

export interface ProtectedConsequence {
  id: string; // PC-UUID
  type: string; // state_change, resource_allocation, etc.
  statePayload: any;
  receipt: ProtectedReceipt;
  status: "ADMITTED" | "EXECUTED" | "ROLLED_BACK" | "INVALIDATED";
}

export class ConsequenceLedger {
  private ledger: ProtectedConsequence[] = [];

  public append(consequence: ProtectedConsequence): void {
    this.ledger.push(consequence);
  }

  public getLedger(): ProtectedConsequence[] {
    return this.ledger;
  }

  public updateStatus(id: string, status: ProtectedConsequence["status"]): void {
    const consequence = this.ledger.find(c => c.id === id);
    if (consequence) {
      consequence.status = status;
    }
  }

  public getConsequence(id: string): ProtectedConsequence | undefined {
    return this.ledger.find(c => c.id === id);
  }
}
