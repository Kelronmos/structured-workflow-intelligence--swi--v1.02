import crypto from 'crypto';
import { SWIInput, Continuation as IContinuation, ExecutionKernelResult } from './types';
import { v4 as uuidv4 } from 'uuid';

export class Continuation implements IContinuation {
  id: string;
  intent: string;
  allowed: boolean;
  constraints: {
    max_amount: number;
    function: string;
  };
  timestamp: number;
  kernel_result: ExecutionKernelResult;
  request: SWIInput;
  meta?: {
    challenged?: boolean;
    requires_human?: boolean;
    standingResolution?: string;
    concerns?: string[];
  };

  private static SECRET = (import.meta as any).env?.VITE_SWI_CONTINUATION_SECRET || process.env.SWI_CONTINUATION_SECRET || "DEV_CONTINUATION_KEY";

  constructor(request: SWIInput, kernelResult: ExecutionKernelResult) {
    this.id = uuidv4();
    this.intent = request.action;
    this.allowed = kernelResult.status === 'ALLOW';
    this.constraints = {
      max_amount: request.amount || 0,
      function: request.function || 'unknown',
    };
    this.timestamp = Date.now() / 1000;
    this.kernel_result = kernelResult;
    this.request = request;
  }

  sign(): string {
    const payload = JSON.stringify({
      id: this.id,
      intent: this.intent,
      allowed: this.allowed,
      constraints: this.constraints,
      timestamp: this.timestamp,
      kernel_result: this.kernel_result,
      request: this.request,
      meta: this.meta
    }, Object.keys(this).sort());
    
    return crypto.createHash('sha256').update(payload + Continuation.SECRET).digest('hex');
  }

  static verify(continuation: IContinuation, signature: string): boolean {
    const payload = JSON.stringify({
      id: continuation.id,
      intent: continuation.intent,
      allowed: continuation.allowed,
      constraints: continuation.constraints,
      timestamp: continuation.timestamp,
      kernel_result: continuation.kernel_result,
      request: continuation.request,
      meta: continuation.meta
    }, Object.keys(continuation).sort());
    
    const calculated = crypto.createHash('sha256').update(payload + Continuation.SECRET).digest('hex');
    return calculated === signature;
  }
}

export function admissibilityToContinuation(swiInput: SWIInput, kernelResult: ExecutionKernelResult): Continuation | null {
  if (kernelResult.status !== "ALLOW") {
    return null;
  }

  return new Continuation(swiInput, kernelResult);
}
