import { executeSovereignAction, AHMR_Package } from './governance';

const testScenarios = [
    {
        id: "TC-001-SEEDER-BYPASS",
        actor: "SYSTEM_SEEDER",
        corridor: "FINANCIAL",
        action: "LEDGER_EXTRACTION",
        ahmr: null, // Attempting bypass
        expected: "HALT"
    },
    {
        id: "TC-002-LEGAL-GATE-PASS",
        actor: "KELETSO_RONALD",
        corridor: "FINANCIAL",
        action: "ESCROW_RELEASE",
        ahmr: {
            attestation_token: "AHMR_LEGAL_9921_X",
            legal_signer_id: "SNYDER_VERIFIER_01",
            dual_signoff: true
        },
        expected: "EXECUTION_COMPLETED"
    },
    {
        id: "TC-003-INVALID-TOKEN",
        actor: "KELETSO_RONALD",
        corridor: "FINANCIAL",
        action: "FUNDS_TRANSFER",
        ahmr: {
            attestation_token: "INVALID_PROX_TOKEN",
            legal_signer_id: "UNKNOWN",
            dual_signoff: false
        },
        expected: "HALT"
    }
];

const runAdmissibilityAudit = () => {
    console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, "--- STARTING SWI ADMISSIBILITY AUDIT ---");
    
    testScenarios.forEach(scenario => {
        const result = executeSovereignAction(scenario, scenario.ahmr as AHMR_Package);
        
        const statusMatch = result.status === scenario.expected ? "✅ PASS" : "❌ FAIL";
        
        console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `[${scenario.id}] Result: ${result.status} | Expected: ${scenario.expected} | ${statusMatch}`);
        
        if (result.status === "HALT") {
            console.log(`[${new Date().toISOString().substring(0, 19)}Z]`, `   └─ Reason: ${result.reason} (Drift: ${result.drift_impact})`);
        }
    });
};

runAdmissibilityAudit();
