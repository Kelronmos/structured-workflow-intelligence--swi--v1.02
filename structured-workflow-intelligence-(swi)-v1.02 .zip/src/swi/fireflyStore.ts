import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

import { Trace } from './types';

const FIREFLY_DIR = path.join(process.cwd(), 'firefly');

if (!fs.existsSync(FIREFLY_DIR)) {
  fs.mkdirSync(FIREFLY_DIR, { recursive: true });
}

export function hash(data: unknown) {
  return crypto.createHash('sha256')
    .update(JSON.stringify(data))
    .digest('hex');
}

export function storeFragment(name: string, data: unknown) {
  const fragment = {
    data,
    hash: hash(data),
    timestamp: Date.now()
  };

  const filePath = path.join(FIREFLY_DIR, `${name}_${fragment.hash}.json`);
  fs.writeFileSync(filePath, JSON.stringify(fragment, null, 2));

  return fragment;
}

export function buildFireflyArtifact(result: Trace) {
  const f1 = storeFragment("token_action", {
    tokenValid: result.tokenValid,
    action: result.action
  });

  const f2 = storeFragment("drift_context", result.drift);

  const f3 = storeFragment("decision", {
    decision: result.decision,
    reason: result.reason
  });

  // 🔗 Merkle root
  const rootHash = hash([f1.hash, f2.hash, f3.hash]);

  const index = {
    rootHash,
    fragments: [
      { name: "token_action", hash: f1.hash },
      { name: "drift_context", hash: f2.hash },
      { name: "decision", hash: f3.hash }
    ],
    createdAt: Date.now()
  };

  const indexPath = path.join(FIREFLY_DIR, `index_${rootHash}.json`);
  fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));

  return index;
}

export function reconstructReport(index: { rootHash: string; fragments: { name: string; hash: string }[] }) {
  const fragments = index.fragments.map((f: { name: string; hash: string }) => {
    const filePath = path.join(FIREFLY_DIR, `${f.name}_${f.hash}.json`);
    if (!fs.existsSync(filePath)) {
      throw new Error(`Fragment missing: ${f.name} (${f.hash})`);
    }
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  });

  const recalculatedRoot = hash(fragments.map(f => f.hash));

  if (recalculatedRoot !== index.rootHash) {
    throw new Error("Integrity violation detected during reconstruction");
  }

  return {
    data: fragments.map(f => f.data),
    rootHash: index.rootHash
  };
}
