export function wellInGuard(result: unknown) {
  const r = result as { drift?: { score?: number } };
  const driftScore = r.drift?.score || 0;
  if (driftScore > 0.7) {
    return {
      override: true,
      decision: "REFUSE",
      reason: "Well-In: Unsafe continuation state"
    };
  }

  return { override: false };
}
