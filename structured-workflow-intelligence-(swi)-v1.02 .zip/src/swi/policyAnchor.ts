/**
 * External Policy Anchor (Non-SWI Source)
 * This simulates a policy defined by an external regulatory body or a separate security layer.
 */

export interface PolicyConstraint {
  maxRiskValue: number;
  minCountdownForReboot: number;
  requiredSignatureAlgorithm: string;
  allowedActions?: string[];
  restrictedContexts?: string[];
}

export interface ExternalPolicy {
  id: string;
  name: string;
  description: string;
  constraints: PolicyConstraint;
  version: string;
  updatedAt: string;
  isCustom?: boolean;
}

export interface PolicyHistoryEntry {
  version: string;
  updatedAt: string;
  changes: string;
  policy: ExternalPolicy;
}

export const POLICY_DRIFT_LIMIT = 0.7; // immutable external rule

let currentPolicy: ExternalPolicy = {
  id: "REG-2026-ALPHA",
  name: "Global Execution Boundary Standard",
  description: "Mandatory risk constraints for autonomous runtime environments.",
  constraints: {
    maxRiskValue: 50,
    minCountdownForReboot: 10,
    requiredSignatureAlgorithm: "sha256",
    allowedActions: ["read", "write", "execute", "admin_override"],
    restrictedContexts: ["compromised", "unstable"]
  },
  version: "1.4.2",
  updatedAt: "2026-03-01T00:00:00Z"
};

const policyHistory: PolicyHistoryEntry[] = [
  {
    version: "1.4.2",
    updatedAt: "2026-03-01T00:00:00Z",
    changes: "Initial baseline for 2026 standards.",
    policy: { ...currentPolicy }
  }
];

export const getExternalPolicy = () => currentPolicy;
export const getPolicyHistory = () => policyHistory;

export const updateExternalPolicy = (newPolicy: Partial<ExternalPolicy>, changeLog: string) => {
  const updatedPolicy: ExternalPolicy = {
    ...currentPolicy,
    ...newPolicy,
    version: incrementVersion(currentPolicy.version),
    updatedAt: new Date().toISOString()
  };
  
  currentPolicy = updatedPolicy;
  policyHistory.push({
    version: updatedPolicy.version,
    updatedAt: updatedPolicy.updatedAt,
    changes: changeLog,
    policy: { ...updatedPolicy }
  });
  
  return updatedPolicy;
};

function incrementVersion(version: string): string {
  if (!version) return "1.0.0";
  const parts = version.split('.').map(Number);
  if (parts.length < 3) return "1.0.0";
  parts[2] += 1;
  return parts.join('.');
}

export function validateAgainstExternalPolicy(state: { value: number; drift?: { score: number } }, action?: string, context?: { environment: string }): { valid: boolean; reason?: string } {
  const policy = getExternalPolicy();
  
  // 1. Value Check
  if (Math.abs(state.value) > policy.constraints.maxRiskValue) {
    return { 
      valid: false, 
      reason: `External Policy Violation: Value ${state.value} exceeds regulatory limit of ${policy.constraints.maxRiskValue}` 
    };
  }

  // 2. Action Check
  if (action && policy.constraints.allowedActions && !policy.constraints.allowedActions.includes(action)) {
    return {
      valid: false,
      reason: `External Policy Violation: Action '${action}' is not permitted by current policy.`
    };
  }

  // 3. Context Check
  if (context && policy.constraints.restrictedContexts && policy.constraints.restrictedContexts.includes(context.environment)) {
    return {
      valid: false,
      reason: `External Policy Violation: Execution restricted in '${context.environment}' environment.`
    };
  }

  // 4. Drift Check (Internal but anchored)
  if (state.drift && state.drift.score > POLICY_DRIFT_LIMIT) {
    return {
      valid: false,
      reason: `External Policy Violation: Drift score ${state.drift.score.toFixed(4)} exceeds immutable limit of ${POLICY_DRIFT_LIMIT}.`
    };
  }

  return { valid: true };
}
