import { buildFireflyArtifact } from './fireflyStore';
import { signRoot, verifyRoot } from './swiCA';

import { Trace } from '../types';

export function generateProof(result: Trace) {
  const artifact = buildFireflyArtifact(result);
  const signature = signRoot(artifact.rootHash);

  return {
    artifactId: `PROOF-${artifact.rootHash.substring(0, 8)}`,
    rootHash: artifact.rootHash,
    signature,
    fragments: artifact.fragments.map(f => f.hash),
    timestamp: artifact.createdAt,
    verified: verifyRoot(artifact.rootHash, signature),
    decision: result.decision,
    reason: result.reason,
    action: result.action,
    context: result.context || { userBehavior: "N/A", environment: "N/A", policyMismatch: false, driftScore: 0 },
    drift: result.drift || { score: 0, degraded: false },
    driftScore: result.drift?.score || 0,
    driftReport: result.drift?.report,
    scenario: result.scenario,
    scenarioId: result.scenarioId,
    tokenValid: result.tokenValid,
    locallyValid: result.locallyValid,
    metadata: result.metadata
  };
}
