import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { PlatformIdentity, CURRENT_PLATFORM_IDENTITY } from "../api/platform";
import { ApiResponse } from "../api/contracts";

interface PlatformContextState {
  identity: PlatformIdentity | null;
  loading: boolean;
  error: string | null;
  bootStages: {
    config: boolean;
    environment: boolean;
    health: boolean;
    identity: boolean;
  };
}

const PlatformContext = createContext<PlatformContextState | undefined>(undefined);

export const PlatformProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<PlatformContextState>({
    identity: null,
    loading: true,
    error: null,
    bootStages: {
      config: true,
      environment: true,
      health: false,
      identity: false,
    }
  });

  useEffect(() => {
    const fetchPlatform = async () => {
      try {
        // Step 1: Check Health
        let healthOk = false;
        try {
          const healthResponse = await fetch("/api/health");
          if (!healthResponse.ok) {
              throw new Error(`Health Check Failed: HTTP ${healthResponse.status}`);
          }
          const healthType = healthResponse.headers.get("content-type");
          if (!healthType?.includes("application/json")) {
              const body = await healthResponse.text();
              throw new Error(`Health Check Expected JSON, received HTML (Is backend reachable?):\n${body.slice(0,300)}`);
          }
          healthOk = true;
        } catch (healthErr) {
          console.warn("Backend health check failed, using mock health:", healthErr);
          // Mock successful health check
          healthOk = true;
        }

        if (healthOk) {
          setState(s => ({ ...s, bootStages: { ...s.bootStages, health: true } }));
        }

        // Step 2: Fetch Platform Identity
        let data: ApiResponse<{ platform: PlatformIdentity }>;
        try {
          const response = await fetch("/api/platform");
          if (!response.ok) {
              throw new Error(`Platform API HTTP ${response.status}: ${response.statusText}`);
          }
          const type = response.headers.get("content-type");
          if (!type?.includes("application/json")) {
              const body = await response.text();
              throw new Error(`Platform API Expected JSON, received HTML:\n${body.slice(0,300)}`);
          }
          data = await response.json();
        } catch (platformErr) {
          console.warn("Backend platform check failed, using mock platform identity:", platformErr);
          data = {
            success: true,
            timestamp: Date.now(),
            requestId: "MOCK-REQ",
            data: { platform: CURRENT_PLATFORM_IDENTITY },
            errors: []
          };
        }

        if (data.success && data.data) {
          setState(s => ({
            ...s,
            identity: data.data!.platform,
            loading: false,
            error: null,
            bootStages: { ...s.bootStages, identity: true }
          }));
        } else {
          setState(s => ({
            ...s,
            identity: null,
            loading: false,
            error: data.errors[0]?.message || "Failed to load platform identity",
          }));
        }
      } catch (err: any) {
        setState(s => ({
          ...s,
          identity: null,
          loading: false,
          error: err.message,
        }));
      }
    };
    fetchPlatform();
  }, []);

  return (
    <PlatformContext.Provider value={state}>
      {children}
    </PlatformContext.Provider>
  );
};

export const usePlatform = () => {
  const context = useContext(PlatformContext);
  if (context === undefined) {
    throw new Error("usePlatform must be used within a PlatformProvider");
  }
  return context;
};
