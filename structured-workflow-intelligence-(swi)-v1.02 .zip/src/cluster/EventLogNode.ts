type Event = {
  id: string;
  data: any;
  hash: string;
};

export class EventLogNode {
  private log: Event[] = [];
  private peers: EventLogNode[] = [];

  connect(peer: EventLogNode) {
    this.peers.push(peer);
  }

  append(event: Event) {
    this.log.push(event);
    this.replicate(event);
  }

  private replicate(event: Event) {
    for (const peer of this.peers) {
      peer.receive(event);
    }
  }

  receive(event: Event) {
    if (!this.log.find((e) => e.hash === event.hash)) {
      this.log.push(event);
    }
  }

  getLog() {
    return this.log;
  }
}
