import { SWIModuleContract } from "../kernel/SWIModuleContract";

export class SecurityBoundary {
  static validate(module: SWIModuleContract) {
    if (module.executionMode === "SIMULATED") {
      throw new Error(
        `SIMULATED MODULE BLOCKED IN TRUST LAYER: ${module.name}`,
      );
    }
  }
}
