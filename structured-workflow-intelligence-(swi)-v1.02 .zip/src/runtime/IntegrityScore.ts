export function computeIntegrityScore(metrics: {
  deterministicFailures: number;
  zkFailures: number;
  pbftFaults: number;
}) {
  return Math.max(
    0,
    1 -
      (metrics.deterministicFailures * 0.4 +
        metrics.zkFailures * 0.3 +
        metrics.pbftFaults * 0.3),
  );
}
