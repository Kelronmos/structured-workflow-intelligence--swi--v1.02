import { SWIModuleContract } from "../kernel/SWIModuleContract";
import { SecurityBoundary } from "./SecurityBoundary";
import CryptoJS from "crypto-js";

export function enforceDeterminism(input: any, expectedHash: string) {
  const recomputed = CryptoJS.SHA256(JSON.stringify(input)).toString(
    CryptoJS.enc.Hex,
  );

  if (recomputed !== expectedHash) {
    throw new Error(
      "DETERMINISM VIOLATION: Sub-system state transition does not match expected hash.",
    );
  }
}

export class ExecutionGraph {
  private modules: SWIModuleContract[] = [];

  register(module: SWIModuleContract, enforceBoundary: boolean = true) {
    if (!module.execute) {
      throw new Error("Invalid SWI module contract violation.");
    }

    if (enforceBoundary) {
      SecurityBoundary.validate(module);
    }

    this.modules.push(module);
  }

  async run(input: any) {
    let state = input;

    for (const module of this.modules) {
      state = await module.execute(state);
    }

    return state;
  }
}
