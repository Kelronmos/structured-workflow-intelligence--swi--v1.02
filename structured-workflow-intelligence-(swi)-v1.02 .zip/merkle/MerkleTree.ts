import crypto from "crypto";

export class MerkleTree {
  leaves: string[];

  constructor(leaves: string[]) {
    this.leaves = leaves;
  }

  hash(data: string) {
    return crypto.createHash("sha256").update(data).digest("hex");
  }

  getRoot() {
    let nodes = this.leaves.map(l => this.hash(l));

    while (nodes.length > 1) {
      const temp = [];
      for (let i = 0; i < nodes.length; i += 2) {
        temp.push(this.hash(nodes[i] + (nodes[i+1] || "")));
      }
      nodes = temp;
    }

    return nodes[0];
  }
}
